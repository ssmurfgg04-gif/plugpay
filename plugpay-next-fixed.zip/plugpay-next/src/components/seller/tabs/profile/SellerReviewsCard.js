import { replaceRoute } from "../../../../lib/router.js";
import { usePlugPay } from "../../../../store/context.js";
import { h } from "../../../common/h.js";
import { Ic } from "../../../common/ui.js";

/* ---- Dashboard tab ---- */
export function SellerReviewsCard() {
  var pp = usePlugPay();
  var st = pp.sellerStats;
  return h("div", { className: "tp-card", style: { padding: 14 } },
    h("div", { className: "tp-section-title" }, "Buyer reviews"),
    h("div", { className: "review-summary-row" },
      h("strong", null, st.avg.toFixed(1)),
      h("span", null, "\u2605"),
      h("span", null, st.reviewCount + " reviews")),
    h("button", { type: "button", className: "pp-btn secondary", onClick: function () { replaceRoute("/seller/reviews"); } }, Ic("star", 14), "View reviews"));
}
