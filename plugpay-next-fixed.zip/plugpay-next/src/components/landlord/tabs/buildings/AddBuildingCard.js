import { usePlugPay } from "../../../../store/context.js";
import { PR, h } from "../../../common/h.js";

export function AddBuildingCard() {
  var pp = usePlugPay();
  var _n = PR.useState(""), name = _n[0], setName = _n[1];
  var _s = PR.useState(""), street = _s[0], setStreet = _s[1];
  var _t = PR.useState(""), stalls = _t[0], setStalls = _t[1];
  return h("section", { className: "app-card", style: { marginTop: 14 } },
    h("div", { className: "app-card-title" }, "Add another building"),
    h("div", { className: "app-card-sub" }, "Each building you add gets its own landlord account, separate from the others."),
    h("div", { className: "app-form-grid", style: { marginTop: 10 } },
      h("label", { className: "pp-field" }, h("span", { className: "pp-label" }, "Building name"), h("input", { className: "pp-input", value: name, onChange: function (e) { setName(e.target.value); }, placeholder: "e.g. Kimathi House" })),
      h("label", { className: "pp-field" }, h("span", { className: "pp-label" }, "Street / area"), h("input", { className: "pp-input", value: street, onChange: function (e) { setStreet(e.target.value); }, placeholder: "e.g. Kimathi St" })),
      h("label", { className: "pp-field" }, h("span", { className: "pp-label" }, "Total stalls"), h("input", { className: "pp-input", type: "number", value: stalls, onChange: function (e) { setStalls(e.target.value); }, placeholder: "e.g. 40" }))),
    h("div", { className: "app-actions" }, h("button", { className: "pp-btn primary", onClick: function () { if (pp.llAddBuilding(name, street, stalls)) { setName(""); setStreet(""); setStalls(""); } } }, "Create building account")));
}
