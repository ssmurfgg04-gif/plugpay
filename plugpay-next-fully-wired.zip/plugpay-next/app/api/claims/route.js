import { adminDb, requireUser, json, body, getSellerForUser, cleanPhone } from '../../../src/server/supabase.js';

export async function GET(request) {
  const a = await requireUser(request);
  if (a.error) return a.error;
  const db = adminDb();
  const seller = await getSellerForUser(a.user.id);
  const sid = seller?.id || '00000000-0000-0000-0000-000000000000';
  const r = await db.from('claims').select('*, buildings(id,name,address), stalls(id,stall_number,floors(label,floor_number)), sellers(id,business_name,owner_name,phone)').or(`agent_id.eq.${a.user.id},seller_id.eq.${sid}`).order('created_at',{ascending:false});
  return r.error ? json({error:r.error.message},500) : json({claims:r.data||[]});
}

export async function POST(request) {
  const a = await requireUser(request);
  if (a.error) return a.error;
  const x = await body(request);
  if (!x.phone || !x.buildingId || !x.stallId) return json({error:'Building, stall and phone are required'},400);
  const db = adminDb();

  let sellerId = x.sellerId || null;
  if (!sellerId && (x.businessName || x.ownerName)) {
    const seller = await db.from('sellers').insert({
      business_name: String(x.businessName || 'New seller').trim(),
      owner_name: String(x.ownerName || 'Seller').trim(),
      phone: cleanPhone(x.phone),
      category: x.category || null,
    }).select('*').single();
    if (!seller.error && seller.data) sellerId = seller.data.id;
  }

  const token='clm_'+crypto.randomUUID().replaceAll('-','');
  const r=await db.from('claims').insert({token,seller_id:sellerId,stall_id:x.stallId,agent_id:a.user.id,building_id:x.buildingId,phone:cleanPhone(x.phone),expires_at:new Date(Date.now()+7*86400000).toISOString()}).select('*').single();
  return r.error ? json({error:r.error.message},400) : json({claim:r.data},201);
}
