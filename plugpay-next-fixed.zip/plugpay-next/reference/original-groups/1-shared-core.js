/* FILE MAP (search for the banner text):
       1. SHARED CORE
       2. LANDING PAGE
       3. PUBLIC VIEW (public seller profile and its tabs)
       4. SEARCH
       5. BUILDING (modal and view)
       6. SELLER PORTAL (auth, dashboard, catalogue, profile, building, reviews, sales)
       7. AGENT ONBOARDING (gate and all stages)
       8. AGENT PORTAL (buildings, claims)
       9. LANDLORD PORTAL (auth, dashboard, buildings, sellers, stalls)
       10. QUICK ACTION
       11. APP ENTRY
     Each group below holds its own components, data, store section, modals, pages and routes. */

  /* ============================================================================
     SHARED CORE
     ============================================================================ */

  /* ---- React handles and rendering primitives ---- */
  var import_client = __toESM(require_client());
  var import_react2 = __toESM(require_react());
  var import_react = __toESM(require_react());
  var import_jsx_runtime = __toESM(require_jsx_runtime());
  var import_react3 = __toESM(require_react());
  var import_react4 = __toESM(require_react());
  var import_react6 = __toESM(require_react());
  var import_reactX = __toESM(require_react());
  var PR = import_reactX;
  var __ce = PR.createElement;
  var h = function (type, props) {
    var a = Array.prototype.slice.call(arguments);
    if (typeof type === "string") { for (var i = 2; i < a.length; i++) { var c = a[i]; if (typeof c === "string") { var f = window.__ppFixChildren(c, type); if (f !== c) a[i] = h.apply(null, [PR.Fragment, null].concat(f)); } } }
    return __ce.apply(PR, a);
  };

  /* ---- Router and navigation ---- */
  var PP_ROUTES = [["/", "home"]];
  function navigate(path) { window.location.hash = path; }
  function goBack() { if (window.history.length > 1) window.history.back(); else navigate("/"); }
  function useHashRoute() {
    var _s = PR.useState(function () {
      var r = window.location.hash.replace(/^#/, "");
      return r || "/";
    });
    var route = _s[0], setRoute = _s[1];
    PR.useEffect(function () {
      function onHash() {
        var r = window.location.hash.replace(/^#/, "");
        setRoute(r || "/");
      }
      window.addEventListener("hashchange", onHash);
      return function () { window.removeEventListener("hashchange", onHash); };
    }, []);
    return route;
  }
  function Link(props) {
    var rest = {};
    for (var k in props) { if (k !== "to" && k !== "children") rest[k] = props[k]; }
    rest.href = "#" + props.to;
    return h("a", rest, props.children);
  }
  var PP_CONFIG = { nav: {
    landlord: [["dashboard", "Dashboard", "/landlord/dashboard"], ["buildings", "Buildings", "/landlord/buildings"], ["sellers", "Sellers", "/landlord/sellers"], ["stalls", "Stalls", "/landlord/stalls"]],
    agent: [["buildings", "Buildings", "/agent/buildings"], ["claims", "Claims", "/agent/claims"]]
  } };
  function parseRoute(route) {
    if (route === "") route = "/";
    for (var i = 0; i < PP_ROUTES.length; i++) {
      var r = PP_ROUTES[i], m = typeof r[0] === "string" ? (route === r[0] ? [] : null) : route.match(r[0]);
      if (m) { var out = { page: r[1] }; if (r[2]) out[r[2]] = decodeURIComponent(m[1]); return out; }
    }
    return { page: "home" };
  }
  function GlobalModals() { return h(Slot, { name: "modals" }); }
  function RouteSwitch() {
    var route = useHashRoute();
    var parsed = parseRoute(route);
    var pp = usePlugPay();
    PR.useEffect(function () {
      ["modal-merchant", "modal-building", "modal-quick", "modal-receipt", "modal-record-sale", "modal-register", "modal-landlord", "modal-admit-seller", "modal-onboard", "modal-stall"].forEach(function (id) { pp.closeModal(id); });
    }, [route]);
    var content;
    if (parsed.page === "home") {
      content = h(LandingPage, null);
      return h(PR.Fragment, null, content, h(GlobalModals, null));
    }
    var render = PP_registry.pages[parsed.page];
    content = render ? render(parsed) : h(LandingPage, null);
    return h(PR.Fragment, null, content, h(GlobalModals, null));
  }

  /* ---- Slot and page registry (how each group plugs itself in) ---- */
  var PP_registry = { slots: {}, pages: {},
    register: function (slot, id, comp, order) {
      var l = (this.slots[slot] || []).filter(function (x) { return x.id !== id; });
      l.push({ id: id, comp: comp, order: order == null ? 100 : order });
      l.sort(function (a, b) { return a.order - b.order; });
      this.slots[slot] = l;
    },
    registerPage: function (name, render) { this.pages[name] = render; },
    list: function (slot) { return this.slots[slot] || []; } };
  class SlotBoundary extends PR.Component {
    constructor(p) { super(p); this.state = { err: null }; }
    static getDerivedStateFromError(e) { return { err: e }; }
    componentDidCatch(e) { console.error("[slot:" + this.props.id + "]", e); }
    render() { return this.state.err ? null : this.props.children; }
  }
  function Slot(props) {
    return h(PR.Fragment, null, PP_registry.list(props.name).map(function (x) { return h(SlotBoundary, { key: x.id, id: x.id }, h(x.comp, props.props || null)); }));
  }

  /* ---- Shared helpers ---- */
  function initials(name) {
    return name.split(" ").map((w) => w[0]).filter(Boolean).join("").slice(0, 2).toUpperCase();
  }
  function floorLabel(floorKey) {
    return floorKey === "G" ? "Ground" : `Floor ${floorKey}`;
  }
  function appBase() { try { return window.location.href.split("#")[0]; } catch (e) { return ""; } }
  function codeOf(c) { return String(c || "").replace("#", ""); }
  function digitsOnly(p) { return String(p || "").replace(/\D/g, ""); }
  function sameNumber(a, b) { var x = digitsOnly(a).slice(-9), y = digitsOnly(b).slice(-9); return !!x && x === y; }
  function relTime(iso) {
    var d = Date.now() - new Date(iso).getTime(), m = Math.floor(d / 60000);
    if (m < 1) return "just now";
    if (m < 60) return m + "m ago";
    if (m < 1440) return Math.floor(m / 60) + "h ago";
    return new Date(iso).toLocaleDateString();
  }

  /* ---- Shared UI kit (shells, modals, skeletons, empty and error states, toast) ---- */
  function Modal({
    id,
    onExit,
    innerClassName = "modal",
    closeButtonStyle,
    hideCloseButton = false,
    children
  }) {
    const { isOpen, closeModal, openModals } = usePlugPay();
    const open = isOpen(id);
    const stackIndex = openModals.indexOf(id);
    const zIndex = 1e3 + (stackIndex >= 0 ? stackIndex : 0);
    (0, import_react4.useEffect)(() => {
      if (!open) return;
      const onKey = (e) => {
        if (e.key === "Escape") handleClose();
      };
      document.addEventListener("keydown", onKey);
      document.body.style.overflow = "hidden";
      return () => {
        document.removeEventListener("keydown", onKey);
        document.body.style.overflow = "";
      };
    }, [open]);
    function handleClose() {
      closeModal(id);
      if (onExit) onExit();
    }
    return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      "div",
      {
        className: `modal-overlay${open ? " on" : ""}`,
        id,
        style: { zIndex },
        onClick: (e) => {
          if (e.target === e.currentTarget) handleClose();
        },
        children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: innerClassName, children: [
          !hideCloseButton && (0, import_jsx_runtime.jsxs)("div", { className: "modal-bar", children: [
            (0, import_jsx_runtime.jsx)("button", { className: "modal-back", style: closeButtonStyle, onClick: handleClose, "aria-label": "Back", children: "\u2190" }),
            (0, import_jsx_runtime.jsx)("button", { className: "modal-close", style: closeButtonStyle, onClick: handleClose, "aria-label": "Close", children: "\u2715" })
          ] }),
          children
        ] })
      }
    );
  }
  var LOGO_DATA_URI = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAaoAAABZCAYAAABv/mD1AAA6r0lEQVR42u19d4BV1bX+t9Y+55aZYRiadA2IUiyxpZiXxEcSE5PnM01QwRp98rPHTkAdR2JLrFGTSCxReolR85KnLy8ajEmMsUQFpImAwFCH6XPvOXuv9fvj3KEo4MzcOwwznm/cAnPvOWef3b691l6FANCgU+9OldJggxy8ZEaxN2xEG9H6C6u6s/TteYJ9vf/vHCoqBB0H6n/yw+ke6R5cqBvW6gdu7fyrMwAUMWIUGOUoZ/SvTMH23z5mS7j+Y8fahhZM4xKUaD3qCQDQt/V1K+ES/VQl5O+odFMx1QGQuMdi7HHxHTZ+Wqmv/o8A+SKgQbRkNo9lAoE+OrB1x8K6p9FF9OHrBK1ekIkUIEukjQo0iEo9AVsYvJ7UbrCqlWGW1qz87dmb2ruhhp10f9L07HObIRynqjbvhgd8FfprWO1uX/HcWbXxUIxRaNww4NrhKfHKQRgIqIUSZKcpSIBGU5K2T00C9OMYg5SUQKpQ2v1c3zsEAEiEFJZg6gnaKHB1INpEgvWOdKMnZl2QbVxTUXN/ddyTMTyvQXwqkqPZT31RXdjqGxhQi7/Z9lWdQABYo/mg6iBqmphoayqt748aN+N1wPwtDDJ/Wz7/3HXt0VANXsr0AB/Dxv+ySt48BTI+XJhpTJQkvHgYxmiXXaiYUmX9Nx/+gU4FYKAlg43buV7c/H+KtsIR+UW/deyUFA3KutmkUstvSV/3Glu8nE6F/7h67b1Vca9+QomKvZRCA1GxUHGdZQqCmNNEPAjEg6DyJXX2It/z1o0cN/NpCOaS895cPG9sUNjniitcOxGA/CWzGDH2TAhOVckJOQiksyiYyZApIaISAxoicF93njbW2+T7U/pdP1vV/63baN6tQEWsKvxEjeVOCQVUoeKgLoyIg02SjDeUyFwF6O/Vsw8cMW7OEXEXx4jRuSAQOHWwaqEKMFGRIT6M2UxRCp73+mduuWPgdYPiloqJqhNyl0BVAHVgY3qxMRdatb8dNX72hIPOeTwVd3WMGJ1xS9r8IxAVeOwNJPDkwNFvbut3w7eaz8lixETV+Qa3ClQEbLyDoXpfUZj86YiznugVd3eMGJ1c2lKBQuGR91kHN31K3+snlqM8EbdMTFSddy8mDkRIEehist5dw095ulvc5TFidH44OBChBxFP8QdkfzQXY0zcKjFRdWLpSgECE/G5XFx/67EnP1wUd3uMGF1iKwomNhCatKTf0MvjFomJqrOzVWTiTnxBQ7eic+NujxGja0AgIKIEEV9b0f+6E+MWiYmqk5OVgNikCeby4eOmx9aAMWJ0IbIyxP0ZPLl8UHnPuEViourkXOXAbIYz+PJRo+ID2BgxugqcWjD4BN+Gp8etERNV5ycrCAj0n/bIISPi7o8Ro6uAIjN2cj+ceOBFPeL2iImqdcOHGMRm74UYIAKwD1wiojBMfZmSY+LujxEjn8WjJT+U+9lHG1GlA4uzPb8e907XQnvHmRMV+UAJ2Y+QRRS/j1RhCEgrtBTEaWaPI8ddRXvFfCEiGMLXR506597F80+L44fFiNF6SrAObjUUbvfyDREIPoAiVXRjopQhJsmFvNV2mNsKhWGTVJXvA5gT91FMVC0cOMjC6Q9J/TccO955GAOAupDE+EwalvgJ9BKVwU7c5wz4RCUcTGBSlfaoF1RliBh3JIA/x8MgRozWSVJO3WZOmlM1S9s8tR8RmOoRUtKw5wTdPGd6K7khjvAFJZzIhP6UU9UVvm6AVR02ecBVg29df88HcW/FRNUS2UWEsXbp7LFrWnHREyPHTT9Ilc9luIuITN/Ck5UCqmXMiZExUcWI0Sa4EA2rKja0Kg3Hw7cccN0RynQpgc4koqJCk5VTgUKGJK05GkBMVF1mc9S+6gHiNuT3eHfmmauXHLJ0ikIni8g2ogJXUwEi8sF6UDwEYsRo0yYU2TDd6rl906afvFPlBT+0sPcpxLbH6RWRKVOST+V7nzFj5prx5X8oLS8vb/MCdOcpd3a7+9S7Y5P5/VuiygMVFfJuefnjI5cdOlhFbowsLgq1+1IQe1Bx/XJkHacM+ATiyBOfLM729PuQkV4s1F2YioxK0jpA4ZzHXsaS1psgsU2Fq5Z4bisKnjrmk4d7197bVD6qvIK2BYcoUFCjJoXCJx9ZoHdeJFU+N7HZJS5yoZy10Tt+3n9M/O+pv7/j5G2tucetX77xSzXvb7pOyHQv/8qtl1a8MPntttTlykFXpnuKf7RKooxQGPWSglhBm/sNHPSvCa9PCAvV/vfjsmR935IvODJpheS1YAuEmMR52vTG/p20r6JCaMwTj6nnncnEB6sWUk1AIOZu/U9+OFX53xMaO8skH/Hdaf0p7R9WkMEqQgw4ByxZOnvc+jYt9mc+eYCFd7hYGGLOu4OUhaBu4ZIZZ1W2R/sN/e6TB6RT5mio+YwlPcZADoWgj0KLWeAJwbBRQI0C6gw0S35QB0LlKNASOX3mG6r0atIP33p7+tkNe17p5prDEu5LklfGUAAqREySgV24cnr7Z7LeZ1N7cUVwS+/rb4dHJzGhW6FPq4gkmc/1tUhdmglQ0dSoJQljj04n3FGn3PD0zc/++DtLP+7aJ69+vnj5P145p25D9WRTzwN8CNTWPHDff9x5wQ9/f/3y1tbl+LXHB8sGvDUWRi4T1ZAKs2P3CLRk09o1pwB4v1Dt3jiw57+J2pmA68l7MLRpKZgoQfDeAUpO3++zyy6ed86akeNmPg/g4sLeWaAqvUpLTFkl0GmIiktSX4TYh1TUR54DllgZoEbAXANgZlvuETpzHDFNJZYSqOS521NiB0Pi/RcKabU1ZowZ6X1nKJE5VSHfF5VhzNqdjAdIFI2bclnZt6uioj/8XFDj7kQ8CKDPsAvOVJItofj/Gn7G7CcyieTvVz/x3eoPP/LYHqlkU1P2EbiwV34SO7GKZlPkXQjg2a4kWTk/tdRo5j0FHVXoewuhdAzGmHmY1+rF8huT5p9bU+NubqhqKAlr6pBJptj2LjtdPDPi5Nuevfi/J53y9z1d+2D5gyWr/++ft2Q3NF7qNRqfFCABtFq+XL++7udPnv/gRWc/eumK1tRnLMa6W82Pfi/CZ3rk9dICKYAIdLgzelghicpBvsXEfTVK3+zncy9DBqry0qT1U5Z0CodfgfyzPSyEIFqkXrdkZ5rcCklB0ZPYlBFzj/yK1x2qPaG27W1gXIIoulcB6lMG43cDULCoIQef9tjgkYnv3aigP4LoNmZzLLHXXYEo6aY6YBd3iA8V1VzaGAuVEGAmZq8PM59oSJ4oDpqeGnnG7G+h/MVdNn1hYzWpak8mU8bEPdtc2JQB0sux7VTjtCW4ufLmJla8wO1wVE5K/qg2SLPfuv6pM+vq9a76LQ3dbFUtWASSaUDNxg2o3RYcVVeLR0659elRu7v2D/f/Idnw0rYpjZX1l5km9iMfMoGyAk5gt2a/tvbtTXc9OOYn/Vpbr8kf3P5/pPqXnTN05fsDAojou4Vq89sGTOwl6o4l4vzrBoJTu0Vhfwt0ksgUhriqsGq/TgzKZZFTQWGKRurqNpM9q6pq4eojICpMZ48YP+3rSZOaQ8ANzHwQ1EXZoFXaLoxuJy6X2/SZ0SD35MjllROPvfDZol27Ck5zCT3zKQRynhrpekOZ1LBZytg/ch9+46rZ36hrktsba8NeQW0NlBQuVzUOLBorN6OuGqPq6vzbzrv/pT4fvn7Vi4t/0FTZcEmyiTwfChOlbQATwEzQEGjaFHy7anXTHdMum1baanWDml+KukyhDFBEFYA7ZdIhkwYWZBOt/ggCDS+ElTYRANCiLZR5pdMQlTrXm6nAg5kIYK5LWNeIGF0KB53zeGrk6U9ezsozif3joTDQ9lnnVRyYTC8CptTX1Tw2Yvy0/oV/iAL5qfv3S5SjnEN1R0j7OPZngFG2pV8++eJZX21qwM/rqu2gprpGwBg4YyBMIGIwGbBTNGyuQkNGvlW5pXYXI5CfnfOzEZtWbL7CqyffKOApwRCD4YHUgNQAYHDowW6256x+Y8VdD4+5o3trXqhP5aAXBHi1cBF8FAB6phr5qwVR+7E9zmOvvxRANalQZdXH7117b1PnISoyX0ChiUoJRLylrjJbEy/tXQejxsxNFGX9H8F4t4O9Xioh2ivCyQ4eEYAIHidOg9LPR4yf1t8enAoL/Iwul3K9vm99WoHR0g5GtwSpq0BFi278H1fO+Gx1ED5Y1yhDM02Z6MSSfbDxwOwBxAAxmAmUrUN9dZ1fF7jxp/5swZCob9QLKjOXmYw/nIUBQiRJKcEgIqyItACGwg8UtrLpB1s/aJw458o56Za+0wRMCD3wLwhasF0LwzAL/Ue+97n9wNt7qNDJhdh0EAgiWKkif9hRz/0cw8dPG07Qrxde8yeAc/WrF5yXiZf3rgPx3JVgmsjgIsg+lEI00sga9r9jhO9OrTC9AHJxj+wZZc47lkFD2mdzS9mWfO+ky3995NZt2YfqAzMiCASGDQx7MBTFIGU2YOOBDAGGAM9DWN+IhsbwC1XVdf8GAE/dPGdEWNP0VZOJtkRMuQiH0RlQTv1HMGTAuW2Tl00YuyW8YvU/F1338IUPt9zoQNyfFPibocIkNCYiCOmx5f1/lFeQ7jBo6EeE4wqh9vPIgBXPTN5w++ZOQVRDL5zbncRcS8SDUWDTdBUHNbw2Xi66kDR12qxxRLiJyCRUO+BIRzU6uzLeGRnN3qgqiUJIcwrAEXepQ9rygdcNIp9vZ+KCZtwmEAINACcbPu6737zgiUO3VbkHG23yOGc1p1CjnQjKBxkfxD7YJEEmAfVSgBpoAKRC92UAWPa3pUPChsah0flqdH30p/lIiaSraOWlrJfObrI/anx/02VzdW6LmGfyhts3K+m8KGZi/kJ2dB8ZytCT8hPN5HjDXJav0RuDEYrd5tjO3fX3+ykOHPfzHqm68AYmnBn1hxZyNAOqGXF2Vby8dxGSGj9tFBiTmLkI2rF2ByoOCrmQ1JUVasA6Z7pMX03uN/kgY/k+hX6h0Go/AgGqmxhmrybgp074xcDaJn0o64q/JM6AlcBsIgmIGcyRuk/ZKHkGMB7AHpgNPDagUFFbkykCgNo125KuwbEx0efMvBNh7ShMFN0fDKMMJgBZStZXNlVUfvP981W1RcxjxT0virdNASL2KBQJThCIjy3PK0cfnQrNnziZGCD9Y5HttXAXKau9B6UT1/KROGauGZHIHmCsd6xTvQJEo0EwKLDej0BQ4irP2oXxEt8FSGrM3ASRuxzGHKZi94s6EZmCjVsC1KP9zexVkfRTLVZtlqM84ZXV99ekNxqwVxvmwxWFj6LOxHDgVWkT/GtP3znlB48M2NDo/aJRE19zFLnPOnggUgBmu5zC0QaZBJrLQpSTuZyAwWiyVi9U9cuOqRjsQmdECZTb+xPRx26uGRLJEHVeSe3qhjt++pWf1qMF/owV6+9YNmXg5N+KuiMLEdxXICDgeLPFDQfwTmuvv2XAtcMBPT7fehAIgYSOgOev3Xhtwz4kKiXf8IFHjJu/1Wp2ly2hsDCyYcIgmVbf9FbGp9jZw1T4GGE9whhTvCPdR3tMM1qSbmxcFC/znR+apKMh+n2i/ciCu9Djdn877SIyfhAOvW3QxFqrjnbdnHoGLkwkPa9Ylfpap0OJGo8U8o9hwkgm9qSdpF6BwCN+65r192zZ7V74woe7r69ztzZq6j8de6AcCSnlvHd2MtpqVgWaiApUKeIyNQwhhp97BY+SDGMBu7M6jravNHuD0cjYPNnk9XBbm2576KT76y557orffbxUJbMN84UG1D9fgnDq4LF3sBg9vi1E5cQf7Rnqlq/Wi4nhxL3t2P3vhz9rV6IiaEpB91vNfORgk4UJnp9QUp/g0qQoJuMxEUGb/V3abQ1xSmSefr0ThU6KsQchfMxcs9CFP4Dxere7NNW8iOnHL0BdGdEOXPs4uPnOQj98gsBQBnsJCyQImmaDIoMEKSlUFe1FUgSCqDYwY9buPj9hzIMlH9RkbmvS9FmWIwLa9Wrsor3aceIQ5c5rTu0qUS49pFh5KlF485E3rWWBpilBzaSxw++T9lJf3qGAE4Wp9Q6qpboHHv7OQ7UTnr5kwV6lqsrbl9wy8Ib5AC4rVOsJu5MeP6j8yfNWV7TKwMxn/iITG5enMaJVByZ+rnzd7Ws/Kn22K5iIzUA23tBdCntDmc0QNv5AZu8AsOkGYo4IyrabFBX1B0OVVoVN7vfxMt/5sdAPBhHJ96DtRVIEYg/RBkqcioZQlebs1J9ckGdghnhkhn608KcM8QCj3JtAxQQiBwdRaZccVDvrSVT1nWYn0Z1x2TJJbjnioFs3U/LijBrj1MGKg4hAsCNJK+mO8tGq5mQsJhAcihJYAQDFBxbVJkq8DDQyyKCcZNaysuO7qgquoYNq1tT88uHvP/SFj3tbY8wvnbraQjgAO3Vg0Je2qNcqP8Dy/leNAOlxhdhkQLVGye42dFq7G1NEXvwfKh/yvEc7qvh2N9AAmr38iGWr4mW+CyyXxP+uoF6FX/+iw3AFNqraaU71KoF3tmOcCfLOh5MKsfZFAFkiA4A+cW2vkD3+6PY/tZ3JaZc+UwP6abOT6I41SOnFv71x1eY+gy+uHnowatlBXABnMwhdAOcsRAQqip0j4CgAoeZCOwqAlAdbkix+AwBGHDVsRbKoaLkxXhSTnBVE2gqyyhWOAs+gBiNq19Q98MTpjxy9t7ftvWbAcih+YwqSBklB4N6ZIPP11lzlmfTxCgwthJRswP9307o73+oQotqvFjU2UHH/9MPwV6ioiFN7dIXFkvjbRIYKPFAAIOPUPaY28bXFgXfekpnj7l0687SZy2aMm7t45thfL5p1xs3V9fUnq+r3xIV/BqkW3Ck9RssXTDJQ0t9WafD8hz/79K//eeb6wL9mS7K7Vzf4QDQMHoA6Ww8JG0C2CRpmIWEAZwOIC6HORRvoXQi2WcQiJIxBkrK/OXzEgQsA4OQp31/ZvV/pczZtI0Mt3cl/ivdSiEHYUVhz/laioGocU7W26lePnPnzw/f0zhMwISS4x0Jx2wohVSkExHRGOU5o0ZHQGIwxpPQZj3w/n81IrmWdqE7do27uk7PzNlAb1pLwfW/PP/v9eGp3fhwxbkYPEXsYFZQgCKrOOrVT6gPv0iVzv78Q88buVvle+d8TGt+dNf4P5BJnOJVHoZBPomTV4SQFA6ey0hB+cvfGu3exFjvm8dc+vyFMTKnhdE91AZzHCId8CvWD+6EuaICETYDNQm0AdVmIC+FcCLEW6hzgJKfsIbAqmBi+NG5OafbRivOOro7WFnKJofzzdFlyYRTNIgq5RNxSSYq2m7RHjsGEhFWYze7YupV19846d9bgPb17tdg3CfhTIRyAI2toHWn6fml4S75/5IBDB6ji2HyjuRswVPUtVnnzk01URBBxIoSf9dnQb248tbsGQqHjWLVPIdXGxAxSfmTp+hU/WTv/tKaWXLN43tgNtSWlVyjc9IJno46xVzAYTl2jkNw6ad0d/9j5sxPnvDJkQ+g9tI1SB4lKlG8DFmHCRzhiOBoOHICaTC1s0AhxmjuaCCESQiSICEtCqAshzkKgIM2gR5E+ed5Xz3th52edefcFq/sOHXirlKGROBfVYhd5KVeUdxQwDBswojiAHhl4iD4zIJiA4G/Vr1UvX3Pv//zX7mNI3r3x7gY2NM+prc9XqspJRT2Nx19r4RZhOKBH5mtEwcQw6s3ZORLFJ46oiKg5GNsvaurqb1+wYLSNp3fh0JFW0wQ5GETFhToDoWhD876SfwcWVLRqnFROPaUxTemJIu4dxGS1j/qfICqBA8pvWn/H4zt/9vBr6i+v4UlV6h9jYWB2suoTEgSpNOTIo5AZPBi1jTUIMzWRVGUtxAa5v2ehNgu4AOoCGNuENAWP9RmG8rFjPxoea8y0cXO7farH7Zo2NaTRE3f+YTBMrni5koBBggwSYCTBSCkhBYIPQgKKVCBIVun3N6/edOfLj7zcbXftELB5FqKvcgGIyiPPg8o3rhx05cfFICSl8Jsee6n8SMrAilvJ7J7f+4akKw9kNgA0UOhDjY2pGypjc/QuxVSi1I+IE4U6qyeTAIGeefeQdz5oy/VvzPh+JdjcR4hT0rQ3DAxUpR4qNy7c8N69OTu97fjlon+eVYXUuMAkARI4SM40PjKYUBFkkynIkUchGNwfdfVbkM3UQCULEgt1djtRkQ1gbCOSrn56abLo2unX7j6zMxFJ2WE9f1I8sORhdCMl8C7WfQyFt1PxofBU4KsgpYqkAEkARSAUgZAGIUkEP0PAJnv6tr8s/+HunluxuiIDxhyXZ+p3IHI9sNAjyiR51N6+d22vO0tI6Wt5S1MAiOTv7/fbtPgTSVTEHlRcpQNfX11bP3H1Mx/Nwhqjky9WjGKiwpmIi80oKf0jH0MbtvJ3cbr4k2263r5SlCEDp24JgX5gN6bv+nAW36/O+tehG7P+Dxu9dBGJgNVFti5CoO1mfABsiDCdBo4+BtlBB6C6biuy9dvgbBOcBLASQlwAco1Iubq5RX72yv999LSqvdVvbMXY4FOfG3pn6adKfokiUV8UCRH4qkhAkYAgiea/K5IAUgBSICRZ4SNybk0SIa2EYjEoVka3auM3rqy96q8Tn/3M7p7rl4SzCPyvfNV/ogKPeZBH9Pm9fa/IrxmuwPB8tBkEglWpF/DTU1+fGn5CiIoA4oigQKG48DnnyfglM06/L5ak2ndv24HoEZ0JFSC1ABmo0gfWkxX53EdlyXtgeitW/7UHQTFU0WSdPMFiT7thwx3zdpfKY2tgv1endAScg1ELzwG+A4wAngDGKdgpyIWQIEQ2mQJ/+ii4vgegrr4WmZqtkGwDRAPAZZHSzJ96pxLXL5h1zZaW1PWkipOqBn5xyLUlfYtmJlKEhBKSwkgpI6mMJGhHUSClkcovIdHnzd9PCiMljCJhpByQWh+W1b+7dfzunnn90p/WWZLHC2F5GiUkMZ/7ad+fFu/pO0nD/8lEeWWd5uhYZlHaNv1PSySvzj+E2YvUfOIyKsFf4HB+Y6LojKVPnvliPMW7LoQppQUiBDIGZHhlWG/X5HOfxfMqAkoWvRcb/xWGnDzywGAopD4Q+Z1CT+2+sd+EyZvuenu3JPGHZaVVoTk9oz4oEMBGaeDVCmBdVJyArINaBTkLySqyRT1ARxwL2+sANDU0IFNbA25qREqaXi727UXPz7lyVWvq/o1rv9Ew5KgjrkkPLH46WZRAkhgJAAkw/FxJKCNFHlLKSOdKSjlHUkBSo7MqA8AnRplLQGuyJ751x4uDdrtlzOIPqrrM5Ll5tGohoqc08dbdpv4oHzUm4VS/la+1rSogiqev/ZCl5u7gdcrhSwByTpaiYaDilkDlHww8b1OZ/1362AV18TTv+usYqXLhQhkxoFztqlxt3hWTsC4K5/TxgUlj7ExLkZ8S5zYfolJvxb0jqq94qv9TuqnxpSvwwF7zTDVVbjyyod4bAvYAjWJOOFWQKqBRTL/oKCfyd4IKIAJxQFhahtQRRyIIG0CbtyDlGt8q6lN8yUtP3bW8LW80+q7RG/54/bNX1Mi6Ul7b+BXKRFEtoArWnJSoAKnCSC5CBaLTNpNrEdopppMnirA227vm3VUHAfhImKEbN9/63q0DJk8D6ZS89STGpK3oVwC8/pGZUjvseIEMZeW8eltUtgQW81ryfa/9VxPeoZprGc/u9P/mvymgLCB1KqgHsB5iVyhosWHzz2zGvlXau/6D16dOCOMJH6ON+ztARYFV+d8pk9kEpgyYU12ZpxjcZrcxzW2pc5QhCjiAt0GxzkGXi+o77PhVUn1HtiQ2Tm5htt6tWXeoCJdGGwXd4afbHAUHChLdbnYgyHW7AiwMW9oL3mGHgRf+c11Z2DjxH8/tXnJrKU6885Q1f7pg3uUNwcZHzLrM543bvjCCc1ESPc1tvnP/Njm/LdNMsLkWY1JkQ6SpgQ7YozQk7nkydIFH5qB8DB0ic36cPAZj7vnwGSAUxxNRz3zOp5gYgYTzvc2JFvm0titRqapTlT+BsQW6FzmRaIfPGAtISZThWDWrahoFYTWrrlHiNexhvTbxxsX1Gxrw3BXZeIHtaLiOEsxVSQqc/4XUT/fM+55K3AiFpS4qUUXRF6RRWf4A4QB7TETUvMxK83UKghDIKjRLQKNAtvpIvu/UrWPPreeEbl65clvjVExt06ZzfU1WmuBB2IFEmmVlqAiA5pBtO7pFmyWtSLCCY4WU9Uf3z/77upISWoqXp+bdXl99ZMyiu0+49W8lLvP5IdwDviiMy9WLckSVq5NB5O61XapS3b4X8MAIiUNNp/aoMSrfcMc/K/rf8JyyTsi7n5WOGTVg1BFYj39tv3//8iKW4Au+8RG2Ob4mIRSbNaS/ubGFG5D2XWGIskpcvmTG6a+gvLzlcmLFzYqCZ0vsIouEkBJhv0lO5DN5qkIdET6IlLKkhRwkhLCpNO8XUeLeBEl11eFLIAiwzWryoooNFVvLUd7iNrsZNzcvy+0CY4mEFSLNRBVFlmiOKRrF8lNAc6pGVahGOalEI8YKlbCN0p9d1ZT5yQl3vXjRgmtGb8mnThO+cM25Lyx865xe9R6SvYbhUFOGhIvkESUFi8JExuwRseaC4rLmTNtz0fpTygiLE/W9Rg7Y6zmqUXnECU5l5l5tlXoUCiIqYQ1OB3YQFSM4Wok+6/KI7eeRQaj6kkHpmy2+pt3VA82JE1tl8lsRM1IngYiWsWHTIUuyUk3hUs4TCDD9+xTR6nzJO1XSQ2yjp64r+5aT1ppIc1aBCm35zG7fuT04TUG2IdAATCQSKWuat3Xictvf5n8rWGl7SiHdrioUNIGwOTSnYkNVzUn3/+Gq5674VpvOLq858cff3bBywx1+Jtlrq23AK1vfR1nZwRhiukFEwSAYJXg5YopGYk6S0pyKEDmpigXpXiULB0784mpM2vMzb9hw22sVAyYtIND38lXPiegJD/YpL7l0c0V9bhN2pCHu29bMzARCqKES9JlJ6ydtbXFd9oF+JrZ/Kiw17FeCphD6KyTRIVVSqlN1KER8PVUHhQysAvrl3SZhtucnIeZfUrL73UsmyP3Dd+F6dgCsQAMHhA4UOpAVIHTQXKHQQUMLtQ4IbVQCm/u+RdYSqrLe+e+933D7hQ8/W9TaulR8545v1m+ouc/P+H27F5WiOFWCDWETXtq2ChulCUkYJF1kep4UQlKAtCOkHCHpCEkhpJ0i6YCkIwSljO6D+z1HzB975CFK94q6bH5zQkFEQ2qMHAtEaj+CfCmfaO1MDAaWWcWfWnVdvPB3to1sodUmBKa2m+8QURkKHb285ZS9WdW5gnCCWKi4QxMpNyyf2wwdM7e7s00j4oHaMfjGMclVKWufTYRNUGcBa0GhAwILCSw0tNvN1MU6iI2+o9aCQwcTWnhBVPxQIBaoyQQTXnxz0/VjyucmWlqPH4+9//NVq2vvRzUO9JWQ9JIoLSlDUXEp1kgGL1avxlYJkIKHtESElRRCQhQJ0dzfc8UxmA34oNJ/bDu4x6wWKsvegNL/5kMqAoEh7gsjJwJAKoEDGOYr+RhpOBWImpcqKm9fEhNVjFYIJcoQbZPj3rCT7k+CzEGFcrptPUvaVQStL4xEpTB+qlTc3j3yPw7ppDuMiT4DcfHg6gBUjB5te5rw0ZKwfpWxFghDaBhCbQgKA1AQbi8chjBhCBNm4dkAyTBAylqkw6ikwgAJl0HgyNSGZuI7mxuuLy9/8WOPS+4e//jnq1c1PM7V/iHFSKLYpJE0PhJeAiUlpSgu7Y5VmsGCutWo1gx8ZXjNzsiqMKrgKIsyIjN6Rf0Avyl5aO+fj7jmuBadl1VUVjQS8xNOJMgnWgUTQ0FfLB969QGhhP9umPu2XZ1IIEU1k3us1fWIh3YngwMKlkhLAWJOKDCgTYO4d78BBB3aYWoepjeFTHWh0nyos1DGt4edOqdPm25QXs4q+h3yvD6qcbqzjsLbt3znjW7UOCWZra4jcSAbgMMAxoZIhFHxwxCJMEAyCJC0FukwhO9C+C6AL2FUNISRKKlrlpKJ2pCvfapq5aV7e/Zdl8w6dMvamnu43huRIg9Jz0eKfaTZR9L4KOIESlMlKOpehmXUiBfqP8A2tvBpB51oLk0wa2RK78p88EHdnkqMHfJUa9ohJbyAiP7MeUhVVi1U9dNeJjVMHZ2YnxkXQSBv9+m35fWYqLo6CppMVkHkg0iHjRrTcrXGduWC4ssMPVy1Y6SHd2actZYUSwtlA6nqwETHekm5qC3XD1926ImqepG6WJrqSBCRnl209Ne9vOwDJZlaTViLhA2QDkMknUXSWaScRcI5+OKQcA5GBCwC2iX7OEV5b0EwKgg00a2qKTHliIsf+/bunjuj/Nnedcs2/pKq7PFJIfieD2N8GM+H5yWRMAn4XhK+SaI4WYRUWU8s9Jvwp2AttpgwZ+QfOfkaIfgK+Akf2YNL3y09fvgdfUcfXt+adrimsmILVJ5xam1bpSqFwme/zJD5NoGOd3loTgwxwHhiwuutdz2IiaqTgYktayHPqQRQ+pz4OKI1V406dU5PFTcO7CU60liewP+rBXSnUhWwuomjzpxxHsbMbXEsmkPGTv8yAVOJTUk8SjseFRUVcl5pqqKnZB8oDhs1YaPAsL4IfOfgOwdPBEYFlDMHp538q5r3/5H1HQEwEEcIkCipDXDLYZf98uAPP3PzWxtuxGY3OhUqPFKQ54E8AxgGGQNmD2wMPPaR5CSK/CKkupfhHdOEBeEGbGMHiuKJQwGEADYPwNb0MYMqek3+7MK2tEMj4xkoL+Y8tA6hWlh1l4PkU21V8TMYInZxkvzn2nZ9jE4FJxQoqGBbdhUHYm8IaXjmCS3QvwPAmDFzjfpyOYCvRhEAOg5BEP6PqjQU7IYKgExaHR4Y6YVThv9g5l7VosPGTysddcasSz2m2czmQMQqv/2IrMYGBxbVlJdQZobRECqac/xttkJXRO5VusdColAnUBeZi6sTZDRxZFMDzt/5WY+e9+tv1m2oG+8HHCVqJRNFmWADz/NgjAfP8+EZf/u/E5xAkVeMVGkPLPUt3nDVaGAHBiBEqB+YVO/wfncdcM9X5rS1DW5be9s6UsyUvDaTCiJK5eMsycRQld9f98HNlW253ouHcyeTqACnBLd9thWGrUBEEzYtW79l+CmP/Gzps3uOlThqzOP9Fvr2WqheTsymw12P66veox69XwTxyQUjCVUQm2IAEznjxo4cP+tpWPxFjawVodAABsy9mPRoUYwF0afJGB8Sk9T+hgX3X1n9xcsevWp1QwaNzj9T2AfERYFydM87dd2hb9j1lwo4UYTGP/PTl/766bcePPfVt2e83eOlma9c4mdMr4BCCJvt0hnlYvoxAUoMsIGKQFTgco7Iqh6kxMc7TRn4rh7HUTdICYUY2fNnetv378Os/Nog5GCGJ/6lxDSo7YYQefhjgWHFVnnMz7XV2Tsmqk4GUW0kaJZA3bRwTAUQpQEtN8VFxwwfO2MmMvT3TM3Sqt7DB7j16O93b9o2iMX/BoDTCPT53Izr8PZY8dwV2RHj5/yS4L5ORIVTQ6oAIGLig0HmamF7OSuqidBEBF8h3UFeEVMuLE/MUfstXn7g/M2Hn3/fNQ6pnhmhb4EUJLxD1Ue7T3X5kd+pzXEVIXRmsLrgiwBeXbxw8ahsXcNxNiOAYXDzGPxQZKnmfxEbkDJYBaIEUQEZD7YohTeCAFQUYsShB/wm8bneUw4eQpm8Jct1P1k7pf/kWUx8reuA82RDDIEueF82vZLHBj1GZ4K1dj0ElQXPd6QKAvtkvO8Zj6ZxMV4uGnDIXxvrixeU1dX+naz3ZyjdQ+T9GxRmf1qZfbV/I9E/Ehd639WcDdaCCD6x6cPGHEhk+hNRkYqNVElxoK/9Hgsf/eHGvsXexSnKvAzlKESlSC7IX66fP1Qgu5YdnwksMYJQjgKAtX9d3cvVZntH6ZVy134MiAjMJlINsgfPeIBJoL4shUUH+zNxwoCrD554Yk3BRrKET1hx62kfL/kUxfULnXPPT62c2ua8gDFRdTKYRHITgI3tE1svWpRBnGY2Q9j4xzB7xzP7RzKb/iB426NS70d4Z+b4bTDeg+rCrdSOCQtVBSoOqg77T7TFGC3Fmz+/YPWwnunLu3HwDtOuGRooVz660OpuCxTYVh8wVCkRUBlZmO1xBLE3sqLtRWEgzFAmqPFguqVR0r/4d30OO+CKkdd/fX0h391tTC8VwrMe7dtEp0QEkH6gLnwmn/vERNXJULz4uVohrGnX8xCVKKSQOKjk/q6yXy/Oi6ef9rxCpyHOWBhjL3jpnnPe7GXCC4uQXcJEO1J/bM9Z5bZvxEhl++93VwJrFfPm+Snf7+uBYZ2Fcw7OOYgIFB8yI9yJpACOokvCQNiDpHyYvt6fDhw54IoJ94zfUuj3rkCFNcC8UIPNvA+XfVWFqM6r2HzXhpioPkF4/fWpISneFnEWcRjFXeYEBd4UUXmu8CrAGF0Jbzxy8Ss9Eu6ChDatNLlEhtstAkVBIiBxucjqeyoCo0To00eSahpYESVglCgiu6hAxEJEIOJy0njuObpDkgMprKegPvxyn2G9L77wwdPeb6/3vnHdrS+o4IV9uWw4lQZP8GS+94mJqhOC2f6NDDbTftN9zbvEDpaq5p9WRdR4tXP2Xx1CVtEKYBVoQmxesV/jrUcv+muJZ67ypGldlClcAUiUwERkx/nVTkVzaUJIARKHnt0IGD3aZm1DJeAcROHERebszWSlDqIOTixEc0UsREI4EjhD4J60sOenyq647KEzlrX72gE3y4o07Yv5ysQg0hdKSurfi4nqE4jea1e8qYoF+4WWiwCFWFUX7A9ts3jG+YtJ8f/EBQvJ7FuyIvagkDlkin4N5nhu7edY9usLnynys5cYadqwI16lQuGioi6339hRos8ExiP0KS1eCgD9jhjUUFqabEqIQp2DE4G1FtZZhC7YqYRwuXNOiIBB8LtjSa9B3c676ldnvbEv3nly5R3PMvFf9omKQwWeJqZeseKBvBPcxpOpE2LBggrLor8WZzs2w3HkixJC8TCI3mtPQ4bW4N3Z4/4RqjtbXPDqviIrYgOR4Cl/s0wwXmId7eND6xhtw3u/vuqZYhNekwhq66EEEgXLjuSFO6v6mm0lRBQJDTepoZcBYPgxhy8q6V70VrdkEnCCrDqEYiOystGZlTqBU91+fmWMgVcmK3v1L5lw1bQLXtt3+0pSgf1Vez/HkIGA/pbNoiAEHBNVJ0V9IlgAovngjlkQo0CwagH8NJDsnejoEBUfworZ57xJLOMltL8BWKid2onYgxICiLuHUt5/vf3HsxtUNJ5XnQjvT79iRonnJvmuKUNqooy/gpxxRbOLQkRSJAxfHXzXNOOHx5e+BADDLzp6Xbp3tycTKc4k4SEUByu6Xc3nnIMVB3EWEEHK95HsyVt6Dyi68tK5F7y0r9+3h3Z7kYHX2t2oQuXPFVsrCmK9GE+oTorVT5yXYUe3wtmF+/w8hhiiEqjQrUHV5lv8hGkkpv1uLC2efvaK6vq6s0HyQxH3HrGHQhmgEDFABqLymgDjF4XedYsfPa0qHpmdE2cOr3moxAtuZK1rUjg4dRDV7VJUdISlIAqRpIalPbolHx47dux279nirw54sle/4j8dkE4iLQTA5s69orMvVQcjilKTQHF3r6rP0J6XTZh/8bMd8a6XrZ+0VRUPCaRdTg8MMZy6VUn1f1Ooe8ZE1YmxaM4Z7zqYSc6FG/YNWRGIDEikHorr6sL1d6547opsoPuvnqvyvyc0Lp4x7gGBfFedvQsq64kNmkvLDpUJII6uIQYRQ0UWQmQiBfz9pTPGzce8sTu5/Md2FJ0NFRUV0idY91ACwT0smZCUIDs5+UIVjBCeravukbAVr/3y4qU7Xz/6vNGZAw7tfXuvASUbBiWLkBSg2Z8qMqoQdOMEundP1pf1K5183vTzZnfk+wpl/wrFO4YKv26IAiR49frKioKdu8VE1cmxdNbpv4PYSyB2TfuSVbRAi9iFlt34d2eNv3/t/KubOk07zTzzncWzxl0Ldie4MLharf2TSrhe1QXEBmR8kEnk/vTB2//uIXK3cbVOguUibqYLgzMyGfvVxbPOuHPxvLFr4lHYNfDK/Hubjh855JZiYx8yyEDJAhKCIGAIkpqp7p5wV77z5PW7jb735QdP/Wv3A8sm9O5fsn5oqgxp9SBEYCh6UQq9y4oauh2QnnTuM+dP7eh3vWndT5cDPN+pgAooV0X30sAx5heyvrHDSRfAkjnnPHXo2OkbPRPeDva+BADbleqFGHpsoGIzIjot4/Fd708bv6sZbQOAFGtn2PYsnn72CgD3oFzvG7l01kglPVZtOESAvkRURuAUyJEKh0raCJEqIVrHbBYH7F5fOX38po9tMUNayNQjQsoKja0z9gHmVYwNRl1cfmO4ye9hKXGOqA8ShSdNy1JJf9K4QzK/rdjL9d98ctyzvzt7GuD0riFbzCGbgyZ44tCjR0rTfRM/Hfi54b8gov1C5DYIZzs1ZzHxMC1gtBkGFodNtc8XlKjEZogTCSb2C94QKi6hJF1JakuQKcw5BxkfCJ0nNlOQ7cyyuWf+9fDTZ45x6v6LFBeA+SBik3NmbB1pETNAHFk4qa1XF/4dwH2N64MXVi84b7dBMpXYsPFznv15NQzENrX/BqqC5F1gEaICQGnYST9LFPUOPKAvavyBbvWqP1ssqGi1kYg6JS3gLpWBSMRrdUWImY2J1DtSwPowBKEp7aJBDhf/vKJ+xHduuxomk3LOjTHGPOdRcN37syYuqmjB9f/55FnPPnP6zPc8v+6u9Bb6sqiF3y/9YOb4w+4cXTF6vzE6mrT+jmVT+k96g4iGFWxsEMOJm1FR9UBtQYnKZjhMpNzrNtuYBrSQvjAE5qwRW90VBm+xzThBt1c0yDhVzXuwURj4Cn5NpXvB2nzh7HEbAfx46Jgnnkz6/ulw8nVVDCfifmQSHlRzhnq5dQzNJzQEcE61ZwNR0c0KtxpE/xRL811N2d9XPPetPZrC9/BS2UYJ/uJCVwnA5bMEKpyBk3X7vodJVzyHLID8Tf6ZQQWLVRuF9xbnWi9RGa4WlQWBBIMUUsiw2UZAG21xKkQXxZKnJ2097LQp17LBI2m/4dVXZ1S0auH99uxxi14sf3FM1YuLR4YBXOnwgxedUTE6uz+9YznKU0phPyUtyGAlEJy4zb6h/yn47ARAJ5zweHJbwhRetdAXePvgs5pQQV3hdJkGfX5Oqme3bMEkxJoBzq1+4rws2inK67CTppV63fgQTiQOVXUjVHUokxsMcIkqPCiUGYFAa6BmHRFWkbr3rfAKk8qsXPzEeS2Mz6U06NS5qZ41hWibvng7SGSxoGU7z/4nP1zUI1U2wEt5tZuLttRXTp3QhA6OmnvYOU/dAZHrC+IDTQSIyzrI+KWzzv5NKxciRv/KVIl0K7hxVz3XaUUe0bBjdDymDJh8GgiPEqi4EKo/n3w45x4rqay++Ao8UFBSjoPFfYJwwgnl3uYD+qSCxFCW4nrCNoATJdpQ84GtTPfI7mq51jkw4owZxxPwGwIFCq0mompV3QpgHVQ3WZI1nuNVIsE2Z9KNXmAbm0ptE1Yhs/rfVwWoqCjsJurC1/zhdcuf8Dz/jEIQFRFDnFQpcPqS2eP+GI/iGIXAjwdNGihCc3z2/s3mryACgSDQBlV7Rvn6O39X6PrGxhSfICyIzlvqu9I7EWkZgfsTMQh0EKh59xWFxElAoCRgTTUYxRZN8tbi0N+q/bF11JJDq2Xs9K3K2MbgjeqZjYZl5aInT1+JNmYiHdW0sj8gQwsWaZ4IRLJRCBviERyjEJiLMWa5mEuItCAkBeQiUYh9Q5z9R3vUOSaqGJ0aCphcljtq/kUEt+t+j1FMoGIi7yAQgQzlLs59V1wgYpvU0dsjvvPb7y55GlvbUh9RHU6gT6NAgTqIPCjJGhNufT/u7Rj54kW86P2l/x+vJsiVhVKoEQhWQwH4dxUb797UHvWOiSpG5yYqp/XE5PY+ljX3354OjQkgThAoQcZ8CcXhyQCeaG1dBp06Jw2x/0XGSxXKdkHVgZiXLZp3aX3c2zFuGzCxlyNzKllemzGZFd2drL1m492N9DHnsuWjyku8GvvZl/F/5zP4NACmUCbpBIIoVrpMMKu93jsmqhidm6iYN4CQAbSk7TvEZgKL8gWR6o0jT5/52ruzxy1qzV26JeQSAGMKZmBHDOdsNTE9E/d0DADIhtb3fHO+Gj0qicR7gaHVt/a/Yf1typUhu21CrpaAJiPGWhXjMbozvMFaI0cL6DOGqIdooW3bFEx4+qaqn6yNiSpGjN0gZVJVoWQaQFRSkA2iKojNwYpw/shx02/WxqL/W/L09/asBhwz1wxhd3DCuMug+v92pIsoGFYXFRf/Pe7pGAAAV9yIRFjpk/8ZgYwg0AjNhWoyIBCMEFTAgBd54BsQyIBBiEI5FXyzqLpekf5Ze752TFQxOjVqPqitLRqQeBvEJxbMqVUcmP0RovIkpZteGzF+xvOseDe0upGgTWzYU6BUgcGs9jiQftOwf2BrHatbolRhop+/PvWU2Aw8RoQqZDCANigBbjfO9QzKees3yzq5WIPtFH/SI4NQgkduqrzxg5ioYsTYk7ix4LzMiPGz5zLRiVpAjlBxIFCCPP8LAH1BbJDxGfVKcARlJSRIqRv5CYa6KBleISmKPai4N2oDnh/3coxmVKAimEI3Vu5x3O5DF0JDBk50UZK96e39rJioYnR6SJN7mVO8nNgcUljCUKizOeLgFIFSuaCbO33eDomNiaBiswDfsXZ+nDokxkekpm3SwRH6c1EonKj+8ob1ty1v/3eOEaOTY9lT45fAmHm5QCvt85DtWV4dVKWAQX8/ugQw+1BgWlBV+mzcuzE+IskobRR1Qh0Yr4HBIPDzkvCn75vnxYjRBRBI9hci9hUynTvIOBkP4oK/sKNb9hZfMcYneKzDNQKa6UiSsmI/EJudWLG6ojomqhgxWogVM85a6xiTxYUbiTonWZExUBe8zRJcumjOGR/EvRpjd3DIrCHitR2RVJvBENUaEF9306afvLPvnhsjRhfBsunjXiCSSxW6ed9kPC4YRUXGE9a+GWTp3IWzz3077s0Ye4T1agFq2NeqP48MRKXWiV5/0/of79MMxTFRxehSWDzjrPmW5Gxn7fKWp5rvQIqKUtuLiJ3tEkXfW/GbcW/GvRhjb6hNZCtJde2+fKZHHkJ1y1Tk/Js33PrwvpfkYsToepLVcxD+nkj4LEgdsQH2J3UgRVmTwQYistaJXBGSm7D0ie+uinsvxsfh3rX3NhFoU7sOURAMGRgyUKDBqXscjr5z04bbO8RdIjZPj9ElsWTu6QuHXXb/WK+q37dYcAnUfob9ZKlK4X2eWkNQzD7EBqGSe0/JzMna8LGV885ZE/dYjNbAqjamyQMIEJWc/1R+XlQEAhHBwCAQmxWVdYboBSb91Vtrl70+D/M6LA1QnI8qRpfH8FMe6cYl6c8RaDSg31DBYWz8lEJB292imif5zoFrtfVTiZqnfERMqlHuQxUHVV2noBcM0R81NAsWzxsbE1SMNqG8//VfTJA/xpEOIaW+IO0N1d4CpInIM8REiGK10F6pKRr3Vp2QUjUBywD+O1Re15BevWnLj5fvD+8bE1WMT9L05qPO+1wva6sPslkdJZ4eY8DHQvRAQLuBOAEgQQQf0dlRxDLbp/SuE2cHsSmgkvOz0hCELBSNUKpSYBHIvcZG/+Wh+9LGLf762Ow8RqHW76v7Xl3Un0vSFigicumM2FIm9BA23dmhpyMtU7huPps0CaUAsEKdMJqgUq+KbUS0IVRU+mQ2ebBbJq2/owodnCU7JqoYMT6EYeOnlSaUhpLTA0IxBxgfPUGuG5RKEEWjSKiSr6QeSAnKygIHghVDWRJpAmk9lOpU7SYl2eh5yTWnDjn9/YoKkriFY8TID/8fuJNXnnxe/MQAAAAASUVORK5CYII=";
  function Toast() {
    const { toast } = usePlugPay();
    return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `toast${toast ? " on" : ""}`, id: "toast", children: toast });
  }
  function DashSignIn(props) {
    return h("div", { className: "app-card" },
      h("div", { className: "app-card-title" }, "Sign in required"),
      h("div", { className: "app-card-sub" }, props.msg),
      h("div", { className: "app-actions" }, h("button", { className: "pp-btn primary", onClick: props.onClick }, "Sign in"))
    );
  }
  /* Generic portal frame: header / body / dock / nav are slots. */
  function TopBar(p) {
    var back = h("button", { className: p.variant === "app" ? "modal-back pg-back" : "tp-navbar-btn", "aria-label": "Back", onClick: goBack }, "\u2190");
    var close = h("button", { className: "modal-close pg-x", "aria-label": "Close", onClick: goBack }, "\u2715");
    if (p.variant === "app") return h("header", { className: "app-topbar" }, h("div", { className: "app-topbar-inner" }, back, h(Link, { to: "/", className: "app-brand" }, h("img", { src: LOGO_DATA_URI, alt: "PlugPay" })), h("div", { className: "app-role" }, p.title), close));
    return h("div", { className: "tp-navbar-fixed" }, back, h("div", { className: "tp-navbar-title" }, p.title), h("div", { className: "sp-right" }, p.actions, close));
  }
  function PortalShell(p) {
    var kids = [h("div", { className: "sp-sticky" }, p.header), p.body, p.dock, p.nav];
    if (p.wrapClass) return h("div", { className: p.shellClass }, h.apply(null, ["div", { className: p.wrapClass }].concat(kids)));
    return h.apply(null, ["div", { className: p.shellClass }].concat(kids));
  }
  function AppShellX(props) {
    var role = props.role;
    return h(PortalShell, { shellClass: "app-shell", header: h(TopBar, { variant: "app", title: role + " portal" }),
      body: h("main", { className: "app-main" },
        h("div", { className: "app-heading" }, h("div", null, h("div", { className: "eyebrow" }, role + " workspace"), h("h1", null, props.title), props.subtitle && h("p", null, props.subtitle))),
        h(WithSkeleton, { kind: "list", dep: props.title }, props.children)),
      nav: h(PortalBottomNav, { items: PP_CONFIG.nav[role === "Agent" ? "agent" : "landlord"], active: props.active, role: role }) });
  }
  function PublicShellX(props) {
    var children = props.children, title = props.title, subtitle = props.subtitle;
    return h("div", { className: "public-inner-shell" },
      h("header", { className: "inner-public-header" },
        h("button", { className: "modal-back pg-back", "aria-label": "Back", onClick: goBack }, "\u2190"),
        h(Link, { to: "/", className: "inner-brand" }, h("img", { src: LOGO_DATA_URI, alt: "PlugPay" })),
        h("button", { className: "modal-close pg-x", "aria-label": "Close", onClick: goBack }, "\u2715")
      ),
      (title || subtitle) && h("div", { className: "inner-page-heading" },
        h("div", { className: "eyebrow" }, "PlugPay"),
        title && h("h1", null, title),
        subtitle && h("p", null, subtitle)
      ),
      children
    );
  }
  function Ic(name, size) {
    return h("span", { className: "pp-ic", style: size ? { width: size, height: size } : undefined, dangerouslySetInnerHTML: { __html: window.__ppIcon(name) } });
  }
  function useLoading(ms, dep) {
    var _s = PR.useState(true), loading = _s[0], setLoading = _s[1];
    PR.useEffect(function () { setLoading(true); var t = setTimeout(function () { setLoading(false); }, ms); return function () { clearTimeout(t); }; }, [dep]);
    return loading;
  }
  function Sk(props) { return h("div", { className: "sk " + (props.cls || ""), style: Object.assign({ width: props.w, height: props.h }, props.style || {}) }); }
  function SkeletonView(props) {
    var kind = props.kind || "list", i;
    if (kind === "dash") return h("div", { className: "sk-wrap", "aria-busy": "true", "aria-label": "Loading" },
      h(Sk, { w: "40%", h: 18 }), h("div", { style: { height: 10 } }),
      h("div", { className: "sk-card" }, h(Sk, { w: "30%", h: 12 }), h(Sk, { w: "60%", h: 30, style: { margin: "10px 0" } }), h(Sk, { w: "100%", h: 110 })),
      h("div", { className: "sk-card" }, [0, 1, 2].map(function (n) { return h("div", { key: n, style: { marginBottom: 12 } }, h(Sk, { w: "70%", h: 12 }), h(Sk, { w: "100%", h: 8, style: { marginTop: 8 } })); })));
    if (kind === "cards") return h("div", { className: "sk-wrap", "aria-busy": "true" }, h("div", { className: "sk-grid" }, [0, 1, 2, 3].map(function (n) { return h("div", { key: n, className: "sk-card" }, h(Sk, { w: "100%", h: 90 }), h(Sk, { w: "80%", h: 12, style: { marginTop: 10 } }), h(Sk, { w: "50%", h: 12 })); })));
    if (kind === "profile") return h("div", { "aria-busy": "true" }, h("div", { className: "sm-head" }, h("div", { className: "sm-top" }, h(Sk, { w: 62, h: 62, cls: "sk-circle", style: { background: "rgba(255,255,255,.35)" } }), h("div", { style: { flex: 1 } }, h(Sk, { w: "70%", h: 18, style: { background: "rgba(255,255,255,.35)" } }), h(Sk, { w: "50%", h: 12, style: { background: "rgba(255,255,255,.35)" } })))),
      h("div", { className: "sm-body" }, h(Sk, { w: "100%", h: 60 }), h("div", { style: { height: 14 } }), h("div", { className: "sk-row" }, [0, 1, 2].map(function (n) { return h(Sk, { key: n, w: 110, h: 110 }); })), h("div", { style: { height: 14 } }), h(Sk, { w: "100%", h: 44 }), h(Sk, { w: "100%", h: 44, style: { marginTop: 8 } })));
    return h("div", { className: "sk-wrap", "aria-busy": "true", "aria-label": "Loading" }, [0, 1, 2].map(function (n) {
      return h("div", { key: n, className: "sk-card" }, h("div", { className: "sk-row" }, h(Sk, { w: 40, h: 40, cls: "sk-circle" }), h("div", { style: { flex: 1 } }, h(Sk, { w: "60%", h: 13 }), h(Sk, { w: "40%", h: 11 })), h(Sk, { w: 60, h: 24 })));
    }));
  }
  function WithSkeleton(props) {
    var loading = useLoading(props.ms || 450, props.dep);
    return loading ? h(SkeletonView, { kind: props.kind }) : props.children;
  }
  function EmptyState(props) {
    var act = props.action;
    return h("div", { className: "es", role: "status" },
      h("div", { className: "es-ic" }, Ic(props.icon || "inbox")),
      h("div", { className: "es-t" }, props.title),
      props.sub && h("div", { className: "es-s" }, props.sub),
      act && (act.to ? h(Link, { to: act.to, className: "es-btn" }, Ic("plus"), act.label) : h("button", { className: "es-btn", onClick: act.onClick }, Ic("plus"), act.label)));
  }
  function ErrorState(props) {
    return h("div", { className: "er", role: "alert" },
      h("div", { className: "er-ic" }, Ic(props.icon || "triangle-alert")),
      h("div", { className: "er-t" }, props.title || "Something went wrong"),
      h("div", { className: "er-s" }, props.sub || "We couldn't load this. Check your connection and try again."),
      props.onRetry && h("button", { className: "es-btn", onClick: props.onRetry }, Ic("refresh-cw"), props.retryLabel || "Try again"),
      props.backTo && h(Link, { to: props.backTo, className: "es-btn alt", style: { marginTop: 8 } }, props.backLabel || "Go back"));
  }
  var PPBoundary = (function () {
    function B(p) { PR.Component.call(this, p); this.state = { err: null }; }
    B.prototype = Object.create(PR.Component.prototype); B.prototype.constructor = B;
    B.getDerivedStateFromError = function (e) { return { err: e }; };
    B.prototype.componentDidCatch = function (e) { try { console.error("PlugPay UI error:", e); } catch (_) {} };
    B.prototype.render = function () {
      var self = this;
      if (this.state.err) return h("div", { style: { maxWidth: 520, margin: "60px auto", padding: 16 } },
        h(ErrorState, { title: "This screen hit a snag", sub: "The page failed to render. Your data is safe - reload to continue.", onRetry: function () { self.setState({ err: null }); }, retryLabel: "Try again", backTo: "/", backLabel: "Back to home" }));
      return this.props.children;
    };
    return B;
  })();
  function NetBanner() {
    var _s = PR.useState(typeof navigator !== "undefined" ? navigator.onLine : true), online = _s[0], setOnline = _s[1];
    PR.useEffect(function () {
      var on = function () { setOnline(true); }, off = function () { setOnline(false); };
      window.addEventListener("online", on); window.addEventListener("offline", off);
      return function () { window.removeEventListener("online", on); window.removeEventListener("offline", off); };
    }, []);
    if (online) return null;
    return h("div", { className: "net-banner", role: "alert" }, Ic("wifi-off"), h("span", null, "You're offline. Changes won't sync until you reconnect."), h("button", { onClick: function () { setOnline(navigator.onLine); } }, "Retry"));
  }
  function BottomNav(props) {
    return h("nav", { className: props.className, "aria-label": props.label, style: props.style },
      props.items.map(function (it) {
        var cls = props.itemClass + (props.active === it[0] ? " on" : "");
        return props.onSelect
          ? h("button", { key: it[0], type: "button", className: cls, onClick: function () { props.onSelect(it[0], it); } }, it[1])
          : h(Link, { key: it[0], to: it[2], className: cls }, it[1]);
      }));
  }
  function PortalBottomNav(p) {
    return h(BottomNav, { className: p.role === "Agent" ? "agent-bottom-nav" : "landlord-bottom-nav", itemClass: "pbn-item", style: { gridTemplateColumns: "repeat(" + p.items.length + ", 1fr)" }, active: p.active, items: p.items });
  }
  function RouteSheet(props) {
    PR.useEffect(function () { document.body.style.overflow = "hidden"; return function () { document.body.style.overflow = ""; }; }, []);
    var exit = props.onClose || goBack;
    return h("div", { className: "modal-overlay on", style: { zIndex: 900 } },
      h("div", { className: props.innerClassName || "modal" },
        !props.hideBar && h("div", { className: "modal-bar" },
          h("button", { className: "modal-back", "aria-label": "Back", onClick: exit }, "\u2190"),
          h("button", { className: "modal-close", "aria-label": "Close", onClick: exit }, "\u2715")),
        props.children));
  }
  function NotFoundPage(props) {
    return h(PublicShellX, { title: props.title }, h("div", { className: "app-card" }, h("div", { className: "app-card-sub" }, props.sub), h("div", { className: "app-actions" }, h(Link, { to: props.to || "/search", className: "pp-btn primary" }, props.cta || "Search PlugPay"))));
  }

  /* ---- Store: single source of truth, split into one section per group ---- */
  function usePersisted(key, initial) {
    var k = "pp6:" + key;
    var st = (0, import_react.useState)(function () {
      try { var raw = window.localStorage.getItem(k); if (raw) return JSON.parse(raw); } catch (e) {}
      return typeof initial === "function" ? initial() : initial;
    });
    (0, import_react.useEffect)(function () { try { window.localStorage.setItem(k, JSON.stringify(st[0])); } catch (e) {} }, [st[0]]);
    (0, import_react.useEffect)(function () {
      function on(e) { if (e.key === k && e.newValue) { try { st[1](JSON.parse(e.newValue)); } catch (err) {} } }
      window.addEventListener("storage", on);
      return function () { window.removeEventListener("storage", on); };
    }, []);
    return st;
  }
  var PlugPayContext = (0, import_react.createContext)(null);
  var PAGE = 4;
  function PlugPayProvider({ children }) {

    /* ---- SHARED CORE: state and actions ---- */
    const [openModals, setOpenModals] = (0, import_react.useState)([]);
    const isOpen = (0, import_react.useCallback)((id) => openModals.includes(id), [openModals]);
    const openModal = (0, import_react.useCallback)((id) => {
      setOpenModals((s) => s.includes(id) ? s : [...s, id]);
    }, []);
    const closeModal = (0, import_react.useCallback)((id) => {
      setOpenModals((s) => s.filter((m) => m !== id));
    }, []);
    const [toast, setToast] = (0, import_react.useState)(null);
    const toastTimer = (0, import_react.useRef)(void 0);
    const showToast = (0, import_react.useCallback)((msg) => {
      if (toastTimer.current) clearTimeout(toastTimer.current);
      setToast(msg);
      toastTimer.current = setTimeout(() => setToast(null), 3e3);
    }, []);
    const copyText = (0, import_react.useCallback)(
      (text, msg) => {
        if (typeof navigator !== "undefined" && navigator.clipboard) {
          navigator.clipboard.writeText(text).catch(() => {
          });
        }
        showToast(msg);
      },
      [showToast]
    );

    /* ---- PUBLIC VIEW: state and actions ---- */
    const [merchantTab, setMerchantTab] = (0, import_react.useState)("profile");
    const [viewedSeller, setViewedSeller] = (0, import_react.useState)(null);
    const openMerchantModal = (0, import_react.useCallback)(() => {
      setViewedSeller(null);
      openModal("modal-merchant");
    }, [openModal]);
    const openMerchantModalOnReviews = (0, import_react.useCallback)(() => {
      setViewedSeller(null);
      openModal("modal-merchant");
      setMerchantTab("reviews");
    }, [openModal]);
    const focusMerchantProfileTab = (0, import_react.useCallback)(() => {
      if (isOpen("modal-merchant")) setMerchantTab("profile");
    }, [isOpen]);
    const [following, setFollowing] = (0, import_react.useState)(false);
    const toggleFollowMerchant = (0, import_react.useCallback)(() => {
      setFollowing((f) => {
        const nv = !f;
        showToast(nv ? "Following Wanjiku Electronics \u2713" : "Unfollowed Wanjiku Electronics");
        return nv;
      });
    }, [showToast]);
    const viewSellerProfile = (0, import_react.useCallback)(() => {
      setViewedSeller(null);
      openModal("modal-merchant");
      setMerchantTab("profile");
    }, [openModal]);
    const [stallHistory, setStallHistory] = usePersisted("stallhistory", []);
    const normLoc = (x) => String(x || "").toLowerCase().replace(/ground floor/, "g").replace(/floor\s*/, "").replace(/[^a-z0-9]/g, "");
    const locFromSub = (sub) => { const m = /(ground floor|floor\s*\w+),\s*stall\s*\w+/i.exec(String(sub || "")); return m ? m[0] : ""; };
    const streetOf = (building) => { const a = lbAccounts.filter((x) => x.name.trim().toLowerCase() === String(building || "").trim().toLowerCase())[0]; return a ? a.street : "Nairobi CBD"; };
    const showSeller = (d) => {
      setViewedSeller(buildViewedSeller({ street: streetOf(d.building), ...d }));
      setMerchantTab("profile");
      openModal("modal-merchant");
      window.setTimeout(() => { document.querySelectorAll(".tpModal, .tpModal .tp-body").forEach((el) => { el.scrollTop = 0; }); }, 60);
    };
    const openOwnProfile = () => { setViewedSeller(null); setMerchantTab("profile"); openModal("modal-merchant"); window.setTimeout(() => { document.querySelectorAll(".tpModal, .tpModal .tp-body").forEach((el) => { el.scrollTop = 0; }); }, 60); };
    const viewStallProfile = (stall, floor, building, merchant) => {
      const p = buildStallProfile({ obMerchantList }, { stall, floor, building, merchant: merchant || null });
      const sameBuilding = String(p.building).trim().toLowerCase() === stallAssignment.building.trim().toLowerCase();
      if (sameBuilding && normLoc(p.loc) === normLoc(stallAssignment.loc)) { openOwnProfile(); return; }
      const bid = lbIdByName(p.building);
      const lists = bid ? (lbData[bid] || emptyLb) : emptyLb;
      const at = (l) => l.filter((t) => normLoc(locFromSub(t.sub)) === normLoc(p.loc))[0];
      const tv = at(lists.verified), tp = at(lists.pending);
      const t = tv || tp;
      if (t && t.phone && sameNumber(t.phone, sellerProfile.phone)) { openOwnProfile(); return; }
      const owner = t ? t.name : p.owner;
      const dir = merchants.filter((m) => m.name === owner && m.sub.indexOf(p.building) > -1)[0];
      const claimed = p.registered && agentClaims.some((c) => c.verified && sameNumber(c.phone, p.phone));
      const verified = t ? !!tv : dir ? dir.badgeClass === "rcb-verified" : p.registered ? claimed : p.verified;
      const catSrc = dir ? dir.sub.split(" \u00b7 ")[0] : t ? String(t.sub).replace(/^Claims\s*/i, "").split(" \u00b7 ").filter((x) => !locFromSub(x))[0] : p.cat;
      showSeller({ biz: t || dir ? owner : p.biz, owner, cat: catSrc || p.cat, loc: p.loc, building: p.building, verified, phone: (t && t.phone) || p.phone, rating: dir ? dir.rating : p.rating, sales: dir && dir.sales, reviews: dir ? dir.reviews : p.reviews, vouches: dir && dir.vouches, years: p.years, photos: p.photos, registered: p.registered });
    };
    const openSellerRef = (ref) => {
      const own = sameNumber(ref.phone, sellerProfile.phone) || (ref.name && ref.name === sellerProfile.ownerName);
      if (own) { openOwnProfile(); return; }
      const dir = merchants.filter((x) => x.name === ref.name)[0];
      if (dir) { openDirectorySeller(dir); return; }
      const raw = String(ref.sub || "").replace(/^Claims\s*/i, "");
      const parts = raw.split(" \u00b7 ");
      const loc = locFromSub(raw);
      const cat = parts.filter((x) => x && !locFromSub(x))[0] || "Retail";
      const building = ref.building || stallAssignment.building;
      showSeller({ biz: ref.name, owner: ref.name, cat, loc: loc || "Stall not listed", building, verified: !!ref.verified, phone: ref.phone || "" });
    };
    const openDirectorySeller = (m) => {
      const name = m.name || m.owner;
      const dir = merchants.filter((x) => x.name === name)[0];
      if (!dir) { openOwnProfile(); return; }
      const parts = dir.sub.split(" \u00b7 ");
      if (dir.name === sellerProfile.ownerName) { openOwnProfile(); return; }
      showSeller({ biz: dir.name, owner: dir.name, cat: parts[0], building: parts[1], loc: parts[2], verified: dir.badgeClass === "rcb-verified", rating: dir.rating, sales: dir.sales, reviews: dir.reviews, vouches: dir.vouches });
    };
    /* Loads a seller into the shared profile state WITHOUT opening the modal (used by the /sellers/:id page). */
    const loadSellerPage = (id) => {
      const k = ppSlug(id);
      if (k && ppSlug(sellerProfile.ownerName) === k) { setViewedSeller(null); setMerchantTab("profile"); return true; }
      const dir = merchants.filter((x) => ppSlug(x.name) === k)[0];
      if (!dir) return false;
      const parts = dir.sub.split(" \u00b7 ");
      setViewedSeller(buildViewedSeller({ street: streetOf(parts[1]), biz: dir.name, owner: dir.name, cat: parts[0], building: parts[1], loc: parts[2], verified: dir.badgeClass === "rcb-verified", rating: dir.rating, sales: dir.sales, reviews: dir.reviews, vouches: dir.vouches }));
      setMerchantTab("profile");
      return true;
    };

    /* ---- SEARCH: state and actions ---- */
    const [searchMode, setSearchMode] = (0, import_react.useState)("merchant");
    const [query, setQuery] = (0, import_react.useState)("");
    const [resultsShown, setResultsShown] = (0, import_react.useState)(false);
    const [currentResults, setCurrentResults] = (0, import_react.useState)([]);
    const [shownCount, setShownCount] = (0, import_react.useState)(0);
    const [filter, setFilterState] = (0, import_react.useState)("all");
    const [resultsTitle, setResultsTitle] = (0, import_react.useState)("Search results");
    const [resultsMeta, setResultsMeta] = (0, import_react.useState)("Showing top matches");
    const pool = (0, import_react.useMemo)(() => [...merchants, ...buildings], []);
    const doSearch = (0, import_react.useCallback)(
      (q) => {
        var _a;
        const query_ = ((_a = q != null ? q : query) != null ? _a : "").toLowerCase().trim();
        setResultsShown(true);
        const results = query_ ? pool.filter((r) => (r.name + r.sub).toLowerCase().includes(query_)) : pool;
        setCurrentResults(results);
        setFilterState("all");
        setShownCount(Math.min(PAGE, results.length));
        setResultsTitle(query_ ? `Results for "${query_}"` : "All merchants & buildings");
        setResultsMeta(`${results.length} match${results.length !== 1 ? "es" : ""}`);
      },
      [pool, query]
    );
    const setFilter = (0, import_react.useCallback)(
      (type) => {
        setFilterState(type);
        const results = type === "all" ? pool : pool.filter((r) => r.type === type);
        setCurrentResults(results);
        setShownCount(Math.min(PAGE, results.length));
        setResultsTitle(type === "all" ? "All results" : type === "merchant" ? "Merchants" : "Buildings");
        setResultsMeta(`${results.length} match${results.length !== 1 ? "es" : ""}`);
      },
      [pool]
    );
    const loadMore = (0, import_react.useCallback)(() => {
      setShownCount((c) => Math.min(c + PAGE, currentResults.length));
    }, [currentResults.length]);
    const shownResults = currentResults.slice(0, shownCount);
    const hasMore = shownCount < currentResults.length;
    const moreHint = `Showing ${shownCount} of ${currentResults.length} results \xB7 ${currentResults.length - shownCount} more`;

    /* ---- BUILDING: state and actions ---- */
    const [bldgFloor, setBldgFloor] = (0, import_react.useState)("G");
    const [bldgId, setBldgId] = (0, import_react.useState)(null);
    const openBuildingModal = (0, import_react.useCallback)((id) => {
      setBldgId(typeof id === "string" ? id : null);
      openModal("modal-building");
      setBldgFloor("G");
    }, [openModal]);

    /* ---- SELLER PORTAL: state and actions ---- */
    const openInvoiceInProfile = (0, import_react.useCallback)(() => {
      openModal("modal-merchant");
      openModal("modal-record-sale");
    }, [openModal]);
    const openReceiptInProfile = (0, import_react.useCallback)(() => {
      openModal("modal-merchant");
      openModal("modal-record-sale");
    }, [openModal]);
    const [riders, setRiders] = (0, import_react.useState)([]);
    const riderIdRef = (0, import_react.useRef)(1);
    const [riderRows, setRiderRows] = (0, import_react.useState)([emptyRiderRow(0)]);
    const updateRiderRow = (0, import_react.useCallback)((id, patch) => {
      setRiderRows((rows) => rows.map((r) => r.id === id ? { ...r, ...patch } : r));
    }, []);
    const saveTrustedRiders = (0, import_react.useCallback)(() => {
      const valid = riderRows.filter((r) => r.name.trim());
      if (valid.length === 0) {
        showToast("Add at least one name first");
        return;
      }
      setRiders((r) => [...valid.map((v) => ({ name: v.name, role: v.role })), ...r]);
      setRiderRows([emptyRiderRow(riderIdRef.current++)]);
      showToast(`${valid.length > 1 ? `${valid.length} trusted people` : valid[0].name} added to your profile \u2713`);
    }, [riderRows, showToast]);
    const [merchantLoggedIn, setMerchantLoggedIn] = (0, import_react.useState)(false);
    const [authMethod, setAuthMethodState] = (0, import_react.useState)("whatsapp");
    const [authStep, setAuthStep] = (0, import_react.useState)("phone");
    const [authPhone, setAuthPhone] = (0, import_react.useState)("");
    const [authOtp, setAuthOtp] = (0, import_react.useState)("");
    const [authPinLoginValue, setAuthPinLoginValue] = (0, import_react.useState)("");
    const [authSetPinValue, setAuthSetPinValue] = (0, import_react.useState)("");
    const [authHasPin, setAuthHasPin] = (0, import_react.useState)(false);
    const finishLoginRef = (0, import_react.useRef)(null);
    const authSetMethod = (0, import_react.useCallback)((m) => {
      setAuthMethodState(m);
      setAuthPhone("");
    }, []);
    const openAuthModal = (0, import_react.useCallback)(() => {
      claimTokenRef.current = null;
      setClaimInfo(null);
      setAuthStep("phone");
      setAuthPhone("");
      setAuthOtp("");
      setAuthPinLoginValue("");
      setAuthSetPinValue("");
      authSetMethod("whatsapp");
      openModal("modal-register");
    }, [authSetMethod, openModal]);
    const requireSellerLogin = (0, import_react.useCallback)(
      (actionLabel) => {
        if (!merchantLoggedIn) {
          showToast("Sign in to your seller account to " + actionLabel);
          openAuthModal();
          return false;
        }
        return true;
      },
      [merchantLoggedIn, openAuthModal, showToast]
    );
    const authSendOTP = (0, import_react.useCallback)(() => {
      const val = authPhone.trim() || "07XX XXX XXX";
      showToast(`OTP sent to ${val} via ${authMethod === "sms" ? "SMS" : "WhatsApp"} \u2713`);
      setAuthStep("otp");
    }, [authMethod, authPhone, showToast]);
    const authVerifyOTP = (0, import_react.useCallback)(() => {
      if (!authHasPin) {
        showToast("Verified \u2713");
        setAuthStep("setpin");
      } else {
        showToast("Verified \u2713 Loading your stall profile\u2026");
        finishLoginRef.current && finishLoginRef.current();
      }
    }, [authHasPin, showToast]);
    const authSetPin = (0, import_react.useCallback)(() => {
      if (!/^\d{6}$/.test(authSetPinValue.trim())) {
        showToast("Enter a 6-digit PIN");
        return;
      }
      setAuthHasPin(true);
      showToast("PIN set \u2713 Use it next time to unlock your profile instantly.");
      finishLoginRef.current && finishLoginRef.current();
    }, [authSetPinValue, showToast]);
    const authShowPinLogin = (0, import_react.useCallback)(() => setAuthStep("pinlogin"), []);
    const authGoBackFromPin = (0, import_react.useCallback)(() => setAuthStep("phone"), []);
    const authPinLogin = (0, import_react.useCallback)(() => {
      if (!/^\d{6}$/.test(authPinLoginValue.trim())) {
        showToast("Enter your 6-digit PIN");
        return;
      }
      setAuthHasPin(true);
      showToast("Unlocked \u2713 Loading your stall profile\u2026");
      finishLoginRef.current && finishLoginRef.current();
    }, [authPinLoginValue, showToast]);
    const authGoBack = (0, import_react.useCallback)(() => setAuthStep("phone"), []);
    const [docStatus, setDocStatus] = (0, import_react.useState)({});
    const fakeUpload = (0, import_react.useCallback)(
      (key, name) => {
        if (docStatus[key] === "done") {
          showToast(`${name} already uploaded \u2713`);
          return;
        }
        setDocStatus((s) => ({ ...s, [key]: "uploading" }));
        setTimeout(() => {
          setDocStatus((s) => ({ ...s, [key]: "done" }));
          showToast(`${name} uploaded successfully \u2713`);
        }, 1200);
      },
      [docStatus, showToast]
    );
    const [showVacateForm, setShowVacateForm] = (0, import_react.useState)(false);
    const [vacateBuilding, setVacateBuilding] = (0, import_react.useState)("");
    const [vacateStall, setVacateStall] = (0, import_react.useState)("");
    const [stallAssignment, setStallAssignment] = usePersisted("stall2", { building: "Anniversary Towers", loc: "Floor 3, Stall 305" });
    const stockRef = (0, import_react.useRef)([]);
    const invoicesListRef = (0, import_react.useRef)([]);
    const rsIdRef = (0, import_react.useRef)(1);
    const [rsName, setRsName] = (0, import_react.useState)("");
    const [rsPhone, setRsPhone] = (0, import_react.useState)("");
    const [rsCode, setRsCode] = (0, import_react.useState)("");
    const [rsItems, setRsItems] = (0, import_react.useState)([emptyItemRow(0)]);
    const [rsSubmitting, setRsSubmitting] = (0, import_react.useState)(false);
    const [receipt, setReceipt] = (0, import_react.useState)({ kind: "receipt", code: "", name: "", rawPhone: "", phone: "", items: [], total: 0 });
    const addItemRow = (0, import_react.useCallback)((prefix) => {
      setRsItems((r) => [...r, emptyItemRow(rsIdRef.current++)]);
    }, []);
    const removeItemRow = (0, import_react.useCallback)((prefix, id) => {
      setRsItems((r) => r.length <= 1 ? r : r.filter((i) => i.id !== id));
    }, []);
    const updateItemRow = (0, import_react.useCallback)((prefix, id, patch) => {
      setRsItems((r) => r.map((i) => i.id === id ? { ...i, ...patch } : i));
    }, []);
    const rsTotal = rsItems.reduce((s, i) => s + (Number(i.price) || 0), 0);
    const startSaleFromProduct = (0, import_react.useCallback)((p) => {
      setRsName("");
      setRsPhone("");
      setRsCode("");
      setRsItems([{ id: rsIdRef.current++, name: p.name, price: String(p.price), productId: p.id, qty: 1, unit: String(p.price), category: p.category }]);
    }, []);
    const [receiptsList, setReceiptsList] = usePersisted("receipts", () => ppDemoSales().receipts);
    const [invoicesList, setInvoicesList] = usePersisted("invoices", () => ppDemoSales().invoices);
    (0, import_react.useEffect)(() => {
      try {
        if (window.localStorage.getItem("pp6:demoSalesSeeded")) return;
        window.localStorage.setItem("pp6:demoSalesSeeded", "1");
      } catch (e) { return; }
      const d = ppDemoSales();
      setReceiptsList((l) => l.concat(d.receipts.filter((x) => !l.some((y) => y.code === x.code))));
      setInvoicesList((l) => l.concat(d.invoices.filter((x) => !l.some((y) => y.token === x.token))));
    }, []);
    const catIdRef = (0, import_react.useRef)(1);
    const [catalogueItems, setCatalogueItems] = usePersisted("catalogue",
      () => PRODUCTS.map((p) => ({ id: "ci" + catIdRef.current++, icon: p.icon, image: "", name: p.name, price: p.price.replace(/[^0-9]/g, ""), category: p.cat, stock: parseInt(p.stock, 10) || 0 }))
    );
    stockRef.current = catalogueItems;
    invoicesListRef.current = invoicesList;
    const addCatalogueItem = (0, import_react.useCallback)((item) => {
      if (!String(item.name || "").trim() || !item.price) {
        showToast("Enter a product name and price");
        return false;
      }
      setCatalogueItems((c) => [{ id: "ci" + Date.now().toString(36) + (catIdRef.current++), icon: "\u{1F4E6}", image: item.image || "", name: item.name.trim(), price: String(item.price), category: (item.category || "").trim() || "General", stock: Number(item.stock) || 0 }, ...c]);
      showToast(`${item.name} added to your catalogue \u2713`);
      return true;
    }, [showToast]);
    const updateCatalogueItem = (0, import_react.useCallback)((id, patch) => {
      setCatalogueItems((c) => c.map((x) => x.id === id ? { ...x, ...patch } : x));
    }, []);
    const removeCatalogueItem = (0, import_react.useCallback)((id) => {
      setCatalogueItems((c) => c.filter((x) => x.id !== id));
      showToast("Product removed");
    }, [showToast]);
    const [sellerProfile, setSellerProfile] = usePersisted("seller", {
      bizName: "Wanjiku Electronics",
      ownerName: "Jane Wanjiku",
      role: "Electronics Retailer",
      bio: "Specializing in phones, laptops & repairs. In business since 2016.",
      street: "Moi Avenue, Nairobi CBD",
      phone: "+254 712 345 678",
      established: "2016 \xB7 8 years in business",
      whatsapp: "+254 712 345 678",
      instagram: "@wanjiku.electronics",
      tiktok: "@wanjikuelectronics",
      facebook: "/WanjikuElectronics",
      paybill: "2332323",
      account: "20262026",
      about: "We specialize in selling and repairing electronics, computers, and mobile phones. All products come with a 30-day warranty. Delivery available across Kenya via M-Pesa payment.",
      llPhoneVerified: true
    });
    const updateSellerProfile = (0, import_react.useCallback)((patch) => {
      setSellerProfile((p) => ({ ...p, ...patch }));
      showToast("Profile updated \u2713");
    }, [showToast]);
    const setLandlordPhoneVerified = (0, import_react.useCallback)((v) => {
      setSellerProfile((p) => ({ ...p, llPhoneVerified: v }));
      showToast(v ? "Phone number & profile confirmed as matching the real owner \u2713" : "Landlord verification revoked");
    }, [showToast]);
    const removeRider = (0, import_react.useCallback)((i) => {
      setRiders((r) => r.filter((_, idx) => idx !== i));
      showToast("Rider removed");
    }, [showToast]);
    finishLoginRef.current = () => {
      setMerchantLoggedIn(true);
      const tok = claimTokenRef.current;
      if (tok) { claimTokenRef.current = null; setClaimInfo(null); applyClaim(tok); }
      closeModal("modal-register");
      window.location.hash = "#/seller/dashboard";
    };
    const confirmVacate = () => {
      if (!vacateBuilding.trim() || !vacateStall.trim()) {
        showToast("Enter the building and stall you're moving to");
        return;
      }
      changeStall(vacateBuilding.trim(), vacateStall.trim());
      showToast(`Moved to ${vacateBuilding}, ${vacateStall} \u2014 your trust score, reviews, vouches, sales history & documents moved with you \u2713 Landlord verification there starts as Pending.`);
      setVacateBuilding("");
      setVacateStall("");
      setShowVacateForm(false);
    };
    const sentReceipts = receiptsList.filter((r) => r.sentAt && !r.demo);
    const sellerReviews = receiptsList.filter((r) => r.review).map((r) => r.review).sort((a, b) => new Date(b.at) - new Date(a.at));
    const sellerStats = (() => {
      const sum = sellerReviews.reduce((t, r) => t + r.rating, 0);
      const reviewCount = 156 + sellerReviews.length;
      const avg = (4.8 * 156 + sum) / reviewCount;
      const sales = 105 + sentReceipts.length;
      const trust = Math.min(99, Math.round(53 + (avg / 5) * 25 + Math.min(18, sales / 15)));
      const dist = { 5: 128, 4: 17, 3: 7, 2: 3, 1: 1 };
      sellerReviews.forEach((r) => { dist[r.rating] = (dist[r.rating] || 0) + 1; });
      return { avg, reviewCount, sales, trust, dist };
    })();
    const decrementStock = (items) => setCatalogueItems((c) => c.map((x) => {
      const sold = items.filter((i) => i.productId === x.id).reduce((t, i) => t + (Number(i.qty) || 1), 0);
      return sold ? { ...x, stock: Math.max(0, x.stock - sold) } : x;
    }));
    const stockShort = (items) => items.filter((i) => {
      const p = i.productId && catalogueItems.filter((x) => x.id === i.productId)[0];
      return p && (Number(i.qty) || 1) > p.stock;
    });
    const maskPhone = (p) => String(p).replace(/(\d{4}).*(\d{3})/, "$1 *** $2");
    const submitRecordSale = () => {
      const items = rsItems.filter((i) => i.name.trim() || i.price);
      if (!rsName.trim() || !rsPhone.trim() || items.length === 0) {
        showToast("Please fill all fields");
        return;
      }
      if (items.some((i) => !i.name.trim() || Number(i.price) <= 0)) {
        showToast("Add a name and price for every item");
        return;
      }
      const clean = items.map((i) => ({ name: i.name, price: Number(i.price), productId: i.productId || "", qty: Number(i.qty) || 1, unit: Number(i.unit) || Number(i.price), category: i.category || "" }));
      const total = clean.reduce((t, i) => t + i.price, 0);
      const now = new Date().toISOString();
      const hasCode = rsCode.trim().length > 0;
      if (hasCode) {
        const short = stockShort(clean);
        if (short.length) { showToast("Not enough stock for " + short[0].name); return; }
        const code = "#" + rsCode.trim().toUpperCase();
        if (receiptsList.some((r) => r.code === code)) { showToast("A receipt with that M-Pesa code already exists"); return; }
        const rc = { code, buyerName: rsName, buyerPhone: rsPhone, paymentRef: rsCode.trim().toUpperCase(), items: clean, total, createdAt: now, sentAt: now, stockApplied: true, review: null };
        setReceiptsList((l) => [rc, ...l]);
        decrementStock(clean);
        openWhatsApp(rc.buyerPhone, waReceiptText(rc, sellerProfile.bizName));
        setReceipt({ kind: "receipt", code, name: rsName, rawPhone: rsPhone, phone: maskPhone(rsPhone), items: clean, total });
        showToast(`Receipt sent to ${rsName} on WhatsApp \u2713 Review link attached`);
      } else {
        const token = "inv" + Date.now().toString(36);
        const inv = { token, buyerName: rsName, buyerPhone: rsPhone, source: "WhatsApp", items: clean, total, status: "PENDING", createdAt: now };
        setInvoicesList((l) => [inv, ...l]);
        openWhatsApp(inv.buyerPhone, waInvoiceText(inv, sellerProfile.bizName));
        setReceipt({ kind: "invoice", code: token, name: rsName, rawPhone: rsPhone, phone: maskPhone(rsPhone), items: clean, total });
        showToast(`Invoice sent to ${rsName} on WhatsApp \u2713`);
      }
      setRsName("");
      setRsPhone("");
      setRsCode("");
      setRsItems([emptyItemRow(rsIdRef.current++)]);
      closeModal("modal-record-sale");
      openModal("modal-receipt");
    };
    const resendInvoice = (token) => {
      const inv = invoicesList.filter((x) => x.token === token)[0];
      if (!inv) return;
      openWhatsApp(inv.buyerPhone, waInvoiceText(inv, sellerProfile.bizName));
      showToast(`Invoice resent to ${inv.buyerName} on WhatsApp`);
    };
    const convertInvoiceToReceipt = (token, code) => {
      const inv = invoicesList.filter((x) => x.token === token)[0];
      if (!inv) { showToast("Invoice not found"); return null; }
      if (!code || !code.trim()) { showToast("Enter the M-Pesa code or paste the payment message"); return null; }
      const rawCode = code.trim().toUpperCase();
      const found = rawCode.match(/\b(?=[A-Z0-9]*\d)(?=[A-Z0-9]*[A-Z])[A-Z0-9]{10}\b/);
      const ref = found ? found[0] : (/\s/.test(rawCode) ? "" : rawCode);
      if (!ref) { showToast("Could not find an M-Pesa code in that message"); return null; }
      const receiptCode = "#" + ref;
      if (receiptsList.some((r) => r.code === receiptCode)) { showToast("A receipt with that M-Pesa code already exists"); return null; }
      setInvoicesList((l) => l.map((x) => x.token === token ? { ...x, status: "PAID", docStatus: "COMPLETE", paymentRef: ref } : x));
      setReceiptsList((l) => [{ code: receiptCode, buyerName: inv.buyerName, buyerPhone: inv.buyerPhone, paymentRef: ref, mpesaMessage: /\s/.test(rawCode) ? code.trim() : "", items: inv.items, total: inv.total, createdAt: new Date().toISOString(), sentAt: null, stockApplied: false, review: null }, ...l]);
      showToast(`Marked as paid \u2713 Send the receipt to ${inv.buyerName} to complete the sale`);
      return receiptCode;
    };
    const setDocumentStatus = (kind, id, status) => {
      if (kind === "invoice") setInvoicesList((l) => l.map((x) => x.token === id ? { ...x, docStatus: status } : x));
      else setReceiptsList((l) => l.map((x) => x.code === id ? { ...x, docStatus: status } : x));
      showToast(status === "COMPLETE" ? "Marked as complete \u2713" : "Marked as pending");
    };
    const sendReceipt = (code) => {
      const c = codeOf(code);
      const r = receiptsList.filter((x) => codeOf(x.code) === c)[0];
      if (!r) { showToast("Receipt not found"); return false; }
      const now = new Date().toISOString();
      if (!r.stockApplied) {
        const short = stockShort(r.items);
        if (short.length) { showToast("Not enough stock for " + short[0].name + " \u2014 update your catalogue first"); return false; }
        decrementStock(r.items);
      }
      const sentAt = r.sentAt || now;
      setReceiptsList((l) => l.map((x) => x.code === r.code ? { ...x, sentAt, stockApplied: true } : x));
      openWhatsApp(r.buyerPhone, waReceiptText({ ...r, sentAt }, sellerProfile.bizName));
      showToast(r.sentAt ? `Receipt resent to ${r.buyerName || "buyer"} \u2713` : `Receipt sent to ${r.buyerName || "buyer"} \u2713 Stock updated, review link attached`);
      return true;
    };
    const submitReview = (code, data) => {
      const c = codeOf(code);
      const r = receiptsList.filter((x) => codeOf(x.code) === c)[0];
      if (!r) return { ok: false, reason: "notfound" };
      const st = reviewStatus(r);
      if (st.state === "done") return { ok: false, reason: "done" };
      if (st.state === "notsent") return { ok: false, reason: "notsent" };
      if (st.state === "expired") return { ok: false, reason: "expired" };
      if (!data || !data.rating) return { ok: false, reason: "norating" };
      const rev = { id: "rv" + Date.now().toString(36), code: r.code, buyerName: r.buyerName, rating: data.rating, comment: String(data.comment || "").trim(), at: new Date().toISOString() };
      setReceiptsList((l) => l.map((x) => x.code === r.code ? { ...x, review: rev } : x));
      showToast("Thanks for your review \u2713");
      return { ok: true };
    };

    /* ---- AGENT ONBOARDING: state and actions ---- */
    const [obAgentGate, setObAgentGate] = (0, import_react.useState)(true);
    const [obAgentMethod, setObAgentMethodState] = (0, import_react.useState)("sms");
    const [obAgentPhoneStep, setObAgentPhoneStep] = (0, import_react.useState)(true);
    const [obAgentPhone, setObAgentPhone] = (0, import_react.useState)("");
    const [obAgentOtp, setObAgentOtp] = (0, import_react.useState)("");
    const [obAgentSending, setObAgentSending] = (0, import_react.useState)(false);
    const [obAgentVerifying, setObAgentVerifying] = (0, import_react.useState)(false);
    const [obStep_, setObStep_] = (0, import_react.useState)(1);
    const [obBldgName, setObBldgName] = (0, import_react.useState)("");
    const [obFloorsCount, setObFloorsCount] = (0, import_react.useState)("6");
    const [obFloorStalls, setObFloorStallsState] = (0, import_react.useState)({});
    const [obPayMethod, setObPayMethod] = (0, import_react.useState)("till");
    const [obMerchantList, setObMerchantList] = (0, import_react.useState)(seedObMerchants);
    const obMerchantIdRef = (0, import_react.useRef)(1);
    const [obEditingMerchantId, setObEditingMerchantId] = (0, import_react.useState)(null);
    const [obNewName, setObNewName] = (0, import_react.useState)("");
    const [obNewPhone, setObNewPhone] = (0, import_react.useState)("");
    const [obNewStallNum, setObNewStallNum] = (0, import_react.useState)("");
    const [obNewFloor, setObNewFloor] = (0, import_react.useState)("G");
    const [obNewBiz, setObNewBiz] = (0, import_react.useState)("");
    const [obNewType, setObNewType] = (0, import_react.useState)("Fashion");
    const [obNewExtra, setObNewExtra] = (0, import_react.useState)({});
    const obAgentSetMethod = (0, import_react.useCallback)((m) => {
      setObAgentMethodState(m);
      setObAgentPhone("");
    }, []);
    const openOnboard = (0, import_react.useCallback)(() => {
      openModal("modal-onboard");
      setObAgentGate(true);
      setObAgentPhoneStep(true);
      setObAgentPhone("");
      setObAgentOtp("");
      obAgentSetMethod("sms");
      setObMerchantList(seedObMerchants);
      setObEditingMerchantId(null);
      setObStep_(1);
    }, [obAgentSetMethod, openModal]);
    const obAgentSendOtp = (0, import_react.useCallback)(() => {
      if (!obAgentPhone.trim()) {
        showToast(obAgentMethod === "email" ? "Enter your email address" : "Enter your phone number");
        return;
      }
      setObAgentSending(true);
      setTimeout(() => {
        setObAgentSending(false);
        setObAgentPhoneStep(false);
        showToast(`OTP sent via ${obAgentMethod === "email" ? "email" : "SMS"} \u2713`);
      }, 500);
    }, [obAgentMethod, obAgentPhone, showToast]);
    const obAgentVerifyOtp = (0, import_react.useCallback)(() => {
      if (!obAgentOtp.trim() || obAgentOtp.trim().length < 4) {
        showToast("Enter the OTP");
        return;
      }
      setObAgentVerifying(true);
      setTimeout(() => {
        setObAgentVerifying(false);
        showToast("Signed in as agent \u2713");
        setObAgentGate(false);
        setObStep_(1);
      }, 500);
    }, [obAgentOtp, showToast]);
    const setObFloorStall = (0, import_react.useCallback)((key, v) => {
      setObFloorStallsState((s) => ({ ...s, [key]: v }));
    }, []);
    const obTotalStalls = (0, import_react.useMemo)(
      () => Object.values(obFloorStalls).reduce((s, v) => s + (parseInt(v) || 0), 0),
      [obFloorStalls]
    );
    const obGoToStep = (0, import_react.useCallback)((n) => setObStep_(n), []);
    const obStep = (0, import_react.useCallback)(
      (dir) => {
        const total = 4;
        if (obStep_ === total && dir > 0) {
          if (obMerchantList.length === 0) {
            showToast("Add at least one seller before publishing");
            return;
          }
          const n = obMerchantList.length;
          showToast(`\u{1F389} Building published with ${n} seller${n === 1 ? "" : "s"} live on PlugPay! QR code sent to the manager and a claim link sent to each seller on WhatsApp.`);
          claimsApiRef.current && claimsApiRef.current.publish(obMerchantList, obBldgName || "New building", obTotalStalls);
          setAgentBuildings((b) => [{ name: obBldgName || "New building", street: "Nairobi CBD", floorsCount: obFloorsCount, stalls: obTotalStalls, merchants: obMerchantList.length }, ...b]);
          closeModal("modal-onboard");
          window.location.hash = "#/agent/claims";
          return;
        }
        let next = obStep_ + dir;
        if (dir > 0 && obStep_ === 1) next = 4;
        if (dir < 0 && obStep_ === 4) next = 1;
        if (next < 1 || next > total) return;
        setObStep_(next);
      },
      [closeModal, obBldgName, obFloorsCount, obMerchantList, obStep_, obTotalStalls, showToast]
    );
    const obAddMerchant = (0, import_react.useCallback)(() => {
      if (!obNewBiz.trim()) {
        showToast("Enter business name");
        return false;
      }
      if (!obNewName.trim()) {
        showToast("Enter owner name");
        return false;
      }
      if (!obNewPhone.trim()) {
        showToast("Enter phone number");
        return false;
      }
      if (!obNewStallNum.trim()) {
        showToast("Enter stall number");
        return false;
      }
      const colors = [
        "#3B3DB8",
        "#185FA5",
        "#8b008b"
      ];
      if (obEditingMerchantId) {
        setObMerchantList(
          (l) => l.map(
            (m) => m.id === obEditingMerchantId ? { ...m, biz: obNewBiz, ownerName: obNewName, phone: obNewPhone, floor: obNewFloor, stallNum: obNewStallNum, type: obNewType, extra: obNewExtra, initials: initials(obNewName) } : m
          )
        );
        claimsApiRef.current && claimsApiRef.current.upsert({ id: obEditingMerchantId, biz: obNewBiz, ownerName: obNewName, phone: obNewPhone, floor: obNewFloor, stallNum: obNewStallNum, type: obNewType }, obBldgName);
        showToast("Merchant profile updated \u2713 \u2014 " + obNewBiz);
        setObEditingMerchantId(null);
      } else {
        const color = colors[obMerchantList.length % colors.length];
        const nm = {
          id: "ob-" + obMerchantIdRef.current++,
          biz: obNewBiz,
          ownerName: obNewName,
          phone: obNewPhone,
          floor: obNewFloor,
          stallNum: obNewStallNum,
          type: obNewType,
          extra: obNewExtra,
          initials: initials(obNewName),
          color,
          status: "invited"
        };
        setObMerchantList((l) => [...l, nm]);
        claimsApiRef.current && claimsApiRef.current.upsert(nm, obBldgName);
        showToast(`${obNewBiz} registered \u2713 Claim link sent to ${obNewPhone} on WhatsApp`);
      }
      setObNewName("");
      setObNewPhone("");
      setObNewStallNum("");
      setObNewFloor("G");
      setObNewBiz("");
      setObNewType("Fashion");
      setObNewExtra({});
      return true;
    }, [obBldgName, obEditingMerchantId, obMerchantList.length, obNewBiz, obNewFloor, obNewName, obNewPhone, obNewStallNum, obNewType, obNewExtra, showToast]);
    const obStartEditMerchant = (0, import_react.useCallback)(
      (id) => {
        const m = obMerchantList.find((x) => x.id === id);
        if (!m) return;
        setObEditingMerchantId(id);
        setObNewBiz(m.biz);
        setObNewName(m.ownerName);
        setObNewPhone(m.phone);
        setObNewStallNum(m.stallNum);
        setObNewFloor(m.floor);
        setObNewType(m.type);
        setObNewExtra(m.extra || {});
      },
      [obMerchantList]
    );
    const obCancelEditMerchant = (0, import_react.useCallback)(() => {
      setObEditingMerchantId(null);
      setObNewName("");
      setObNewPhone("");
      setObNewStallNum("");
      setObNewFloor("G");
      setObNewBiz("");
      setObNewType("Fashion");
      setObNewExtra({});
    }, []);
    const obPrefillNewMerchantStall = (0, import_react.useCallback)((floor, stallNum) => {
      setObEditingMerchantId(null);
      setObNewBiz("");
      setObNewName("");
      setObNewPhone("");
      setObNewType("Fashion");
      setObNewExtra({});
      setObNewFloor(floor);
      setObNewStallNum(stallNum);
    }, []);
    const obRemoveMerchant = (0, import_react.useCallback)(
      (id) => {
        const m = obMerchantList.find((x) => x.id === id);
        setObMerchantList((l) => l.filter((x) => x.id !== id));
        if (obEditingMerchantId === id) obCancelEditMerchant();
        if (m) showToast(`${m.biz} removed from this building`);
      },
      [obCancelEditMerchant, obEditingMerchantId, obMerchantList, showToast]
    );

    /* ---- AGENT PORTAL: state and actions ---- */
    const claimTokenRef = (0, import_react.useRef)(null);
    const claimsApiRef = (0, import_react.useRef)(null);
    const [claimInfo, setClaimInfo] = (0, import_react.useState)(null);
    const [agentClaims, setAgentClaims] = usePersisted("claims", []);
    const [agentBuildings, setAgentBuildings] = (0, import_react.useState)([]);
    const stallLoc = (m) => (m.floor === "G" ? "Ground Floor" : "Floor " + m.floor) + ", Stall " + m.stallNum;
    const newAgentClaim = (m, bldg, extra) => ({ id: m.id, token: "clm" + m.id, businessName: m.biz, ownerName: m.ownerName, phone: m.phone, category: m.type, floor: m.floor, number: m.stallNum, loc: stallLoc(m), buildingName: bldg || "New building", status: "INVITED", verified: false, source: "agent", sentAt: new Date().toISOString(), ...(extra || {}) });
    const upsertAgentClaim = (m, bldg) => {
      setAgentClaims((l) => {
        const ex = l.filter((x) => x.id === m.id)[0];
        if (!ex) return [newAgentClaim(m, bldg, { draft: true }), ...l];
        return l.map((x) => x.id === m.id ? { ...x, businessName: m.biz, ownerName: m.ownerName, phone: m.phone, category: m.type, floor: m.floor, number: m.stallNum, loc: stallLoc(m), buildingName: x.draft ? (bldg || x.buildingName) : x.buildingName, sentAt: x.phone !== m.phone ? new Date().toISOString() : x.sentAt } : x);
      });
    };
    const publishAgentClaims = (list, bldg, stalls) => {
      setAgentClaims((l) => {
        const out = l.slice();
        list.forEach((m) => {
          const i = out.findIndex((x) => x.id === m.id);
          if (i >= 0) { if (out[i].draft) out[i] = { ...out[i], buildingName: bldg, draft: false }; }
          else out.unshift(newAgentClaim(m, bldg));
        });
        return out;
      });
      ensureLbAccount(bldg, "Nairobi CBD", stalls);
    };
    claimsApiRef.current = { upsert: upsertAgentClaim, publish: publishAgentClaims };
    const resendClaim = (token) => {
      const c = agentClaims.filter((x) => x.token === token)[0];
      if (!c) return;
      openWhatsApp(c.phone, waClaimText(c));
      showToast(`Claim link resent to ${c.ownerName || c.businessName} on WhatsApp`);
    };
    const openClaimSignIn = (token) => {
      const c = agentClaims.filter((x) => x.token === token)[0];
      if (!c) return;
      claimTokenRef.current = token;
      setClaimInfo({ token, name: c.businessName || c.ownerName, loc: c.loc, building: c.buildingName });
      setAuthStep("phone");
      setAuthOtp("");
      setAuthPinLoginValue("");
      setAuthSetPinValue("");
      setAuthMethodState("whatsapp");
      setAuthPhone(c.phone || "");
      openModal("modal-register");
    };
    const applyClaim = (token) => {
      const c = agentClaims.filter((x) => x.token === token)[0];
      if (!c) return;
      const same = sameNumber(c.phone, sellerProfile.phone);
      const loc = c.loc || "";
      setAgentClaims((l) => l.map((x) => x.token === token ? { ...x, status: "CLAIMED", claimedAt: new Date().toISOString() } : x));
      setSellerProfile((p) => Object.assign({}, p, same ? {} : { bizName: c.businessName || p.bizName, ownerName: c.ownerName || p.ownerName, phone: c.phone || p.phone, whatsapp: c.phone || p.whatsapp }, { llPhoneVerified: !!c.verified }));
      if (same && (stallAssignment.building !== c.buildingName || stallAssignment.loc !== loc)) {
        setStallHistory((hs) => [{ building: stallAssignment.building, loc: stallAssignment.loc, until: new Date().toISOString() }, ...hs]);
      }
      setStallAssignment({ building: c.buildingName, loc });
      const bid = lbIdByName(c.buildingName);
      if (bid && !c.verified) {
        const cur = lbData[bid] || emptyLb;
        const exists = cur.pending.concat(cur.verified).some((t) => t.claimToken === token || sameNumber(t.phone, c.phone));
        if (!exists) updLb(bid, (cu) => ({ pending: [{ id: "clm-" + token, claimToken: token, name: c.ownerName || c.businessName, phone: c.phone, sub: (c.category || "Seller") + " \u00b7 " + loc, initials: initials(c.ownerName || c.businessName || "S"), color: "#8a8a8a" }, ...cu.pending] }));
      }
      showToast(c.verified ? `Stall claimed \u2713 ${c.buildingName}'s landlord has already verified you` : `Stall claimed \u2713 Pending until ${c.buildingName}'s landlord verifies you`);
    };
    const changeStall = (building, loc) => {
      const prev = stallAssignment;
      if (prev.building === building && prev.loc === loc) return;
      const moved = prev.building.trim().toLowerCase() !== String(building).trim().toLowerCase();
      setStallHistory((hs) => [{ building: prev.building, loc: prev.loc, until: new Date().toISOString() }, ...hs]);
      setStallAssignment({ building, loc });
      if (!moved) return;
      setSellerProfile((p) => ({ ...p, llPhoneVerified: false }));
      const oldId = lbIdByName(prev.building);
      if (oldId) updLb(oldId, (cur) => {
        const gone = cur.verified.concat(cur.pending).filter((t) => sameNumber(t.phone, sellerProfile.phone));
        return gone.length ? { verified: cur.verified.filter((t) => !sameNumber(t.phone, sellerProfile.phone)), pending: cur.pending.filter((t) => !sameNumber(t.phone, sellerProfile.phone)), vacated: gone.concat(cur.vacated) } : {};
      });
      const newId = lbIdByName(building);
      if (newId) updLb(newId, (cur) => cur.pending.concat(cur.verified).some((t) => sameNumber(t.phone, sellerProfile.phone)) ? {} : { pending: [{ id: "mv-" + Date.now().toString(36), name: sellerProfile.ownerName || sellerProfile.bizName, phone: sellerProfile.phone, sub: (sellerProfile.role || "Seller") + " \u00b7 " + loc, initials: initials(sellerProfile.ownerName || sellerProfile.bizName || "S"), color: "#8a8a8a" }, ...cur.pending] });
    };

    /* ---- LANDLORD PORTAL: state and actions ---- */
    const [llMethod, setLlMethodState] = (0, import_react.useState)("sms");
    const [llStep, setLlStep] = (0, import_react.useState)("phone");
    const [llAuthed, setLlAuthed] = (0, import_react.useState)(false);
    const [llPhone, setLlPhone] = (0, import_react.useState)("");
    const [llOtp, setLlOtp] = (0, import_react.useState)("");
    const [llPinLoginPhone, setLlPinLoginPhone] = (0, import_react.useState)("");
    const [llPinLoginPin, setLlPinLoginPin] = (0, import_react.useState)("");
    const [llSetPinValue, setLlSetPinValue] = (0, import_react.useState)("");
    const [llHasPin, setLlHasPin] = (0, import_react.useState)(false);
    const llSetMethod = (0, import_react.useCallback)((m) => {
      setLlMethodState(m);
      setLlPhone("");
    }, []);
    const openLandlordModal = (0, import_react.useCallback)(() => {
      if (llAuthed) { window.location.hash = "#/landlord/dashboard"; return; }
      setLlStep("phone");
      setLlPhone("");
      setLlOtp("");
      setLlPinLoginPhone("");
      setLlPinLoginPin("");
      setLlSetPinValue("");
      llSetMethod("sms");
      openModal("modal-landlord");
    }, [llAuthed, llSetMethod, openModal]);
    const llSendOTP = (0, import_react.useCallback)(() => {
      const val = llPhone.trim() || (llMethod === "email" ? "you@email.com" : "07XX XXX XXX");
      showToast(`OTP sent to ${val} via ${llMethod === "email" ? "email" : "SMS"} \u2713`);
      setLlStep("otp");
    }, [llMethod, llPhone, showToast]);
    const llGoBack = (0, import_react.useCallback)(() => setLlStep("phone"), []);
    const emptyLb = { pending: [], verified: [], vacated: [], vacant: [], onPlugPay: 0 };
    const [lbAccounts, setLbAccounts] = usePersisted("lbaccounts", initialLbAccounts);
    const [lbData, setLbData] = usePersisted("lbdata", initialLbData);
    const [lbActiveId, setLbActiveId] = (0, import_react.useState)("lb1");
    const lbActive = lbAccounts.filter((a) => a.id === lbActiveId)[0] || lbAccounts[0];
    const lbCur = lbData[lbActive.id] || emptyLb;
    const pendingTraders = lbCur.pending;
    const verifiedTraders = lbCur.verified;
    const vacatedTraders = lbCur.vacated;
    const vacantStalls = lbCur.vacant;
    const updLb = (id, patch) => setLbData((d) => {
      const cur = d[id] || emptyLb;
      const p = typeof patch === "function" ? patch(cur) : patch;
      return { ...d, [id]: { ...cur, ...p } };
    });
    const llEnterDashboard = () => {
      setLlAuthed(true);
      closeModal("modal-landlord");
      window.location.hash = "#/landlord/dashboard";
    };
    const llVerifyOTP = (0, import_react.useCallback)(() => {
      if (!llHasPin) {
        showToast("Verified \u2713");
        setLlStep("setpin");
      } else {
        showToast("Verified \u2713 Loading your building dashboard\u2026");
        llEnterDashboard();
      }
    }, [llHasPin, showToast]);
    const llSetPin = (0, import_react.useCallback)(() => {
      if (!/^\d{6}$/.test(llSetPinValue.trim())) {
        showToast("Enter a 6-digit PIN");
        return;
      }
      setLlHasPin(true);
      showToast("PIN set \u2713 You can sign in with your phone + PIN next time.");
      llEnterDashboard();
    }, [llSetPinValue, showToast]);
    const llShowPinLogin = (0, import_react.useCallback)(() => setLlStep("pinlogin"), []);
    const llGoBackFromPin = (0, import_react.useCallback)(() => setLlStep("phone"), []);
    const llPinLogin = (0, import_react.useCallback)(() => {
      if (!llPinLoginPhone.trim()) {
        showToast("Enter your phone number");
        return;
      }
      if (!/^\d{6}$/.test(llPinLoginPin.trim())) {
        showToast("Enter your 6-digit PIN");
        return;
      }
      setLlHasPin(true);
      showToast("Signed in \u2713 Loading your building dashboard\u2026");
      llEnterDashboard();
    }, [llPinLoginPhone, llPinLoginPin, showToast]);
    const [asStall, setAsStall] = (0, import_react.useState)(null);
    const [asName, setAsName] = (0, import_react.useState)("");
    const [asPhone, setAsPhone] = (0, import_react.useState)("");
    const [asCategory, setAsCategory] = (0, import_react.useState)("");
    const [asSubmitting, setAsSubmitting] = (0, import_react.useState)(false);
    const asStallLabel = asStall ? `Into ${asStall.label} \u2014 ${lbActive.name}` : "";
    const llOpenAdmitSeller = (0, import_react.useCallback)(
      (stallId, stallLabel) => {
        setAsStall({ id: stallId, label: stallLabel });
        setAsName("");
        setAsPhone("");
        setAsCategory("");
        openModal("modal-admit-seller");
      },
      [openModal]
    );
    const lbIdByName = (name) => {
      const n = String(name || "").trim().toLowerCase();
      const a = lbAccounts.filter((x) => x.name.trim().toLowerCase() === n)[0];
      return a ? a.id : null;
    };
    const lbSwitch = (id) => {
      const a = lbAccounts.filter((x) => x.id === id)[0];
      if (!a) return;
      setLbActiveId(id);
      showToast(`Switched to ${a.name} \u2014 its own landlord account`);
    };
    const ensureLbAccount = (name, street, stalls) => {
      if (!String(name || "").trim() || lbIdByName(name)) return;
      const id = "lb" + Date.now().toString(36);
      setLbAccounts((a) => [...a, { id, name: name.trim(), street: street || "Nairobi CBD", totalStalls: Number(stalls) || 0 }]);
      setLbData((d) => ({ ...d, [id]: { ...emptyLb } }));
    };
    const llAddBuilding = (name, street, stalls) => {
      if (!String(name || "").trim()) { showToast("Enter the building name"); return false; }
      if (lbIdByName(name)) { showToast("You already manage a building with that name"); return false; }
      const id = "lb" + Date.now().toString(36);
      setLbAccounts((a) => [...a, { id, name: name.trim(), street: String(street || "").trim() || "Nairobi CBD", totalStalls: Number(stalls) || 0 }]);
      setLbData((d) => ({ ...d, [id]: { ...emptyLb } }));
      setLbActiveId(id);
      showToast(`${name.trim()} added \u2014 it has its own landlord account \u2713`);
      return true;
    };
    const landlordVerifyPending = !sellerProfile.llPhoneVerified;
    const llVerifyTrader = (id) => {
      const t = pendingTraders.filter((p) => p.id === id)[0];
      if (!t) return;
      updLb(lbActive.id, (cur) => ({ pending: cur.pending.filter((x) => x.id !== id), verified: [{ ...t, badge: "\u2713 Verified" }, ...cur.verified] }));
      if (t.phone && sameNumber(t.phone, sellerProfile.phone)) setSellerProfile((p) => ({ ...p, llPhoneVerified: true }));
      showToast(`${t.name} verified \u2713`);
    };
    const llSubmitAdmitSeller = () => {
      if (!asName.trim() || !asPhone.trim() || !asCategory.trim()) {
        showToast("Please fill in all fields");
        return;
      }
      if (!asStall) {
        closeModal("modal-admit-seller");
        return;
      }
      const stall = asStall, name = asName.trim(), phone = asPhone.trim(), category = asCategory.trim();
      const token = "clm" + Date.now().toString(36);
      const colors = ["#51104a", "#185FA5", "#534AB7", "#BA7517", "#8b008b"];
      const color = colors[Math.floor(Math.random() * colors.length)];
      setAgentClaims((l) => [{ id: token, token, businessName: "", ownerName: name, phone, category, floor: "", number: stall.id, loc: stall.label, buildingName: lbActive.name, status: "INVITED", verified: true, source: "landlord", sentAt: new Date().toISOString() }, ...l]);
      updLb(lbActive.id, (cur) => ({
        vacant: cur.vacant.filter((s) => s.id !== stall.id),
        onPlugPay: cur.onPlugPay + 1,
        verified: [{ id: "nv-" + token, claimToken: token, name, phone, sub: `${category} \u00b7 ${stall.label}`, initials: initials(name), color, badge: "\u2713 Verified" }, ...cur.verified]
      }));
      showToast(`${name} admitted & verified \u2713 Claim link sent to ${phone} on WhatsApp`);
      setAsStall(null);
      closeModal("modal-admit-seller");
    };

    /* ---- Shared context value, listed by group ---- */
    const value = {
      // SHARED CORE
      openModals,
      isOpen,
      openModal,
      closeModal,
      toast,
      showToast,
      copyText,
      // PUBLIC VIEW
      viewedSeller,
      loadSellerPage,
      openDirectorySeller,
      openSellerRef,
      stallHistory,
      merchantTab,
      setMerchantTab,
      openMerchantModal,
      openMerchantModalOnReviews,
      focusMerchantProfileTab,
      following,
      toggleFollowMerchant,
      viewSellerProfile,
      viewStallProfile,
      // SEARCH
      searchMode,
      setSearchMode,
      query,
      setQuery,
      resultsShown,
      resultsTitle,
      resultsMeta,
      shownResults,
      hasMore,
      moreHint,
      filter,
      setFilter,
      doSearch,
      loadMore,
      // BUILDING
      bldgFloor,
      setBldgFloor,
      bldgId,
      openBuildingModal,
      // SELLER PORTAL
      updateCatalogueItem,
      sentReceipts,
      sellerReviews,
      sellerStats,
      sendReceipt,
      submitReview,
      resendInvoice,
      sellerProfile,
      updateSellerProfile,
      setLandlordPhoneVerified,
      removeRider,
      receiptsList,
      invoicesList,
      catalogueItems,
      addCatalogueItem,
      removeCatalogueItem,
      openInvoiceInProfile,
      openReceiptInProfile,
      riders,
      riderRows,
      updateRiderRow,
      saveTrustedRiders,
      merchantLoggedIn,
      requireSellerLogin,
      openAuthModal,
      authMethod,
      authSetMethod,
      authStep,
      authPhone,
      setAuthPhone,
      authOtp,
      setAuthOtp,
      authPinLoginValue,
      setAuthPinLoginValue,
      authSetPinValue,
      setAuthSetPinValue,
      authSendOTP,
      authVerifyOTP,
      authSetPin,
      authShowPinLogin,
      authGoBackFromPin,
      authPinLogin,
      authGoBack,
      docStatus,
      fakeUpload,
      vacateBuilding,
      setVacateBuilding,
      vacateStall,
      setVacateStall,
      confirmVacate,
      stallAssignment,
      rsName,
      setRsName,
      rsPhone,
      setRsPhone,
      rsCode,
      setRsCode,
      rsItems,
      rsTotal,
      rsSubmitting,
      addItemRow,
      removeItemRow,
      updateItemRow,
      submitRecordSale,
      startSaleFromProduct,
      convertInvoiceToReceipt,
      setDocumentStatus,
      receipt,
      // AGENT ONBOARDING
      openOnboard,
      obAgentGate,
      obAgentMethod,
      obAgentSetMethod,
      obAgentPhoneStep,
      obAgentPhone,
      setObAgentPhone,
      obAgentOtp,
      setObAgentOtp,
      obAgentSending,
      obAgentVerifying,
      obAgentSendOtp,
      obAgentVerifyOtp,
      obStep_,
      obGoToStep,
      obStep,
      obBldgName,
      setObBldgName,
      obFloorsCount,
      setObFloorsCount,
      obFloorStalls,
      setObFloorStall,
      obTotalStalls,
      obPayMethod,
      obNewExtra,
      setObNewExtra,
      setObPayMethod,
      obMerchantList,
      obNewName,
      setObNewName,
      obNewPhone,
      setObNewPhone,
      obNewBiz,
      setObNewBiz,
      obNewType,
      setObNewType,
      obAddMerchant,
      obStartEditMerchant,
      obCancelEditMerchant,
      obPrefillNewMerchantStall,
      obRemoveMerchant,
      // AGENT PORTAL
      resendClaim,
      changeStall,
      openClaimSignIn,
      claimInfo,
      agentClaims,
      agentBuildings,
      // LANDLORD PORTAL
      lbAccounts,
      lbData,
      lbActive,
      lbSwitch,
      llAddBuilding,
      landlordVerifyPending,
      llMethod,
      llSetMethod,
      llStep,
      llAuthed,
      openLandlordModal,
      llPhone,
      setLlPhone,
      llOtp,
      setLlOtp,
      llPinLoginPhone,
      setLlPinLoginPhone,
      llPinLoginPin,
      setLlPinLoginPin,
      llSetPinValue,
      setLlSetPinValue,
      llSendOTP,
      llGoBack,
      llVerifyOTP,
      llSetPin,
      llShowPinLogin,
      llGoBackFromPin,
      llPinLogin,
      pendingTraders,
      verifiedTraders,
      vacatedTraders,
      vacantStalls,
      llVerifyTrader,
      updLb,
      llOpenAdmitSeller,
      asStallLabel,
      asName,
      setAsName,
      asPhone,
      setAsPhone,
      asCategory,
      setAsCategory,
      asSubmitting,
      llSubmitAdmitSeller
    };
    return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlugPayContext.Provider, { value, children });
  }
  function usePlugPay() {
    const ctx = (0, import_react2.useContext)(PlugPayContext);
    if (!ctx) throw new Error("usePlugPay must be used inside <PlugPayProvider>");
    return ctx;
  }

  /* ---- Wiring: registers this group's modals, slots, pages and routes ---- */
  PP_ROUTES.push(
    ["/", "home"]
  );
  PP_registry.register("modals", "toast", Toast, 10);
  PP_registry.register("modals", "net", NetBanner, 20);