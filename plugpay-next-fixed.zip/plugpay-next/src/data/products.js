export var PRODUCTS = [
    { icon: "\u{1F4F1}", name: "Samsung Galaxy A15", price: "KSh 18,500", stock: "4 in stock", cat: "Phones" },
    { icon: "\u{1F4BB}", name: "HP 250 G8 Laptop", price: "KSh 42,000", stock: "2 in stock", cat: "Laptops" },
    { icon: "\u{1F50C}", name: "USB-C Charger 65W", price: "KSh 1,200", stock: "20 in stock", cat: "Accessories" },
    { icon: "\u{1F4F1}", name: "Tecno Camon 20", price: "KSh 22,000", stock: "3 in stock", cat: "Phones" },
    { icon: "\u{1F5A5}\uFE0F", name: "Dell Inspiron 3511", price: "KSh 55,000", stock: "1 in stock", cat: "Laptops" },
    { icon: "\u{1F3A7}", name: "Wireless Earbuds", price: "KSh 2,800", stock: "12 in stock", cat: "Accessories" }
  ];
