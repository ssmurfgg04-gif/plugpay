import { adminDb, requireUser, json, body } from '../../../src/server/supabase.js';

export async function GET() {
  const db = adminDb();
  const r = await db.from('buildings').select('id,name,address,floors,category,maps_url,created_at,updated_at,floors(*, stalls(*))').order('name');
  return r.error ? json({ error: r.error.message }, 500) : json({ buildings: r.data || [] });
}

export async function POST(request) {
  const a = await requireUser(request);
  if (a.error) return a.error;
  const x = await body(request);
  const name = String(x.name || '').trim();
  const address = String(x.address || '').trim();
  const floorCount = Math.max(1, Number(x.floors) || Number(x.floorCount) || 1);
  const totalStalls = Math.max(0, Number(x.stalls) || Number(x.totalStalls) || 0);
  if (!name || !address) return json({ error: 'Building name and address are required' }, 400);

  const db = adminDb();
  const profile = await db.from('profiles').select('roles').eq('id', a.user.id).maybeSingle();
  const roles = profile.data?.roles || [];
  const isLandlord = roles.includes('landlord');
  const r = await db.from('buildings').insert({
    name, address, floors: floorCount,
    category: x.category || null,
    maps_url: x.mapsUrl || x.maps_url || null,
    owner_id: isLandlord ? a.user.id : null,
    agent_id: isLandlord ? null : a.user.id,
  }).select('*').single();
  if (r.error) return json({ error: r.error.message }, 400);

  // Create the complete floor/stall topology in one API operation so the frontend
  // never has to manufacture database IDs.
  const floorRows = [];
  for (let i = 0; i < floorCount; i++) {
    floorRows.push({ building_id: r.data.id, label: i === 0 ? 'Ground Floor' : `Floor ${i}`, floor_number: i });
  }
  const fr = await db.from('floors').insert(floorRows).select('*');
  if (fr.error) return json({ error: fr.error.message }, 400);

  if (totalStalls > 0) {
    const stalls = [];
    for (let i = 0; i < totalStalls; i++) {
      const floor = fr.data[i % fr.data.length];
      const n = Math.floor(i / fr.data.length) + 1;
      stalls.push({ building_id: r.data.id, floor_id: floor.id, stall_number: String(n), status: 'vacant' });
    }
    const sr = await db.from('stalls').insert(stalls).select('*');
    if (sr.error) return json({ error: sr.error.message }, 400);
  }

  const full = await db.from('buildings').select('*, floors(*, stalls(*))').eq('id', r.data.id).single();
  return full.error ? json({ building: r.data }, 201) : json({ building: full.data }, 201);
}
