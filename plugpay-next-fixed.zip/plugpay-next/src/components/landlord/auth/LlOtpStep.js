import * as import_jsx_runtime from "../../../ppJsxRuntime.js";
import { usePlugPay } from "../../../store/context.js";
import { llAuthCodeInput, llAuthIconWrap, llAuthLabel, llAuthLink, llAuthSubmitBtn, llFocusRing } from "./llAuthStyles.js";

export function LlOtpStep() {
  const { llPhone, llMethod, llOtp, setLlOtp, llVerifyOTP, llGoBack } = usePlugPay();
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { padding: "32px" }, children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { textAlign: "center", marginBottom: "20px" }, children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: llAuthIconWrap, children: "\u{1F4AC}" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { fontSize: "22px", fontWeight: 900, color: "var(--ink)", marginBottom: "4px" }, children: "Enter your OTP" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { fontSize: "13px", color: "var(--muted)", lineHeight: "1.55" }, children: [
        "Code sent to",
        " ",
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { style: { color: "var(--ink)" }, children: llPhone.trim() || (llMethod === "email" ? "you@email.com" : "07XX XXX XXX") }),
        " ",
        "via ",
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: llMethod === "email" ? "email" : "SMS" }),
        "."
      ] })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { style: llAuthLabel, children: "ONE-TIME CODE" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      "input",
      {
        type: "tel",
        placeholder: "_ _ _ _ _ _",
        maxLength: 6,
        style: llAuthCodeInput,
        value: llOtp,
        onChange: (e) => setLlOtp(e.target.value),
        onKeyDown: (e) => {
          if (e.key === "Enter") llVerifyOTP();
        },
        ...llFocusRing()
      }
    ),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { style: llAuthSubmitBtn, onClick: () => llVerifyOTP(), children: "Verify & open dashboard \u2192" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { textAlign: "center", fontSize: "12px", color: "var(--muted2)", marginTop: "14px", fontFamily: "var(--fm)" }, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      "a",
      {
        href: "#",
        onClick: (e) => {
          e.preventDefault();
          llGoBack();
        },
        style: llAuthLink,
        children: "\u2190 Change number"
      }
    ) })
  ] });
}
