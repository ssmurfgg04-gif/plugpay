# PlugPay backend setup

The existing PlugPay visual/application layer is preserved. The backend adds PostgreSQL/Supabase persistence, authentication APIs, normalized business records, and a compatibility state bridge.

## 1. Create the database

In Supabase SQL Editor run:

`supabase/schema.sql` (one file: the whole schema, safe to re-run)

The lockdown section at the end of the file removes direct database access for the public anon key and signed-in users. The app only reaches the database through its own API (service-role key), so nothing is lost, and without it anyone holding the public anon key could call the sale function or read every seller column straight from PostgREST.

Set the three `NEXT_PUBLIC_SUPABASE_*` / `SUPABASE_SERVICE_ROLE_KEY` variables **before** `next build` (Next inlines `NEXT_PUBLIC_*` at build time). In Supabase enable Phone auth; phone numbers are normalised to `+254…` before they reach Supabase.

This creates:

- profiles and roles
- buildings → floors → stalls
- sellers and stall assignments
- seller documents
- products/catalogue
- invoices and invoice items
- sales and sale items
- receipts
- reviews
- vouches
- claims/invitations
- riders
- `ui_state` migration bridge
- indexes, timestamps, RLS and atomic sale/invoice functions

## 2. Configure authentication

Enable Phone authentication in Supabase Authentication and configure the SMS provider. The existing PlugPay WhatsApp/SMS choice is retained in the UI, but actual OTP delivery is delegated to the configured authentication provider.

The current API routes are:

- `POST /api/auth/otp/start`
- `POST /api/auth/otp/verify`
- `POST /api/auth/pin/set`
- `POST /api/auth/pin/login`
- `GET /api/auth/session`
- `POST /api/auth/logout`

The browser stores the Supabase access token and sends it as a Bearer token to protected API routes.

## 3. Environment

Copy `.env.example` to `.env.local` and fill in the three Supabase values.

Never expose `SUPABASE_SERVICE_ROLE_KEY` to browser/client code.

## 4. Current backend endpoints

### Discovery/public

- `GET /api/health`
- `GET /api/bootstrap`
- `GET /api/search?q=...`
- `GET /api/sellers/:sellerId`
- `GET /api/seller/receipts/:code`
- `POST /api/reviews`
- `GET /api/reviews/:sellerId`
- `GET /api/claims/:token`

### Authenticated seller

- `GET|PUT /api/seller/profile`
- `GET|POST /api/seller/catalogue`
- `PATCH|DELETE /api/seller/catalogue/:id`
- `GET|POST /api/seller/sales`
- `PATCH /api/seller/sales/:token`

Sale creation is server validated. The server calculates totals and the SQL function updates stock and creates the sale/receipt atomically.

### Authenticated buildings/claims/landlord

- `GET|POST /api/buildings`
- `GET /api/buildings/:id`
- `POST /api/buildings/:id/stalls`
- `GET|POST /api/claims`
- `POST /api/landlord/verify`

### Compatibility persistence

- `GET /api/state?key=...`
- `PUT /api/state`

`usePersisted()` now hydrates from `ui_state` after authentication and writes changes back to PostgreSQL. LocalStorage remains a short-lived UI fallback, not the production source of truth.

## 5. Routing

The existing PlugPay pathname router remains in place. Existing URLs continue to work, including:

- `/`
- `/search`
- `/sellers/:id`
- `/seller/dashboard`
- `/seller/catalogue`
- `/seller/profile`
- `/seller/building`
- `/seller/invoices`
- `/seller/receipts`
- `/seller/invoices/:token`
- `/seller/receipts/:code`
- `/landlord/dashboard`
- `/landlord/buildings`
- `/landlord/sellers`
- `/landlord/stalls`
- `/agent`
- `/agent/buildings`
- `/agent/claims`
- `/agent/onboarding`
- `/claim/:token`
- `/review/:code`
- `/r/:code`
- `/pay/:token`

No landing-page metric/number was changed as part of this backend work.

## 6. Production migration sequence

The compatibility `ui_state` table is intentionally transitional. The next cleanup pass should replace each persisted UI slice with its normalized API one domain at a time:

1. seller profile
2. catalogue/products
3. buildings/floors/stalls
4. claims/assignments
5. sales/invoices/receipts
6. reviews/vouches
7. riders/documents
8. remove the corresponding `ui_state` keys

This avoids breaking the existing visual application while the production records move to the proper relational tables.

## End-to-end data flow

Frontend components call the `/api/*` contract. The route handlers validate the authenticated user and ownership, then use `src/server/supabase.js` to access the normalized Supabase schema. Sales and invoice conversion are atomic PostgreSQL RPCs. Browser state is only a compatibility bridge in `ui_state`; business records live in the normalized tables.
