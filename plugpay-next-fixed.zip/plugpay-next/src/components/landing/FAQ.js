import * as import_jsx_runtime from "../../ppJsxRuntime.js";
import { usePlugPay } from "../../store/context.js";
import { FAQS } from "./landingData.js";

export function FAQ() {
  const { openAuthModal, openMerchantModal } = usePlugPay();
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", { className: "faq", id: "faq", children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "wrap", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "eyebrow", children: "Common questions" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Frequently asked questions" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "faq-list", children: FAQS.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", { className: "faq-item", open: f.open, children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("summary", { className: "faq-q", children: [
          f.q,
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "faq-plus", children: "+" })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "faq-a", children: f.a })
      ] }, f.q)) })
    ] }) }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", { className: "merchant-cta", children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "mc-inner", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "mc-lead", children: "Your stall is already on PlugPay. Sign in with your WhatsApp number, complete your profile, and go live in minutes." }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "mc-actions", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { className: "mc-btn-solid", onClick: () => openAuthModal(), children: "Sign in to your stall" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { className: "mc-btn-outline", onClick: () => openMerchantModal(), children: "See a live profile first" })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "mc-caption", children: "No password \xB7 Any phone number works \xB7 Buyers never sign up \xB7 Nairobi first" })
    ] }) })
  ] });
}
