import { usePlugPay } from "../../../store/context.js";
import { PR, h } from "../../common/h.js";
import { floorLabel } from "../../common/ui.js";

export function ObReview() {
  var pp = usePlugPay();
  var list = pp.obMerchantList;
  return h(PR.Fragment, null,
    h("div", { className: "ob-section-divider" }, "\u2705 Ready to publish"),
    h("div", { className: "ob-summary-card" },
      h("div", { className: "ob-summary-row" }, h("span", { className: "ob-summary-label" }, "Building"), h("span", { className: "ob-summary-val" }, (pp.obBldgName || "\u2014") + " \u00b7 " + (pp.obFloorsCount || "\u2014") + " floors \u00b7 " + pp.obTotalStalls + " stalls")),
      h("div", { className: "ob-summary-row" }, h("span", { className: "ob-summary-label" }, "Sellers registered"), h("span", { className: "ob-summary-val" }, list.length))),
    list.length > 0 && h("div", { className: "ob-merchant-list", style: { marginTop: 10 } }, list.map(function (m) {
      return h("div", { key: m.id, className: "ob-merchant-row" },
        h("div", { className: "ob-merchant-av", style: { background: m.color } }, m.initials),
        h("div", { style: { flex: 1, minWidth: 0 } }, h("div", { className: "ob-merchant-name" }, m.biz), h("div", { className: "ob-merchant-stall" }, floorLabel(m.floor) + ", Stall " + m.stallNum + " \u00b7 " + m.type)));
    })),
    h("div", { style: { textAlign: "center", marginTop: 12, fontSize: 11, color: "var(--muted)", fontFamily: "var(--fm)" } }, "Or send a self-registration link: ", h("strong", { style: { color: "var(--accent)" } }, "plug.pay/join/anniversary-towers")),
    h("div", { className: "ob-doc-note", style: { marginTop: 10 } }, "\u26A1 Publishing goes live for every seller above at once. Buyers can then search this building and see all registered merchants."));
}
