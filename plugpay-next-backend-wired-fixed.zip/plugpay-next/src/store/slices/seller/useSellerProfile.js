/* useSellerProfile — "sellerProfile" group of the PlugPay store, extracted from PlugPayProvider.
   Statements are the original ones, in their original relative order. Names owned by other groups arrive through the shared
   per-render context object (ctx): groups that run earlier are destructured below, groups that run later are read lazily as ctx.name. */
import * as import_react from "react";
import { navigate } from "../../../lib/router.js";
import { apiFetch, getAuthToken } from "../../../lib/backend.js";
import { usePersisted } from "../../usePersisted.js";

export function useSellerProfile(ctx) {
    const { closeModal, finishLoginRef, setMerchantLoggedIn, setRiders, setShowVacateForm, setVacateBuilding, setVacateStall, showToast, vacateBuilding, vacateStall } = ctx;
    const [sellerProfile, setSellerProfile] = usePersisted("seller", {
      bizName: "Wanjiku Electronics",
      ownerName: "Jane Wanjiku",
      role: "Electronics Retailer",
      bio: "Specializing in phones, laptops & repairs. In business since 2016.",
      street: "Moi Avenue, Nairobi CBD",
      phone: "+254 712 345 678",
      established: "2016 \xB7 8 years in business",
      whatsapp: "+254 712 345 678",
      instagram: "@wanjiku.electronics",
      tiktok: "@wanjikuelectronics",
      facebook: "/WanjikuElectronics",
      paybill: "2332323",
      account: "20262026",
      about: "We specialize in selling and repairing electronics, computers, and mobile phones. All products come with a 30-day warranty. Delivery available across Kenya via M-Pesa payment.",
      llPhoneVerified: true
    });
    const updateSellerProfile = (0, import_react.useCallback)((patch) => {
      setSellerProfile((p) => ({ ...p, ...patch }));
      apiFetch('/api/seller/profile',{method:'PUT',body:JSON.stringify(patch)}).catch((e)=>showToast(e.message));
      showToast("Profile updated \u2713");
    }, [showToast]);
    // The sellers table is the source of truth (buyers read from it). Load the saved profile when signed in and on page load.
    const mergeSellerFromServer = (0, import_react.useCallback)(() => {
      if (!getAuthToken()) return;
      apiFetch('/api/seller/profile').then((r) => {
        const s = r && r.seller; if (!s) return;
        setSellerProfile((p) => ({ ...p, bizName: s.business_name, ownerName: s.owner_name, phone: s.phone, whatsapp: s.whatsapp || s.phone, role: s.role || p.role || '', bio: s.bio || '', street: s.address || '', established: s.established_year ? String(s.established_year) : '', about: s.about || '', instagram: s.instagram || '', tiktok: s.tiktok || '', facebook: s.facebook || '', payMethod: s.pay_method || 'Paybill', paybill: s.paybill || '', account: s.account_number || '', llPhoneVerified: s.verification_status === 'verified' }));
      }).catch(() => {});
    }, []);
    (0, import_react.useEffect)(() => {
      mergeSellerFromServer();
      window.addEventListener('pp:auth', mergeSellerFromServer);
      return () => window.removeEventListener('pp:auth', mergeSellerFromServer);
    }, [mergeSellerFromServer]);
    const setLandlordPhoneVerified = (0, import_react.useCallback)((v) => {
      setSellerProfile((p) => ({ ...p, llPhoneVerified: v }));
      showToast(v ? "Phone number & profile confirmed as matching the real owner \u2713" : "Landlord verification revoked");
    }, [showToast]);
    const removeRider = (0, import_react.useCallback)((i) => {
      setRiders((r) => r.filter((_, idx) => idx !== i));
      showToast("Rider removed");
    }, [showToast]);
    finishLoginRef.current = () => {
      setMerchantLoggedIn(true);
      mergeSellerFromServer();
      const tok = ctx.claimTokenRef.current;
      if (tok) { ctx.claimTokenRef.current = null; ctx.setClaimInfo(null); ctx.applyClaim(tok); }
      closeModal("modal-register");
      navigate("/seller/dashboard");
    };
    const confirmVacate = () => {
      if (!vacateBuilding.trim() || !vacateStall.trim()) {
        showToast("Enter the building and stall you're moving to");
        return;
      }
      ctx.changeStall(vacateBuilding.trim(), vacateStall.trim());
      showToast(`Moved to ${vacateBuilding}, ${vacateStall} \u2014 your trust score, reviews, vouches, sales history & documents moved with you \u2713 Landlord verification there starts as Pending.`);
      setVacateBuilding("");
      setVacateStall("");
      setShowVacateForm(false);
    };
    return {
      sellerProfile,
      setSellerProfile,
      updateSellerProfile,
      setLandlordPhoneVerified,
      removeRider,
      confirmVacate
    };
}
