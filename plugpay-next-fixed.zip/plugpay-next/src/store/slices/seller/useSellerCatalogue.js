/* useSellerCatalogue — "sellerCatalogue" group of the PlugPay store, extracted from PlugPayProvider.
   Statements are the original ones, in their original relative order. Names owned by other groups arrive through the shared
   per-render context object (ctx): groups that run earlier are destructured below, groups that run later are read lazily as ctx.name. */
import * as import_react from "react";
import { PRODUCTS } from "../../../data/products.js";
import { usePersisted } from "../../usePersisted.js";

export function useSellerCatalogue(ctx) {
    const { invoicesList, invoicesListRef, showToast, stockRef } = ctx;
    const catIdRef = (0, import_react.useRef)(1);
    const [catalogueItems, setCatalogueItems] = usePersisted("catalogue",
      () => PRODUCTS.map((p) => ({ id: "ci" + catIdRef.current++, icon: p.icon, image: "", name: p.name, price: p.price.replace(/[^0-9]/g, ""), category: p.cat, stock: parseInt(p.stock, 10) || 0 }))
    );
    stockRef.current = catalogueItems;
    invoicesListRef.current = invoicesList;
    const addCatalogueItem = (0, import_react.useCallback)((item) => {
      if (!String(item.name || "").trim() || !item.price) {
        showToast("Enter a product name and price");
        return false;
      }
      setCatalogueItems((c) => [{ id: "ci" + Date.now().toString(36) + (catIdRef.current++), icon: "\u{1F4E6}", image: item.image || "", name: item.name.trim(), price: String(item.price), category: (item.category || "").trim() || "General", stock: Number(item.stock) || 0 }, ...c]);
      showToast(`${item.name} added to your catalogue \u2713`);
      return true;
    }, [showToast]);
    const updateCatalogueItem = (0, import_react.useCallback)((id, patch) => {
      setCatalogueItems((c) => c.map((x) => x.id === id ? { ...x, ...patch } : x));
    }, []);
    const removeCatalogueItem = (0, import_react.useCallback)((id) => {
      setCatalogueItems((c) => c.filter((x) => x.id !== id));
      showToast("Product removed");
    }, [showToast]);
    return {
      setCatalogueItems,
      catalogueItems,
      updateCatalogueItem,
      addCatalogueItem,
      removeCatalogueItem
    };
}
