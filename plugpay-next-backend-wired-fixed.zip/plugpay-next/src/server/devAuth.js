// ─────────────────────────────────────────────────────────────────────────────────────────────
// DEVELOPMENT-ONLY LOGIN. While DEV_AUTH=true:
//   • any phone number signs in with OTP  123456   (no SMS is sent)
//   • any phone number signs in with PIN  121212   (also the default PIN of every new account)
// This is an authentication bypass: anyone who knows a seller's phone number could log in as them.
// It is OFF unless DEV_AUTH=true is set, and it is forced OFF on Vercel production deployments.
// Remove this file and its three call sites (auth/otp/start, auth/otp/verify, auth/pin/login) before launch.
// ─────────────────────────────────────────────────────────────────────────────────────────────
import { adminDb, authAdminFetch, authPasswordLogin } from './supabase.js';

export const DEV_OTP = '123456';
export const DEV_PIN = '121212';

export function devAuthEnabled() {
  return process.env.DEV_AUTH === 'true' && process.env.VERCEL_ENV !== 'production';
}

let warned = false;
function warnOnce() {
  if (warned) return;
  warned = true;
  console.warn('[PlugPay] DEV_AUTH is ON: OTP 123456 and PIN 121212 work for ANY phone number. Never enable this in production.');
}

// Make sure a confirmed Supabase user exists for this phone and that its password is the dev PIN.
async function ensureUser(phone, role) {
  warnOnce();
  const created = await authAdminFetch('/users', {
    method: 'POST',
    body: JSON.stringify({ phone, phone_confirm: true, password: DEV_PIN, user_metadata: { requested_role: role } }),
  });
  if (!created.error) return { data: created.data, error: null };
  if (created.status !== 422 && created.status !== 409) return { data: null, error: created.error };
  // Already registered: look the user up via its profile row, then reset its password to the dev PIN.
  const digits = phone.replace(/\D/g, '');
  const { data: profile } = await adminDb().from('profiles').select('id').or(`phone.eq.${digits},phone.eq.+${digits}`).limit(1).maybeSingle();
  if (!profile?.id) return { data: null, error: new Error('Account exists but could not be found') };
  const updated = await authAdminFetch(`/users/${profile.id}`, { method: 'PUT', body: JSON.stringify({ password: DEV_PIN, phone_confirm: true }) });
  return updated.error ? { data: null, error: updated.error } : { data: updated.data, error: null };
}

export async function devEnsureUser(phone, role = 'seller') {
  return ensureUser(phone, role);
}

// Returns the same shape as authVerifyOtp / authPasswordLogin (a flat GoTrue session).
export async function devSession(phone, role = 'seller') {
  const made = await ensureUser(phone, role);
  if (made.error) return { data: null, error: made.error };
  return authPasswordLogin(phone, DEV_PIN);
}
