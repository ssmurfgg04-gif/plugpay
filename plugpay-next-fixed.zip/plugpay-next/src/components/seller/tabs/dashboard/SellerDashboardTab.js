import * as import_react from "react";
import { usePlugPay } from "../../../../store/context.js";
import { PR, h } from "../../../common/h.js";
import { Slot } from "../../../common/registry.js";
import { Link } from "../../../common/routing.js";
import { SellerSalesSummary } from "./SellerSalesSummary.js";
import { salesDocStatus } from "../sales/salesShared.js";

var DashCtx = import_react.createContext(null);

export function SellerDashboardTabSection1() {
  var __c = import_react.useContext(DashCtx) || {}; var mode = __c.mode, setMode = __c.setMode, top = __c.top, todayName = __c.todayName;
  return h("div", { className: "dx-top" },
      h("div", null, h("div", { className: "dx-date" }, todayName), h("div", { className: "dx-h" }, "Overview")),
      h("div", { className: "dx-seg" }, ["daily", "weekly", "yearly"].map(function (m) { return h("button", { key: m, className: mode === m ? "on" : "", onClick: function () { setMode(m); } }, m === "daily" ? "Daily" : m === "weekly" ? "Weekly" : "Yearly"); })));
}

export function SellerDashboardTabSection2() {
  var __c = import_react.useContext(DashCtx) || {}; var mode = __c.mode, money = __c.money, n = __c.n, k = __c.k, now = __c.now, yr = __c.yr, series = __c.series, cur = __c.cur, curN = __c.curN, maxAmt = __c.maxAmt, delta = __c.delta, W = __c.W, H = __c.H, bw = __c.bw;
  return h("div", { className: "dx-card" },
      h("div", { className: "dx-k" }, mode === "daily" ? "Sales \u00b7 this week (Mon\u2013Sun)" : mode === "weekly" ? "Sales \u00b7 last 6 weeks" : "Sales \u00b7 " + yr + " by month"),
      h("div", { className: "dx-big" }, money(cur)),
      delta !== null && h("div", { className: "dx-delta " + (delta >= 0 ? "up" : "down") }, (delta >= 0 ? "\u2191 " : "\u2193 ") + Math.abs(delta) + "% vs previous period"),
      h("svg", { className: "dx-chart", viewBox: "0 0 " + W + " " + (H + 18), preserveAspectRatio: "none" },
        series.map(function (s, j) {
          var bh = Math.max(2, s.amt / maxAmt * H);
          return h("g", { key: j },
            h("rect", { className: "dx-bar" + (s.latest ? " now" : ""), x: j * bw + bw * 0.2, y: H - bh, width: bw * 0.6, height: bh, rx: 3 }),
            h("text", { className: "dx-lbl", x: j * bw + bw / 2, y: H + 13, textAnchor: "middle" }, s.label));
        })),
      h("div", { className: "dx-mini" },
        h("div", null, h("b", null, curN), h("span", null, "Items sold")),
        h("div", null, h("b", null, money(curN ? cur / curN : 0)), h("span", null, "Avg. sale")),
        h("div", null, h("b", null, (series.filter(function (x) { return x.latest; })[0] || { n: 0 }).n), h("span", null, mode === "daily" ? "Today" : mode === "weekly" ? "This week" : "This month"))));
}

export function SellerDashboardTabSection3() {
  var __c = import_react.useContext(DashCtx) || {}; var money = __c.money, k = __c.k, i = __c.i, cur = __c.cur, top = __c.top, topMax = __c.topMax;
  return h("div", { className: "dx-card" },
      h("div", { className: "dx-k" }, "Sales by product"),
      top.length === 0 ? h("div", { className: "dx-empty" }, "No sales in this period.") : top.map(function (t) {
        return h("div", { key: t.name, className: "dx-row" },
          h("div", { className: "dx-rowtop" }, h("span", { className: "dx-name" }, t.name), h("b", null, money(t.amt))),
          h("div", { className: "dx-track" }, h("i", { style: { width: Math.max(4, t.amt / topMax * 100) + "%" } })),
          h("div", { className: "dx-sub" }, t.units + (t.units === 1 ? " unit" : " units") + " \u00b7 " + (cur ? Math.round(t.amt / cur * 100) : 0) + "% of sales"));
      }));
}

export function SellerDashboardTabSection4() {
  var __c = import_react.useContext(DashCtx) || {}; var money = __c.money, k = __c.k, i = __c.i, catAgg = __c.catAgg;
  return h("div", { className: "dx-card" },
      h("div", { className: "dx-k" }, "Sales by category"),
      Object.keys(catAgg).length === 0 ? h("div", { className: "dx-empty" }, "No categorised sales in this period.") : Object.keys(catAgg).sort(function (a, b) { return catAgg[b] - catAgg[a]; }).map(function (k) {
        var mx = Math.max.apply(null, Object.keys(catAgg).map(function (x) { return catAgg[x]; }));
        return h("div", { key: k, className: "dx-row" }, h("div", { className: "dx-rowtop" }, h("span", { className: "dx-name" }, k), h("b", null, money(catAgg[k]))), h("div", { className: "dx-track" }, h("i", { style: { width: Math.max(4, catAgg[k] / mx * 100) + "%" } })));
      }));
}

export function SellerDashboardTabSection5() {
  var pp = usePlugPay();
  var receipts = pp.receiptsList || [], invoices = pp.invoicesList || [];
  function toRow(kind, d) {
    var isInv = kind === "invoice";
    return {
      key: isInv ? d.token : d.code,
      code: isInv ? (d.number || "Invoice \u00b7 " + (d.buyerName || "Buyer")) : d.code,
      state: salesDocStatus(kind, d),
      total: Number(d.total) || 0,
      to: isInv ? "/seller/invoices/" + encodeURIComponent(d.token) : "/seller/receipts/" + encodeURIComponent(d.code)
    };
  }
  function docCol(title, list) {
    return h("div", { className: "sp-document-column" },
      h("div", { className: "sp-document-heading" }, title),
      list.length === 0 && h("div", { className: "sales-doc-sub" }, "None yet"),
      list.map(function (r) {
        return h(Link, { key: r.key, to: r.to, className: "sp-document-row" },
          h("span", null, r.code),
          h("strong", null, "KSh " + r.total.toLocaleString()),
          h("em", { className: r.state === "COMPLETE" ? "complete" : "pending" }, r.state));
      }));
  }
  return h("div", { className: "dx-card" },
    h("div", { className: "dx-head" },
      h("div", { className: "dx-k", style: { margin: 0 } }, "Invoices & receipts"),
      h("span", { className: "dx-chip ok" }, (receipts.length + invoices.length) + " records")),
    h(SellerSalesSummary, null),
    h("div", { className: "sp-document-summary" },
      docCol("Receipts \u00b7 " + receipts.length, receipts.slice(0, 5).map(function (d) { return toRow("receipt", d); })),
      docCol("Invoices \u00b7 " + invoices.length, invoices.slice(0, 5).map(function (d) { return toRow("invoice", d); }))),
    h("div", { className: "dx-btns" },
      h(Link, { to: "/seller/receipts", className: "bd-btn fill" }, h("span", null, "View all sales"), h("span", { className: "a" }, "\u2192"))));
}

export function SellerDashboardTabSection6() {
  var __c = import_react.useContext(DashCtx) || {}; var pp = __c.pp, k = __c.k, i = __c.i, stock = __c.stock, stockMax = __c.stockMax, lowCount = __c.lowCount;
  return h("div", { className: "dx-card" },
      h("div", { className: "dx-head" }, h("div", { className: "dx-k", style: { margin: 0 } }, "Stock levels"), h("span", { className: "dx-chip " + (lowCount ? "warn" : "ok") }, lowCount ? lowCount + " need restock" : "All healthy")),
      stock.map(function (c) {
        var st = c.stock === 0 ? "out" : c.stock <= 5 ? "low" : "ok";
        return h("div", { key: c.id, className: "dx-row" },
          h("div", { className: "dx-rowtop" }, h("span", { className: "dx-name" }, c.name), h("span", { className: "dx-st " + st }, c.stock === 0 ? "Out of stock" : c.stock + " left")),
          h("div", { className: "dx-track" }, h("i", { className: st, style: { width: Math.max(3, c.stock / stockMax * 100) + "%" } })));
      }),
      h("div", { className: "dx-btns" },
        h(Link, { to: "/seller/catalogue", className: "bd-btn fill" }, h("span", null, "Manage catalogue"), h("span", { className: "a" }, "\u2192")),
        h("button", { className: "bd-btn pill", onClick: function () { pp.openBuildingModal(pp.stallAssignment && pp.stallAssignment.building); } }, h("span", null, "View building"), h("span", { className: "a" }, "\u2192"))));
}

export function SellerDashboardTabSection7() {
  var __c = import_react.useContext(DashCtx) || {}; var demo = __c.demo;
  return demo && h("div", { className: "dx-note" }, "Showing sample data. Record a sale and your real numbers appear here.");
}

export function SellerDashboardTab() {
  var pp = usePlugPay();
  var _m = PR.useState("daily"), mode = _m[0], setMode = _m[1];
  var cat = pp.catalogueItems;
  var money = function (n) { return "KSh " + Math.round(n).toLocaleString(); };
  var rows = [];
  pp.sentReceipts.forEach(function (r) { (r.items || []).forEach(function (it) { rows.push({ name: it.name, amt: Number(it.price) || 0, qty: Number(it.qty) || 1, cat: it.category || (it.productId ? "" : "Not in catalogue"), at: new Date(r.createdAt) }); }); });
  var demo = rows.length === 0;
  if (demo && cat.length) {
    var seed = 7, rnd = function () { seed = (seed * 9301 + 49297) % 233280; return seed / 233280; };
    for (var d = 0; d < 800; d++) {
      var n = 1 + Math.floor(rnd() * 4);
      for (var k = 0; k < n; k++) {
        var p = cat[Math.floor(rnd() * rnd() * cat.length)];
        var dt = new Date(); dt.setHours(9 + Math.floor(rnd() * 9), 0, 0, 0); dt.setDate(dt.getDate() - d);
        rows.push({ name: p.name, amt: Number(p.price) || 0, qty: 1, cat: p.category, at: dt });
      }
    }
  }
  var DAY = 86400000, i, now = new Date(); now.setHours(0, 0, 0, 0);
  var addD = function (d0, n) { var x = new Date(d0); x.setDate(x.getDate() + n); return x; };
  var wkStart = addD(now, -((now.getDay() + 6) % 7));
  var DN = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"], MN = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  var starts = [], ends = [], labels = [], prevStart, prevEnd, yr = now.getFullYear();
  if (mode === "daily") {
    for (i = 0; i < 7; i++) { starts.push(addD(wkStart, i).getTime()); ends.push(addD(wkStart, i + 1).getTime()); labels.push(DN[i]); }
    prevStart = addD(wkStart, -7).getTime(); prevEnd = wkStart.getTime();
  } else if (mode === "weekly") {
    for (i = 0; i < 6; i++) { var ws = addD(wkStart, (i - 5) * 7); starts.push(ws.getTime()); ends.push(addD(ws, 7).getTime()); labels.push(ws.getDate() + " " + MN[ws.getMonth()]); }
    prevStart = addD(wkStart, -77).getTime(); prevEnd = starts[0];
  } else {
    for (i = 0; i < 12; i++) { starts.push(new Date(yr, i, 1).getTime()); ends.push(new Date(yr, i + 1, 1).getTime()); labels.push(MN[i]); }
    prevStart = new Date(yr - 1, 0, 1).getTime(); prevEnd = starts[0];
  }
  var count = starts.length, nowT = Date.now();
  var series = labels.map(function (l, idx) { return { amt: 0, n: 0, label: l, latest: nowT >= starts[idx] && nowT < ends[idx] }; });
  var catAgg = {}; var cur = 0, curN = 0, prev = 0, prod = {};
  rows.forEach(function (r) {
    var t = r.at.getTime();
    if (t >= prevStart && t < prevEnd) { prev += r.amt; return; }
    for (var bi = 0; bi < count; bi++) {
      if (t >= starts[bi] && t < ends[bi]) {
        series[bi].amt += r.amt; series[bi].n += (r.qty || 1); cur += r.amt; curN += (r.qty || 1);
        var q = prod[r.name] || (prod[r.name] = { name: r.name, units: 0, amt: 0 }); q.units += (r.qty || 1); q.amt += r.amt; var ck = r.cat || "General"; catAgg[ck] = (catAgg[ck] || 0) + r.amt;
        break;
      }
    }
  });
  var maxAmt = Math.max.apply(null, series.map(function (s) { return s.amt; }).concat([1]));
  var delta = prev > 0 ? Math.round((cur - prev) / prev * 100) : null;
  var top = Object.keys(prod).map(function (k) { return prod[k]; }).sort(function (a, b) { return b.amt - a.amt; }).slice(0, 6);
  var topMax = top.length ? top[0].amt : 1;
  var stock = cat.slice().sort(function (a, b) { return a.stock - b.stock; });
  var stockMax = Math.max.apply(null, cat.map(function (c) { return c.stock; }).concat([1]));
  var lowCount = cat.filter(function (c) { return c.stock <= 5; }).length;
  var W = 320, H = 110, bw = W / count;
  var todayName = new Date().toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long" });
  
  var __v = { pp: pp, _m: _m, mode: mode, setMode: setMode, cat: cat, money: money, rows: rows, demo: demo, seed: seed, rnd: rnd, d: d, n: n, k: k, p: p, dt: dt, DAY: DAY, i: i, now: now, addD: addD, wkStart: wkStart, DN: DN, MN: MN, starts: starts, ends: ends, labels: labels, prevStart: prevStart, prevEnd: prevEnd, yr: yr, ws: ws, count: count, nowT: nowT, series: series, catAgg: catAgg, cur: cur, curN: curN, prev: prev, prod: prod, maxAmt: maxAmt, delta: delta, top: top, topMax: topMax, stock: stock, stockMax: stockMax, lowCount: lowCount, W: W, H: H, bw: bw, todayName: todayName };
  return h(DashCtx.Provider, { value: __v }, h("div", { className: "dx" },
    h(Slot, { name: "seller.dashboard" })
  ));
}
