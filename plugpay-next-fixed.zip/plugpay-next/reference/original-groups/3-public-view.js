
  /* ============================================================================
     PUBLIC VIEW (public seller profile and its tabs)
     ============================================================================ */
  var merchants = [
    { type: "merchant", name: "Jane Mwangi", sub: "Fashion \xB7 Anniversary Towers \xB7 Floor 3, Stall 301", initials: "JM", color: "#51104a", badge: "Verified", badgeClass: "rcb-verified", rating: "4.9", sales: 847, reviews: 38, vouches: 38 },
    { type: "merchant", name: "Peter Otieno", sub: "Electronics \xB7 Anniversary Towers \xB7 Floor 3, Stall 302", initials: "PO", color: "#185FA5", badge: "Verified", badgeClass: "rcb-verified", rating: "4.8", sales: 312, reviews: 24, vouches: 18 },
    { type: "merchant", name: "David Mutua", sub: "Hardware \xB7 Anniversary Towers \xB7 Floor 2, Stall 202", initials: "DM", color: "#534AB7", badge: "Verified", badgeClass: "rcb-verified", rating: "4.7", sales: 560, reviews: 41, vouches: 52 },
    { type: "merchant", name: "Amina Kibe", sub: "Food \xB7 Anniversary Towers \xB7 Floor 3, Stall 303", initials: "AK", color: "#BA7517", badge: "Verified", badgeClass: "rcb-verified", rating: "4.6", sales: 210, reviews: 17, vouches: 8 },
    { type: "merchant", name: "Grace Akinyi", sub: "Beauty \xB7 Lonrho House \xB7 Floor 1, Stall 5", initials: "GA", color: "#D85A30", badge: "Verified", badgeClass: "rcb-verified", rating: "4.9", sales: 428, reviews: 33, vouches: 24 }
  ];
  function BuildingTab() {
    const { requireSellerLogin, openBuildingModal, stallHistory, openSellerRef } = usePlugPay();
    const sv = useSV();
    const sellerStats = sv.stats, stallAssignment = sv.assignment;
    return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "modal-tab-body on", style: { padding: "16px" }, children: [
      h(BuildingViewContainer, { id: stallAssignment.building }),
      h("div", { className: "bldg-card-redesign building-header-card", style: { margin: "14px 0" } }, h("div", { className: "bldg-card-grid", style: { gridTemplateColumns: "1fr 1fr" } },
        h("div", { className: "bldg-card-stat" }, h("div", { className: "bldg-card-n" }, sellerStats.avg.toFixed(1) + "\u2605"), h("div", { className: "bldg-card-l" }, "This merchant")),
        h("div", { className: "bldg-card-stat" }, h("div", { className: "bldg-card-n" }, String(sellerStats.trust)), h("div", { className: "bldg-card-l" }, "Trust score")))),
      h("div", { className: "rv-note", style: { marginTop: 0, marginBottom: 14 } }, h("span", null, "\uD83D\uDD12"), h("span", null, h("b", null, "A seller's record travels with them. "), "Trust score, reviews, sales history and documents belong to the seller. If they move stalls or buildings it all comes along; only the landlord verification at the new place starts as Pending.")),
      sv.own && stallHistory.length > 0 && h("div", { className: "vouch-list", style: { marginBottom: 14 } }, stallHistory.map(function (x, i) { return h("div", { className: "vouch-item", key: i }, h("div", { className: "vouch-av", style: { background: "var(--muted2)" } }, "\uD83D\uDCCD"), h("div", { className: "vouch-info" }, h("div", { className: "vouch-name" }, "Previously " + x.building), h("div", { className: "vouch-sub" }, x.loc + " \u00b7 until " + new Date(x.until).toLocaleDateString()))); })),
    ] });
  }
  var PRODUCTS = [
    { icon: "\u{1F4F1}", name: "Samsung Galaxy A15", price: "KSh 18,500", stock: "4 in stock", cat: "Phones" },
    { icon: "\u{1F4BB}", name: "HP 250 G8 Laptop", price: "KSh 42,000", stock: "2 in stock", cat: "Laptops" },
    { icon: "\u{1F50C}", name: "USB-C Charger 65W", price: "KSh 1,200", stock: "20 in stock", cat: "Accessories" },
    { icon: "\u{1F4F1}", name: "Tecno Camon 20", price: "KSh 22,000", stock: "3 in stock", cat: "Phones" },
    { icon: "\u{1F5A5}\uFE0F", name: "Dell Inspiron 3511", price: "KSh 55,000", stock: "1 in stock", cat: "Laptops" },
    { icon: "\u{1F3A7}", name: "Wireless Earbuds", price: "KSh 2,800", stock: "12 in stock", cat: "Accessories" }
  ];
  var FILTERS = ["All", "Phones", "Laptops", "Accessories"];
  function CatalogueTab() {
    const { showToast, openAuthModal, merchantLoggedIn } = usePlugPay();
    const catalogueItems = useSV().catalogue;
    const PRODUCTS = catalogueItems.map((i) => ({ icon: i.icon, image: i.image, name: i.name, price: "KSh " + Number(i.price).toLocaleString(), stock: i.stock > 0 ? i.stock + " in stock" : "Out of stock", cat: i.category }));
    const FILTERS = ["All", ...Array.from(new Set(PRODUCTS.map((p) => p.cat)))];
    const [filter, setFilter] = (0, import_react6.useState)("All");
    const items = filter === "All" ? PRODUCTS : PRODUCTS.filter((p) => p.cat === filter);
    return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "modal-tab-body on", style: { padding: "12px" }, children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "cat-filters", children: FILTERS.map((f) => {
        const count = f === "All" ? PRODUCTS.length : PRODUCTS.filter((p) => p.cat === f).length;
        return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", { className: `cat-filter${filter === f ? " on" : ""}`, onClick: () => setFilter(f), children: [
          f,
          " (",
          count,
          ")"
        ] }, f);
      }) }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "cat-grid", children: items.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "cat-item", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "cat-img", children: p.image ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", { src: p.image, alt: p.name, style: { width: "100%", height: "100%", objectFit: "cover" } }) : p.icon }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "cat-body", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "cat-name", children: p.name }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "cat-price", children: p.price }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "cat-stock", children: p.stock }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { className: "cat-buy", onClick: () => showToast(`Opening WhatsApp checkout for ${p.name} \u2713`), children: "Checkout via WhatsApp" })
        ] })
      ] }, p.name)) })
    ] });
  }
  var ProfCtx = import_react.createContext(null);
  function ProfileTabSection1() {
    var __c = import_react.useContext(ProfCtx) || {}; var sellerProfile = __c.sellerProfile;
    return (0, import_jsx_runtime.jsxs)("div", { className: "tp-card tp-info-card", style: { margin: "9px 9px 0" }, children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-info-row", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-info-ico", style: { background: "#fff8e1" }, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "\u{1F4CD}" }) }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-info-text", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-info-label", children: "LOCATION" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-info-val", children: sellerProfile.street })
          ] })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-info-row", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-info-ico", style: { background: "#f8f1f7" }, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "\u{1F4DE}" }) }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-info-text", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-info-label", children: "PHONE" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-info-val", children: sellerProfile.phone })
          ] })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-info-row", style: { border: "none" }, children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-info-ico", style: { background: "#ede7f6" }, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "\u{1F4C5}" }) }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-info-text", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-info-label", children: "ESTABLISHED" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-info-val", children: sellerProfile.established })
          ] })
        ] })
      ] });
  }
  function ProfileTabSection2() {
    var __c = import_react.useContext(ProfCtx) || {}; var showToast = __c.showToast, sellerProfile = __c.sellerProfile;
    return (0, import_jsx_runtime.jsxs)("div", { className: "tp-card", style: { margin: "9px 9px 0", padding: "13px" }, children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-section-title", children: "Social Media" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-social-list", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-social-row", onClick: () => showToast("Opening WhatsApp\u2026"), children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "tp-social-ico", style: { background: "#25D36622", color: "#1a8a4a" }, children: "\u{1F4AC}" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "tp-social-handle", children: sellerProfile.whatsapp })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-social-row", onClick: () => showToast("Opening Instagram\u2026"), children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "tp-social-ico", style: { background: "#f58529", color: "#fff" }, children: "\u{1F4F7}" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "tp-social-handle", children: sellerProfile.instagram })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-social-row", onClick: () => showToast("Opening TikTok\u2026"), children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "tp-social-ico", style: { background: "#00000014", color: "#000" }, children: "\u{1F3B5}" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "tp-social-handle", children: sellerProfile.tiktok })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-social-row", onClick: () => showToast("Opening Facebook\u2026"), children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "tp-social-ico", style: { background: "#1877F222", color: "#1877F2" }, children: "f" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "tp-social-handle", children: sellerProfile.facebook })
          ] })
        ] })
      ] });
  }
  function ProfileTabSection3() {
    var __c = import_react.useContext(ProfCtx) || {}; var showToast = __c.showToast, copyText = __c.copyText, sellerProfile = __c.sellerProfile;
    return sellerProfile.paybill && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-card tp-pay-info-card", style: { margin: "9px 9px 0" }, children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-pay-info-header", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-pay-info-title", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "tp-pay-info-icon", children: "\u{1F4B3}" }),
            " Payment Information"
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-pay-info-badge", children: "M-Pesa" })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-pay-info-rows", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-pay-info-row", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-pay-info-ico", style: { background: "#f8f1f7" }, children: "\u{1F3E6}" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-pay-info-text", children: [
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-pay-info-label", children: "PAYBILL NUMBER" }),
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-pay-info-val", children: sellerProfile.paybill })
            ] }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { className: "tp-copy-btn", onClick: () => copyText(sellerProfile.paybill, "Paybill copied!"), children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Copy" }) })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-pay-info-row", style: { border: "none" }, children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-pay-info-ico", style: { background: "#e3f2fd" }, children: "\u{1F522}" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-pay-info-text", children: [
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-pay-info-label", children: "ACCOUNT NUMBER" }),
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-pay-info-val", children: sellerProfile.account })
            ] }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { className: "tp-copy-btn", onClick: () => copyText(sellerProfile.account, "Account copied!"), children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Copy" }) })
          ] })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", { className: "tp-pay-now-btn", onClick: () => showToast("Opening M-Pesa payment for " + sellerProfile.bizName + "\u2026"), children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Pay via M-Pesa" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "tp-pay-arrow", children: "\u2192" })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-pay-note", children: [
          "Send to Paybill ",
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: sellerProfile.paybill }),
          ", Account ",
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: sellerProfile.account }),
          ", then ask the seller for your receipt."
        ] })
      ] });
  }
  function ProfileTabSection4() {
    var __c = import_react.useContext(ProfCtx) || {}; var sellerProfile = __c.sellerProfile;
    return (0, import_jsx_runtime.jsxs)("div", { className: "tp-card", style: { margin: "9px 9px 0", padding: "13px" }, children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-section-title", children: "About the Business" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-section-body", children: sellerProfile.about })
      ] });
  }
  function ProfileTabSection5() {
    var __c = import_react.useContext(ProfCtx) || {}; var sv = __c.sv;
    return (0, import_jsx_runtime.jsxs)("div", { className: "tp-card", style: { margin: "9px 9px 9px", padding: "13px" }, children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-section-title", children: "Verification Documents" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-docs-grid", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-doc-item", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-doc-label", children: "ID FRONT" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-doc-badge", children: sv.own || !sv.pending ? "\u2713 Verified" : "\u23F3 Pending" })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-doc-item", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-doc-label", children: "ID BACK" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-doc-badge", children: sv.own || !sv.pending ? "\u2713 Verified" : "\u23F3 Pending" })
          ] })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-doc-item tp-doc-wide", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-doc-label", children: "BUSINESS LICENSE" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-doc-badge", children: sv.own || !sv.pending ? "\u2713 Verified" : "\u23F3 Pending" })
        ] })
      ] });
  }
  function ProfileTabSection6() {
    var __c = import_react.useContext(ProfCtx) || {}; var sv = __c.sv;
    return !sv.own && h("div", { className: "tp-card public-trusted-people", style: { margin: "9px 9px 9px", padding: "13px" } },
        h("div", { className: "tp-section-title" }, "Runners & Errand People"),
        h("div", { className: "tp-section-body" }, "People this seller has worked with."),
        h("div", { className: "vouch-list" }, [["Brian Otieno", "Boda rider", "\uD83C\uDFCD\uFE0F"], ["Faith Nekesa", "Errand runner", "\uD83C\uDFC3"]].map(function (person) {
          return h("div", { className: "vouch-item", key: person[0] },
            h("div", { className: "vouch-av" }, person[2]),
            h("div", { className: "vouch-info" }, h("div", { className: "vouch-name" }, person[0]), h("div", { className: "vouch-sub" }, person[1])));
        })));
  }
  function ProfileTabSection7() {
    var __c = import_react.useContext(ProfCtx) || {}; var riders = __c.riders, sv = __c.sv;
    return sv.own && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-card", style: { margin: "9px 9px 9px", padding: "13px" }, children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-section-title", children: "Trusted Riders & Errand People" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-section-body", style: { marginBottom: "10px" }, children: "People this seller has personally worked with and vouches for." }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "vouch-list", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "vouch-item", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "vouch-av", style: { background: "#185FA5" }, children: "\u{1F3CD}\uFE0F" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "vouch-info", children: [
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "vouch-name", children: "Brian Otieno" }),
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "vouch-sub", children: "Boda rider \xB7 Added by this seller" })
            ] }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { style: { fontSize: "11px", fontWeight: 700, color: "#8b008b", fontFamily: "var(--fm)", whiteSpace: "nowrap" }, children: "\u2713 Trusted" })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "vouch-item", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "vouch-av", style: { background: "#BA7517" }, children: "\u{1F3C3}" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "vouch-info", children: [
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "vouch-name", children: "Faith Nekesa" }),
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "vouch-sub", children: "Errand runner \xB7 Added by this seller" })
            ] }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { style: { fontSize: "11px", fontWeight: 700, color: "#8b008b", fontFamily: "var(--fm)", whiteSpace: "nowrap" }, children: "\u2713 Trusted" })
          ] }),
          riders.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "vouch-item", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "vouch-av", style: { background: "#51104a" }, children: r.role === "Errand runner" ? "\u{1F3C3}" : "\u{1F3CD}\uFE0F" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "vouch-info", children: [
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "vouch-name", children: r.name }),
              /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "vouch-sub", children: [
                r.role,
                " \xB7 Added by this seller"
              ] })
            ] }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { style: { fontSize: "11px", fontWeight: 700, color: "#8b008b", fontFamily: "var(--fm)", whiteSpace: "nowrap" }, children: "\u2713 Trusted" })
          ] }, i))
        ] })
      ] });
  }
  function ProfileTab({ onViewCatalogue }) {
    const { showToast, copyText, riders } = usePlugPay();
    const sv = useSV();
    const sellerProfile = sv.profile;
    
    var __v = { onViewCatalogue: onViewCatalogue, showToast: showToast, copyText: copyText, riders: riders, sv: sv, sellerProfile: sellerProfile };
    return h(ProfCtx.Provider, { value: __v }, (0, import_jsx_runtime.jsxs)("div", { className: "modal-tab-body on", style: { padding: "0" }, children: h(Slot, { name: "merchant.profile" }) }));
  }
  var REVIEWS = [
    {
      initials: "JK",
      bg: "#1e3a5f",
      fg: "#60a5fa",
      name: "James Kamau",
      date: "2 days ago",
      stars: 5,
      text: "Bought a Samsung Galaxy. Genuine product, great price. Comes with 30-day warranty as promised. Fast delivery too.",
      receipt: "#01201"
    },
    {
      initials: "FO",
      bg: "#380b33",
      fg: "#e557d6",
      name: "Faith Otieno",
      date: "1 week ago",
      stars: 5,
      text: "Best electronics shop in Moi Avenue. Honest seller, original products. Will definitely come back.",
      receipt: "#01187"
    },
    {
      initials: "BN",
      bg: "#3c1f6e",
      fg: "#a78bfa",
      name: "Brian Njoroge",
      date: "2 weeks ago",
      stars: 4,
      text: "Good laptop at fair price. Would have preferred original box but overall happy with the purchase.",
      receipt: "#01156"
    }
  ];
  function ReviewsTab() {
    var pp = usePlugPay();
    var sv = useSV();
    var st = sv.stats;
    var fresh = sv.reviews.map(function (r) {
      return { initials: initials(r.buyerName || "Buyer"), bg: "#380b33", fg: "#e557d6", name: r.buyerName || "Verified buyer", date: relTime(r.at), stars: r.rating, text: r.comment || "Left a star rating.", receipt: r.code };
    });
    var list = sv.own ? fresh.concat(REVIEWS) : REVIEWS.slice(0, Math.min(REVIEWS.length, st.reviewCount));
    var rounded = Math.round(st.avg);
    return h("div", { className: "modal-tab-body on", style: { padding: "12px" } },
      h("div", { className: "rev-summary" },
        h("div", { style: { textAlign: "center", flexShrink: 0 } },
          h("div", { className: "rev-big-num" }, st.avg.toFixed(1)),
          h("div", { className: "rev-stars-big" }, "\u2605".repeat(rounded) + "\u2606".repeat(5 - rounded)),
          h("div", { className: "rev-sub" }, st.reviewCount + " reviews")),
        h("div", { className: "rev-bars" }, [5, 4, 3, 2, 1].map(function (n) {
          var c = st.dist[n] || 0, pct = Math.round(c / st.reviewCount * 100);
          return h("div", { className: "rev-bar-row", key: n }, h("span", { className: "rev-bar-lbl" }, n), h("div", { className: "rev-bar-track" }, h("div", { className: "rev-bar-fill", style: { width: pct + "%" } })), h("span", { className: "rev-bar-ct" }, c));
        }))),
      h("div", { className: "rev-list" }, list.map(function (r) {
        return h("div", { className: "rev-item", key: r.name + r.receipt },
          h("div", { className: "rev-item-top" },
            h("div", { className: "rev-item-av", style: { background: r.bg, color: r.fg } }, r.initials),
            h("div", null, h("div", { className: "rev-item-name" }, r.name), h("div", { className: "rev-item-date" }, r.date)),
            h("div", { className: "rev-item-stars" }, "\u2605".repeat(r.stars), r.stars < 5 && h("span", { style: { color: "#ccc" } }, "\u2605".repeat(5 - r.stars)))),
          h("div", { className: "rev-item-text" }, r.text),
          h("div", { className: "rev-verified" }, "\u2713 Verified buyer \u00b7 Receipt " + r.receipt));
      })));
  }
  function PublicSellerProfileHeader(props) {
    const { toggleFollowMerchant, following, showToast, copyText } = usePlugPay();
    const sv = useSV();
    const sellerProfile = sv.profile, sellerStats = sv.stats, landlordVerifyPending = sv.pending;
    return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-hero public-seller-profile-header", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-hero-avatar-wrap", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-hero-avatar", children: (sellerProfile.bizName || "W").charAt(0).toUpperCase() }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-hero-av-check", children: "\u2713" })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-hero-name", children: sellerProfile.bizName }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-hero-role", children: sellerProfile.ownerName + " \xB7 " + sellerProfile.role }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-hero-badge", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "tp-v-icon", children: "\u2713" }),
            " Verified Seller Profile"
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-hero-bio", children: sellerProfile.bio }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-hero-loc", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "\u{1F4CD} " + sellerProfile.street }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: sv.assignment.building + ", " + sv.assignment.loc })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-landlord-tag", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `tp-landlord-tick${landlordVerifyPending ? " pending" : ""}`, children: landlordVerifyPending ? "\u23F3" : "\u2713" }),
            " ",
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: landlordVerifyPending ? undefined : "tp-verified-badge", children: landlordVerifyPending ? "Pending" : "Landlord verified" })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-hero-actions", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", { className: "tp-hero-btn tp-hero-btn-solid", onClick: () => toggleFollowMerchant(), children: [
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: following ? "\u2713" : "\uFF0B" }),
              " ",
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: following ? "Following" : "Follow" })
            ] }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
              "button",
              {
                className: "tp-hero-btn tp-hero-btn-outline",
                onClick: () => showToast("Opening WhatsApp chat with " + sellerProfile.bizName + "\u2026"),
                children: "Message"
              }
            ),
            (0, import_jsx_runtime.jsx)("button", { className: "tp-hero-btn tp-hero-btn-outline tp-hero-share", "aria-label": "Share profile", onClick: () => { if (navigator.share) { navigator.share({ title: sellerProfile.bizName, url: "https://plug.pay/m/wanjiku-electronics" }).catch(() => {}); } else copyText("plug.pay/m/wanjiku-electronics", "Profile link copied \u2713"); }, children: (0, import_jsx_runtime.jsxs)("svg", { viewBox: "0 0 24 24", width: 16, height: 16, fill: "none", stroke: "currentColor", strokeWidth: 2, strokeLinecap: "round", strokeLinejoin: "round", children: [
              (0, import_jsx_runtime.jsx)("circle", { cx: 18, cy: 5, r: 3 }),
              (0, import_jsx_runtime.jsx)("circle", { cx: 6, cy: 12, r: 3 }),
              (0, import_jsx_runtime.jsx)("circle", { cx: 18, cy: 19, r: 3 }),
              (0, import_jsx_runtime.jsx)("line", { x1: 8.59, y1: 13.51, x2: 15.42, y2: 17.49 }),
              (0, import_jsx_runtime.jsx)("line", { x1: 15.41, y1: 6.51, x2: 8.59, y2: 10.49 })
            ] }) })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-hero-stats", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-hero-stat", children: [
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-hero-stat-n", children: String(sellerStats.sales) }),
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-hero-stat-l", children: "Sales" })
            ] }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-hero-stat", children: [
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-hero-stat-n", children: String(sellerStats.followers || 235) }),
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-hero-stat-l", children: "Followers" })
            ] }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-hero-stat", children: [
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-hero-stat-n", children: String(sellerStats.reviewCount) }),
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-hero-stat-l", children: "Reviews" })
            ] }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-hero-stat", children: [
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-hero-stat-n", children: String(sellerStats.trust) }),
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-hero-stat-l", children: "Trust" })
            ] })
          ] })
        ] });
  }
  /* The ONE public seller profile. Modal and /sellers/:id page both render this. */
  function MerchantProfileBody(props) {
    var pp = usePlugPay();
    var tab = pp.merchantTab, setTab = pp.setMerchantTab;
    return h(PR.Fragment, null,
      h("div", { className: "tp-navbar-fixed" },
        h("button", { className: "tp-navbar-btn", onClick: props.onClose, "aria-label": "Back" }, "\u2190"),
        h("div", { className: "tp-navbar-title" }, ""),
        h("button", { className: "modal-close", "aria-label": "Close", onClick: props.onClose }, "\u2715")),
      h("div", { className: "tp-body public-seller-profile" },
        tab === "profile" && h(PublicSellerProfileHeader, { seller: pp.viewedSeller }),
        tab === "profile" && h(ProfileTab, { onViewCatalogue: function () { setTab("catalogue"); } }),
        tab === "catalogue" && h(CatalogueTab, null),
        tab === "reviews" && h(ReviewsTab, null),
        tab === "building" && h(BuildingTab, null)),
      h(PublicSellerBottomNavigation, { active: tab, onChange: setTab }));
  }
  function MerchantModal() {
    var pp = usePlugPay();
    return h(Modal, { id: "modal-merchant", innerClassName: "modal tpModal", hideCloseButton: true }, h(MerchantProfileBody, { onClose: function () { pp.closeModal("modal-merchant"); } }));
  }
  var STALL_POOL = [["Njeri Fashions", "Fashion"], ["Kamau Electronics", "Electronics"], ["Otieno Hardware", "Hardware"], ["Wambui Beauty Hub", "Beauty"], ["Mama Ann Foods", "Food"], ["Salim Mobile Accessories", "Electronics"], ["Achieng Textiles", "Fashion"], ["Mwangi Tools & Fittings", "Hardware"], ["Zawadi Cosmetics", "Beauty"], ["Kip Sneakers", "Fashion"]];
  var STALL_PRODUCTS = {
    Fashion: [["Ankara dress", 1800], ["Men's shirt", 1200], ["Kitenge skirt", 950]],
    Electronics: [["Phone charger", 450], ["Bluetooth earbuds", 1500], ["Power bank 10,000mAh", 1900]],
    Hardware: [["Claw hammer", 650], ["Padlock", 400], ["Paint 4L", 2200]],
    Beauty: [["Shea butter 250ml", 600], ["Hair oil", 450], ["Body lotion 400ml", 550]],
    Food: [["Chapati (10)", 250], ["Mandazi pack", 100], ["Samosas (6)", 180]],
    Other: [["Everyday essentials", 500], ["Bestseller", 800], ["Gift set", 1200]]
  };
  function hashStr(s) { var x = 7; for (var i = 0; i < s.length; i++) x = (x * 31 + s.charCodeAt(i)) % 100003; return x; }
  function buildStallProfile(pp, sp) {
    var st = sp.stall, hsh = hashStr(sp.floor + ":" + st.id);
    var reg = sp.merchant || (pp.obMerchantList || []).filter(function (m) { return m.floor === sp.floor && String(parseInt(m.stallNum, 10)) === String(parseInt(st.id, 10)); })[0];
    var named = st.n && st.n.indexOf("Stall ") !== 0 ? st.n : "";
    var pool = STALL_POOL[hsh % STALL_POOL.length];
    var biz = reg ? reg.biz : (named || pool[0]);
    var cat = reg ? reg.type : (named ? "Retail" : pool[1]);
    var ex = (reg && reg.extra) || {};
    return {
      biz: biz, owner: reg ? reg.ownerName : (named ? named : biz.split(" ")[0] + " (owner)"), cat: cat,
      loc: (sp.floor === "G" ? "Ground floor" : "Floor " + sp.floor) + ", Stall " + st.id, building: sp.building || "Anniversary Towers",
      verified: st.s === "v" || (reg && reg.status === "done"), rating: (4.2 + (hsh % 8) / 10).toFixed(1), reviews: 8 + (hsh % 60), years: ex.years || (1 + hsh % 9),
      phone: reg ? reg.phone : "", photos: ex.photos || [], products: STALL_PRODUCTS[cat] || STALL_PRODUCTS.Other, registered: !!reg
    };
  }
  var CAT_ICON = { Fashion: "\uD83D\uDC57", Electronics: "\uD83D\uDCF1", Hardware: "\uD83D\uDD27", Beauty: "\uD83D\uDC84", Food: "\uD83C\uDF72", Other: "\uD83D\uDCE6" };
  function slugOf(s) { return String(s || "").toLowerCase().replace(/[^a-z0-9]+/g, ""); }
  function buildViewedSeller(d) {
    var hs = hashStr((d.building || "") + "|" + (d.loc || "") + "|" + (d.owner || d.biz));
    var cat = d.cat || "Retail";
    var avg = Number(d.rating) || 4.2 + (hs % 8) / 10;
    var reviewCount = Number(d.reviews) || 8 + (hs % 60);
    var sales = Number(d.sales) || 20 + (hs % 400);
    var vouches = Number(d.vouches) || 3 + (hs % 25);
    var trust = Math.min(99, Math.round(53 + (avg / 5) * 25 + Math.min(15, sales / 20) + Math.min(12, vouches / 4)));
    var n5 = Math.round(reviewCount * 0.74), n4 = Math.round(reviewCount * 0.15), n3 = Math.round(reviewCount * 0.06), n2 = Math.round(reviewCount * 0.03);
    var dist = { 5: n5, 4: n4, 3: n3, 2: n2, 1: Math.max(0, reviewCount - n5 - n4 - n3 - n2) };
    var years = Number(d.years) || 1 + (hs % 9);
    var slug = slugOf(d.biz);
    var stockBase = STALL_PRODUCTS[cat] || STALL_PRODUCTS.Other;
    return {
      key: (d.building || "") + "|" + (d.loc || ""),
      verified: !!d.verified,
      registered: !!d.registered,
      assignment: { building: d.building || "", loc: d.loc || "" },
      stats: { avg: avg, reviewCount: reviewCount, sales: sales, vouches: vouches, trust: trust, dist: dist, followers: 40 + (hs % 300) },
      profile: {
        bizName: d.biz, ownerName: d.owner || d.biz, role: cat === "Retail" ? "Retail Trader" : cat + " Retailer",
        bio: cat + " seller at " + d.building + ". In business for " + years + " year" + (years > 1 ? "s" : "") + ".",
        street: (d.street || "Nairobi CBD"), phone: d.phone || "Not shared", whatsapp: d.phone || "Not shared",
        established: (2026 - years) + " \u00b7 " + years + " year" + (years > 1 ? "s" : "") + " in business",
        instagram: "@" + slug, tiktok: "@" + slug, facebook: "/" + d.biz.replace(/\s+/g, ""),
        paybill: "", account: "",
        about: d.biz + " sells " + cat.toLowerCase() + " products from " + d.loc + ", " + d.building + ". Message the seller on WhatsApp to place an order.",
        llPhoneVerified: !!d.verified
      },
      catalogue: stockBase.map(function (p, i) { return { id: "v" + i, icon: CAT_ICON[cat] || CAT_ICON.Other, image: "", name: p[0], price: p[1], stock: 4 + ((hs + i * 7) % 20), category: cat }; })
    };
  }
  // The official profile reads its data through this hook so own and other sellers render identically.
  function useSV() {
    var pp = usePlugPay(), v = pp.viewedSeller;
    if (v) return { own: false, profile: v.profile, stats: v.stats, assignment: v.assignment, pending: !v.verified, catalogue: v.catalogue, reviews: [] };
    return { own: true, profile: pp.sellerProfile, stats: pp.sellerStats, assignment: pp.stallAssignment, pending: pp.landlordVerifyPending, catalogue: pp.catalogueItems, reviews: pp.sellerReviews };
  }
  var PUBLIC_SELLER_TABS = [
    ["profile", "Profile"],
    ["catalogue", "Catalogue"],
    ["reviews", "Reviews"],
    ["building", "Building"]
  ];
  function PublicSellerBottomNavigation(
    props
  ) {

    return h(
      "nav",
      {
        className:
          "public-seller-bottom-navigation"
      },

      PUBLIC_SELLER_TABS.map(
        function (tab) {

          return h(
            "button",
            {
              key:
                tab[0],

              type:
                "button",

              className:
                "public-seller-bottom-item" +
                (
                  props.active ===
                  tab[0]
                    ? " active"
                    : ""
                ),

              onClick:
                function () {

                  props.onChange(
                    tab[0]
                  );

                }
            },

            tab[1]
          );

        }
      )
    );
  }
  function resolvePublicStallSeller(stall) {
    if (stall && stall.n && String(stall.n).trim()) return null;
    return { biz: "Wanjiku Electronics", ownerName: "Jane Wanjiku", type: "Electronics", phone: "", status: "done" };
  }
  function SellerPublicPage(props) {
    var pp = usePlugPay();
    var k = ppSlug(props.id);
    var found = merchants.some(function (m) { return ppSlug(m.name) === k; }) || ppSlug(pp.sellerProfile.ownerName) === k;
    PR.useLayoutEffect(function () { if (found) pp.loadSellerPage(props.id); }, [props.id]);
    if (!found) return h(NotFoundPage, { title: "Seller not found", sub: "We couldn't find a seller at this link." });
    return h(RouteSheet, { innerClassName: "modal tpModal", hideBar: true }, h(MerchantProfileBody, { onClose: goBack }));
  }

  /* ---- Wiring: registers this group's modals, slots, pages and routes ---- */
  PP_ROUTES.push(
    [/^\/sellers\/(.+)$/, "seller-public", "id"]
  );
  PP_registry.register("modals", "merchant", MerchantModal, 30);
  PP_registry.registerPage("seller-public", function (r) { return h(SellerPublicPage, { id: r.id }); });
  PP_registry.register("merchant.profile", "s1", ProfileTabSection1, 10);
  PP_registry.register("merchant.profile", "s2", ProfileTabSection2, 20);
  PP_registry.register("merchant.profile", "s3", ProfileTabSection3, 30);
  PP_registry.register("merchant.profile", "s4", ProfileTabSection4, 40);
  PP_registry.register("merchant.profile", "s5", ProfileTabSection5, 50);
  PP_registry.register("merchant.profile", "s6", ProfileTabSection6, 60);
  PP_registry.register("merchant.profile", "s7", ProfileTabSection7, 70);