import * as import_jsx_runtime from "../../ppJsxRuntime.js";
import { FinalCta } from "./FinalCta.js";

export function Pricing() {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", { className: "pricing", id: "pricing", children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "wrap", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "eyebrow on-dark", children: "Pricing" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Free for every trader. No catch." }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "section-p", style: { color: "rgba(255,255,255,.6)" }, children: "PlugPay never takes a hidden cut of your sales, and never charges you to be verified, listed, or found. The trust layer is free \u2014 because the more traders it holds, the more valuable it becomes to everyone." }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "price-grid", style: { maxWidth: "380px", marginLeft: "auto", marginRight: "auto" }, children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "price-card featured", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "price-badge", children: "Always free" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "price-tier", children: "Every verified trader" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "price-n", children: "KSh 0" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "price-who", children: "Forever \u2014 no upgrade tier, no paywall" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", { className: "price-list", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Verified public profile at plug.pay/yourname" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Unlimited sales recording & floor-map listing" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Unlimited WhatsApp receipts" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Peer vouching & receipt-anchored reviews" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Full trust-score building, from day one" })
        ] })
      ] }) }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { className: "price-note", style: { maxWidth: "60ch" }, children: [
        "Our business is built on two things: the ",
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { style: { color: "#fff" }, children: "delivery marketplace" }),
        " ",
        "connecting buyers to verified runners, and ",
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { style: { color: "#fff" }, children: "credit data" }),
        " - turning a trader's real transaction and vouching history into evidence sellers can use to get suppliers and financial institutions to safely extend stock credit or a loan."
      ] })
    ] }) }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", { className: "voices", children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "wrap", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "eyebrow", children: "Community voices" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Traders are already excited about safer WhatsApp commerce." }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "section-p", children: "Thousands of buyers and sellers deal with the same DM anxiety every day. Here's what traders are saying about the trust layer PlugPay is building for Kenyan commerce." }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "t-card", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "t-av", children: "WM" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "t-name", children: "Wanjiru M." }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "t-role", children: "Fashion seller, Nairobi CBD" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "t-stars", children: "\u2605\u2605\u2605\u2605\u2605" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "t-quote", children: `"Buyers used to disappear the moment I asked for payment first. Now they see my badge and pay before I've even finished typing the price."` }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "t-dots", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "on" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
        ] })
      ] })
    ] }) }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", { className: "market", children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "wrap", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "eyebrow on-dark", children: "The market focus" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "The trust layer for Kenya's digital commerce." }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "market-grid", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "market-left", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "market-sub", children: "Commerce is moving faster than formal systems." }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "section-p", children: "Social selling is exploding across WhatsApp, Instagram and Facebook Marketplace. Millions of traders sell every day without a shopfront, a website, or any way to prove they're real." }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "check-list", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "check-item", children: [
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "check-icon", children: "\u2713" }),
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Securing transactions between strangers on social media" })
            ] }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "check-item", children: [
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "check-icon", children: "\u2713" }),
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "No expensive developer integrations required for local vendors" })
            ] }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "check-item", children: [
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "check-icon", children: "\u2713" }),
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Works over WhatsApp \u2014 no app download for buyers" })
            ] }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "check-item", children: [
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "check-icon", children: "\u2713" }),
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Every sale becomes a verifiable, public track record" })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "stat-callout", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "bt-n", children: "KSh 400B+" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "bt-l", children: "Kenya's informal retail economy" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Estimated annual value moving through jua kali stalls and social-media traders with no formal trust layer today." })
        ] })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FinalCta, {})
    ] }) })
  ] });
}
