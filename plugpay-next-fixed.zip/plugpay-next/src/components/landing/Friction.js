import * as import_jsx_runtime from "../../ppJsxRuntime.js";
import { usePlugPay } from "../../store/context.js";
import { CARDS } from "./landingData.js";

export function Friction() {
  const { openAuthModal } = usePlugPay();
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", { className: "friction", id: "friction", children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "wrap", children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "eyebrow", children: "The friction" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "WhatsApp commerce still runs on trust gaps." }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "section-p", children: "Social selling has turned every trader's DMs into a storefront. Millions of Kenyans buy and sell this way daily \u2014 but transacting with a stranger over chat is still a gamble for everyone involved." }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "f-cards", children: CARDS.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "f-card", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "f-n", children: c.n }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "f-t", children: c.t }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "f-d", children: c.d })
    ] }, c.n)) }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { textAlign: "center", marginTop: "32px" }, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { className: "btn-mint", onClick: () => openAuthModal(), children: "Get started \u2014 it's free \u2192" }) })
  ] }) });
}
