import * as import_reactX from "react";

export var PR = import_reactX;

var __ce = PR.createElement;

export var h = function (type, props) {
  var a = Array.prototype.slice.call(arguments);
  if (typeof type === "string") { for (var i = 2; i < a.length; i++) { var c = a[i]; if (typeof c === "string") { var f = window.__ppFixChildren(c, type); if (f !== c) a[i] = h.apply(null, [PR.Fragment, null].concat(f)); } } }
  return __ce.apply(PR, a);
};
