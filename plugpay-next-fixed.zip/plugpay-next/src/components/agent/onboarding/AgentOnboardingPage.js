import { navigate } from "../../../lib/router.js";
import { usePlugPay } from "../../../store/context.js";
import { OnboardFlow } from "./OnboardFlow.js";
import { PR, h } from "../../common/h.js";
import { RouteSheet } from "../../common/shells.js";

export function AgentOnboardingPage() {
  var pp = usePlugPay();
  PR.useEffect(function () { pp.openOnboard(); pp.closeModal("modal-onboard"); }, []);
  return h(RouteSheet, { innerClassName: "ob-modal", onClose: function () { navigate("/agent/buildings"); } }, h(OnboardFlow, null));
}
