import * as import_jsx_runtime from "../../../ppJsxRuntime.js";
import { usePlugPay } from "../../../store/context.js";
import { AgentGate } from "./AgentGate.js";
import { Step1Building } from "./Step1Building.js";
import { Step4StallsConfirm } from "./Step4StallsConfirm.js";

var STEP_META = {
  1: { title: "\u{1F4CD} Onboard a Building", sub: "Step 1 of 2 \xB7 Building details", pip: 1 },
  4: { title: "\u{1F4CD} Onboard a Building", sub: "Step 2 of 2 \xB7 Map stalls & register sellers", pip: 2 }
};

export function OnboardFlow() {
  var _a;
  const { obAgentGate, obStep_, obStep, obMerchantList } = usePlugPay();
  const meta = (_a = STEP_META[obStep_]) != null ? _a : STEP_META[1];
  return obAgentGate ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AgentGate, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ob-header", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ob-title", children: meta.title }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ob-sub", children: meta.sub }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ob-steps-bar", children: [1, 2].map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `ob-step-pip${p <= meta.pip ? " active" : ""}` }, p)) })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ob-body", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Step1Building, { active: obStep_ === 1 }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Step4StallsConfirm, { active: obStep_ === 4 })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ob-footer", children: [
      obStep_ > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { className: "ob-btn-back", onClick: () => obStep(-1), children: "\u2190 Back" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { className: "ob-btn-primary", onClick: () => obStep(1), children: obStep_ === 4 ? `Publish ${obMerchantList.length} seller${obMerchantList.length === 1 ? "" : "s"} \u{1F680}` : "Save & Continue \u2192" })
    ] })
  ] });
}
