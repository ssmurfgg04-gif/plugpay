import { adminDb, json } from '../../../../src/server/supabase.js';
export async function GET(_request,ctx){ const params = await ctx.params;const db=adminDb();const r=await db.from('reviews').select('*').eq('seller_id',params.id).order('created_at',{ascending:false}).limit(100);return r.error?json({error:r.error.message},500):json({reviews:r.data||[]});}
