import { navigate } from "../../../../lib/router.js";
import { usePlugPay } from "../../../../store/context.js";
import { PR, h } from "../../../common/h.js";
import { EmptyState } from "../../../common/states.js";
import { Ic } from "../../../common/ui.js";

/* ---- Catalogue tab ---- */
function ProductForm(props) {
  var init = props.initial || { name: "", price: "", category: "", stock: "", image: "" };
  var _s = PR.useState(init), f = _s[0], setF = _s[1];
  var fileRef = PR.useRef(null);
  function set(k, v) { var n = {}; n[k] = v; setF(Object.assign({}, f, n)); }
  return h("div", { className: "tp-card", style: { padding: 13 } },
    h("div", { className: "tp-section-title" }, props.title),
    h("div", { className: "sp-img-up" },
      h("div", { className: "sp-img-prev", onClick: function () { fileRef.current && fileRef.current.click(); } }, f.image ? h("img", { src: f.image, alt: "", style: { width: "100%", height: "100%", objectFit: "cover" } }) : h("span", null, "\uD83D\uDCF7", h("br"), "Upload photo")),
      h("div", { style: { flex: 1 } },
        h("input", { ref: fileRef, type: "file", accept: "image/*", style: { display: "none" }, onChange: function (e) { var file = e.target.files && e.target.files[0]; if (file) readImage(file, function (d) { set("image", d); }); e.target.value = ""; } }),
        h("button", { className: "sp-edit-btn on", onClick: function () { fileRef.current && fileRef.current.click(); } }, f.image ? "Change image" : "Upload image"),
        f.image && h("button", { className: "sp-edit-btn", style: { marginLeft: 8 }, onClick: function () { set("image", ""); } }, "Remove image"),
        h("div", { className: "tp-section-body", style: { marginTop: 6 } }, "JPG or PNG. Shown to buyers on your catalogue."))
    ),
    h("label", { className: "plc-field", style: { display: "block", marginBottom: 10 } }, h("span", { className: "plc-label" }, "Product name"), h("input", { className: "plc-input", value: f.name, onChange: function (e) { set("name", e.target.value); }, placeholder: "e.g. Samsung Galaxy A15" })),
    h("div", { className: "sp-two" },
      h("label", { className: "plc-field" }, h("span", { className: "plc-label" }, "Price (KSh)"), h("input", { className: "plc-input", type: "number", min: 1, value: f.price, onChange: function (e) { set("price", e.target.value); } })),
      h("label", { className: "plc-field" }, h("span", { className: "plc-label" }, "Stock"), h("input", { className: "plc-input", type: "number", min: 0, value: f.stock, onChange: function (e) { set("stock", e.target.value); } }))
    ),
    h("label", { className: "plc-field", style: { display: "block", margin: "10px 0" } }, h("span", { className: "plc-label" }, "Category"), h("input", { className: "plc-input", value: f.category, onChange: function (e) { set("category", e.target.value); }, placeholder: "e.g. Phones" })),
    h("div", { className: "sp-edit-actions" },
      h("button", { className: "sp-edit-btn on", onClick: function () { props.onSubmit(f); } }, props.submitLabel),
      h("button", { className: "sp-edit-btn", onClick: props.onCancel }, "Cancel"))
  );
}

export function SellerCatalogueTab() {
  var pp = usePlugPay();
  var _m = PR.useState(null), mode = _m[0], setMode = _m[1];
  var _f = PR.useState("All"), filter = _f[0], setFilter = _f[1];
  var items = pp.catalogueItems;
  var cats = ["All"].concat(Array.from(new Set(items.map(function (i) { return i.category; }))));
  var shown = filter === "All" ? items : items.filter(function (i) { return i.category === filter; });
  var editing = mode && mode !== "new" ? items.filter(function (i) { return i.id === mode; })[0] : null;
  return h("div", { style: { padding: 12 } },
    h("div", { className: "cat-merchant-bar" },
      h("button", { className: "cat-mb-btn cat-mb-primary", onClick: function () { setMode(mode === "new" ? null : "new"); } }, "\uFF0B Add Product"),
      h("span", { className: "cat-mb-btn", style: { textAlign: "center", cursor: "default" } }, items.length + " product" + (items.length === 1 ? "" : "s"))
    ),
    mode === "new" && h(ProductForm, { key: "new", title: "Add product", submitLabel: "Add product", onCancel: function () { setMode(null); }, onSubmit: function (f) { if (pp.addCatalogueItem(f)) setMode(null); } }),
    editing && h(ProductForm, { key: editing.id, title: "Edit product", submitLabel: "Save changes", initial: { name: editing.name, price: editing.price, category: editing.category, stock: String(editing.stock), image: editing.image }, onCancel: function () { setMode(null); }, onSubmit: function (f) {
      if (!f.name.trim() || !f.price) { pp.showToast("Enter a product name and price"); return; }
      pp.updateCatalogueItem(editing.id, { name: f.name.trim(), price: String(f.price), category: f.category.trim() || "General", stock: Number(f.stock) || 0, image: f.image });
      pp.showToast("Product updated \u2713"); setMode(null);
    } }),
    h("div", { className: "cat-filters" }, cats.map(function (c) {
      var n = c === "All" ? items.length : items.filter(function (i) { return i.category === c; }).length;
      return h("button", { key: c, className: "cat-filter" + (filter === c ? " on" : ""), onClick: function () { setFilter(c); } }, c + " (" + n + ")");
    })),
    shown.length === 0 && h(EmptyState, { icon: "package", title: filter === "All" ? "No products yet" : "Nothing in " + filter, sub: "Products you add here autofill your invoices and receipts, and feed your sales analytics.", action: mode === "new" ? null : { label: "Add product", onClick: function () { setMode("new"); } } }),
    h("div", { className: "cat-grid" }, shown.map(function (p) {
      return h("div", { key: p.id, className: "cat-item", style: { cursor: "default" } },
        h("div", { className: "cat-img" }, p.image ? h("img", { src: p.image, alt: p.name, style: { width: "100%", height: "100%", objectFit: "cover" } }) : p.icon),
        h("div", { className: "cat-body" },
          h("div", { className: "cat-name" }, p.name),
          h("div", { className: "cat-price" }, "KSh " + Number(p.price).toLocaleString()),
          h("div", { className: "cat-stock" }, (p.stock > 0 ? p.stock + " in stock" : "Out of stock") + " \u00b7 " + p.category),
          h("button", { className: "cat-sale-btn", disabled: p.stock <= 0, onClick: function () { pp.startSaleFromProduct(p); navigate("/seller/receipts/new"); } }, Ic("shopping-cart", 15), p.stock > 0 ? "Record sale" : "Out of stock"),
          h("div", { className: "catalogue-action-row", style: { marginTop: 8 } },
            h("button", { className: "sp-edit-btn", onClick: function () { setMode(p.id); window.scrollTo({ top: 0, behavior: "smooth" }); } }, "\u270F\uFE0F Edit"),
            h("button", { className: "sp-edit-btn danger", onClick: function () { pp.removeCatalogueItem(p.id); if (mode === p.id) setMode(null); } }, "Remove")))
      );
    }))
  );
}
