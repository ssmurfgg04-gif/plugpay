import * as import_react4 from "react";
import * as import_jsx_runtime from "../../ppJsxRuntime.js";
import { usePlugPay } from "../../store/context.js";

/* ---- Shared UI kit (shells, modals, skeletons, empty and error states, toast) ---- */
export function Modal({
  id,
  onExit,
  innerClassName = "modal",
  closeButtonStyle,
  hideCloseButton = false,
  children
}) {
  const { isOpen, closeModal, openModals } = usePlugPay();
  const open = isOpen(id);
  const stackIndex = openModals.indexOf(id);
  const zIndex = 1e3 + (stackIndex >= 0 ? stackIndex : 0);
  (0, import_react4.useEffect)(() => {
    if (!open) return;
    const onKey = (e) => {
      if (e.key === "Escape") handleClose();
    };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open]);
  function handleClose() {
    closeModal(id);
    if (onExit) onExit();
  }
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
    "div",
    {
      className: `modal-overlay${open ? " on" : ""}`,
      id,
      style: { zIndex },
      onClick: (e) => {
        if (e.target === e.currentTarget) handleClose();
      },
      children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: innerClassName, children: [
        !hideCloseButton && (0, import_jsx_runtime.jsxs)("div", { className: "modal-bar", children: [
          (0, import_jsx_runtime.jsx)("button", { className: "modal-back", style: closeButtonStyle, onClick: handleClose, "aria-label": "Back", children: "\u2190" }),
          (0, import_jsx_runtime.jsx)("button", { className: "modal-close", style: closeButtonStyle, onClick: handleClose, "aria-label": "Close", children: "\u2715" })
        ] }),
        children
      ] })
    }
  );
}
