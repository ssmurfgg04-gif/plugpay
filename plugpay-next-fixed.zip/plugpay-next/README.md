# PlugPay — Next.js port

Ported from `plugpay_desktop.html`; the app code is unchanged apart from the changes listed below.

- `app/globals.css` — the original `<style>` block, verbatim
- `src/PlugPayApp.jsx` — app entry (43 lines): imports each feature's `register.js` in the original order, then `Home`
- `src/app/RouteSwitch.js` — route switch + global modal slot
- `src/components/` — all UI, one folder per feature (see below)
- `src/store/` — the former 1,150-line `PlugPayProvider`, split into one hook per group (see below)
- `src/data/`, `src/lib/` — demo data and helpers that used to share the bundle's scope, now real modules
- `src/ppJsxRuntime.js` — the bundle's patched JSX runtime (emoji -> inline SVG icons)
- `src/legacy/icons-script.js` — the original icon map, emoji map and helpers
- `app/[[...slug]]` — catch-all route that mounts the app client-side; the original route table resolves the path
- `reference/original-groups/` — the source split by the original banners, for reading only (not imported)

Changes from the HTML: bundler requires became real imports; the hash router (`#/seller/dashboard`) became a pathname router (`/seller/dashboard`); same-origin links navigate client-side; share links use `origin + /path`.

    npm install && npm run dev

## How the store is wired

`PlugPayProvider` (`src/store/PlugPayProvider.jsx`, ~30 lines) calls one hook per group, in order, and builds the context value:

    const ctx = {};                                   // fresh object every render
    Object.assign(ctx, useCoreStore(ctx));            // modals, toast, copyText
    Object.assign(ctx, usePublicViewStore(ctx));      // merchant modal, follow, view seller/stall
    Object.assign(ctx, useSearchStore(ctx));
    Object.assign(ctx, useBuildingStore(ctx));
    Object.assign(ctx, useSellerRiders(ctx));         // seller/
    Object.assign(ctx, useSellerAuth(ctx));           //   OTP, PIN, login gate
    Object.assign(ctx, useSellerStall(ctx));          //   documents, vacate form, stall assignment
    Object.assign(ctx, useSellerSales(ctx));          //   record-sale form, receipts/invoices lists
    Object.assign(ctx, useSellerCatalogue(ctx));
    Object.assign(ctx, useSellerProfile(ctx));
    Object.assign(ctx, useSellerRecords(ctx));        //   stats, reviews, send/convert/resend
    Object.assign(ctx, useOnboardingState(ctx));      // onboarding/
    Object.assign(ctx, useOnboardingAgentAuth(ctx));
    Object.assign(ctx, useOnboardingBuilding(ctx));
    Object.assign(ctx, useOnboardingMerchants(ctx));
    Object.assign(ctx, useAgentClaims(ctx));          // agent/
    Object.assign(ctx, useLandlordBuildings(ctx));    // landlord/
    Object.assign(ctx, useLandlordAuth(ctx));
    Object.assign(ctx, useLandlordAdmitSeller(ctx));
    const value = buildContextValue(ctx);             // same list of keys as the original value object

Each hook body is the original code. A hook gets names from groups that run **earlier** through a destructure at the top
(`const { openModal, showToast } = ctx;`) and names from groups that run **later** through `ctx.name`, read at call time.
This is needed because the original groups referenced each other in both directions (the public view reads landlord and
seller state, the agent portal writes seller sign-in state, and so on). Because `ctx` is created per render, those lazy reads
see the same values the original closures did. The only cross-group references evaluated during render are to the core
group, which always runs first.

## Where the components are

    src/components/
      common/            h.js · routing.js · registry.js (Slot, PP_registry) · Modal.js · feedback.js (Toast, NetBanner)
                         shells.js (TopBar, PortalShell, AppShellX, PublicShellX, bottom navs, NotFoundPage) · states.js (skeletons, empty/error) · ui.js · register.js
      landing/           Navbar · Hero · PhoneDemo · Friction · HowItWorks · Contrast · Pricing · FAQ · FinalCta · Footer · LandingPage · landingData.js · register.js
      public-view/       SellerPublicPage · MerchantModal · MerchantProfileBody · PublicSellerProfileHeader · PublicSellerBottomNavigation · useSV · register.js
                         tabs/  ProfileTab · CatalogueTab · ReviewsTab · BuildingTab
      search/            SearchPage · SearchBar · ResultsSection · ResultCards · register.js
      building/          BuildingPage · BuildingModal · BuildingView · BuildingViewContainer · FloorMap · floors.js · buildingData.js · register.js
      seller/            auth/ (RegisterModal, Auth*Step, authStyles)   shell/ (SellerShell incl. SellerGate, SellerPortalPage)
                         tabs/dashboard · tabs/catalogue · tabs/profile · tabs/sales (list, receipt/invoice detail, doc cards)
                         modals/ (ReceiptModal, RecordSaleModal)   buyer-pages/ (PublicReceiptPage, ReviewPage, PayInvoicePage)   register.js
      agent/             onboarding/ (AgentGate, Step1Building, Step4StallsConfirm, StallGrid, OnboardFlow, OnboardModal, AgentOnboardingPage, register.js)
                         portal/ (AgentBuildingsPage, AgentClaimsPage, register.js)   claim/ (ClaimPage)
      landlord/          auth/ (LandlordModal, Ll*Step)   tabs/dashboard · tabs/buildings · tabs/sellers · tabs/stalls   modals/AdmitSellerModal   register.js
      quick-action/      FabQuick · QuickModal · register.js

Every component is the original function, moved unchanged (imports/exports added, indentation reduced by two spaces).
Each `register.js` holds that feature's original wiring (`PP_ROUTES.push`, `PP_registry.register`, `registerPage`).
