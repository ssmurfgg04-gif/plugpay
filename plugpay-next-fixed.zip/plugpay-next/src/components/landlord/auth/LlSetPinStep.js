import * as import_jsx_runtime from "../../../ppJsxRuntime.js";
import { usePlugPay } from "../../../store/context.js";
import { llAuthCodeInput, llAuthIconWrap, llAuthLabel, llAuthSubmitBtn, llFocusRing } from "./llAuthStyles.js";

export function LlSetPinStep() {
  const { llSetPinValue, setLlSetPinValue, llSetPin } = usePlugPay();
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { padding: "32px" }, children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { textAlign: "center", marginBottom: "20px" }, children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: llAuthIconWrap, children: "\u{1F511}" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { fontSize: "22px", fontWeight: 900, color: "var(--ink)", marginBottom: "4px" }, children: "Set a 6-digit PIN" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { fontSize: "13px", color: "var(--muted)", lineHeight: "1.55" }, children: "Use this PIN with your phone number to sign in next time \u2014 no OTP needed." })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { style: llAuthLabel, children: "CHOOSE A 6-DIGIT PIN" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      "input",
      {
        type: "password",
        inputMode: "numeric",
        placeholder: "_ _ _ _ _ _",
        maxLength: 6,
        style: llAuthCodeInput,
        value: llSetPinValue,
        onChange: (e) => setLlSetPinValue(e.target.value),
        onKeyDown: (e) => {
          if (e.key === "Enter") llSetPin();
        },
        ...llFocusRing()
      }
    ),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { style: llAuthSubmitBtn, onClick: () => llSetPin(), children: "Set PIN & open dashboard \u2192" })
  ] });
}
