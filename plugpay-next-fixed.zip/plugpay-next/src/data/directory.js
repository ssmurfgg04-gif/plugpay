export var merchants = [
    { type: "merchant", name: "Jane Mwangi", sub: "Fashion \xB7 Anniversary Towers \xB7 Floor 3, Stall 301", initials: "JM", color: "#51104a", badge: "Verified", badgeClass: "rcb-verified", rating: "4.9", sales: 847, reviews: 38, vouches: 38 },
    { type: "merchant", name: "Peter Otieno", sub: "Electronics \xB7 Anniversary Towers \xB7 Floor 3, Stall 302", initials: "PO", color: "#185FA5", badge: "Verified", badgeClass: "rcb-verified", rating: "4.8", sales: 312, reviews: 24, vouches: 18 },
    { type: "merchant", name: "David Mutua", sub: "Hardware \xB7 Anniversary Towers \xB7 Floor 2, Stall 202", initials: "DM", color: "#534AB7", badge: "Verified", badgeClass: "rcb-verified", rating: "4.7", sales: 560, reviews: 41, vouches: 52 },
    { type: "merchant", name: "Amina Kibe", sub: "Food \xB7 Anniversary Towers \xB7 Floor 3, Stall 303", initials: "AK", color: "#BA7517", badge: "Verified", badgeClass: "rcb-verified", rating: "4.6", sales: 210, reviews: 17, vouches: 8 },
    { type: "merchant", name: "Grace Akinyi", sub: "Beauty \xB7 Lonrho House \xB7 Floor 1, Stall 5", initials: "GA", color: "#D85A30", badge: "Verified", badgeClass: "rcb-verified", rating: "4.9", sales: 428, reviews: 33, vouches: 24 }
  ];

export var buildings = [
    { type: "building", name: "Anniversary Towers", street: "Mama Ngina Street", sub: "Mama Ngina St \xB7 6 floors \xB7 72 stalls \xB7 58 registered", floors: 6, stalls: 72, registered: 58, pct: 67 },
    { type: "building", name: "Lonrho House", street: "Kenyatta Avenue", sub: "Kenyatta Ave \xB7 4 floors \xB7 58 stalls \xB7 39 registered", floors: 4, stalls: 58, registered: 39, pct: 67 },
    { type: "building", name: "Kencom House", street: "Moi Avenue", sub: "Moi Ave \xB7 5 floors \xB7 84 stalls \xB7 51 registered", floors: 5, stalls: 84, registered: 51, pct: 61 },
    { type: "building", name: "Odeon Cinema Bldg", street: "Tom Mboya Street", sub: "Tom Mboya St \xB7 3 floors \xB7 64 stalls \xB7 28 registered", floors: 3, stalls: 64, registered: 28, pct: 44 }
  ];
