import { usePlugPay } from "../../../../store/context.js";
import { h } from "../../../common/h.js";
import { salesDocStatus } from "../sales/salesShared.js";

export function SellerSalesSummary() {
  var pp = usePlugPay();
  var rc = pp.receiptsList || [], iv = pp.invoicesList || [];
  var all = rc.map(function (r) { return salesDocStatus("receipt", r); }).concat(iv.map(function (i) { return salesDocStatus("invoice", i); }));
  var complete = all.filter(function (x) { return x === "COMPLETE"; }).length;
  function cell(n, label) { return h("div", null, h("strong", null, n), h("span", null, label)); }
  return h("div", { className: "seller-sales-summary" }, cell(rc.length, "Receipts"), cell(iv.length, "Invoices"), cell(complete, "Complete"), cell(all.length - complete, "Pending"));
}
