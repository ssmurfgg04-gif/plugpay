import * as import_jsx_runtime from "../../../ppJsxRuntime.js";
import { usePlugPay } from "../../../store/context.js";
import { LOGO_DATA_URI } from "../../common/ui.js";
import { authIconWrap, authLabel, authLink, authSubmitBtn, authTextInput, focusRing } from "./authStyles.js";

export function AuthPhoneStep() {
  const { authMethod, authSetMethod, authPhone, setAuthPhone, authSendOTP, authShowPinLogin, claimInfo } = usePlugPay();
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "auth-shell", children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { textAlign: "center", marginBottom: "20px" }, children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: authIconWrap, children: "\u{1F510}" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { fontSize: "22px", fontWeight: 900, color: "var(--ink)", marginBottom: "4px" }, children: [
        "Sign in to",
        " ",
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
          "img",
          {
            src: LOGO_DATA_URI,
            alt: "PlugPay",
            style: { height: "22px", width: "auto", verticalAlign: "-5px", display: "inline-block" }
          }
        )
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { fontSize: "13px", color: "var(--muted)", lineHeight: "1.55" }, children: "Enter your WhatsApp number. We'll send you a one-time code \u2014 SMS if WhatsApp isn't available." })
    ] }),
    claimInfo && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "rv-note", style: { marginBottom: "14px" }, children: [
      (0, import_jsx_runtime.jsx)("span", { children: "\u{1F4F2}" }),
      (0, import_jsx_runtime.jsxs)("span", { children: [(0, import_jsx_runtime.jsx)("b", { children: "Claim link opened. " }), "Sign in with the number on file to claim " + claimInfo.name + " \u00b7 " + claimInfo.building + ", " + claimInfo.loc + "."] })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "method-toggle", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        "button",
        {
          type: "button",
          className: `method-toggle-btn${authMethod === "whatsapp" ? " active" : ""}`,
          onClick: () => authSetMethod("whatsapp"),
          children: "\u{1F4AC} WhatsApp"
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        "button",
        {
          type: "button",
          className: `method-toggle-btn${authMethod === "sms" ? " active" : ""}`,
          onClick: () => authSetMethod("sms"),
          children: "\u{1F4F1} SMS"
        }
      )
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { style: authLabel, children: authMethod === "sms" ? "PHONE NUMBER" : "WHATSAPP NUMBER" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      "input",
      {
        type: "tel",
        placeholder: "07XX XXX XXX",
        style: authTextInput,
        value: authPhone,
        onChange: (e) => setAuthPhone(e.target.value),
        ...focusRing()
      }
    ),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { style: authSubmitBtn, onClick: () => authSendOTP(), children: "Send OTP \u2192" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { textAlign: "center", fontSize: "11.5px", color: "var(--muted2)", marginTop: "14px", lineHeight: "1.6" }, children: [
      "Your stall is registered by an agent.",
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
      "Claimed your profile? Sign in here with the phone number on file to complete it."
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { textAlign: "center", fontSize: "12px", marginTop: "10px", fontFamily: "var(--fm)" }, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      "a",
      {
        href: "#",
        onClick: (e) => {
          e.preventDefault();
          authShowPinLogin();
        },
        style: authLink,
        children: "Already set a PIN? Sign in with PIN \u2192"
      }
    ) })
  ] });
}
