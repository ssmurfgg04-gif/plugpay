import { json } from '../../../../../src/server/supabase.js';
import { loadPublicInvoice } from '../../../../../src/server/publicDocs.js';
export async function GET(_request, ctx) {
  const { token } = await ctx.params;
  const r = await loadPublicInvoice(decodeURIComponent(token));
  return r.error ? json({ error: r.error }, r.status) : json({ invoice: r.invoice, seller: r.seller });
}
