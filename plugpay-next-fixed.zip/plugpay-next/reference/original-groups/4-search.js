
  /* ============================================================================
     SEARCH
     ============================================================================ */
  function ResultCard({ result }) {
    return result.type === "merchant" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MerchantCard, { r: result }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuildingCard, { r: result });
  }
  function MerchantCard({ r }) {
    const { openDirectorySeller } = usePlugPay();
    return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "res-card", onClick: () => openDirectorySeller(r), children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "rc-top", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rc-av", style: { background: r.color }, children: r.initials }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "rc-info", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rc-name", children: r.name }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rc-sub", children: r.sub }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `rc-badge ${r.badgeClass}`, children: r.badge })
        ] })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "rc-stats", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "rcs", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "rcs-n", children: [
            r.rating,
            "\u2605"
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rcs-l", children: "Rating" })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "rcs", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rcs-n", children: r.sales }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rcs-l", children: "Sales" })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "rcs", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rcs-n", children: r.reviews }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rcs-l", children: "Reviews" })
        ] })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { className: "rc-btn", children: "View profile \u2192" })
    ] });
  }
  var MINI_STALLS = ["t", "v", "b", "e", "v", "b", "t", "e", "v", "b", "e", "b"];
  function BuildingCard({ r }) {
    const { openBuildingModal } = usePlugPay();
    return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "res-card bldg", onClick: () => openBuildingModal(r.name), children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "rc-top", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rc-av", style: { background: "var(--grad)", borderRadius: "var(--r4)" }, children: "\u{1F3E2}" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "rc-info", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rc-name", children: r.name }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rc-sub", children: r.sub })
        ] })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "floor-mini", children: MINI_STALLS.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `fm-stall ${s === "e" ? "fms-vac" : "fms-occ"}` }, i)) }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "rc-stats", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "rcs", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rcs-n", children: r.registered }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rcs-l", children: "Registered" })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "rcs", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rcs-n", children: r.floors }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rcs-l", children: "Floors" })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "rcs", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "rcs-n", children: [
            r.pct,
            "%"
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rcs-l", children: "Covered" })
        ] })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { className: "rc-btn bd-btn-mini", children: "View building \u2192" })
    ] });
  }
  function ResultsSection() {
    const { resultsShown, resultsTitle, resultsMeta, shownResults, hasMore, moreHint, filter, setFilter, loadMore } = usePlugPay();
    return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `results-section results-container${resultsShown ? " on" : ""}`, id: "results-section", children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "results-inner", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "results-header", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "results-title", id: "results-title", children: resultsTitle }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "results-meta", id: "results-meta", children: resultsMeta })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { display: "flex", gap: "8px" }, children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { className: `rf${filter === "all" ? " on" : ""}`, onClick: () => setFilter("all"), children: "All" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { className: `rf${filter === "merchant" ? " on" : ""}`, onClick: () => setFilter("merchant"), children: "Merchants" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { className: `rf${filter === "building" ? " on" : ""}`, onClick: () => setFilter("building"), children: "Buildings" })
        ] })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "results-grid", id: "results-grid", children: shownResults.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultCard, { result: r }, r.name + i)) }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "load-more-wrap", id: "load-more-wrap", style: { display: hasMore ? "block" : "none" }, children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { className: "load-more-btn", onClick: () => loadMore(), children: "Show more results \u2192" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "load-more-hint", id: "load-more-hint", children: hasMore ? moreHint : "" })
      ] })
    ] }) });
  }
  function SearchBar() {
    const { searchMode, setSearchMode, query, setQuery, doSearch } = usePlugPay();
    return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "hero-search-box search-wrap", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "hsb-tabs", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `hsb-tab${searchMode === "merchant" ? " on" : ""}`, onClick: () => setSearchMode("merchant"), children: "\u{1F3EC} Find a merchant" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `hsb-tab${searchMode === "building" ? " on" : ""}`, onClick: () => setSearchMode("building"), children: "\u{1F3E2} Find a building" })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "hsb-input-row", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", { width: "16", height: "16", viewBox: "0 0 24 24", fill: "none", stroke: "#8a8ca0", strokeWidth: 2, children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", { cx: "11", cy: "11", r: "7" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", { x1: "21", y1: "21", x2: "16.65", y2: "16.65" })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
          "input",
          {
            type: "text",
            id: "heroSearch",
            value: query,
            onChange: (e) => setQuery(e.target.value),
            placeholder: searchMode === "merchant" ? "e.g. Jane Mwangi, Zawadi Fashion, electronics\u2026" : "e.g. Anniversary Towers, Lonrho House\u2026",
            onKeyDown: (e) => {
              if (e.key === "Enter") doSearch();
            }
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { className: "hsb-btn", onClick: () => doSearch(), children: "Search \u2192" })
      ] })
    ] });
  }
  function SearchPage() {
    var pp = usePlugPay();
    return h(PublicShellX, { title: "Search PlugPay", subtitle: "Find a verified seller or a connected commercial building." },
      h("div", { className: "public-content" },
        h("div", { className: "public-search-box" }, h("div", { className: "public-search-row" },
          h("input", { className: "pp-input", value: pp.query, onChange: function (e) { pp.setQuery(e.target.value); }, placeholder: "Search seller, business or building", onKeyDown: function (e) { if (e.key === "Enter") pp.doSearch(); } }),
          h("button", { className: "pp-btn primary", onClick: function () { pp.doSearch(); } }, "Search")
        )),
        pp.resultsShown && h("div", { className: "public-count" }, pp.resultsMeta),
        h("div", { className: "public-result-grid" }, pp.shownResults.map(function (r, i) {
          return h("div", { className: "public-result", key: i, style: { cursor: "pointer" }, onClick: function () { if (r.type === "merchant") pp.viewSellerProfile(); else pp.openBuildingModal(r.name); } },
            h("div", { className: "public-result-title" }, r.name),
            h("div", { className: "public-result-meta" }, r.sub)
          );
        })),
        pp.resultsShown && pp.shownResults.length === 0 && h(EmptyState, { icon: "search", title: "No matches found", sub: "Try a different seller, business or building name." })
      )
    );
  }

  /* ---- Wiring: registers this group's modals, slots, pages and routes ---- */
  PP_ROUTES.push(
    ["/search", "search"]
  );
  PP_registry.registerPage("search", function () { return h(SearchPage, null); });