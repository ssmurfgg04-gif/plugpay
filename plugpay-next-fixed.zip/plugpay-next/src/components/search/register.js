import { h } from "../common/h.js";
import { PP_registry } from "../common/registry.js";
import { PP_ROUTES } from "../common/routing.js";
import { SearchPage } from "./SearchPage.js";

/* ---- Wiring: registers this group's modals, slots, pages and routes ---- */
PP_ROUTES.push(
  ["/search", "search"]
);

PP_registry.registerPage("search", function () { return h(SearchPage, null); });
