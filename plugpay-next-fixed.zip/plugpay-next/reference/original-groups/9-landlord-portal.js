
  /* ============================================================================
     LANDLORD PORTAL (auth, dashboard, buildings, sellers, stalls)
     ============================================================================ */

  /* ---- Auth: sign in ---- */
  var llAuthIconWrap = {
    width: "56px",
    height: "56px",
    borderRadius: "50%",
    background: "var(--accent-bg)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontSize: "26px",
    margin: "0 auto 12px"
  };
  var llAuthLabel = {
    fontSize: "11px",
    fontWeight: 700,
    color: "var(--muted)",
    fontFamily: "var(--fm)",
    display: "block",
    marginBottom: "6px",
    textTransform: "uppercase",
    letterSpacing: ".06em"
  };
  var llAuthTextInput = {
    width: "100%",
    padding: "13px 14px",
    border: "1.5px solid var(--border2)",
    borderRadius: "var(--r6)",
    fontSize: "16px",
    fontFamily: "var(--fb)",
    outline: "none",
    background: "var(--bg)",
    transition: "border-color .2s",
    marginBottom: "16px"
  };
  var llAuthCodeInput = {
    width: "100%",
    padding: "16px 14px",
    border: "1.5px solid var(--border2)",
    borderRadius: "var(--r6)",
    fontSize: "28px",
    fontFamily: "var(--fm)",
    outline: "none",
    background: "var(--bg)",
    transition: "border-color .2s",
    marginBottom: "16px",
    letterSpacing: "10px",
    textAlign: "center"
  };
  var llAuthSubmitBtn = {
    width: "100%",
    padding: "14px",
    borderRadius: "100px",
    background: "var(--grad)",
    color: "#fff",
    fontFamily: "var(--fb)",
    fontSize: "15px",
    fontWeight: 800,
    border: "none",
    cursor: "pointer"
  };
  var llAuthLink = {
    color: "var(--accent)",
    textDecoration: "none",
    fontWeight: 700
  };
  function llFocusRing() {
    return {
      onFocus: (e) => e.currentTarget.style.borderColor = "var(--accent)",
      onBlur: (e) => e.currentTarget.style.borderColor = "var(--border2)"
    };
  }
  function LlOtpStep() {
    const { llPhone, llMethod, llOtp, setLlOtp, llVerifyOTP, llGoBack } = usePlugPay();
    return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { padding: "32px" }, children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { textAlign: "center", marginBottom: "20px" }, children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: llAuthIconWrap, children: "\u{1F4AC}" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { fontSize: "22px", fontWeight: 900, color: "var(--ink)", marginBottom: "4px" }, children: "Enter your OTP" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { fontSize: "13px", color: "var(--muted)", lineHeight: "1.55" }, children: [
          "Code sent to",
          " ",
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { style: { color: "var(--ink)" }, children: llPhone.trim() || (llMethod === "email" ? "you@email.com" : "07XX XXX XXX") }),
          " ",
          "via ",
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: llMethod === "email" ? "email" : "SMS" }),
          "."
        ] })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { style: llAuthLabel, children: "ONE-TIME CODE" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        "input",
        {
          type: "tel",
          placeholder: "_ _ _ _ _ _",
          maxLength: 6,
          style: llAuthCodeInput,
          value: llOtp,
          onChange: (e) => setLlOtp(e.target.value),
          onKeyDown: (e) => {
            if (e.key === "Enter") llVerifyOTP();
          },
          ...llFocusRing()
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { style: llAuthSubmitBtn, onClick: () => llVerifyOTP(), children: "Verify & open dashboard \u2192" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { textAlign: "center", fontSize: "12px", color: "var(--muted2)", marginTop: "14px", fontFamily: "var(--fm)" }, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        "a",
        {
          href: "#",
          onClick: (e) => {
            e.preventDefault();
            llGoBack();
          },
          style: llAuthLink,
          children: "\u2190 Change number"
        }
      ) })
    ] });
  }
  function LlPhoneStep() {
    const { llMethod, llSetMethod, llPhone, setLlPhone, llSendOTP, llShowPinLogin } = usePlugPay();
    return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { padding: "32px" }, children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { textAlign: "center", marginBottom: "20px" }, children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: llAuthIconWrap, children: "\u{1F3E2}" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { fontSize: "22px", fontWeight: 900, color: "var(--ink)", marginBottom: "4px" }, children: "Landlord sign-in" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { fontSize: "13px", color: "var(--muted)", lineHeight: "1.55" }, children: "Enter your email or phone number. We'll verify you're the registered owner or property manager for your building(s)." })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "method-toggle", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { type: "button", className: `method-toggle-btn${llMethod === "sms" ? " active" : ""}`, onClick: () => llSetMethod("sms"), children: "\u{1F4F1} SMS" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { type: "button", className: `method-toggle-btn${llMethod === "email" ? " active" : ""}`, onClick: () => llSetMethod("email"), children: "\u2709\uFE0F Email" })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { style: llAuthLabel, children: llMethod === "email" ? "EMAIL ADDRESS" : "PHONE NUMBER" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        "input",
        {
          type: llMethod === "email" ? "email" : "tel",
          placeholder: llMethod === "email" ? "you@email.com" : "07XX XXX XXX",
          style: llAuthTextInput,
          value: llPhone,
          onChange: (e) => setLlPhone(e.target.value),
          ...llFocusRing()
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { style: llAuthSubmitBtn, onClick: () => llSendOTP(), children: "Send OTP \u2192" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { textAlign: "center", fontSize: "11.5px", color: "var(--muted2)", marginTop: "14px", lineHeight: "1.6" }, children: "Only verified landlords & property managers can access trader verification." }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { textAlign: "center", fontSize: "12px", marginTop: "10px", fontFamily: "var(--fm)" }, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        "a",
        {
          href: "#",
          onClick: (e) => {
            e.preventDefault();
            llShowPinLogin();
          },
          style: llAuthLink,
          children: "Already set a PIN? Sign in with phone + PIN \u2192"
        }
      ) })
    ] });
  }
  function LlPinLoginStep() {
    const { llPinLoginPhone, setLlPinLoginPhone, llPinLoginPin, setLlPinLoginPin, llPinLogin, llGoBackFromPin } = usePlugPay();
    return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { padding: "32px" }, children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { textAlign: "center", marginBottom: "20px" }, children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: llAuthIconWrap, children: "\u{1F511}" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { fontSize: "22px", fontWeight: 900, color: "var(--ink)", marginBottom: "4px" }, children: "Sign in with PIN" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { fontSize: "13px", color: "var(--muted)", lineHeight: "1.55" }, children: "Enter your phone number and 6-digit PIN." })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { style: llAuthLabel, children: "PHONE NUMBER" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        "input",
        {
          type: "tel",
          placeholder: "07XX XXX XXX",
          style: { ...llAuthTextInput, marginBottom: "14px" },
          value: llPinLoginPhone,
          onChange: (e) => setLlPinLoginPhone(e.target.value),
          ...llFocusRing()
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { style: llAuthLabel, children: "6-DIGIT PIN" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        "input",
        {
          type: "password",
          inputMode: "numeric",
          placeholder: "_ _ _ _ _ _",
          maxLength: 6,
          style: llAuthCodeInput,
          value: llPinLoginPin,
          onChange: (e) => setLlPinLoginPin(e.target.value),
          onKeyDown: (e) => {
            if (e.key === "Enter") llPinLogin();
          },
          ...llFocusRing()
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { style: llAuthSubmitBtn, onClick: () => llPinLogin(), children: "Sign in \u2192" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { textAlign: "center", fontSize: "12px", color: "var(--muted2)", marginTop: "14px", fontFamily: "var(--fm)" }, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        "a",
        {
          href: "#",
          onClick: (e) => {
            e.preventDefault();
            llGoBackFromPin();
          },
          style: llAuthLink,
          children: "\u2190 Use OTP instead"
        }
      ) })
    ] });
  }
  function LlSetPinStep() {
    const { llSetPinValue, setLlSetPinValue, llSetPin } = usePlugPay();
    return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { padding: "32px" }, children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { textAlign: "center", marginBottom: "20px" }, children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: llAuthIconWrap, children: "\u{1F511}" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { fontSize: "22px", fontWeight: 900, color: "var(--ink)", marginBottom: "4px" }, children: "Set a 6-digit PIN" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { fontSize: "13px", color: "var(--muted)", lineHeight: "1.55" }, children: "Use this PIN with your phone number to sign in next time \u2014 no OTP needed." })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { style: llAuthLabel, children: "CHOOSE A 6-DIGIT PIN" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        "input",
        {
          type: "password",
          inputMode: "numeric",
          placeholder: "_ _ _ _ _ _",
          maxLength: 6,
          style: llAuthCodeInput,
          value: llSetPinValue,
          onChange: (e) => setLlSetPinValue(e.target.value),
          onKeyDown: (e) => {
            if (e.key === "Enter") llSetPin();
          },
          ...llFocusRing()
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { style: llAuthSubmitBtn, onClick: () => llSetPin(), children: "Set PIN & open dashboard \u2192" })
    ] });
  }
  function LandlordModal() {
    const { llStep } = usePlugPay();
    return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, { id: "modal-landlord", children: [
      llStep === "phone" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LlPhoneStep, {}),
      llStep === "pinlogin" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LlPinLoginStep, {}),
      llStep === "otp" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LlOtpStep, {}),
      llStep === "setpin" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LlSetPinStep, {})
    ] });
  }

  /* ---- Landlord data and helpers ---- */
  var initialVacantStalls = [
    { id: "103", label: "Floor 1, Stall 103" },
    { id: "204", label: "Floor 2, Stall 204" },
    { id: "402", label: "Floor 4, Stall 402" }
  ];
  var initialPendingTraders = [
    { id: "mary", name: "Mary Njeri", sub: "Claims Floor 1, Stall 8 \xB7 Textiles", initials: "MN", color: "#8a8a8a" },
    { id: "samuel", name: "Samuel Kiptoo", sub: "Claims Floor 2, Stall 14 \xB7 Phone Accessories", initials: "SK", color: "#8a8a8a" },
    { id: "lucy", name: "Lucy Wambui", sub: "Claims Floor 3, Stall 3 \xB7 Cosmetics", initials: "LW", color: "#8a8a8a" }
  ];
  var initialVerifiedTraders = [
    { id: "jane", name: "Jane Mwangi", sub: "Fashion \xB7 Floor 3, Stall 301", initials: "JM", color: "#51104a" },
    { id: "peter", name: "Peter Otieno", sub: "Electronics \xB7 Floor 3, Stall 302", initials: "PO", color: "#185FA5" },
    { id: "david", name: "David Mutua", sub: "Hardware \xB7 Floor 2, Stall 202", initials: "DM", color: "#534AB7" },
    { id: "amina", name: "Amina Kibe", sub: "Food \xB7 Floor 3, Stall 303", initials: "AK", color: "#BA7517" }
  ];
  var initialLbAccounts = [
    { id: "lb1", name: "Anniversary Towers", street: "Moi Avenue \xB7 Nairobi CBD", totalStalls: 72 },
    { id: "lb2", name: "Lonrho House", street: "Kenyatta Ave \xB7 Nairobi CBD", totalStalls: 58 }
  ];
  var initialLbData = {
    lb1: { pending: initialPendingTraders, verified: initialVerifiedTraders, vacated: [], vacant: initialVacantStalls, onPlugPay: 58 },
    lb2: { pending: [], verified: [{ id: "grace", name: "Grace Akinyi", sub: "Beauty \xB7 Floor 1, Stall 5", initials: "GA", color: "#D85A30" }], vacated: [], vacant: [{ id: "l2s4", label: "Floor 2, Stall 4" }, { id: "l2s9", label: "Floor 3, Stall 9" }], onPlugPay: 39 }
  };
  function LlStatus(props) { return h("span", { className: "pp-status" + (props.ok ? "" : " pending") }, props.ok ? "VERIFIED" : "PENDING"); }
  function landlordVacateSeller(
    pp,
    seller
  ) {

    if (!seller) {
      return;
    }

    var sellerId =
      seller.id;

    var location =
      String(
        seller.sub ||
        seller.location ||
        ""
      );

    var stallMatch =
      location.match(
        /Stall\s*([A-Za-z0-9-]+)/i
      );

    var stallId =
      stallMatch
        ? stallMatch[1]
        : seller.stallId;

    var buildingId =
      pp.lbActive &&
      pp.lbActive.id;

    if (!buildingId) {
      return;
    }

    pp.updLb(
      buildingId,
      function (current) {

        var vacant =
          current.vacant ||
          [];

        var alreadyVacant =
          vacant.some(
            function (stall) {
              return String(
                stall.id
              ) === String(
                stallId
              );
            }
          );

        return {

          pending:
            current.pending ||
            [],

          verified:
            (
              current.verified ||
              []
            ).filter(
              function (x) {
                return x.id !==
                  sellerId;
              }
            ),

          vacated:
            [
              seller,
              ...(current.vacated || [])
            ],

          vacant:
            stallId &&
            !alreadyVacant

              ? [
                  {
                    id:
                      stallId,

                    label:
                      "Stall " +
                      stallId,

                    available:
                      true
                  },

                  ...vacant
                ]

              : vacant
        };

      }
    );

    pp.showToast(
      seller.name +
      " vacated. Stall " +
      (
        stallId ||
        ""
      ) +
      " is now available."
    );
  }

  /* ---- Dashboard, buildings, sellers and stalls pages ---- */
  function LbSwitcher() {
    var pp = usePlugPay();
    return h("div", { className: "lb-switch" },
      h("div", { className: "lb-switch-l" }, "Building account"),
      h("div", { className: "lb-chips" }, pp.lbAccounts.map(function (a) {
        return h("button", { key: a.id, className: "lb-chip" + (a.id === pp.lbActive.id ? " on" : ""), onClick: function () { pp.lbSwitch(a.id); } }, a.name);
      })));
  }
  function LandlordSellerList(props) {
    return h("section", { className: "ll-status-card" },
      h("div", { className: "ll-section-title" }, props.title),
      h("div", { className: "ll-section-sub" }, props.subtitle),
      h("div", { className: "ll-seller-list" },
        props.items.map(function (seller) {
          return h("div", { className: "ll-seller-row", key: seller.id },
            h("div", { className: "ll-seller-avatar", style: seller.color ? { background: seller.color, color: "#fff" } : undefined }, seller.initials || seller.name.charAt(0)),
            h("div", { className: "ll-seller-info" }, h("strong", null, seller.name), h("span", null, seller.sub)),
            h("button", { className: "sp-edit-btn", onClick: function () { if (props.action) props.action(seller); } }, props.actionLabel));
        }),
        props.items.length === 0 && h("div", { className: "ll-empty" }, props.empty)));
  }
  function LandlordVerificationList() {
    var pp = usePlugPay();
    return h(LandlordSellerList, { title: "Awaiting verification", subtitle: "Sellers waiting for landlord verification.", items: pp.pendingTraders, actionLabel: "Verify", action: function (seller) { pp.llVerifyTrader(seller.id); }, empty: "No sellers awaiting verification." });
  }
  function LandlordVerifiedList() {
    var pp = usePlugPay();
    return h(LandlordSellerList, { title: "Verified by landlord", subtitle: "Sellers currently occupying this building.", items: pp.verifiedTraders, actionLabel: "Vacate", action: function (seller) {
      landlordVacateSeller(
        pp,
        seller
      );
    }, empty: "No verified sellers yet." });
  }
  function LandlordVacatedList() {
    var pp = usePlugPay();
    return h("section", { className: "ll-status-card" },
      h("div", { className: "ll-section-title" }, "Recently vacated"),
      h("div", { className: "ll-section-sub" }, "Seller history remains attached to the seller."),
      pp.vacatedTraders.map(function (seller) {
        return h("div", { className: "ll-seller-row muted", key: seller.id },
          h("div", { className: "ll-seller-avatar" }, "\u2713"),
          h("div", { className: "ll-seller-info" }, h("strong", null, seller.name), h("span", null, seller.sub)),
          h("span", { className: "pp-status" }, "VACATED"));
      }));
  }
  function LandlordVacantStalls() {
    var pp = usePlugPay();
    var vacant = pp.vacantStalls || [];
    return h("section", { className: "ll-status-card" },
      h("div", { className: "ll-section-title" }, "Unoccupied stalls"),
      h("div", { className: "ll-section-sub" }, "Available stalls ready for admission."),
      vacant.map(function (stall) {
        return h("div", { className: "ll-seller-row", key: stall.id },
          h("div", { className: "ll-seller-avatar vacant" }, "+"),
          h("div", { className: "ll-seller-info" }, h("strong", null, stall.id), h("span", null, stall.label)),
          h("button", { className: "sp-edit-btn on", onClick: function () { pp.llOpenAdmitSeller(stall.id, stall.label); } }, "Admit seller"));
      }),
      vacant.length === 0 && h("div", { className: "ll-empty" }, "No vacant stalls right now."));
  }
  function LandlordBuildingView() {
    var pp = usePlugPay();
    return h("div", { className: "ll-building-view", style: { borderRadius: 18, overflow: "hidden", border: "1px solid var(--border)", background: "#fff", marginBottom: 14 } },
      h(BuildingViewContainer, { id: pp.lbActive.name, landlord: true }));
  }
  function LandlordDashboardPage() {
    var pp = usePlugPay();
    if (!pp.llAuthed) return h(AppShellX, { role: "Landlord", active: "dashboard", title: "Landlord dashboard" }, h(DashSignIn, { msg: "Sign in to your landlord account to view your dashboard.", onClick: pp.openLandlordModal }));
    return h(AppShellX, { role: "Landlord", active: "dashboard", title: pp.lbActive.name, subtitle: "Manage your building, sellers, verification and vacant stalls." }, h(Slot, { name: "landlord.dashboard" }));
  }
  function AddBuildingCard() {
    var pp = usePlugPay();
    var _n = PR.useState(""), name = _n[0], setName = _n[1];
    var _s = PR.useState(""), street = _s[0], setStreet = _s[1];
    var _t = PR.useState(""), stalls = _t[0], setStalls = _t[1];
    return h("section", { className: "app-card", style: { marginTop: 14 } },
      h("div", { className: "app-card-title" }, "Add another building"),
      h("div", { className: "app-card-sub" }, "Each building you add gets its own landlord account, separate from the others."),
      h("div", { className: "app-form-grid", style: { marginTop: 10 } },
        h("label", { className: "pp-field" }, h("span", { className: "pp-label" }, "Building name"), h("input", { className: "pp-input", value: name, onChange: function (e) { setName(e.target.value); }, placeholder: "e.g. Kimathi House" })),
        h("label", { className: "pp-field" }, h("span", { className: "pp-label" }, "Street / area"), h("input", { className: "pp-input", value: street, onChange: function (e) { setStreet(e.target.value); }, placeholder: "e.g. Kimathi St" })),
        h("label", { className: "pp-field" }, h("span", { className: "pp-label" }, "Total stalls"), h("input", { className: "pp-input", type: "number", value: stalls, onChange: function (e) { setStalls(e.target.value); }, placeholder: "e.g. 40" }))),
      h("div", { className: "app-actions" }, h("button", { className: "pp-btn primary", onClick: function () { if (pp.llAddBuilding(name, street, stalls)) { setName(""); setStreet(""); setStalls(""); } } }, "Create building account")));
  }
  function LandlordBuildingsPage() {
    var pp = usePlugPay();
    if (!pp.llAuthed) return h(AppShellX, { role: "Landlord", active: "buildings", title: "My buildings" }, h(DashSignIn, { msg: "Sign in to view your buildings.", onClick: pp.openLandlordModal }));
    return h(AppShellX, { role: "Landlord", active: "buildings", title: "My buildings", subtitle: "One login, one separate account per building." },
      h("div", { className: "app-list" },
        pp.lbAccounts.map(function (a) {
          var d = pp.lbData[a.id] || { pending: [], verified: [], vacant: [] };
          var on = a.id === pp.lbActive.id;
          return h("div", { className: "app-list-row", key: a.id },
            h("div", { className: "app-list-main" }, h("div", { className: "app-list-name" }, a.name + (on ? " \u00b7 open" : "")), h("div", { className: "app-list-meta" }, a.street + " \u00b7 " + a.totalStalls + " stalls \u00b7 " + d.verified.length + " verified \u00b7 " + d.pending.length + " pending")),
            h("button", { className: "pp-btn " + (on ? "secondary" : "primary"), onClick: function () { pp.lbSwitch(a.id); if (on) pp.openBuildingModal(a.name); else window.location.hash = "#/landlord/dashboard"; } }, on ? "View" : "Open account"));
        })),
      h(AddBuildingCard, null)
    );
  }
  function LandlordSellersPage() {
    var pp = usePlugPay();
    if (!pp.llAuthed) return h(AppShellX, { role: "Landlord", active: "sellers", title: "Sellers & verification" }, h(DashSignIn, { msg: "Sign in to review your sellers.", onClick: pp.openLandlordModal }));
    var total = pp.pendingTraders.length + pp.verifiedTraders.length;
    var sp = pp.sellerProfile, spVerified = !!sp.llPhoneVerified, here = pp.stallAssignment.building.trim().toLowerCase() === pp.lbActive.name.trim().toLowerCase();
    return h(AppShellX, { role: "Landlord", active: "sellers", title: pp.lbActive.name, subtitle: "Verify each seller who claims a stall. Pending until you do." },
      h(LbSwitcher, null),
      here && h("div", { className: "app-card", style: { marginBottom: 14 } },
        h("div", { className: "app-list-row", style: { border: 0, padding: 0 } },
          h("div", { className: "app-list-main" }, h("div", { className: "app-list-name" }, sp.bizName), h("div", { className: "app-list-meta" }, sp.ownerName + " \u00b7 " + sp.phone + " \u00b7 " + pp.stallAssignment.loc)),
          h(LlStatus, { ok: spVerified })),
        h("div", { className: "app-actions" },
          spVerified
            ? h("button", { className: "pp-btn danger", onClick: function () { pp.setLandlordPhoneVerified(false); } }, "Set back to Pending")
            : h("button", { className: "pp-btn primary", onClick: function () { pp.setLandlordPhoneVerified(true); } }, "Verify"))),
      h("div", { className: "app-list" },
        pp.pendingTraders.map(function (t) {
          return h("div", { className: "app-list-row", key: t.id },
            h("div", { className: "app-list-main" }, h("div", { className: "app-list-name" }, t.name), h("div", { className: "app-list-meta" }, t.sub)),
            h("div", { style: { display: "flex", gap: 8, alignItems: "center" } }, h(LlStatus, { ok: false }), h("button", { className: "pp-btn primary", onClick: function () { pp.llVerifyTrader(t.id); } }, "Verify")));
        }),
        pp.verifiedTraders.map(function (t) {
          return h("div", { className: "app-list-row", key: t.id },
            h("div", { className: "app-list-main" }, h("div", { className: "app-list-name" }, t.name), h("div", { className: "app-list-meta" }, t.sub)),
            h("div", { style: { display: "flex", gap: 8, alignItems: "center" } }, h(LlStatus, { ok: true }), h("button", { className: "pp-btn danger", onClick: function () { landlordVacateSeller(pp, t); } }, "Mark vacated")));
        }),
        total === 0 && h(EmptyState, { icon: "store", title: "No sellers in this building", sub: "Admit a seller from a vacant stall to get started." })
      )
    );
  }
  function LandlordStallsPage() {
    var pp = usePlugPay();
    var _f = PR.useState("all"), filter = _f[0], setFilter = _f[1];
    if (!pp.llAuthed) return h(AppShellX, { role: "Landlord", active: "stalls", title: "Stalls" }, h(DashSignIn, { msg: "Sign in to view stall occupancy.", onClick: pp.openLandlordModal }));
    var pending = pp.pendingTraders || [], verified = pp.verifiedTraders || [], vacant = pp.vacantStalls || [];
    var total = pending.length + verified.length + vacant.length;
    var rows = [];
    verified.forEach(function (t) { rows.push({ key: "occ-" + t.id, kind: "occupied", name: t.sub, meta: t.name, item: t }); });
    pending.forEach(function (t) { rows.push({ key: "p-" + t.id, kind: "awaiting", name: t.sub, meta: t.name, item: t }); });
    vacant.forEach(function (st) { rows.push({ key: "v-" + st.id, kind: "vacant", name: st.label, meta: "No seller yet", item: st }); });
    var shown = rows.filter(function (r) { return filter === "all" || r.kind === filter; });
    var tabs = [["all", "All (" + total + ")"], ["occupied", "Occupied (" + verified.length + ")"], ["awaiting", "Awaiting (" + pending.length + ")"], ["vacant", "Vacant (" + vacant.length + ")"]];
    function action(r) {
      if (r.kind === "vacant") return h("button", { className: "sp-edit-btn on", onClick: function () { pp.llOpenAdmitSeller(r.item.id, r.item.label); } }, "Admit");
      if (r.kind === "awaiting") return h("button", { className: "sp-edit-btn on", onClick: function () { pp.llVerifyTrader(r.item.id); } }, "Verify");
      return h("button", { className: "sp-edit-btn danger", onClick: function () { landlordVacateSeller(pp, r.item); } }, "Vacate");
    }
    return h(AppShellX, { role: "Landlord", active: "stalls", title: pp.lbActive.name, subtitle: "Every stall in this building and who is in it." },
      h(LbSwitcher, null),
      h("section", { className: "ll-stalls-summary" },
        h("div", null, h("b", null, total), h("span", null, "Total stalls")),
        h("div", null, h("b", null, verified.length), h("span", null, "Occupied")),
        h("div", null, h("b", null, pending.length), h("span", null, "Awaiting")),
        h("div", null, h("b", null, vacant.length), h("span", null, "Vacant"))),
      h(LandlordBuildingView, null),
      h("div", { className: "ll-stalls-filter" }, tabs.map(function (t) {
        return h("button", { key: t[0], type: "button", className: filter === t[0] ? "on" : "", onClick: function () { setFilter(t[0]); } }, t[1]);
      })),
      h("div", { className: "app-list" },
        shown.map(function (r) {
          return h("div", { className: "app-list-row", key: r.key },
            h("div", { className: "app-list-main" }, h("div", { className: "app-list-name" }, r.name), h("div", { className: "app-list-meta" }, r.meta)),
            h("div", { style: { display: "flex", gap: 8, alignItems: "center" } },
              r.kind === "vacant" ? h("span", { className: "pp-status pending" }, "VACANT") : h(LlStatus, { ok: r.kind === "occupied" }),
              action(r)));
        }),
        shown.length === 0 && h("div", { className: "ll-empty" }, "No stalls in this view.")
      )
    );
  }

  /* ---- Admit seller ---- */
  var labelStyle = {
    fontSize: "11px",
    fontWeight: 700,
    color: "var(--muted)",
    fontFamily: "var(--fm)",
    display: "block",
    marginBottom: "6px",
    textTransform: "uppercase",
    letterSpacing: ".06em"
  };
  var inputStyle = {
    width: "100%",
    padding: "12px 14px",
    border: "1.5px solid var(--border2)",
    borderRadius: "var(--r6)",
    fontSize: "14.5px",
    fontFamily: "var(--fb)",
    outline: "none",
    background: "var(--bg)",
    marginBottom: "12px"
  };
  function focusHandlers() {
    return {
      onFocus: (e) => e.currentTarget.style.borderColor = "var(--accent)",
      onBlur: (e) => e.currentTarget.style.borderColor = "var(--border2)"
    };
  }
  function AdmitSellerModal() {
    const {
      asStallLabel,
      asName,
      setAsName,
      asPhone,
      setAsPhone,
      asCategory,
      setAsCategory,
      asSubmitting,
      llSubmitAdmitSeller
    } = usePlugPay();
    return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, { id: "modal-admit-seller", innerClassName: "modal", children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { padding: "48px 24px 24px", maxWidth: "380px" }, children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { textAlign: "center", marginBottom: "18px" }, children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
          "div",
          {
            style: {
              width: "52px",
              height: "52px",
              borderRadius: "50%",
              background: "var(--accent-bg)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontSize: "24px",
              margin: "0 auto 10px"
            },
            children: "\u{1F513}"
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { fontSize: "19px", fontWeight: 900, color: "var(--ink)", marginBottom: "4px" }, children: "Admit a new seller" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { fontSize: "12.5px", color: "var(--muted)", lineHeight: "1.55" }, children: asStallLabel || "Into an unoccupied stall" })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { style: labelStyle, children: "SELLER NAME" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        "input",
        {
          type: "text",
          placeholder: "e.g. Grace Wambui",
          style: inputStyle,
          value: asName,
          onChange: (e) => setAsName(e.target.value),
          ...focusHandlers()
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { style: labelStyle, children: "PHONE NUMBER" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        "input",
        {
          type: "tel",
          placeholder: "07XX XXX XXX",
          style: inputStyle,
          value: asPhone,
          onChange: (e) => setAsPhone(e.target.value),
          ...focusHandlers()
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { style: labelStyle, children: "BUSINESS CATEGORY" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        "input",
        {
          type: "text",
          placeholder: "e.g. Fashion, Electronics\u2026",
          style: { ...inputStyle, marginBottom: "16px" },
          value: asCategory,
          onChange: (e) => setAsCategory(e.target.value),
          onKeyDown: (e) => {
            if (e.key === "Enter") llSubmitAdmitSeller();
          },
          ...focusHandlers()
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(
        "div",
        {
          style: {
            fontSize: "11.5px",
            color: "var(--muted)",
            lineHeight: "1.6",
            background: "var(--accent-bg)",
            borderRadius: "var(--r6)",
            padding: "10px 12px",
            marginBottom: "16px",
            display: "flex",
            gap: "8px",
            alignItems: "flex-start"
          },
          children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { style: { fontSize: "14px", flexShrink: 0 }, children: "\u2139\uFE0F" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Admitting a seller here marks them Verified and sends a claim link to their WhatsApp. It opens the sign-in page so they can take over the stall." })
          ]
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        "button",
        {
          style: {
            width: "100%",
            padding: "14px",
            borderRadius: "100px",
            background: "var(--grad)",
            color: "#fff",
            fontFamily: "var(--fb)",
            fontSize: "15px",
            fontWeight: 800,
            border: "none",
            cursor: "pointer"
          },
          onClick: () => llSubmitAdmitSeller(),
          disabled: asSubmitting,
          children: asSubmitting ? "Admitting\u2026" : "Admit & verify seller \u2192"
        }
      )
    ] }) });
  }

  /* ---- Wiring: registers this group's modals, slots, pages and routes ---- */
  PP_ROUTES.push(
    ["/landlord/dashboard", "landlord-dashboard"],
    ["/landlord/buildings", "landlord-buildings"],
    ["/landlord/sellers", "landlord-sellers"],
    ["/landlord/stalls", "landlord-stalls"],
    ["/landlord/documents", "landlord-sellers"]
  );
  PP_registry.register("modals", "landlord", LandlordModal, 90);
  PP_registry.register("modals", "admit-seller", AdmitSellerModal, 110);
  PP_registry.register("landlord.dashboard", "switcher", LbSwitcher, 10);
  PP_registry.register("landlord.dashboard", "building", LandlordBuildingView, 20);
  PP_registry.register("landlord.dashboard", "verification", LandlordVerificationList, 30);
  PP_registry.register("landlord.dashboard", "verified", LandlordVerifiedList, 40);
  PP_registry.register("landlord.dashboard", "vacated", LandlordVacatedList, 50);
  PP_registry.register("landlord.dashboard", "vacant", LandlordVacantStalls, 60);
  PP_registry.registerPage("landlord-dashboard", function () { return h(LandlordDashboardPage, null); });
  PP_registry.registerPage("landlord-buildings", function () { return h(LandlordBuildingsPage, null); });
  PP_registry.registerPage("landlord-sellers", function () { return h(LandlordSellersPage, null); });
  PP_registry.registerPage("landlord-stalls", function () { return h(LandlordStallsPage, null); });