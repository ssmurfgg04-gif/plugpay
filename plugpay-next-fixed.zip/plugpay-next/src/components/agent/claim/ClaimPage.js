import { usePlugPay } from "../../../store/context.js";
import { PR, h } from "../../common/h.js";
import { Link } from "../../common/routing.js";
import { PublicShellX } from "../../common/shells.js";

export function ClaimPage(props) {
  var pp = usePlugPay();
  var claim = pp.agentClaims.filter(function (c) { return c.token === props.token; })[0];
  var opened = PR.useRef(false);
  PR.useEffect(function () {
    if (claim && claim.status === "INVITED" && !opened.current) {
      opened.current = true;
      setTimeout(function () { pp.openClaimSignIn(claim.token); }, 120);
    }
  }, [claim && claim.status]);
  if (!claim) return h(PublicShellX, { title: "Claim link not found" }, h("div", { className: "app-card" }, h("div", { className: "app-card-title" }, "This claim link isn't valid or has expired."), h("div", { className: "app-card-sub" }, "Ask your agent or landlord to resend it."), h(Link, { to: "/", className: "pp-btn secondary" }, "Return home")));
  if (claim.status === "CLAIMED") return h(PublicShellX, { title: "Stall claimed", subtitle: claim.buildingName },
    h("section", { className: "app-card" },
      h("div", { className: "app-card-title" }, "\u2713 " + (claim.businessName || claim.ownerName || "This stall") + " is claimed"),
      h("div", { className: "app-card-sub" }, "Sign in with your number to open your dashboard."),
      h("div", { className: "app-actions" }, h("button", { className: "pp-btn primary", onClick: pp.openAuthModal }, "Sign in"), h(Link, { to: "/", className: "pp-btn secondary" }, "Return home"))));
  return h(PublicShellX, { title: "Claim your stall", subtitle: claim.buildingName + " \u00b7 " + claim.loc },
    h("section", { className: "app-card" },
      h("div", { className: "app-card-title" }, claim.businessName || claim.ownerName || "Your stall"),
      h("div", { className: "app-card-sub" }, claim.ownerName + " \u00b7 " + (claim.phone || "No phone on file")),
      h("div", { className: "app-card-sub" }, "Sign in with this number to claim the stall. " + (claim.verified ? "The landlord has already verified you." : "You'll show as Pending until the landlord verifies you.")),
      h("div", { className: "app-actions" }, h("button", { className: "pp-btn primary", onClick: function () { pp.openClaimSignIn(claim.token); } }, "Sign in to claim"))));
}
