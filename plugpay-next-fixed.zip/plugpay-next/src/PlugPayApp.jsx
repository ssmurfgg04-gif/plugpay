"use client";
/* PlugPay UI entry. Components live in src/components/<feature>/…; each feature's register.js wires its modals, slots, pages and routes.
   The register files are imported in the original group order, which keeps route and slot registration order unchanged. */
import "./legacy/icons-script.js";
import { navigate } from "./lib/router.js";
import { PlugPayProvider } from "./store/PlugPayProvider.jsx";
import { RouteSwitch } from "./app/RouteSwitch.js";
import { PR, h } from "./components/common/h.js";
import { PPBoundary } from "./components/common/states.js";
import "./components/common/register.js";
import "./components/landing/register.js";
import "./components/public-view/register.js";
import "./components/search/register.js";
import "./components/building/register.js";
import "./components/seller/register.js";
import "./components/agent/onboarding/register.js";
import "./components/agent/portal/register.js";
import "./components/landlord/register.js";
import "./components/quick-action/register.js";

function NavCatcher(props) {
  /* Pathname router replaces the original hash router: same-origin links navigate client-side, like the hash links did. */
  PR.useEffect(function () {
    function onClick(e) {
      if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
      var a = e.target && e.target.closest ? e.target.closest("a[href]") : null;
      if (!a || a.target === "_blank" || a.hasAttribute("download")) return;
      var href = a.getAttribute("href");
      if (!href || href.charAt(0) !== "/" || href.charAt(1) === "/") return;
      e.preventDefault();
      navigate(href);
    }
    document.addEventListener("click", onClick);
    return function () { document.removeEventListener("click", onClick); };
  }, []);
  return props.children;
}

function Home() {
  return h(PlugPayProvider, null, h(PPBoundary, null, h(NavCatcher, null, h(RouteSwitch, null))));
}

export default Home;
