import * as import_jsx_runtime from "../../ppJsxRuntime.js";
import { usePlugPay } from "../../store/context.js";

export function SearchBar() {
  const { searchMode, setSearchMode, query, setQuery, doSearch } = usePlugPay();
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "hero-search-box search-wrap", children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "hsb-tabs", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `hsb-tab${searchMode === "merchant" ? " on" : ""}`, onClick: () => setSearchMode("merchant"), children: "\u{1F3EC} Find a merchant" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `hsb-tab${searchMode === "building" ? " on" : ""}`, onClick: () => setSearchMode("building"), children: "\u{1F3E2} Find a building" })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "hsb-input-row", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", { width: "16", height: "16", viewBox: "0 0 24 24", fill: "none", stroke: "#8a8ca0", strokeWidth: 2, children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", { cx: "11", cy: "11", r: "7" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", { x1: "21", y1: "21", x2: "16.65", y2: "16.65" })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        "input",
        {
          type: "text",
          id: "heroSearch",
          value: query,
          onChange: (e) => setQuery(e.target.value),
          placeholder: searchMode === "merchant" ? "e.g. Jane Mwangi, Zawadi Fashion, electronics\u2026" : "e.g. Anniversary Towers, Lonrho House\u2026",
          onKeyDown: (e) => {
            if (e.key === "Enter") doSearch();
          }
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { className: "hsb-btn", onClick: () => doSearch(), children: "Search \u2192" })
    ] })
  ] });
}
