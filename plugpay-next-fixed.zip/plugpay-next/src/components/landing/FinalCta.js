import * as import_jsx_runtime from "../../ppJsxRuntime.js";
import { usePlugPay } from "../../store/context.js";

export function FinalCta() {
  const { openOnboard, openLandlordModal } = usePlugPay();
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "final-cta", id: "final-cta", children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Ready to sell without the risk?" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "section-p", children: "PlugPay bridges the gap between a DM and a real sale. Join other verified traders building trust on WhatsApp today." }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { display: "flex", flexWrap: "wrap", gap: "12px", justifyContent: "center" }, children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { className: "btn-mint", onClick: () => openOnboard(), children: "I'm an agent \u2192" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        "button",
        {
          className: "btn-mint",
          style: { background: "transparent", border: "1.5px solid rgba(255,255,255,.25)", color: "#fff" },
          onClick: () => openLandlordModal(),
          children: "I own a building"
        }
      )
    ] })
  ] });
}
