/* useAgentClaims — "agentClaims" group of the PlugPay store, extracted from PlugPayProvider.
   Statements are the original ones, in their original relative order. Names owned by other groups arrive through the shared
   per-render context object (ctx): groups that run earlier are destructured below, groups that run later are read lazily as ctx.name. */
import * as import_react from "react";
import { waClaimText } from "../../../data/claims.js";
import { initials, sameNumber } from "../../../lib/utils.js";
import { openWhatsApp } from "../../../lib/whatsapp.js";
import { usePersisted } from "../../usePersisted.js";

export function useAgentClaims(ctx) {
    const { openModal, sellerProfile, setAuthMethodState, setAuthOtp, setAuthPhone, setAuthPinLoginValue, setAuthSetPinValue, setAuthStep, setSellerProfile, setStallAssignment, setStallHistory, showToast, stallAssignment } = ctx;
    const claimTokenRef = (0, import_react.useRef)(null);
    const claimsApiRef = (0, import_react.useRef)(null);
    const [claimInfo, setClaimInfo] = (0, import_react.useState)(null);
    const [agentClaims, setAgentClaims] = usePersisted("claims", []);
    const [agentBuildings, setAgentBuildings] = (0, import_react.useState)([]);
    const stallLoc = (m) => (m.floor === "G" ? "Ground Floor" : "Floor " + m.floor) + ", Stall " + m.stallNum;
    const newAgentClaim = (m, bldg, extra) => ({ id: m.id, token: "clm" + m.id, businessName: m.biz, ownerName: m.ownerName, phone: m.phone, category: m.type, floor: m.floor, number: m.stallNum, loc: stallLoc(m), buildingName: bldg || "New building", status: "INVITED", verified: false, source: "agent", sentAt: new Date().toISOString(), ...(extra || {}) });
    const upsertAgentClaim = (m, bldg) => {
      setAgentClaims((l) => {
        const ex = l.filter((x) => x.id === m.id)[0];
        if (!ex) return [newAgentClaim(m, bldg, { draft: true }), ...l];
        return l.map((x) => x.id === m.id ? { ...x, businessName: m.biz, ownerName: m.ownerName, phone: m.phone, category: m.type, floor: m.floor, number: m.stallNum, loc: stallLoc(m), buildingName: x.draft ? (bldg || x.buildingName) : x.buildingName, sentAt: x.phone !== m.phone ? new Date().toISOString() : x.sentAt } : x);
      });
    };
    const publishAgentClaims = (list, bldg, stalls) => {
      setAgentClaims((l) => {
        const out = l.slice();
        list.forEach((m) => {
          const i = out.findIndex((x) => x.id === m.id);
          if (i >= 0) { if (out[i].draft) out[i] = { ...out[i], buildingName: bldg, draft: false }; }
          else out.unshift(newAgentClaim(m, bldg));
        });
        return out;
      });
      ctx.ensureLbAccount(bldg, "Nairobi CBD", stalls);
    };
    claimsApiRef.current = { upsert: upsertAgentClaim, publish: publishAgentClaims };
    const resendClaim = (token) => {
      const c = agentClaims.filter((x) => x.token === token)[0];
      if (!c) return;
      openWhatsApp(c.phone, waClaimText(c));
      showToast(`Claim link resent to ${c.ownerName || c.businessName} on WhatsApp`);
    };
    const openClaimSignIn = (token) => {
      const c = agentClaims.filter((x) => x.token === token)[0];
      if (!c) return;
      claimTokenRef.current = token;
      setClaimInfo({ token, name: c.businessName || c.ownerName, loc: c.loc, building: c.buildingName });
      setAuthStep("phone");
      setAuthOtp("");
      setAuthPinLoginValue("");
      setAuthSetPinValue("");
      setAuthMethodState("whatsapp");
      setAuthPhone(c.phone || "");
      openModal("modal-register");
    };
    const applyClaim = (token) => {
      const c = agentClaims.filter((x) => x.token === token)[0];
      if (!c) return;
      const same = sameNumber(c.phone, sellerProfile.phone);
      const loc = c.loc || "";
      setAgentClaims((l) => l.map((x) => x.token === token ? { ...x, status: "CLAIMED", claimedAt: new Date().toISOString() } : x));
      setSellerProfile((p) => Object.assign({}, p, same ? {} : { bizName: c.businessName || p.bizName, ownerName: c.ownerName || p.ownerName, phone: c.phone || p.phone, whatsapp: c.phone || p.whatsapp }, { llPhoneVerified: !!c.verified }));
      if (same && (stallAssignment.building !== c.buildingName || stallAssignment.loc !== loc)) {
        setStallHistory((hs) => [{ building: stallAssignment.building, loc: stallAssignment.loc, until: new Date().toISOString() }, ...hs]);
      }
      setStallAssignment({ building: c.buildingName, loc });
      const bid = ctx.lbIdByName(c.buildingName);
      if (bid && !c.verified) {
        const cur = ctx.lbData[bid] || ctx.emptyLb;
        const exists = cur.pending.concat(cur.verified).some((t) => t.claimToken === token || sameNumber(t.phone, c.phone));
        if (!exists) ctx.updLb(bid, (cu) => ({ pending: [{ id: "clm-" + token, claimToken: token, name: c.ownerName || c.businessName, phone: c.phone, sub: (c.category || "Seller") + " \u00b7 " + loc, initials: initials(c.ownerName || c.businessName || "S"), color: "#8a8a8a" }, ...cu.pending] }));
      }
      showToast(c.verified ? `Stall claimed \u2713 ${c.buildingName}'s landlord has already verified you` : `Stall claimed \u2713 Pending until ${c.buildingName}'s landlord verifies you`);
    };
    const changeStall = (building, loc) => {
      const prev = stallAssignment;
      if (prev.building === building && prev.loc === loc) return;
      const moved = prev.building.trim().toLowerCase() !== String(building).trim().toLowerCase();
      setStallHistory((hs) => [{ building: prev.building, loc: prev.loc, until: new Date().toISOString() }, ...hs]);
      setStallAssignment({ building, loc });
      if (!moved) return;
      setSellerProfile((p) => ({ ...p, llPhoneVerified: false }));
      const oldId = ctx.lbIdByName(prev.building);
      if (oldId) ctx.updLb(oldId, (cur) => {
        const gone = cur.verified.concat(cur.pending).filter((t) => sameNumber(t.phone, sellerProfile.phone));
        return gone.length ? { verified: cur.verified.filter((t) => !sameNumber(t.phone, sellerProfile.phone)), pending: cur.pending.filter((t) => !sameNumber(t.phone, sellerProfile.phone)), vacated: gone.concat(cur.vacated) } : {};
      });
      const newId = ctx.lbIdByName(building);
      if (newId) ctx.updLb(newId, (cur) => cur.pending.concat(cur.verified).some((t) => sameNumber(t.phone, sellerProfile.phone)) ? {} : { pending: [{ id: "mv-" + Date.now().toString(36), name: sellerProfile.ownerName || sellerProfile.bizName, phone: sellerProfile.phone, sub: (sellerProfile.role || "Seller") + " \u00b7 " + loc, initials: initials(sellerProfile.ownerName || sellerProfile.bizName || "S"), color: "#8a8a8a" }, ...cur.pending] });
    };
    return {
      agentClaims,
      claimTokenRef,
      setClaimInfo,
      applyClaim,
      changeStall,
      claimsApiRef,
      setAgentBuildings,
      setAgentClaims,
      resendClaim,
      openClaimSignIn,
      claimInfo,
      agentBuildings
    };
}
