import { usePlugPay } from "../../../../store/context.js";
import { usePersisted } from "../../../../store/usePersisted.js";
import { h } from "../../../common/h.js";

export function SellerDashboardVouches() {
  var pp = usePlugPay();
  var _v = usePersisted("vouches", {
    people: [
      { id: "v1", name: "Peter Otieno", role: "Electronics seller", vouched: true },
      { id: "v2", name: "Amina Kibe", role: "Fashion seller", vouched: true },
      { id: "u1", name: "Samuel Kamau", role: "Mobile accessories", vouched: false }
    ]
  }), state = _v[0], setState = _v[1];
  var people = state.people || [];
  function setVouch(id, value) {
    setState({ people: people.map(function (x) { return x.id === id ? Object.assign({}, x, { vouched: value }) : x; }) });
    var who = people.filter(function (x) { return x.id === id; })[0];
    if (who) pp.showToast(value ? "You vouched for " + who.name + " \u2713" : "Vouch removed for " + who.name);
  }
  function col(title, list, mark, cls, empty) {
    return h("div", { className: "sp-vouch-column" },
      h("div", { className: "sp-vouch-heading" }, title + " (" + list.length + ")"),
      list.map(function (x) {
        return h("div", { className: "sp-vouch-person", key: x.id },
          h("span", { className: cls }, mark),
          h("div", { className: "sp-vouch-who" }, h("strong", null, x.name), h("small", null, x.role)),
          x.vouched
            ? h("button", { type: "button", className: "sp-edit-btn danger", onClick: function () { setVouch(x.id, false); } }, "Remove vouch")
            : h("button", { type: "button", className: "sp-edit-btn on", onClick: function () { setVouch(x.id, true); } }, "Vouch"));
      }),
      list.length === 0 && h("small", { className: "sp-vouch-empty" }, empty));
  }
  return h("div", { className: "dx-card" },
    h("div", { className: "dx-head" },
      h("div", { className: "dx-k", style: { margin: 0 } }, "Vouching"),
      h("span", { className: "dx-chip ok" }, people.filter(function (x) { return x.vouched; }).length + " vouched")),
    h("section", { className: "sp-vouch-summary" },
      col("Vouched sellers", people.filter(function (x) { return x.vouched; }), "\u2713", "sp-vouch-check", "No vouched sellers yet."),
      col("Yet to be vouched", people.filter(function (x) { return !x.vouched; }), "\u2022", "sp-vouch-pending", "Everyone is vouched.")));
}
