/* useOnboardingBuilding — "onbBuilding" group of the PlugPay store, extracted from PlugPayProvider.
   Statements are the original ones, in their original relative order. Names owned by other groups arrive through the shared
   per-render context object (ctx): groups that run earlier are destructured below, groups that run later are read lazily as ctx.name. */
import * as import_react from "react";
import { navigate } from "../../../lib/router.js";

export function useOnboardingBuilding(ctx) {
    const { closeModal, obBldgName, obFloorStalls, obFloorsCount, obMerchantList, obStep_, setObFloorStallsState, setObStep_, showToast } = ctx;
    const setObFloorStall = (0, import_react.useCallback)((key, v) => {
      setObFloorStallsState((s) => ({ ...s, [key]: v }));
    }, []);
    const obTotalStalls = (0, import_react.useMemo)(
      () => Object.values(obFloorStalls).reduce((s, v) => s + (parseInt(v) || 0), 0),
      [obFloorStalls]
    );
    const obGoToStep = (0, import_react.useCallback)((n) => setObStep_(n), []);
    const obStep = (0, import_react.useCallback)(
      (dir) => {
        const total = 4;
        if (obStep_ === total && dir > 0) {
          if (obMerchantList.length === 0) {
            showToast("Add at least one seller before publishing");
            return;
          }
          const n = obMerchantList.length;
          showToast(`\u{1F389} Building published with ${n} seller${n === 1 ? "" : "s"} live on PlugPay! QR code sent to the manager and a claim link sent to each seller on WhatsApp.`);
          ctx.claimsApiRef.current && ctx.claimsApiRef.current.publish(obMerchantList, obBldgName || "New building", obTotalStalls);
          ctx.setAgentBuildings((b) => [{ name: obBldgName || "New building", street: "Nairobi CBD", floorsCount: obFloorsCount, stalls: obTotalStalls, merchants: obMerchantList.length }, ...b]);
          closeModal("modal-onboard");
          navigate("/agent/claims");
          return;
        }
        let next = obStep_ + dir;
        if (dir > 0 && obStep_ === 1) next = 4;
        if (dir < 0 && obStep_ === 4) next = 1;
        if (next < 1 || next > total) return;
        setObStep_(next);
      },
      [closeModal, obBldgName, obFloorsCount, obMerchantList, obStep_, obTotalStalls, showToast]
    );
    return {
      obGoToStep,
      obStep,
      setObFloorStall,
      obTotalStalls
    };
}
