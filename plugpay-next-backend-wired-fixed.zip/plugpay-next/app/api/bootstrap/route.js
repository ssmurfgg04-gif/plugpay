import { adminDb, requireUser, json, getSellerForUser, publicSeller } from '../../../src/server/supabase.js';
export async function GET(request) {
  const db = adminDb();
  const auth = await requireUser(request);
  let user = null, profile = null, seller = null;
  if (!auth.error) { user = auth.user; const p = await db.from('profiles').select('*').eq('id', user.id).maybeSingle(); profile = p.data; seller = await getSellerForUser(user.id); }
  const [buildings, publicSellers] = await Promise.all([
    db.from('buildings').select('id,name,address,floors,category,maps_url').order('name'),
    db.from('sellers').select('*').order('business_name').limit(100)
  ]);
  return json({ user, profile, seller: seller ? publicSeller(seller) : null, buildings: buildings.data || [], sellers: (publicSellers.data || []).map(s => publicSeller(s)) });
}
