/* useSearchStore — "search" group of the PlugPay store, extracted from PlugPayProvider.
   Statements are the original ones, in their original relative order. Names owned by other groups arrive through the shared
   per-render context object (ctx): groups that run earlier are destructured below, groups that run later are read lazily as ctx.name. */
import * as import_react from "react";
import { buildings, merchants } from "../../data/directory.js";
import { apiFetch } from "../../lib/backend.js";

var PAGE = 4;

export function useSearchStore(ctx) {
    const [searchMode, setSearchMode] = (0, import_react.useState)("merchant");
    const [query, setQuery] = (0, import_react.useState)("");
    const [resultsShown, setResultsShown] = (0, import_react.useState)(false);
    const [currentResults, setCurrentResults] = (0, import_react.useState)([]);
    const [shownCount, setShownCount] = (0, import_react.useState)(0);
    const [filter, setFilterState] = (0, import_react.useState)("all");
    const [resultsTitle, setResultsTitle] = (0, import_react.useState)("Search results");
    const [resultsMeta, setResultsMeta] = (0, import_react.useState)("Showing top matches");
    const pool = (0, import_react.useMemo)(() => [...merchants, ...buildings], []);
    const doSearch = (0, import_react.useCallback)(async (q) => {
      var _a; const query_ = ((_a=q!=null?q:query)!=null?_a:"").trim(); setResultsShown(true); setFilterState("all");
      try { const remote=await apiFetch(`/api/search?q=${encodeURIComponent(query_)}`); const results=remote.results||[]; setCurrentResults(results); setShownCount(Math.min(PAGE,results.length)); setResultsTitle(query_?`Results for "${query_}"`:"All merchants & buildings"); setResultsMeta(`${results.length} match${results.length!==1?"es":""}`); }
      catch(e){ const ql=query_.toLowerCase(); const results=ql?pool.filter(r=>(r.name+r.sub).toLowerCase().includes(ql)):pool; setCurrentResults(results); setShownCount(Math.min(PAGE,results.length)); setResultsTitle(query_?`Results for "${query_}"`:"All merchants & buildings"); setResultsMeta(`${results.length} match${results.length!==1?"es":""}`); }
    }, [pool,query]);
    const setFilter = (0, import_react.useCallback)(
      (type) => {
        setFilterState(type);
        const results = type === "all" ? pool : pool.filter((r) => r.type === type);
        setCurrentResults(results);
        setShownCount(Math.min(PAGE, results.length));
        setResultsTitle(type === "all" ? "All results" : type === "merchant" ? "Merchants" : "Buildings");
        setResultsMeta(`${results.length} match${results.length !== 1 ? "es" : ""}`);
      },
      [pool]
    );
    const loadMore = (0, import_react.useCallback)(() => {
      setShownCount((c) => Math.min(c + PAGE, currentResults.length));
    }, [currentResults.length]);
    const shownResults = currentResults.slice(0, shownCount);
    const hasMore = shownCount < currentResults.length;
    const moreHint = `Showing ${shownCount} of ${currentResults.length} results \xB7 ${currentResults.length - shownCount} more`;
    return {
      searchMode,
      setSearchMode,
      query,
      setQuery,
      resultsShown,
      resultsTitle,
      resultsMeta,
      shownResults,
      hasMore,
      moreHint,
      filter,
      setFilter,
      doSearch,
      loadMore
    };
}
