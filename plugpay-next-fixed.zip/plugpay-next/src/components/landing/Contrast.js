import * as import_jsx_runtime from "../../ppJsxRuntime.js";
import { PROFILE_SHOT_DATA_URI, WITH, WITHOUT } from "./landingData.js";

export function Contrast() {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", { className: "contrast", id: "contrast", children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "wrap", children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "eyebrow", children: "Trust contrast" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "The PlugPay trust advantage." }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "section-p", children: "Comparing the risk of a bare WhatsApp number to the confidence of a PlugPay-verified stall." }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "cc-grid", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "cc-col without", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "cc-h", children: "Without PlugPay" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "cc-sub", children: "Bare WhatsApp number" }),
        WITHOUT.map((it) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "cc-item", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "cc-icon", children: "\u2715" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "cc-item-t", children: it.t }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "cc-item-d", children: it.d })
          ] })
        ] }, it.t))
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "cc-col with", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "cc-h", children: "With PlugPay" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "cc-sub", children: "Verified trust infrastructure" }),
        WITH.map((it) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "cc-item", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "cc-icon", children: "\u2713" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "cc-item-t", children: it.t }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "cc-item-d", children: it.d })
          ] })
        ] }, it.t))
      ] })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "cc-showcase", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "cc-showcase-text", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "cc-h", children: "See a real trust profile" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "section-p", children: "Every verified trader gets a public profile like this one. Buyers can check sales, reviews and building verification before they ever send a shilling." })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "cc-showcase-visual", children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "shot-frame", children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", { src: PROFILE_SHOT_DATA_URI, alt: "Verified PlugPay seller profile for Wanjiku Electronics" }) }) })
    ] })
  ] }) });
}
