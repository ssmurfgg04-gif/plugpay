import { openWhatsApp } from "../../../lib/whatsapp.js";
import { usePublicDoc } from "../../../lib/publicDoc.js";
import { usePlugPay } from "../../../store/context.js";
import { h } from "../../common/h.js";
import { Link } from "../../common/routing.js";
import { PublicShellX } from "../../common/shells.js";
import { ErrorState } from "../../common/states.js";
import { Ic } from "../../common/ui.js";
import { DocBadges, DocItems, DocPayInfo, DocTrader, sellerBadgeInfo } from "../tabs/sales/salesShared.js";

export function PayInvoicePage(props) {
  var pp = usePlugPay();
  var local = pp.invoicesList.filter(function (x) { return x.token === props.token; })[0];
  var remote = usePublicDoc("invoice", props.token, !!local);
  var invoice = local || remote.doc;
  if (!local && remote.status === "loading") return h(PublicShellX, { title: "Loading" }, h("div", { className: "app-card" }, h("div", { className: "app-card-sub" }, "Loading\u2026")));
  if (!invoice) return h(PublicShellX, { title: "Invoice not found" }, h(ErrorState, { icon: "file-text", title: "Invoice unavailable", sub: "This invoice is no longer available or the link is wrong.", backTo: "/", backLabel: "Return home" }));
  var sp = local ? pp.sellerProfile : remote.seller;
  var badges = local ? sellerBadgeInfo(pp) : { plugpay: true, landlord: !!(sp && sp.llPhoneVerified) };
  var paid = invoice.status === "PAID" || invoice.status === "COMPLETE";
  return h(PublicShellX, { title: "PlugPay invoice", subtitle: sp.bizName + " \u00b7 " + (paid ? "Paid" : "Awaiting payment") },
    h("div", { className: "doc-wrap" }, h("div", { className: "doc-card" },
      h("div", { className: "doc-band" },
        h("div", { className: "doc-band-top" }, h("div", { className: "doc-kind" }, Ic("file-text", 12), "PlugPay Invoice"), h("span", { className: "doc-status " + (paid ? "paid" : "pending") }, Ic(paid ? "badge-check" : "clock", 11), paid ? "Paid" : "Pending")),
        h("div", { className: "doc-amt" }, "KSh " + invoice.total.toLocaleString()),
        h("div", { className: "doc-amt-label" }, "Requested from " + invoice.buyerName + " \u00b7 " + new Date(invoice.createdAt).toLocaleString())),
      h(DocTrader, { sp: sp }),
      h(DocBadges, { badges: badges }),
      h("div", { className: "doc-sec" }, h("div", { className: "doc-sec-h" }, Ic("user", 13), "Bill to"),
        h("div", { className: "doc-row" }, h("span", null, "Buyer"), h("strong", null, invoice.buyerName)),
        h("div", { className: "doc-row" }, h("span", null, "Phone"), h("strong", null, invoice.buyerPhone)),
        h("div", { className: "doc-row" }, h("span", null, "Sent via"), h("strong", null, invoice.source))),
      !paid && h(DocPayInfo, { sp: sp }),
      h(DocItems, { items: invoice.items }),
      h("div", { className: "doc-total-row" }, h("span", null, paid ? "Total paid" : "Total due"), h("strong", null, "KSh " + invoice.total.toLocaleString())),
      h("div", { className: "doc-actions" },
        !paid && h("button", { className: "es-btn", onClick: function () { pp.showToast("Opening M-Pesa to pay " + sp.bizName + "\u2026"); } }, Ic("credit-card", 14), "Pay via M-Pesa"),
        paid && invoice.paymentRef && h(Link, { to: "/r/" + encodeURIComponent(invoice.paymentRef), className: "es-btn" }, Ic("receipt", 14), "View receipt"),
        h("button", { className: "es-btn alt", onClick: function () { openWhatsApp(sp.whatsapp || sp.phone, "Hi " + sp.bizName + ", I'm following up on invoice for KSh " + invoice.total.toLocaleString()); } }, Ic("message-circle", 14), "Message seller")),
      h("div", { className: "doc-note" }, paid ? "This invoice has been paid and a receipt was issued to the buyer." : "This is a pending payment-link invoice. It only becomes a confirmed sale once the seller marks it as paid with the M-Pesa code.")
    ))
  );
}
