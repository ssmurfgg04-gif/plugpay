/* useOnboardingAgentAuth — "onbAgentAuth" group of the PlugPay store, extracted from PlugPayProvider.
   Statements are the original ones, in their original relative order. Names owned by other groups arrive through the shared
   per-render context object (ctx): groups that run earlier are destructured below, groups that run later are read lazily as ctx.name. */
import * as import_react from "react";
import { seedObMerchants } from "../../../data/onboarding.js";

export function useOnboardingAgentAuth(ctx) {
    const { obAgentMethod, obAgentOtp, obAgentPhone, openModal, setObAgentGate, setObAgentMethodState, setObAgentOtp, setObAgentPhone, setObAgentPhoneStep, setObAgentSending, setObAgentVerifying, setObEditingMerchantId, setObMerchantList, setObStep_, showToast } = ctx;
    const obAgentSetMethod = (0, import_react.useCallback)((m) => {
      setObAgentMethodState(m);
      setObAgentPhone("");
    }, []);
    const openOnboard = (0, import_react.useCallback)(() => {
      openModal("modal-onboard");
      setObAgentGate(true);
      setObAgentPhoneStep(true);
      setObAgentPhone("");
      setObAgentOtp("");
      obAgentSetMethod("sms");
      setObMerchantList(seedObMerchants);
      setObEditingMerchantId(null);
      setObStep_(1);
    }, [obAgentSetMethod, openModal]);
    const obAgentSendOtp = (0, import_react.useCallback)(() => {
      if (!obAgentPhone.trim()) {
        showToast(obAgentMethod === "email" ? "Enter your email address" : "Enter your phone number");
        return;
      }
      setObAgentSending(true);
      setTimeout(() => {
        setObAgentSending(false);
        setObAgentPhoneStep(false);
        showToast(`OTP sent via ${obAgentMethod === "email" ? "email" : "SMS"} \u2713`);
      }, 500);
    }, [obAgentMethod, obAgentPhone, showToast]);
    const obAgentVerifyOtp = (0, import_react.useCallback)(() => {
      if (!obAgentOtp.trim() || obAgentOtp.trim().length < 4) {
        showToast("Enter the OTP");
        return;
      }
      setObAgentVerifying(true);
      setTimeout(() => {
        setObAgentVerifying(false);
        showToast("Signed in as agent \u2713");
        setObAgentGate(false);
        setObStep_(1);
      }, 500);
    }, [obAgentOtp, showToast]);
    return {
      openOnboard,
      obAgentSetMethod,
      obAgentSendOtp,
      obAgentVerifyOtp
    };
}
