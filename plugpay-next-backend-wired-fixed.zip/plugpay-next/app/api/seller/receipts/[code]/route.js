// Kept for backwards compatibility; same safe public shape as /api/public/receipts/[code].
import { json } from '../../../../../src/server/supabase.js';
import { loadPublicReceipt } from '../../../../../src/server/publicDocs.js';
export async function GET(_request, ctx) {
  const { code } = await ctx.params;
  const r = await loadPublicReceipt(decodeURIComponent(code));
  return r.error ? json({ error: r.error }, r.status) : json({ receipt: r.receipt, seller: r.seller });
}
