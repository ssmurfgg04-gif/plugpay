// Buyer-facing documents. These are opened by the BUYER (no account) from the link the seller sends on WhatsApp,
// so they are keyed by an unguessable code/token and expose only what the buyer needs: never user ids, internal
// notes or the buyer's full phone number.
import { adminDb, publicSeller } from './supabase.js';

const major = (minor) => Number(minor || 0) / 100;
function maskPhone(p) { const s = String(p || ''); return s.length <= 6 ? s : s.slice(0, s.startsWith('+') ? 5 : 4) + '•••••' + s.slice(-3); }
function items(rows) { return (rows || []).map((i) => ({ name: i.name_snapshot, qty: i.qty, unit: major(i.unit_price_minor), price: major(i.line_total_minor) })); }
async function sellerOf(id) {
  const { data } = await adminDb().from('sellers').select('*').eq('id', id).maybeSingle();
  return publicSeller(data);
}

export async function loadPublicReceipt(rawCode) {
  const db = adminDb();
  const code = String(rawCode || '').startsWith('#') ? String(rawCode) : '#' + rawCode;
  const r = await db.from('receipts').select('id,code,sent_at,review_expires_at,sales(seller_id,buyer_name,buyer_phone,payment_ref,total_minor,created_at,sale_items(name_snapshot,qty,unit_price_minor,line_total_minor))').eq('code', code).maybeSingle();
  if (r.error) return { status: 500, error: r.error.message };
  if (!r.data || !r.data.sales) return { status: 404, error: 'Receipt not found' };
  const sale = r.data.sales;
  const rev = await db.from('reviews').select('rating,comment,created_at').eq('receipt_id', r.data.id).maybeSingle();
  return {
    status: 200,
    receipt: {
      code: r.data.code, paymentRef: sale.payment_ref, total: major(sale.total_minor), createdAt: sale.created_at,
      sentAt: r.data.sent_at, reviewExpiresAt: r.data.review_expires_at,
      buyerName: sale.buyer_name, buyerPhone: maskPhone(sale.buyer_phone), items: items(sale.sale_items),
      review: rev.data ? { rating: rev.data.rating, comment: rev.data.comment || '', at: rev.data.created_at } : null,
    },
    seller: await sellerOf(sale.seller_id),
  };
}

export async function loadPublicInvoice(token) {
  const db = adminDb();
  const r = await db.from('invoices').select('seller_id,token,buyer_name,buyer_phone,status,total_minor,payment_ref,created_at,invoice_items(name_snapshot,qty,unit_price_minor,line_total_minor)').eq('token', String(token || '')).maybeSingle();
  if (r.error) return { status: 500, error: r.error.message };
  if (!r.data) return { status: 404, error: 'Invoice not found' };
  const i = r.data;
  return {
    status: 200,
    invoice: {
      token: i.token, status: String(i.status).toUpperCase(), total: major(i.total_minor), createdAt: i.created_at,
      buyerName: i.buyer_name, buyerPhone: maskPhone(i.buyer_phone), source: 'WhatsApp', paymentRef: i.payment_ref || null, items: items(i.invoice_items),
    },
    seller: await sellerOf(i.seller_id),
  };
}
