import { usePlugPay } from "../../../../store/context.js";
import { h } from "../../../common/h.js";
import { landlordVacateSeller } from "../../landlordVacateSeller.js";

function LandlordSellerList(props) {
  return h("section", { className: "ll-status-card" },
    h("div", { className: "ll-section-title" }, props.title),
    h("div", { className: "ll-section-sub" }, props.subtitle),
    h("div", { className: "ll-seller-list" },
      props.items.map(function (seller) {
        return h("div", { className: "ll-seller-row", key: seller.id },
          h("div", { className: "ll-seller-avatar", style: seller.color ? { background: seller.color, color: "#fff" } : undefined }, seller.initials || seller.name.charAt(0)),
          h("div", { className: "ll-seller-info" }, h("strong", null, seller.name), h("span", null, seller.sub)),
          h("button", { className: "sp-edit-btn", onClick: function () { if (props.action) props.action(seller); } }, props.actionLabel));
      }),
      props.items.length === 0 && h("div", { className: "ll-empty" }, props.empty)));
}

export function LandlordVerificationList() {
  var pp = usePlugPay();
  return h(LandlordSellerList, { title: "Awaiting verification", subtitle: "Sellers waiting for landlord verification.", items: pp.pendingTraders, actionLabel: "Verify", action: function (seller) { pp.llVerifyTrader(seller.id); }, empty: "No sellers awaiting verification." });
}

export function LandlordVerifiedList() {
  var pp = usePlugPay();
  return h(LandlordSellerList, { title: "Verified by landlord", subtitle: "Sellers currently occupying this building.", items: pp.verifiedTraders, actionLabel: "Vacate", action: function (seller) {
    landlordVacateSeller(
      pp,
      seller
    );
  }, empty: "No verified sellers yet." });
}

export function LandlordVacatedList() {
  var pp = usePlugPay();
  return h("section", { className: "ll-status-card" },
    h("div", { className: "ll-section-title" }, "Recently vacated"),
    h("div", { className: "ll-section-sub" }, "Seller history remains attached to the seller."),
    pp.vacatedTraders.map(function (seller) {
      return h("div", { className: "ll-seller-row muted", key: seller.id },
        h("div", { className: "ll-seller-avatar" }, "\u2713"),
        h("div", { className: "ll-seller-info" }, h("strong", null, seller.name), h("span", null, seller.sub)),
        h("span", { className: "pp-status" }, "VACATED"));
    }));
}
