import { usePlugPay } from "../../../../store/context.js";
import { h } from "../../../common/h.js";

export function LandlordVacantStalls() {
  var pp = usePlugPay();
  var vacant = pp.vacantStalls || [];
  return h("section", { className: "ll-status-card" },
    h("div", { className: "ll-section-title" }, "Unoccupied stalls"),
    h("div", { className: "ll-section-sub" }, "Available stalls ready for admission."),
    vacant.map(function (stall) {
      return h("div", { className: "ll-seller-row", key: stall.id },
        h("div", { className: "ll-seller-avatar vacant" }, "+"),
        h("div", { className: "ll-seller-info" }, h("strong", null, stall.id), h("span", null, stall.label)),
        h("button", { className: "sp-edit-btn on", onClick: function () { pp.llOpenAdmitSeller(stall.id, stall.label); } }, "Admit seller"));
    }),
    vacant.length === 0 && h("div", { className: "ll-empty" }, "No vacant stalls right now."));
}
