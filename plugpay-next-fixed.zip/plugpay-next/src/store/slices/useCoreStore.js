/* useCoreStore — "core" group of the PlugPay store, extracted from PlugPayProvider.
   Statements are the original ones, in their original relative order. Names owned by other groups arrive through the shared
   per-render context object (ctx): groups that run earlier are destructured below, groups that run later are read lazily as ctx.name. */
import * as import_react from "react";

export function useCoreStore(ctx) {
    const [openModals, setOpenModals] = (0, import_react.useState)([]);
    const isOpen = (0, import_react.useCallback)((id) => openModals.includes(id), [openModals]);
    const openModal = (0, import_react.useCallback)((id) => {
      setOpenModals((s) => s.includes(id) ? s : [...s, id]);
    }, []);
    const closeModal = (0, import_react.useCallback)((id) => {
      setOpenModals((s) => s.filter((m) => m !== id));
    }, []);
    const [toast, setToast] = (0, import_react.useState)(null);
    const toastTimer = (0, import_react.useRef)(void 0);
    const showToast = (0, import_react.useCallback)((msg) => {
      if (toastTimer.current) clearTimeout(toastTimer.current);
      setToast(msg);
      toastTimer.current = setTimeout(() => setToast(null), 3e3);
    }, []);
    const copyText = (0, import_react.useCallback)(
      (text, msg) => {
        if (typeof navigator !== "undefined" && navigator.clipboard) {
          navigator.clipboard.writeText(text).catch(() => {
          });
        }
        showToast(msg);
      },
      [showToast]
    );
    return {
      openModal,
      isOpen,
      showToast,
      closeModal,
      openModals,
      toast,
      copyText
    };
}
