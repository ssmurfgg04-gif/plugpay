import { adminDb, json, publicSeller } from '../../../../src/server/supabase.js';
export async function GET(_request, ctx) { const params = await ctx.params;
  const db = adminDb(); const { data: seller, error } = await db.from('sellers').select('*').eq('id', params.sellerId).maybeSingle();
  if (error) return json({ error: error.message }, 500); if (!seller) return json({ error: 'Seller not found' }, 404);
  const [products, reviews, assignment] = await Promise.all([
    db.from('products').select('*').eq('seller_id', seller.id).eq('active', true).order('created_at', { ascending:false }),
    db.from('reviews').select('*').eq('seller_id', seller.id).order('created_at', { ascending:false }).limit(100),
    db.from('stall_assignments').select('*, stalls(stall_number, floor_id, floors(label, floor_number), buildings(id,name,address))').eq('seller_id', seller.id).is('ended_at', null).maybeSingle()
  ]);
  const rr = reviews.data || []; const avg = rr.length ? rr.reduce((a,r)=>a+r.rating,0)/rr.length : 0;
  return json({ seller: publicSeller(seller, { avg, reviewCount: rr.length }), products: products.data || [], reviews: rr, assignment: assignment.data || null });
}
