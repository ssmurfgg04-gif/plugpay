/* useLandlordAuth — "landlordAuth" group of the PlugPay store, extracted from PlugPayProvider.
   Statements are the original ones, in their original relative order. Names owned by other groups arrive through the shared
   per-render context object (ctx): groups that run earlier are destructured below, groups that run later are read lazily as ctx.name. */
import * as import_react from "react";
import { navigate } from "../../../lib/router.js";

export function useLandlordAuth(ctx) {
    const { closeModal, openModal, showToast } = ctx;
    const [llMethod, setLlMethodState] = (0, import_react.useState)("sms");
    const [llStep, setLlStep] = (0, import_react.useState)("phone");
    const [llAuthed, setLlAuthed] = (0, import_react.useState)(false);
    const [llPhone, setLlPhone] = (0, import_react.useState)("");
    const [llOtp, setLlOtp] = (0, import_react.useState)("");
    const [llPinLoginPhone, setLlPinLoginPhone] = (0, import_react.useState)("");
    const [llPinLoginPin, setLlPinLoginPin] = (0, import_react.useState)("");
    const [llSetPinValue, setLlSetPinValue] = (0, import_react.useState)("");
    const [llHasPin, setLlHasPin] = (0, import_react.useState)(false);
    const llSetMethod = (0, import_react.useCallback)((m) => {
      setLlMethodState(m);
      setLlPhone("");
    }, []);
    const openLandlordModal = (0, import_react.useCallback)(() => {
      if (llAuthed) { navigate("/landlord/dashboard"); return; }
      setLlStep("phone");
      setLlPhone("");
      setLlOtp("");
      setLlPinLoginPhone("");
      setLlPinLoginPin("");
      setLlSetPinValue("");
      llSetMethod("sms");
      openModal("modal-landlord");
    }, [llAuthed, llSetMethod, openModal]);
    const llSendOTP = (0, import_react.useCallback)(() => {
      const val = llPhone.trim() || (llMethod === "email" ? "you@email.com" : "07XX XXX XXX");
      showToast(`OTP sent to ${val} via ${llMethod === "email" ? "email" : "SMS"} \u2713`);
      setLlStep("otp");
    }, [llMethod, llPhone, showToast]);
    const llGoBack = (0, import_react.useCallback)(() => setLlStep("phone"), []);
    const llEnterDashboard = () => {
      setLlAuthed(true);
      closeModal("modal-landlord");
      navigate("/landlord/dashboard");
    };
    const llVerifyOTP = (0, import_react.useCallback)(() => {
      if (!llHasPin) {
        showToast("Verified \u2713");
        setLlStep("setpin");
      } else {
        showToast("Verified \u2713 Loading your building dashboard\u2026");
        llEnterDashboard();
      }
    }, [llHasPin, showToast]);
    const llSetPin = (0, import_react.useCallback)(() => {
      if (!/^\d{6}$/.test(llSetPinValue.trim())) {
        showToast("Enter a 6-digit PIN");
        return;
      }
      setLlHasPin(true);
      showToast("PIN set \u2713 You can sign in with your phone + PIN next time.");
      llEnterDashboard();
    }, [llSetPinValue, showToast]);
    const llShowPinLogin = (0, import_react.useCallback)(() => setLlStep("pinlogin"), []);
    const llGoBackFromPin = (0, import_react.useCallback)(() => setLlStep("phone"), []);
    const llPinLogin = (0, import_react.useCallback)(() => {
      if (!llPinLoginPhone.trim()) {
        showToast("Enter your phone number");
        return;
      }
      if (!/^\d{6}$/.test(llPinLoginPin.trim())) {
        showToast("Enter your 6-digit PIN");
        return;
      }
      setLlHasPin(true);
      showToast("Signed in \u2713 Loading your building dashboard\u2026");
      llEnterDashboard();
    }, [llPinLoginPhone, llPinLoginPin, showToast]);
    return {
      llMethod,
      llSetMethod,
      llStep,
      llAuthed,
      openLandlordModal,
      llPhone,
      setLlPhone,
      llOtp,
      setLlOtp,
      llPinLoginPhone,
      setLlPinLoginPhone,
      llPinLoginPin,
      setLlPinLoginPin,
      llSetPinValue,
      setLlSetPinValue,
      llSendOTP,
      llGoBack,
      llVerifyOTP,
      llSetPin,
      llShowPinLogin,
      llGoBackFromPin,
      llPinLogin
    };
}
