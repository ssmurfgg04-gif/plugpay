import { json, body, authRefresh } from '../../../../../src/server/supabase.js';
export async function POST(request) {
  const { refresh_token } = await body(request);
  if (!refresh_token) return json({ error: 'Refresh token is required' }, 400);
  const { data, error } = await authRefresh(refresh_token);
  if (error || !data) return json({ error: error?.message || 'Session refresh failed' }, 401);
  return json({ access_token: data.access_token, refresh_token: data.refresh_token, expires_at: data.expires_at, user: data.user });
}
