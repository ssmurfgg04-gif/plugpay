import { usePlugPay } from "../../../store/context.js";
import { h } from "../../common/h.js";
import { AppShellX } from "../../common/shells.js";
import { EmptyState } from "../../common/states.js";

export function AgentBuildingsPage() {
  var pp = usePlugPay();
  return h(AppShellX, { role: "Agent", active: "buildings", title: "Agent buildings", subtitle: "Buildings and stalls you have onboarded into PlugPay." },
    h("div", { className: "app-list" },
      pp.agentBuildings.map(function (b, i) {
        return h("div", { className: "app-list-row", key: i },
          h("div", { className: "app-list-main" }, h("div", { className: "app-list-name" }, b.name), h("div", { className: "app-list-meta" }, b.street + " \u00b7 " + b.floorsCount + " floors \u00b7 " + b.stalls + " stalls \u00b7 " + b.merchants + " sellers")),
          h("button", { className: "pp-btn secondary", onClick: function () { pp.openBuildingModal(b.name); } }, "View")
        );
      }),
      pp.agentBuildings.length === 0 && h(EmptyState, { icon: "building-2", title: "No buildings yet", sub: "Onboard your first building to start registering sellers.", action: { label: "Onboard a building", onClick: pp.openOnboard } })
    ),
    h("div", { className: "app-actions" }, h("button", { className: "pp-btn primary", onClick: pp.openOnboard }, "+ Onboard another building"))
  );
}
