export var initialVacantStalls = [
    { id: "103", label: "Floor 1, Stall 103" },
    { id: "204", label: "Floor 2, Stall 204" },
    { id: "402", label: "Floor 4, Stall 402" }
  ];

export var initialPendingTraders = [
    { id: "mary", name: "Mary Njeri", sub: "Claims Floor 1, Stall 8 \xB7 Textiles", initials: "MN", color: "#8a8a8a" },
    { id: "samuel", name: "Samuel Kiptoo", sub: "Claims Floor 2, Stall 14 \xB7 Phone Accessories", initials: "SK", color: "#8a8a8a" },
    { id: "lucy", name: "Lucy Wambui", sub: "Claims Floor 3, Stall 3 \xB7 Cosmetics", initials: "LW", color: "#8a8a8a" }
  ];

export var initialVerifiedTraders = [
    { id: "jane", name: "Jane Mwangi", sub: "Fashion \xB7 Floor 3, Stall 301", initials: "JM", color: "#51104a" },
    { id: "peter", name: "Peter Otieno", sub: "Electronics \xB7 Floor 3, Stall 302", initials: "PO", color: "#185FA5" },
    { id: "david", name: "David Mutua", sub: "Hardware \xB7 Floor 2, Stall 202", initials: "DM", color: "#534AB7" },
    { id: "amina", name: "Amina Kibe", sub: "Food \xB7 Floor 3, Stall 303", initials: "AK", color: "#BA7517" }
  ];

export var initialLbAccounts = [
    { id: "lb1", name: "Anniversary Towers", street: "Moi Avenue \xB7 Nairobi CBD", totalStalls: 72 },
    { id: "lb2", name: "Lonrho House", street: "Kenyatta Ave \xB7 Nairobi CBD", totalStalls: 58 }
  ];

export var initialLbData = {
    lb1: { pending: initialPendingTraders, verified: initialVerifiedTraders, vacated: [], vacant: initialVacantStalls, onPlugPay: 58 },
    lb2: { pending: [], verified: [{ id: "grace", name: "Grace Akinyi", sub: "Beauty \xB7 Floor 1, Stall 5", initials: "GA", color: "#D85A30" }], vacated: [], vacant: [{ id: "l2s4", label: "Floor 2, Stall 4" }, { id: "l2s9", label: "Floor 3, Stall 9" }], onPlugPay: 39 }
  };
