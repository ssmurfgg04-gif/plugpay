import * as import_react from 'react';
import { backendStateFetch, backendStateSet, getAuthToken } from '../lib/backend.js';

/*
 * Server-backed persistence bridge. The existing UI keeps its local state API; once a user is signed in the same state is
 * loaded from PostgreSQL (ui_state) and every later change is saved back. Normalized records (sales, invoices, products,
 * reviews, sellers) are written through their own API routes and are what buyers read.
 *
 * Safety rules (a previous version could overwrite a seller's saved data with demo defaults on a second device):
 *   1. Nothing is written to the server until the first read for the current sign-in has SUCCEEDED.
 *   2. A failed read leaves the server copy alone (the hook stays local-only until the next sign-in event).
 *   3. Saved state always wins over local/demo state on load.
 */

// Keys whose source of truth is a normalized table, never mirrored to / hydrated from ui_state.
var SERVER_OWNED = { seller: 1 };
// Demo-seeded lists: a brand-new signed-in account starts empty instead of inheriting the sample data.
var EMPTY_FOR_NEW_ACCOUNT = { receipts: [], invoices: [], catalogue: [] };

export function usePersisted(key, initial) {
  var k = 'pp6:' + key;
  var st = (0, import_react.useState)(function () {
    try { var raw = window.localStorage.getItem(k); if (raw) return JSON.parse(raw); } catch (e) {}
    return typeof initial === 'function' ? initial() : initial;
  });
  var syncedToken = (0, import_react.useRef)(null); // token whose first server read has completed successfully
  var lastSent = (0, import_react.useRef)(null);    // JSON of the last value known to be on the server
  (0, import_react.useEffect)(function () {
    var alive = true;
    function hydrate(token) {
      if (!token || SERVER_OWNED[key] || syncedToken.current === token) return;
      backendStateFetch(key).then(function (res) {
        if (!alive || !res.ok || getAuthToken() !== token) return; // failed read: stay local-only, never write
        if (res.state !== null && res.state !== undefined) { lastSent.current = JSON.stringify(res.state); st[1](res.state); }
        else if (Object.prototype.hasOwnProperty.call(EMPTY_FOR_NEW_ACCOUNT, key)) { st[1](EMPTY_FOR_NEW_ACCOUNT[key]); }
        syncedToken.current = token;
      });
    }
    hydrate(getAuthToken());
    function onAuth(e) { syncedToken.current = null; hydrate(e.detail && e.detail.token); }
    window.addEventListener('pp:auth', onAuth);
    return function () { alive = false; window.removeEventListener('pp:auth', onAuth); };
  }, [key]);
  (0, import_react.useEffect)(function () {
    try { window.localStorage.setItem(k, JSON.stringify(st[0])); } catch (e) {}
    var token = getAuthToken();
    if (!SERVER_OWNED[key] && token && syncedToken.current === token) {
      var j = JSON.stringify(st[0]);
      if (j !== lastSent.current) { lastSent.current = j; backendStateSet(key, st[0]); }
    }
  }, [st[0], key, k]);
  (0, import_react.useEffect)(function () {
    function on(e) { if (e.key === k && e.newValue) { try { st[1](JSON.parse(e.newValue)); } catch (err) {} } }
    window.addEventListener('storage', on);
    return function () { window.removeEventListener('storage', on); };
  }, [k]);
  return st;
}
