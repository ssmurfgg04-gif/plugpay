import { usePlugPay } from "../../../store/context.js";
import { h } from "../../common/h.js";
import { PP_registry } from "../../common/registry.js";
import { WithSkeleton } from "../../common/states.js";
import { SellerGate, SellerPortalShell } from "./SellerShell.js";

export function SellerPortalPage(props) {
  var pp = usePlugPay();
  if (!pp.merchantLoggedIn) return h(SellerGate, { active: props.tab });
  var tabRender = PP_registry.pages["seller.tab." + props.tab] || PP_registry.pages["seller.tab.dashboard"];
  var body = tabRender();
  return h(SellerPortalShell, { active: props.tab }, h(WithSkeleton, { kind: props.tab === "catalogue" ? "cards" : props.tab === "dashboard" ? "dash" : "list", dep: props.tab }, body));
}
