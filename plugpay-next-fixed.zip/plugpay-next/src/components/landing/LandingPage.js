import { h } from "../common/h.js";
import { Slot } from "../common/registry.js";

export function LandingPage() { return h(Slot, { name: "landing" }); }
