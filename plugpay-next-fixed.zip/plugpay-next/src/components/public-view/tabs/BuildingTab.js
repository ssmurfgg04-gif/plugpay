import * as import_jsx_runtime from "../../../ppJsxRuntime.js";
import { usePlugPay } from "../../../store/context.js";
import { BuildingViewContainer } from "../../building/BuildingViewContainer.js";
import { h } from "../../common/h.js";
import { useSV } from "../useSV.js";

export function BuildingTab() {
  const { requireSellerLogin, openBuildingModal, stallHistory, openSellerRef } = usePlugPay();
  const sv = useSV();
  const sellerStats = sv.stats, stallAssignment = sv.assignment;
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "modal-tab-body on", style: { padding: "16px" }, children: [
    h(BuildingViewContainer, { id: stallAssignment.building }),
    h("div", { className: "bldg-card-redesign building-header-card", style: { margin: "14px 0" } }, h("div", { className: "bldg-card-grid", style: { gridTemplateColumns: "1fr 1fr" } },
      h("div", { className: "bldg-card-stat" }, h("div", { className: "bldg-card-n" }, sellerStats.avg.toFixed(1) + "\u2605"), h("div", { className: "bldg-card-l" }, "This merchant")),
      h("div", { className: "bldg-card-stat" }, h("div", { className: "bldg-card-n" }, String(sellerStats.trust)), h("div", { className: "bldg-card-l" }, "Trust score")))),
    h("div", { className: "rv-note", style: { marginTop: 0, marginBottom: 14 } }, h("span", null, "\uD83D\uDD12"), h("span", null, h("b", null, "A seller's record travels with them. "), "Trust score, reviews, sales history and documents belong to the seller. If they move stalls or buildings it all comes along; only the landlord verification at the new place starts as Pending.")),
    sv.own && stallHistory.length > 0 && h("div", { className: "vouch-list", style: { marginBottom: 14 } }, stallHistory.map(function (x, i) { return h("div", { className: "vouch-item", key: i }, h("div", { className: "vouch-av", style: { background: "var(--muted2)" } }, "\uD83D\uDCCD"), h("div", { className: "vouch-info" }, h("div", { className: "vouch-name" }, "Previously " + x.building), h("div", { className: "vouch-sub" }, x.loc + " \u00b7 until " + new Date(x.until).toLocaleDateString()))); })),
  ] });
}
