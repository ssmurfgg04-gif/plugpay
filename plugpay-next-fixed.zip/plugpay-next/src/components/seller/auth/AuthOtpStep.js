import * as import_jsx_runtime from "../../../ppJsxRuntime.js";
import { usePlugPay } from "../../../store/context.js";
import { authCodeInput, authIconWrap, authLabel, authLink, authSubmitBtn, focusRing } from "./authStyles.js";

export function AuthOtpStep() {
  const { authPhone, authMethod, authOtp, setAuthOtp, authVerifyOTP, authGoBack } = usePlugPay();
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "auth-shell", children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { textAlign: "center", marginBottom: "20px" }, children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: authIconWrap, children: "\u{1F4AC}" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { fontSize: "22px", fontWeight: 900, color: "var(--ink)", marginBottom: "4px" }, children: "Enter your OTP" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { fontSize: "13px", color: "var(--muted)", lineHeight: "1.55" }, children: [
        "Code sent to ",
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { style: { color: "var(--ink)" }, children: authPhone.trim() || "07XX XXX XXX" }),
        " via",
        " ",
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: authMethod === "sms" ? "SMS" : "WhatsApp" }),
        "."
      ] })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { style: authLabel, children: "ONE-TIME CODE" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      "input",
      {
        type: "tel",
        placeholder: "_ _ _ _ _ _",
        maxLength: 6,
        style: authCodeInput,
        value: authOtp,
        onChange: (e) => setAuthOtp(e.target.value),
        onKeyDown: (e) => {
          if (e.key === "Enter") authVerifyOTP();
        },
        ...focusRing()
      }
    ),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { style: authSubmitBtn, onClick: () => authVerifyOTP(), children: "Verify & open my profile \u2192" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { textAlign: "center", fontSize: "12px", color: "var(--muted2)", marginTop: "14px", fontFamily: "var(--fm)" }, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      "a",
      {
        href: "#",
        onClick: (e) => {
          e.preventDefault();
          authGoBack();
        },
        style: authLink,
        children: "\u2190 Change number"
      }
    ) })
  ] });
}
