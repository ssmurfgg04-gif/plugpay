import { usePlugPay } from "../../../../store/context.js";
import { PR, h } from "../../../common/h.js";
import { AppShellX, DashSignIn } from "../../../common/shells.js";
import { LlStatus } from "../../LlStatus.js";
import { landlordVacateSeller } from "../../landlordVacateSeller.js";
import { LandlordBuildingView } from "../dashboard/LandlordBuildingView.js";
import { LbSwitcher } from "../dashboard/LbSwitcher.js";

export function LandlordStallsPage() {
  var pp = usePlugPay();
  var _f = PR.useState("all"), filter = _f[0], setFilter = _f[1];
  if (!pp.llAuthed) return h(AppShellX, { role: "Landlord", active: "stalls", title: "Stalls" }, h(DashSignIn, { msg: "Sign in to view stall occupancy.", onClick: pp.openLandlordModal }));
  var pending = pp.pendingTraders || [], verified = pp.verifiedTraders || [], vacant = pp.vacantStalls || [];
  var total = pending.length + verified.length + vacant.length;
  var rows = [];
  verified.forEach(function (t) { rows.push({ key: "occ-" + t.id, kind: "occupied", name: t.sub, meta: t.name, item: t }); });
  pending.forEach(function (t) { rows.push({ key: "p-" + t.id, kind: "awaiting", name: t.sub, meta: t.name, item: t }); });
  vacant.forEach(function (st) { rows.push({ key: "v-" + st.id, kind: "vacant", name: st.label, meta: "No seller yet", item: st }); });
  var shown = rows.filter(function (r) { return filter === "all" || r.kind === filter; });
  var tabs = [["all", "All (" + total + ")"], ["occupied", "Occupied (" + verified.length + ")"], ["awaiting", "Awaiting (" + pending.length + ")"], ["vacant", "Vacant (" + vacant.length + ")"]];
  function action(r) {
    if (r.kind === "vacant") return h("button", { className: "sp-edit-btn on", onClick: function () { pp.llOpenAdmitSeller(r.item.id, r.item.label); } }, "Admit");
    if (r.kind === "awaiting") return h("button", { className: "sp-edit-btn on", onClick: function () { pp.llVerifyTrader(r.item.id); } }, "Verify");
    return h("button", { className: "sp-edit-btn danger", onClick: function () { landlordVacateSeller(pp, r.item); } }, "Vacate");
  }
  return h(AppShellX, { role: "Landlord", active: "stalls", title: pp.lbActive.name, subtitle: "Every stall in this building and who is in it." },
    h(LbSwitcher, null),
    h("section", { className: "ll-stalls-summary" },
      h("div", null, h("b", null, total), h("span", null, "Total stalls")),
      h("div", null, h("b", null, verified.length), h("span", null, "Occupied")),
      h("div", null, h("b", null, pending.length), h("span", null, "Awaiting")),
      h("div", null, h("b", null, vacant.length), h("span", null, "Vacant"))),
    h(LandlordBuildingView, null),
    h("div", { className: "ll-stalls-filter" }, tabs.map(function (t) {
      return h("button", { key: t[0], type: "button", className: filter === t[0] ? "on" : "", onClick: function () { setFilter(t[0]); } }, t[1]);
    })),
    h("div", { className: "app-list" },
      shown.map(function (r) {
        return h("div", { className: "app-list-row", key: r.key },
          h("div", { className: "app-list-main" }, h("div", { className: "app-list-name" }, r.name), h("div", { className: "app-list-meta" }, r.meta)),
          h("div", { style: { display: "flex", gap: 8, alignItems: "center" } },
            r.kind === "vacant" ? h("span", { className: "pp-status pending" }, "VACANT") : h(LlStatus, { ok: r.kind === "occupied" }),
            action(r)));
      }),
      shown.length === 0 && h("div", { className: "ll-empty" }, "No stalls in this view.")
    )
  );
}
