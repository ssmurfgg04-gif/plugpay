
  /* ============================================================================
     BUILDING (modal and view)
     ============================================================================ */
  var buildings = [
    { type: "building", name: "Anniversary Towers", street: "Mama Ngina Street", sub: "Mama Ngina St \xB7 6 floors \xB7 72 stalls \xB7 58 registered", floors: 6, stalls: 72, registered: 58, pct: 67 },
    { type: "building", name: "Lonrho House", street: "Kenyatta Avenue", sub: "Kenyatta Ave \xB7 4 floors \xB7 58 stalls \xB7 39 registered", floors: 4, stalls: 58, registered: 39, pct: 67 },
    { type: "building", name: "Kencom House", street: "Moi Avenue", sub: "Moi Ave \xB7 5 floors \xB7 84 stalls \xB7 51 registered", floors: 5, stalls: 84, registered: 51, pct: 61 },
    { type: "building", name: "Odeon Cinema Bldg", street: "Tom Mboya Street", sub: "Tom Mboya St \xB7 3 floors \xB7 64 stalls \xB7 28 registered", floors: 3, stalls: 64, registered: 28, pct: 44 }
  ];
  function ppSlug(s) { return String(s || "").toLowerCase().replace(/&/g, "and").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, ""); }
  /* One lookup for every building the app knows: public directory, landlord accounts, agent-onboarded buildings. */
  function ppResolveBuilding(id, accounts, agentList) {
    var k = ppSlug(id);
    if (!k) return null;
    var b = buildings.filter(function (x) { return ppSlug(x.name) === k; })[0];
    if (b) return b;
    var a = (accounts || []).filter(function (x) { return ppSlug(x.name) === k; })[0];
    if (a) return { type: "building", name: a.name, street: a.street, floors: a.floors, stalls: a.totalStalls || a.stalls, registered: null, pct: null };
    var g = (agentList || []).filter(function (x) { return ppSlug(x.name) === k; })[0];
    if (g) return { type: "building", name: g.name, street: g.street, floors: g.floorsCount, stalls: g.stalls, registered: g.merchants, pct: g.stalls ? Math.round(g.merchants / g.stalls * 100) : null };
    return null;
  }
  function ppBuildingMerchants(name) {
    return merchants.filter(function (m) { return String(m.sub).indexOf(name) > -1; }).map(function (m) {
      var parts = String(m.sub).split(" \u00B7 ");
      return { initials: m.initials, color: m.color, name: m.name, sub: parts.filter(function (x) { return x !== name; }).join(" \u00B7 "), rating: m.rating, rev: m.reviews };
    });
  }
  var namedFloors = {
    G: [{ id: "G01", n: "M-Pesa", s: "t" }, { id: "G02", n: "Newsstand", s: "b" }, { id: "G03", n: "Chemist", s: "v" }, { id: "G04", n: "", s: "e" }, { id: "G05", n: "Shoe Repair", s: "b" }, { id: "G06", n: "Snack Bar", s: "v" }, { id: "G07", n: "", s: "e" }, { id: "G08", n: "Accessories", s: "v" }, { id: "G09", n: "Airtime", s: "b" }, { id: "G10", n: "", s: "e" }, { id: "G11", n: "Bureau", s: "v" }, { id: "G12", n: "", s: "e" }],
    "1": [{ id: "101", n: "Wanjiku Fab", s: "t" }, { id: "102", n: "Peter Phones", s: "v" }, { id: "103", n: "", s: "e" }, { id: "104", n: "Ali Hardware", s: "b" }, { id: "105", n: "Grace Beauty", s: "v" }, { id: "106", n: "", s: "e" }, { id: "107", n: "Tom Stat.", s: "b" }, { id: "108", n: "Ropa Fashion", s: "v" }, { id: "109", n: "", s: "e" }, { id: "110", n: "Ken Bags", s: "b" }, { id: "111", n: "", s: "e" }, { id: "112", n: "E. Bureau", s: "v" }],
    "2": [{ id: "201", n: "Amina Spices", s: "b" }, { id: "202", n: "David Mutua", s: "t" }, { id: "203", n: "Nafisa Bags", s: "v" }, { id: "204", n: "", s: "e" }, { id: "205", n: "Joyce Tailor", s: "b" }, { id: "206", n: "Ben Watches", s: "v" }, { id: "207", n: "", s: "e" }, { id: "208", n: "Ken Bureau", s: "b" }, { id: "209", n: "M. Printing", s: "v" }, { id: "210", n: "", s: "e" }, { id: "211", n: "Kariuki Shoe", s: "b" }, { id: "212", n: "", s: "e" }],
    "3": [{ id: "301", n: "Jane Mwangi", s: "v" }, { id: "302", n: "Peter Otieno", s: "v" }, { id: "303", n: "Amina Kibe", s: "b" }, { id: "304", n: "Sarah W.", s: "b" }, { id: "305", n: "Wanjiku Electronics", s: "v" }, { id: "306", n: "M. Ali", s: "v" }, { id: "307", n: "Rosa Import", s: "t" }, { id: "308", n: "", s: "e" }, { id: "309", n: "Ben Tailor", s: "b" }, { id: "310", n: "", s: "e" }, { id: "311", n: "Eva Cosm.", s: "v" }, { id: "312", n: "", s: "e" }],
    "4": [{ id: "401", n: "Rosa Import", s: "v" }, { id: "402", n: "", s: "e" }, { id: "403", n: "Ken Courier", s: "b" }, { id: "404", n: "Liz Cosm.", s: "v" }, { id: "405", n: "", s: "e" }, { id: "406", n: "Victor Pr.", s: "b" }, { id: "407", n: "", s: "e" }, { id: "408", n: "Big Whole.", s: "t" }, { id: "409", n: "", s: "e" }, { id: "410", n: "Ravi Text.", s: "b" }, { id: "411", n: "", s: "e" }, { id: "412", n: "", s: "e" }]
  };
  var FILLER_STATUS_CYCLE = ["b", "e", "v", "e", "b", "t", "e", "b", "v", "e"];
  var FILLER_STALLS_PER_FLOOR = 42;
  function padFloor(floorKey, named) {
    const stalls = [...named];
    const usedNumbers = new Set(named.map((s) => parseInt(s.id.replace(/\D/g, ""), 10)));
    let next = floorKey === "G" ? 1 : parseInt(floorKey, 10) * 100 + 1;
    let i = 0;
    while (stalls.length < FILLER_STALLS_PER_FLOOR) {
      while (usedNumbers.has(next)) next++;
      const status = FILLER_STATUS_CYCLE[i % FILLER_STATUS_CYCLE.length];
      const id = floorKey === "G" ? `G${String(next).padStart(2, "0")}` : String(next);
      stalls.push({ id, n: status === "e" ? "" : `Stall ${id}`, s: status });
      usedNumbers.add(next);
      next++;
      i++;
    }
    return stalls;
  }
  var floors = Object.fromEntries(
    Object.entries(namedFloors).map(([key, named]) => [key, padFloor(key, named)])
  );
  var stallClass = { t: "bsg-occ", v: "bsg-occ", b: "bsg-occ", e: "bsg-vac" };
  var stallNameClass = { t: "bsgn-occ", v: "bsgn-occ", b: "bsgn-occ", e: "bsgn-vac" };
  var FLOOR_TABS = [
    { key: "G", label: "Ground" },
    { key: "1", label: "Floor 1" },
    { key: "2", label: "Floor 2" },
    { key: "3", label: "Floor 3" },
    { key: "4", label: "Floor 4" }
  ];
  /* Presentational: no context, no modal. Reusable by modal, page, landlord, agent. */
  function BuildingView(p) {
    var legend = h("div", { className: "bldg-legend" },
      h("span", null, h("span", { className: "bl-dot", style: { background: "var(--accent-bg)", border: "1px solid #c798c2" } }), "Occupied"),
      h("span", null, h("span", { className: "bl-dot", style: { background: "var(--bg)", border: "1px solid var(--border)" } }), "Vacant"));
    return h(PR.Fragment, null,
      h("div", { className: "bldg-hero bldg-hero-redesign" }, h("div", { className: "bh-inner" },
        h("div", { className: "bh-name" }, "\uD83C\uDFE2 " + p.name),
        h("div", { className: "bh-addr" }, p.address),
        h("div", { className: "bldg-hero-grid" }, p.stats.map(function (x) {
          return h("div", { className: "bldg-hero-cell", key: x.l }, h("div", { className: "bldg-hero-n" }, x.n), h("div", { className: "bldg-hero-l" }, x.l));
        })))),
      h("div", { className: "bldg-body" },
        h(FloorMap, { className: "bldg-map-section", title: "Floor map \u2014 click a stall to view merchant", titleClass: "bldg-map-label", tabs: p.tabs, floors: p.floors, floor: p.floor, onFloorChange: p.onFloorChange, onStallSelect: p.onStallSelect,
          subtitle: p.subtitle, subtitleClass: "bldg-map-sub",
          isClickable: p.isClickable || function (st) { return st.s !== "e"; }, stallTitle: p.stallTitle || function (st) { return st.s === "e" ? "Vacant" : "Occupied \u2014 tap to view seller profile"; }, footer: legend }),
        p.merchants.length > 0 && h("div", { style: { marginTop: "20px" } },
          h("div", { className: "bldg-map-label" }, "Top merchants"),
          h("div", { className: "bldg-merch-list" }, p.merchants.map(function (m) {
            return h("div", { className: "bml-item", key: m.name, onClick: function () { p.onMerchantSelect(m); } },
              h("div", { className: "bml-av", style: { background: m.color } }, m.initials),
              h("div", { className: "bml-info" }, h("div", { className: "bml-name" }, m.name), h("div", { className: "bml-sub" }, m.sub)),
              h("div", { className: "bml-rating" }, m.rating, "\u2605", h("span", { className: "bml-rev" }, " (", m.rev, ")")));
          })))));
  }
  /* Container: the ONE building view. Modal, /buildings/:id page, seller Building tab, search, landlord and agent all render this. */
  function BuildingViewContainer(p) {
    var pp = usePlugPay();
    var ll = !!p.landlord;
    var b = ppResolveBuilding(p.id, pp.lbAccounts, pp.agentBuildings) || (p.id ? { name: String(p.id), street: "", registered: null, stalls: null, pct: null } : buildings[0]);
    var dash = function (v, suffix) { return v == null ? "\u2014" : String(v) + (suffix || ""); };
    var stats = [{ n: dash(b.registered), l: "Merchants" }, { n: dash(b.stalls), l: "Total stalls" }, { n: "4.7\u2605", l: "Avg rating" }, { n: dash(b.pct, "%"), l: "Coverage" }];
    var street = b.street || (b.sub ? String(b.sub).split(" \u00B7 ")[0] : "");
    return h(BuildingView, { name: b.name, address: (street ? street + " \u00B7 " : "") + "Nairobi CBD", stats: stats, tabs: FLOOR_TABS, floors: floors, floor: pp.bldgFloor, onFloorChange: pp.setBldgFloor,
      onStallSelect: function (st) {
        if (st.s === "e") return ll ? pp.llOpenAdmitSeller(st.id, floorStallLabel(pp.bldgFloor, st.id)) : pp.showToast("This stall is vacant");
        return pp.viewStallProfile(st, pp.bldgFloor, b.name, resolvePublicStallSeller(st) || undefined);
      },
      isClickable: ll ? function () { return true; } : undefined,
      stallTitle: ll ? function (st) { return st.s === "e" ? "Vacant \u2014 tap to admit a seller" : "Occupied \u2014 tap to view seller profile"; } : undefined,
      subtitle: ll ? "Select a stall to admit, verify, view or vacate a seller." : undefined,
      merchants: ppBuildingMerchants(b.name), onMerchantSelect: p.onMerchantSelect || pp.openDirectorySeller });
  }
  function BuildingModal() {
    var pp = usePlugPay();
    return h(Modal, { id: "modal-building", onExit: pp.focusMerchantProfileTab }, h(BuildingViewContainer, { id: pp.bldgId }));
  }
  function floorStallLabel(floor, stallId) {
    return floor === "G" ? `Ground Floor, Stall ${stallId}` : `Floor ${floor}, Stall ${stallId}`;
  }
  function FloorMap(props) {
    return h("div", { className: props.className },
      props.title && h("div", { className: props.titleClass }, props.title),
      props.subtitle && h("div", { className: props.subtitleClass }, props.subtitle),
      h("div", { className: "bldg-floor-tabs" }, props.tabs.map(function (f) {
        return h("button", { key: f.key, className: "bft" + (props.floor === f.key ? " on" : ""), onClick: function () { props.onFloorChange(f.key); } }, f.label);
      })),
      h(StallGrid, { stalls: props.floors[props.floor] || [], onStallClick: props.onStallSelect,
        renderCell: function (st) { return { className: stallClass[st.s], clickable: props.isClickable(st), title: props.stallTitle(st), label: h("span", { className: stallNameClass[st.s] }, st.id) }; } }),
      props.footer);
  }
  function BuildingPage(props) {
    var pp = usePlugPay();
    var found = ppResolveBuilding(props.id, pp.lbAccounts, pp.agentBuildings);
    PR.useEffect(function () { pp.setBldgFloor("G"); }, [props.id]);
    if (!found) return h(NotFoundPage, { title: "Building not found", sub: "We couldn't find a building at this link." });
    return h(RouteSheet, null, h(BuildingViewContainer, { id: props.id, onMerchantSelect: function (m) { navigate("/sellers/" + ppSlug(m.name)); } }));
  }

  /* ---- Wiring: registers this group's modals, slots, pages and routes ---- */
  PP_ROUTES.push(
    [/^\/buildings\/(.+)$/, "building-public", "id"]
  );
  PP_registry.register("modals", "building", BuildingModal, 40);
  PP_registry.registerPage("building-public", function (r) { return h(BuildingPage, { id: r.id }); });