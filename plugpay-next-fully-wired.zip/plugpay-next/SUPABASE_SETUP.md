# PlugPay — Supabase setup

The complete database schema is attached directly to this project.

## Schema file

Use either:

- `SUPABASE_SCHEMA.sql` — single copy/paste schema at the project root
- `supabase/schema.sql` — same schema in the Supabase folder

The two files contain the same SQL.

## Later, when setting up Supabase

1. Create a new Supabase project.
2. Open **SQL Editor → New query**.
3. Open `SUPABASE_SCHEMA.sql` from this project.
4. Copy the entire file.
5. Paste it into the Supabase SQL Editor.
6. Run the complete script.
7. Enable Phone Authentication if you want the production OTP flow.
8. Add your Supabase URL/key values to `.env.local` using `.env.example`.

The schema is designed to be safe to re-run and includes the PlugPay relational model, indexes, triggers, RLS, atomic sale/invoice functions, and the server-side access lockdown.

## Main tables

- profiles
- buildings
- floors
- stalls
- sellers
- stall_assignments
- seller_documents
- products
- invoices
- invoice_items
- sales
- sale_items
- receipts
- reviews
- vouches
- claims
- riders
- ui_state

No Supabase credentials are included in this project.
