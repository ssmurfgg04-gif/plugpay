const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

function requireEnv() { if (!url || !serviceKey || !anonKey) throw new Error('Supabase environment is not configured'); }
function headers(key, token) { return { apikey:key, Authorization:`Bearer ${token || key}`, 'Content-Type':'application/json', Prefer:'return=representation' }; }

class Query {
  constructor(table,key){ this.table=table; this.key=key; this.params=[]; this.method='GET'; this.payload=null; this.want='many'; this.ordering=null; this.limitN=null; this.orExpr=null; this.count=null; }
  select(columns='*'){ this.selectCols=columns; return this; }
  eq(k,v){this.params.push([k,'eq.'+encodeURIComponent(v)]);return this;} neq(k,v){this.params.push([k,'neq.'+encodeURIComponent(v)]);return this;} is(k,v){this.params.push([k,'is.'+String(v)]);return this;} in(k,vals){this.params.push([k,'in.('+vals.map(x=>`"${x}"`).join(',')+')']);return this;}
  or(expr){this.orExpr=expr;return this;} order(k,o={}){this.ordering=`${k}.${o.ascending===false?'desc':'asc'}`;return this;} limit(n){this.limitN=n;return this;} maybeSingle(){this.want='maybe';return this;} single(){this.want='single';return this;}
  insert(payload){this.method='POST';this.payload=payload;return this;} update(payload){this.method='PATCH';this.payload=payload;return this;} upsert(payload,opts={}){this.method='POST';this.payload=payload;this.upsert=true;this.onConflict=opts.onConflict;return this;}
  then(resolve, reject) { return this.run().then(resolve, reject); } // makes `await db.from(...).select(...)` actually execute the request
  async run(){
    requireEnv(); let endpoint=`${url}/rest/v1/${this.table}`; const qs=[];
    if(this.selectCols)qs.push('select='+encodeURIComponent(this.selectCols));
    for(const [k,v] of this.params)qs.push(`${k}=${v}`); if(this.orExpr)qs.push('or='+encodeURIComponent(`(${this.orExpr})`)); if(this.ordering)qs.push('order='+this.ordering); if(this.limitN!=null)qs.push('limit='+this.limitN); if(this.upsert&&this.onConflict)qs.push('on_conflict='+encodeURIComponent(this.onConflict));
    if(qs.length)endpoint+='?'+qs.join('&'); const h=headers(this.key); if(this.upsert)h.Prefer='resolution=merge-duplicates,return=representation';
    const res=await fetch(endpoint,{method:this.method,headers:h,body:this.method==='GET'?undefined:JSON.stringify(this.payload)}); const text=await res.text(); let data=null; try{data=text?JSON.parse(text):null;}catch{}
    if(!res.ok)return{data:null,error:new Error(data?.message||data?.hint||data?.details||text||`Supabase error ${res.status}`)};
    if(this.want==='single'){if(!Array.isArray(data)||data.length!==1)return{data:null,error:new Error('Expected one row')};return{data:data[0],error:null};}
    if(this.want==='maybe')return{data:Array.isArray(data)?(data[0]||null):data,error:null}; return{data,error:null};
  }
}
function client(key){ requireEnv(); return { from:(table)=>new Query(table,key), async rpc(fn,args){ const res=await fetch(`${url}/rest/v1/rpc/${fn}`,{method:'POST',headers:headers(key),body:JSON.stringify(args)});const text=await res.text();let data=null;try{data=text?JSON.parse(text):null}catch{};return res.ok?{data,error:null}:{data:null,error:new Error(data?.message||data?.hint||text||`RPC error ${res.status}`)}; } }; }

export function adminDb(){ return client(serviceKey); }
export function publicDb(){ return client(anonKey); }

async function authFetch(path, opts={}, token){ requireEnv(); const res=await fetch(`${url}/auth/v1${path}`,{...opts,headers:{...headers(anonKey,token),...(opts.headers||{})}});const text=await res.text();let data=null;try{data=text?JSON.parse(text):null}catch{};return res.ok?{data,error:null}:{data:null,error:new Error(data?.msg||data?.message||text||`Auth error ${res.status}`)}; }

// Supabase Auth admin API (service-role key). Used only by the dev-auth bypass.
export async function authAdminFetch(path, opts={}){ requireEnv(); const res=await fetch(`${url}/auth/v1/admin${path}`,{...opts,headers:{...headers(serviceKey),...(opts.headers||{})}});const text=await res.text();let data=null;try{data=text?JSON.parse(text):null}catch{};return res.ok?{data,error:null}:{data:null,error:new Error(data?.msg||data?.message||text||`Auth admin error ${res.status}`),status:res.status}; }
export async function authSignInOtp(phone, metadata={}){ return authFetch('/otp',{method:'POST',body:JSON.stringify({phone, data:metadata})}); }
export async function authVerifyOtp(phone, token){ return authFetch('/verify',{method:'POST',body:JSON.stringify({phone,token,type:'sms'})}); }
export async function authGetUser(token){ return authFetch('/user',{method:'GET'},token); }
export async function authUpdatePassword(token,password){ return authFetch('/user',{method:'PUT',body:JSON.stringify({password})},token); }
export async function authPasswordLogin(phone,password){ return authFetch('/token?grant_type=password',{method:'POST',body:JSON.stringify({phone,password})}); }

export async function requireUser(request){ const value=request.headers.get('authorization')||'';const token=value.startsWith('Bearer ')?value.slice(7):null;if(!token)return{error:json({error:'Authentication required'},401)};const r=await authGetUser(token);if(r.error||!r.data?.id)return{error:json({error:'Invalid or expired session'},401)};return{user:r.data,token}; }
export function json(data,status=200){return new Response(JSON.stringify(data),{status,headers:{'content-type':'application/json','cache-control':'no-store'}});}
export async function body(request){try{return await request.json();}catch{return{};}}
export function cleanPhone(phone){ // normalise to E.164 (+254...): Supabase phone auth rejects local formats like 0712 345 678
  const raw=String(phone||'').trim();const d=raw.replace(/\D/g,'');if(!d)return '';
  if(raw.startsWith('+'))return '+'+d;if(d.startsWith('254'))return '+'+d;if(d.startsWith('0'))return '+254'+d.slice(1);if(d.length===9)return '+254'+d;return '+'+d;}
export function minor(value){const n=Number(value);if(!Number.isFinite(n)||n<0)throw new Error('Invalid monetary amount');return Math.round(n*100);}
export function publicSeller(row,stats={}){if(!row)return null;return{id:row.id,bizName:row.business_name,ownerName:row.owner_name,phone:row.phone,whatsapp:row.whatsapp,category:row.category,role:row.role,bio:row.bio,street:row.address,established:row.established_year?String(row.established_year):'',about:row.about,instagram:row.instagram,tiktok:row.tiktok,facebook:row.facebook,payMethod:row.pay_method||'Paybill',paybill:row.paybill,account:row.account_number,llPhoneVerified:row.verification_status==='verified',trustScore:Number(row.trust_score||0),...stats};}
export async function getSellerForUser(userId){const db=adminDb();const {data,error}=await db.from('sellers').select('*').eq('user_id',userId).maybeSingle();if(error)throw error;return data;}
