export var seedObMerchants = [
    { id: "seed-jane", biz: "Jane Mwangi", ownerName: "Jane Mwangi", phone: "0712 345 678", floor: "3", stallNum: "14", type: "Fashion", initials: "JM", color: "#51104a", status: "done" },
    { id: "seed-peter", biz: "Peter Otieno", ownerName: "Peter Otieno", phone: "0723 456 789", floor: "3", stallNum: "12", type: "Electronics", initials: "PO", color: "#185FA5", status: "done" },
    { id: "seed-david", biz: "David Mutua", ownerName: "David Mutua", phone: "0734 567 890", floor: "2", stallNum: "5", type: "Hardware", initials: "DM", color: "#6B3DB8", status: "pending" }
  ];
