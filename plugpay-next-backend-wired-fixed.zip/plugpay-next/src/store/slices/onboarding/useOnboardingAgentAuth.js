import * as import_react from 'react';
import { seedObMerchants } from '../../../data/onboarding.js';
import { apiFetch, setAuthToken } from '../../../lib/backend.js';
export function useOnboardingAgentAuth(ctx) {
  const { obAgentMethod, obAgentOtp, obAgentPhone, openModal, setObAgentGate, setObAgentMethodState, setObAgentOtp, setObAgentPhone, setObAgentPhoneStep, setObAgentSending, setObAgentVerifying, setObEditingMerchantId, setObMerchantList, setObStep_, showToast } = ctx;
  const obAgentSetMethod=m=>{setObAgentMethodState(m);setObAgentPhone('');};
  const openOnboard=import_react.useCallback(()=>{openModal('modal-onboard');setObAgentGate(true);setObAgentPhoneStep(true);setObAgentPhone('');setObAgentOtp('');obAgentSetMethod('sms');setObMerchantList(seedObMerchants);setObEditingMerchantId(null);setObStep_(1);},[obAgentSetMethod,openModal]);
  const obAgentSendOtp=import_react.useCallback(async()=>{if(!obAgentPhone.trim()){showToast('Enter your phone number');return;}setObAgentSending(true);try{await apiFetch('/api/auth/otp/start',{method:'POST',body:JSON.stringify({phone:obAgentPhone,role:'agent',method:obAgentMethod})});setObAgentPhoneStep(false);showToast('OTP sent ✓');}catch(e){showToast(e.message);}finally{setObAgentSending(false);}},[obAgentPhone,obAgentMethod,showToast]);
  const obAgentVerifyOtp=import_react.useCallback(async()=>{if(!obAgentOtp.trim()){showToast('Enter the OTP');return;}setObAgentVerifying(true);try{const r=await apiFetch('/api/auth/otp/verify',{method:'POST',body:JSON.stringify({phone:obAgentPhone,token:obAgentOtp,role:'agent'})});setAuthToken(r.access_token);setObAgentGate(false);setObStep_(1);showToast('Signed in as agent ✓');}catch(e){showToast(e.message);}finally{setObAgentVerifying(false);}},[obAgentOtp,obAgentPhone,showToast]);
  return {openOnboard,obAgentSetMethod,obAgentSendOtp,obAgentVerifyOtp};
}
