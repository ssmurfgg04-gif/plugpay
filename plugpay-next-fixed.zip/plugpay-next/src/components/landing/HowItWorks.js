import * as import_jsx_runtime from "../../ppJsxRuntime.js";

export function HowItWorks() {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", { className: "breakthrough", id: "breakthrough", children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "wrap", children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "eyebrow on-dark", children: "The breakthrough" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Meet PlugPay." }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "section-p", children: "PlugPay verifies every seller's ID and location, anchors every sale to a real WhatsApp receipt, and builds a public trust profile automatically \u2014 so buyers can check you out before they pay, and you can grow past people who already know you." }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "bt-stats", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "bt-stat", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "bt-n", children: "0%" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "bt-l", children: "Fake alert losses" })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "bt-stat", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "bt-n", children: "3\xD7" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "bt-l", children: "More buyer trust" })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "bt-stat", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "bt-n", children: "100%" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "bt-l", children: "Receipt-backed reviews" })
      ] })
    ] })
  ] }) });
}
