
  /* ============================================================================
     AGENT PORTAL (buildings, claims)
     ============================================================================ */
  function claimLink(t) { return appBase() + "#/claim/" + encodeURIComponent(t); }
  function waClaimText(c) {
    return "Hi " + (c.ownerName || "there") + ", you've been added to PlugPay" + (c.businessName ? " as " + c.businessName : "") + " at " + c.buildingName + " (" + c.loc + "). Tap to claim your stall and sign in:\n" + claimLink(c.token);
  }
  function AgentBuildingsPage() {
    var pp = usePlugPay();
    return h(AppShellX, { role: "Agent", active: "buildings", title: "Agent buildings", subtitle: "Buildings and stalls you have onboarded into PlugPay." },
      h("div", { className: "app-list" },
        pp.agentBuildings.map(function (b, i) {
          return h("div", { className: "app-list-row", key: i },
            h("div", { className: "app-list-main" }, h("div", { className: "app-list-name" }, b.name), h("div", { className: "app-list-meta" }, b.street + " \u00b7 " + b.floorsCount + " floors \u00b7 " + b.stalls + " stalls \u00b7 " + b.merchants + " sellers")),
            h("button", { className: "pp-btn secondary", onClick: function () { pp.openBuildingModal(b.name); } }, "View")
          );
        }),
        pp.agentBuildings.length === 0 && h(EmptyState, { icon: "building-2", title: "No buildings yet", sub: "Onboard your first building to start registering sellers.", action: { label: "Onboard a building", onClick: pp.openOnboard } })
      ),
      h("div", { className: "app-actions" }, h("button", { className: "pp-btn primary", onClick: pp.openOnboard }, "+ Onboard another building"))
    );
  }
  function AgentClaimsPage() {
    var pp = usePlugPay();
    return h(AppShellX, { role: "Agent", active: "claims", title: "Seller claim links", subtitle: "A claim link goes to each seller's WhatsApp as soon as you register them. It opens the sign-in page." },
      h("div", { className: "app-list" },
        pp.agentClaims.filter(function (c) { return c.source !== "landlord"; }).map(function (c) {
          return h("div", { className: "app-card", key: c.id },
            h("div", { className: "app-list-row", style: { border: 0, padding: 0 } },
              h("div", { className: "app-list-main" }, h("div", { className: "app-list-name" }, c.businessName || "Unnamed seller"), h("div", { className: "app-list-meta" }, c.ownerName + " \u00b7 " + (c.phone || "No phone") + " \u00b7 " + c.buildingName + " \u00b7 " + c.loc)),
              h("span", { className: "pp-status" + (c.status !== "INVITED" ? "" : " pending") }, c.status === "INVITED" ? "LINK SENT" : "CLAIMED")),
            c.status === "INVITED" && h("div", { className: "app-actions" },
              h("button", { className: "pp-btn primary", onClick: function () { pp.resendClaim(c.token); } }, "Resend on WhatsApp"),
              h("button", { className: "pp-btn secondary", onClick: function () { pp.copyText(claimLink(c.token), "Claim link copied"); } }, "Copy link")));
        }),
        pp.agentClaims.filter(function (c) { return c.source !== "landlord"; }).length === 0 && h(EmptyState, { icon: "mail", title: "No claim links yet", sub: "Register a seller in a building and their claim link is sent to WhatsApp automatically.", action: { label: "Onboard a building", onClick: pp.openOnboard } })
      )
    );
  }
  function ClaimPage(props) {
    var pp = usePlugPay();
    var claim = pp.agentClaims.filter(function (c) { return c.token === props.token; })[0];
    var opened = PR.useRef(false);
    PR.useEffect(function () {
      if (claim && claim.status === "INVITED" && !opened.current) {
        opened.current = true;
        setTimeout(function () { pp.openClaimSignIn(claim.token); }, 120);
      }
    }, [claim && claim.status]);
    if (!claim) return h(PublicShellX, { title: "Claim link not found" }, h("div", { className: "app-card" }, h("div", { className: "app-card-title" }, "This claim link isn't valid or has expired."), h("div", { className: "app-card-sub" }, "Ask your agent or landlord to resend it."), h(Link, { to: "/", className: "pp-btn secondary" }, "Return home")));
    if (claim.status === "CLAIMED") return h(PublicShellX, { title: "Stall claimed", subtitle: claim.buildingName },
      h("section", { className: "app-card" },
        h("div", { className: "app-card-title" }, "\u2713 " + (claim.businessName || claim.ownerName || "This stall") + " is claimed"),
        h("div", { className: "app-card-sub" }, "Sign in with your number to open your dashboard."),
        h("div", { className: "app-actions" }, h("button", { className: "pp-btn primary", onClick: pp.openAuthModal }, "Sign in"), h(Link, { to: "/", className: "pp-btn secondary" }, "Return home"))));
    return h(PublicShellX, { title: "Claim your stall", subtitle: claim.buildingName + " \u00b7 " + claim.loc },
      h("section", { className: "app-card" },
        h("div", { className: "app-card-title" }, claim.businessName || claim.ownerName || "Your stall"),
        h("div", { className: "app-card-sub" }, claim.ownerName + " \u00b7 " + (claim.phone || "No phone on file")),
        h("div", { className: "app-card-sub" }, "Sign in with this number to claim the stall. " + (claim.verified ? "The landlord has already verified you." : "You'll show as Pending until the landlord verifies you.")),
        h("div", { className: "app-actions" }, h("button", { className: "pp-btn primary", onClick: function () { pp.openClaimSignIn(claim.token); } }, "Sign in to claim"))));
  }

  /* ---- Wiring: registers this group's modals, slots, pages and routes ---- */
  PP_ROUTES.push(
    ["/agent", "agent-buildings"],
    ["/agent/buildings", "agent-buildings"],
    ["/agent/claims", "agent-claims"],
    [/^\/claim\/(.+)$/, "claim", "token"]
  );
  PP_registry.registerPage("agent-buildings", function () { return h(AgentBuildingsPage, null); });
  PP_registry.registerPage("agent-claims", function () { return h(AgentClaimsPage, null); });
  PP_registry.registerPage("claim", function (r) { return h(ClaimPage, { token: r.token }); });