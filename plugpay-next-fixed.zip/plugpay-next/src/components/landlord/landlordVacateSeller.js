export function landlordVacateSeller(
  pp,
  seller
) {

  if (!seller) {
    return;
  }

  var sellerId =
    seller.id;

  var location =
    String(
      seller.sub ||
      seller.location ||
      ""
    );

  var stallMatch =
    location.match(
      /Stall\s*([A-Za-z0-9-]+)/i
    );

  var stallId =
    stallMatch
      ? stallMatch[1]
      : seller.stallId;

  var buildingId =
    pp.lbActive &&
    pp.lbActive.id;

  if (!buildingId) {
    return;
  }

  pp.updLb(
    buildingId,
    function (current) {

      var vacant =
        current.vacant ||
        [];

      var alreadyVacant =
        vacant.some(
          function (stall) {
            return String(
              stall.id
            ) === String(
              stallId
            );
          }
        );

      return {

        pending:
          current.pending ||
          [],

        verified:
          (
            current.verified ||
            []
          ).filter(
            function (x) {
              return x.id !==
                sellerId;
            }
          ),

        vacated:
          [
            seller,
            ...(current.vacated || [])
          ],

        vacant:
          stallId &&
          !alreadyVacant

            ? [
                {
                  id:
                    stallId,

                  label:
                    "Stall " +
                    stallId,

                  available:
                    true
                },

                ...vacant
              ]

            : vacant
      };

    }
  );

  pp.showToast(
    seller.name +
    " vacated. Stall " +
    (
      stallId ||
      ""
    ) +
    " is now available."
  );
}
