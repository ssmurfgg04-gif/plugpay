import { navigate } from "../../../lib/router.js";
import { usePlugPay } from "../../../store/context.js";
import { Modal } from "../../common/Modal.js";
import { h } from "../../common/h.js";

export function ReceiptModal() {
  var pp = usePlugPay();
  var r = pp.receipt, isInv = r.kind === "invoice", sp = pp.sellerProfile;
  var closeStyle = { background: "rgba(255,255,255,.16)", color: "#fff", borderColor: "rgba(255,255,255,.65)" };
  function row(l, v, cls) { return h("div", { className: "rm-row" + (cls ? " " + cls : ""), key: l + v }, h("span", { className: "rm-lbl" }, l), h("span", { className: "rm-val" }, v)); }
  return h(Modal, { id: "modal-receipt", innerClassName: "receipt-modal", closeButtonStyle: closeStyle, onExit: pp.focusMerchantProfileTab },
    h("div", { className: "rm-top" },
      h("div", { className: "rm-icon" }, isInv ? "\uD83D\uDCC4" : "\uD83E\uDDFE"),
      h("div", { className: "rm-title" }, isInv ? "Invoice sent!" : "Receipt sent!"),
      h("div", { className: "rm-sub" }, isInv ? "Payment link delivered \u00b7 add the M-Pesa code once it's paid" : "Sale recorded \u00b7 Review link attached \u00b7 Stock updated")),
    h("div", { className: "rm-body" },
      h("div", { className: "rm-rows" },
        row("Seller", sp.bizName + " \u00b7 " + pp.stallAssignment.loc),
        row(isInv ? "Invoice" : "Receipt #", isInv ? "#" + String(r.code).toUpperCase() : r.code),
        row("Buyer", (r.name ? r.name + " \u00b7 " : "") + r.phone),
        r.items.map(function (it, i) { return h("div", { className: "rm-row item-row", key: i }, h("span", { className: "rm-lbl" }, it.name + (it.qty > 1 ? " \u00d7 " + it.qty : "")), h("span", { className: "rm-val" }, "KSh " + Number(it.price).toLocaleString())); }),
        row("Total", "KSh " + Number(r.total).toLocaleString(), "total")),
      h("div", { className: "rm-verified" },
        h("span", { style: { fontSize: "18px" } }, "\u2713"),
        h("div", null,
          h("div", { className: "rm-verified-text" }, "Sent to the buyer's WhatsApp"),
          h("div", { className: "rm-verified-text", style: { opacity: ".6", fontSize: "10px" } }, isInv ? "Not counted as a sale until it is paid and a receipt is sent" : "Review link is open for 6 hours \u00b7 one review per receipt"))),
      h("div", { className: "rm-actions" },
        h("button", { className: "rm-btn rmb-primary", onClick: function () { if (isInv) pp.resendInvoice(r.code); else pp.sendReceipt(r.code); } }, isInv ? "Resend on WhatsApp" : "Resend with review link"),
        h(ReceiptOpenButton, { isInv: isInv, code: r.code }),
        h(ReceiptDoneButton, null))));
}

function ReceiptOpenButton(props) {
  var pp = usePlugPay();
  return h("button", { className: "rm-btn rmb-secondary", onClick: function () { pp.closeModal("modal-receipt"); navigate(props.isInv ? "/seller/invoices" : "/seller/receipts/" + encodeURIComponent(props.code)); } }, props.isInv ? "View invoice" : "Open receipt");
}

function ReceiptDoneButton() {
  var pp = usePlugPay();
  return h("button", { className: "rm-btn rmb-secondary", onClick: function () { pp.closeModal("modal-receipt"); pp.focusMerchantProfileTab(); } }, "Done");
}
