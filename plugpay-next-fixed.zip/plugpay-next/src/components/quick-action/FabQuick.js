import * as import_jsx_runtime from "../../ppJsxRuntime.js";
import { usePlugPay } from "../../store/context.js";

export function FabQuick() {
  const { openModal } = usePlugPay();
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { className: "fab-quick", onClick: () => openModal("modal-quick"), title: "Quick actions", "aria-label": "Quick actions", children: "\u26A1" });
}
