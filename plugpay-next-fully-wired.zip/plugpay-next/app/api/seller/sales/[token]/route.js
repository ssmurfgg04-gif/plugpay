import { adminDb, requireUser, json, body, getSellerForUser } from '../../../../../src/server/supabase.js';

export async function PATCH(request,ctx){
  const params = await ctx.params;
  const a=await requireUser(request); if(a.error)return a.error;
  const s=await getSellerForUser(a.user.id); if(!s)return json({error:'Seller not found'},404);
  const x=await body(request); const db=adminDb();
  if (x.status !== 'COMPLETE') return json({ error:'Only COMPLETE conversion is supported' },400);
  const r=await db.rpc('convert_invoice_to_sale_atomic',{p_invoice_token:params.token,p_payment_ref:x.paymentRef||null,p_send:x.send!==false});
  return r.error?json({error:r.error.message},400):json({ok:true,result:r.data});
}
