import { PR, h } from "../../../common/h.js";
import { Link } from "../../../common/routing.js";
import { InvoiceConvertBox } from "./InvoiceConvertBox.js";
import { ReviewChip, salesDocStatus } from "./salesShared.js";

export function SalesDocCard(props) {
  var pp = props.pp, kind = props.kind, d = props.doc;
  var _o = PR.useState(false), open = _o[0], setOpen = _o[1];
  var isInvoice = kind === "invoice";
  var id = isInvoice ? d.token : d.code;
  var paid = isInvoice && d.status === "PAID";
  var status = salesDocStatus(kind, d);
  var complete = status === "COMPLETE";
  var receiptLink = isInvoice ? (paid && d.paymentRef ? "/seller/receipts/" + encodeURIComponent("#" + d.paymentRef) : null) : "/seller/receipts/" + encodeURIComponent(d.code);
  var fullLink = isInvoice ? "/seller/invoices/" + encodeURIComponent(id) : "/seller/receipts/" + encodeURIComponent(d.code);
  var items = d.items || [];
  return h("div", { className: "sales-doc" },
    h("div", { className: "sales-doc-head" },
      h("div", { className: "sales-doc-main" },
        h("strong", null, isInvoice ? "Invoice " + (d.number ? d.number + " " : "") + "\u00b7 " + (d.buyerName || "Buyer") : "Receipt " + d.code),
        h("div", { className: "sales-doc-sub" }, (isInvoice ? "" : (d.buyerName || "Buyer") + " \u00b7 ") + (d.buyerPhone || "") + " \u00b7 " + new Date(d.createdAt).toLocaleString()),
        !isInvoice && h("div", { style: { marginTop: 6 } }, h(ReviewChip, { r: d }))),
      h("div", { className: "sales-doc-right" },
        h("strong", null, "KSh " + Number(d.total || 0).toLocaleString()),
        h("span", { className: "sales-pill " + (complete ? "complete" : "pending") }, complete ? "COMPLETE" : "PENDING"))),
    h("div", { className: "sales-doc-actions" },
      h(Link, { to: fullLink, className: "sp-edit-btn on" }, "View full doc"),
      h("button", { type: "button", className: "sp-edit-btn", onClick: function () { setOpen(!open); } }, open ? "Hide" : "Quick view"),
      !paid && h("button", { type: "button", className: "sp-edit-btn", onClick: function () { pp.setDocumentStatus(kind, id, complete ? "PENDING" : "COMPLETE"); } }, complete ? "Mark pending" : "Mark complete"),
      !isInvoice && !d.sentAt && h("button", { type: "button", className: "sp-edit-btn", onClick: function () { pp.sendReceipt(d.code); } }, "Send receipt"),
      isInvoice && !paid && h("button", { type: "button", className: "sp-edit-btn", onClick: function () { pp.resendInvoice(d.token); } }, "Resend")),
    open && h("div", { className: "sales-doc-panel" },
      h("div", { className: "sales-doc-items" },
        items.map(function (it, i) {
          return h("div", { key: i, className: "sales-doc-item" }, h("span", null, it.name + " \u00d7 " + (it.qty || 1)), h("strong", null, "KSh " + Number(it.price || 0).toLocaleString()));
        }),
        h("div", { className: "sales-doc-item total" }, h("span", null, "Total"), h("strong", null, "KSh " + Number(d.total || 0).toLocaleString()))),
      d.paymentRef && h("div", { className: "sales-doc-sub", style: { marginTop: 8 } }, "M-Pesa code: " + d.paymentRef),
      d.mpesaMessage && h("div", { className: "sales-doc-msg" }, d.mpesaMessage),
      h("div", { className: "sales-doc-actions", style: { marginTop: 10 } },
        isInvoice && receiptLink && h(Link, { to: receiptLink, className: "sp-edit-btn on" }, "Open receipt"),
        isInvoice && h(Link, { to: "/pay/" + d.token, className: "sp-edit-btn" }, "Open payment link"))),
    isInvoice && !paid && h(InvoiceConvertBox, { pp: pp, doc: d }),
    paid && receiptLink && h("div", { className: "sales-doc-sub", style: { marginTop: 8 } }, "Paid \u00b7 receipt " + "#" + d.paymentRef + " created")
  );
}
