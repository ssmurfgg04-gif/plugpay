import { usePlugPay } from "../../../../store/context.js";
import { h } from "../../../common/h.js";
import { Link } from "../../../common/routing.js";
import { ErrorState } from "../../../common/states.js";
import { Ic } from "../../../common/ui.js";
import { AppShellSeller, SellerGate } from "../../shell/SellerShell.js";
import { InvoiceConvertBox } from "./InvoiceConvertBox.js";
import { DocBadges, DocItems, DocPayInfo, DocTrader, salesDocStatus, sellerBadgeInfo } from "./salesShared.js";

export function SellerInvoiceDetailPage(props) {
  var pp = usePlugPay();
  var inv = pp.invoicesList.filter(function (x) { return x.token === props.token; })[0];
  if (!pp.merchantLoggedIn) return h(SellerGate, { active: "sales", msg: "Sign in to view this invoice." });
  if (!inv) return h(AppShellSeller, { title: "Invoice not found" }, h(ErrorState, { icon: "file-text", title: "Invoice not found", sub: "We couldn't find that invoice. It may have been removed.", backTo: "/seller/invoices", backLabel: "Back to sales" }));
  var sp = pp.sellerProfile, badges = sellerBadgeInfo(pp);
  var paid = inv.status === "PAID";
  var complete = salesDocStatus("invoice", inv) === "COMPLETE";
  return h(AppShellSeller, { title: "Invoice" + (inv.number ? " " + inv.number : ""), subtitle: paid ? "Paid. A receipt was created from this invoice." : "Awaiting payment. Paste the M-Pesa code or message below once the buyer pays." },
    h("div", { className: "doc-wrap" }, h("div", { className: "doc-card" },
      h("div", { className: "doc-band" },
        h("div", { className: "doc-band-top" }, h("div", { className: "doc-kind" }, Ic("file-text", 12), "PlugPay Invoice"), h("span", { className: "doc-status " + (complete ? "paid" : "pending") }, Ic(complete ? "badge-check" : "clock", 11), complete ? "Complete" : "Pending")),
        h("div", { className: "doc-amt" }, "KSh " + Number(inv.total || 0).toLocaleString()),
        h("div", { className: "doc-amt-label" }, "Billed to " + (inv.buyerName || "Buyer") + " \u00b7 " + new Date(inv.createdAt).toLocaleString())),
      h(DocTrader, { sp: sp }),
      h(DocBadges, { badges: badges }),
      h("div", { className: "doc-sec" }, h("div", { className: "doc-sec-h" }, Ic("user", 13), "Buyer & payment"),
        inv.number && h("div", { className: "doc-row" }, h("span", null, "Invoice no."), h("strong", null, inv.number)),
        h("div", { className: "doc-row" }, h("span", null, "Buyer phone"), h("strong", null, inv.buyerPhone || "\u2014")),
        h("div", { className: "doc-row" }, h("span", null, "Payment"), h("strong", null, paid ? "Paid" : "Awaiting payment")),
        inv.paymentRef && h("div", { className: "doc-row" }, h("span", null, "M-Pesa code"), h("strong", null, inv.paymentRef))),
      !paid && h(DocPayInfo, { sp: sp }),
      h(DocItems, { items: inv.items || [] }),
      h("div", { className: "doc-total-row" }, h("span", null, paid ? "Total paid" : "Total due"), h("strong", null, "KSh " + Number(inv.total || 0).toLocaleString())),
      !paid && h("div", { style: { padding: "0 20px 14px" } }, h(InvoiceConvertBox, { pp: pp, doc: inv })),
      h("div", { className: "doc-actions" },
        !paid && h("button", { className: "es-btn", onClick: function () { pp.setDocumentStatus("invoice", inv.token, complete ? "PENDING" : "COMPLETE"); } }, Ic(complete ? "clock" : "badge-check", 14), complete ? "Mark pending" : "Mark complete"),
        !paid && h("button", { className: "es-btn alt", onClick: function () { pp.resendInvoice(inv.token); } }, Ic("send", 14), "Resend on WhatsApp"),
        h(Link, { to: "/pay/" + inv.token, className: "es-btn alt" }, Ic("link", 14), "Payment link"),
        paid && inv.paymentRef && h(Link, { to: "/seller/receipts/" + encodeURIComponent("#" + inv.paymentRef), className: "es-btn alt" }, Ic("receipt", 14), "Open receipt")),
      h("div", { className: "app-actions", style: { padding: "0 20px 18px" } }, h(Link, { to: "/seller/invoices", className: "pp-btn secondary" }, "Back to sales"))
    ))
  );
}
