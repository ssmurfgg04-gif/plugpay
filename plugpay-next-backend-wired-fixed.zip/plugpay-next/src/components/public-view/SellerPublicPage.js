import { merchants } from '../../data/directory.js';
import { ppSlug } from '../../lib/utils.js';
import { apiFetch } from '../../lib/backend.js';
import { usePlugPay } from '../../store/context.js';
import { PR, h } from '../common/h.js';
import { goBack } from '../common/routing.js';
import { NotFoundPage, RouteSheet } from '../common/shells.js';
import { MerchantProfileBody } from './MerchantProfileBody.js';

export function SellerPublicPage(props) {
  var pp = usePlugPay();
  var [loading,setLoading]=PR.useState(true), [found,setFound]=PR.useState(false);
  PR.useEffect(function(){ let live=true; setLoading(true); apiFetch('/api/sellers/'+encodeURIComponent(props.id)).then(function(r){ if(!live)return; pp.loadSellerPage(r); setFound(true); }).catch(function(){ if(!live)return; var k=ppSlug(props.id); var ok=merchants.some(function(m){return ppSlug(m.name)===k;}) || ppSlug(pp.sellerProfile.ownerName)===k; if(ok){pp.loadSellerPage(props.id);setFound(true);} }).finally(function(){if(live)setLoading(false);}); return function(){live=false;}; },[props.id]);
  if(loading) return h(RouteSheet,{innerClassName:'modal tpModal',hideBar:true},h('div',{className:'app-card',style:{margin:24}},'Loading seller profile…'));
  if(!found) return h(NotFoundPage,{title:'Seller not found',sub:"We couldn't find a seller at this link."});
  return h(RouteSheet,{innerClassName:'modal tpModal',hideBar:true},h(MerchantProfileBody,{onClose:goBack}));
}
