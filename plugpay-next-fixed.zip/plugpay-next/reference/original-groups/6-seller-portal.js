
  /* ============================================================================
     SELLER PORTAL (auth, dashboard, catalogue, profile, building, reviews, sales)
     ============================================================================ */

  /* ---- Auth: sign in and register ---- */
  var authIconWrap = {
    width: "56px",
    height: "56px",
    borderRadius: "50%",
    background: "var(--accent-bg)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontSize: "26px",
    margin: "0 auto 12px"
  };
  var authLabel = {
    fontSize: "11px",
    fontWeight: 700,
    color: "var(--muted)",
    fontFamily: "var(--fm)",
    display: "block",
    marginBottom: "6px",
    textTransform: "uppercase",
    letterSpacing: ".06em"
  };
  var authTextInput = {
    width: "100%",
    padding: "13px 14px",
    border: "1.5px solid var(--border2)",
    borderRadius: "var(--r6)",
    fontSize: "16px",
    fontFamily: "var(--fb)",
    outline: "none",
    background: "var(--bg)",
    transition: "border-color .2s",
    marginBottom: "16px"
  };
  var authCodeInput = {
    width: "100%",
    padding: "16px 14px",
    border: "1.5px solid var(--border2)",
    borderRadius: "var(--r6)",
    fontSize: "28px",
    fontFamily: "var(--fm)",
    outline: "none",
    background: "var(--bg)",
    transition: "border-color .2s",
    marginBottom: "16px",
    letterSpacing: "10px",
    textAlign: "center"
  };
  var authSubmitBtn = {
    width: "100%",
    padding: "14px",
    borderRadius: "100px",
    background: "var(--grad)",
    color: "#fff",
    fontFamily: "var(--fb)",
    fontSize: "15px",
    fontWeight: 800,
    border: "none",
    cursor: "pointer"
  };
  var authLink = {
    color: "var(--accent)",
    textDecoration: "none",
    fontWeight: 700
  };
  function focusRing() {
    return {
      onFocus: (e) => e.currentTarget.style.borderColor = "var(--accent)",
      onBlur: (e) => e.currentTarget.style.borderColor = "var(--border2)"
    };
  }
  function AuthOtpStep() {
    const { authPhone, authMethod, authOtp, setAuthOtp, authVerifyOTP, authGoBack } = usePlugPay();
    return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "auth-shell", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { textAlign: "center", marginBottom: "20px" }, children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: authIconWrap, children: "\u{1F4AC}" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { fontSize: "22px", fontWeight: 900, color: "var(--ink)", marginBottom: "4px" }, children: "Enter your OTP" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { fontSize: "13px", color: "var(--muted)", lineHeight: "1.55" }, children: [
          "Code sent to ",
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { style: { color: "var(--ink)" }, children: authPhone.trim() || "07XX XXX XXX" }),
          " via",
          " ",
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: authMethod === "sms" ? "SMS" : "WhatsApp" }),
          "."
        ] })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { style: authLabel, children: "ONE-TIME CODE" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        "input",
        {
          type: "tel",
          placeholder: "_ _ _ _ _ _",
          maxLength: 6,
          style: authCodeInput,
          value: authOtp,
          onChange: (e) => setAuthOtp(e.target.value),
          onKeyDown: (e) => {
            if (e.key === "Enter") authVerifyOTP();
          },
          ...focusRing()
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { style: authSubmitBtn, onClick: () => authVerifyOTP(), children: "Verify & open my profile \u2192" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { textAlign: "center", fontSize: "12px", color: "var(--muted2)", marginTop: "14px", fontFamily: "var(--fm)" }, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        "a",
        {
          href: "#",
          onClick: (e) => {
            e.preventDefault();
            authGoBack();
          },
          style: authLink,
          children: "\u2190 Change number"
        }
      ) })
    ] });
  }
  function AuthPhoneStep() {
    const { authMethod, authSetMethod, authPhone, setAuthPhone, authSendOTP, authShowPinLogin, claimInfo } = usePlugPay();
    return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "auth-shell", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { textAlign: "center", marginBottom: "20px" }, children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: authIconWrap, children: "\u{1F510}" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { fontSize: "22px", fontWeight: 900, color: "var(--ink)", marginBottom: "4px" }, children: [
          "Sign in to",
          " ",
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
            "img",
            {
              src: LOGO_DATA_URI,
              alt: "PlugPay",
              style: { height: "22px", width: "auto", verticalAlign: "-5px", display: "inline-block" }
            }
          )
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { fontSize: "13px", color: "var(--muted)", lineHeight: "1.55" }, children: "Enter your WhatsApp number. We'll send you a one-time code \u2014 SMS if WhatsApp isn't available." })
      ] }),
      claimInfo && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "rv-note", style: { marginBottom: "14px" }, children: [
        (0, import_jsx_runtime.jsx)("span", { children: "\u{1F4F2}" }),
        (0, import_jsx_runtime.jsxs)("span", { children: [(0, import_jsx_runtime.jsx)("b", { children: "Claim link opened. " }), "Sign in with the number on file to claim " + claimInfo.name + " \u00b7 " + claimInfo.building + ", " + claimInfo.loc + "."] })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "method-toggle", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
          "button",
          {
            type: "button",
            className: `method-toggle-btn${authMethod === "whatsapp" ? " active" : ""}`,
            onClick: () => authSetMethod("whatsapp"),
            children: "\u{1F4AC} WhatsApp"
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
          "button",
          {
            type: "button",
            className: `method-toggle-btn${authMethod === "sms" ? " active" : ""}`,
            onClick: () => authSetMethod("sms"),
            children: "\u{1F4F1} SMS"
          }
        )
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { style: authLabel, children: authMethod === "sms" ? "PHONE NUMBER" : "WHATSAPP NUMBER" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        "input",
        {
          type: "tel",
          placeholder: "07XX XXX XXX",
          style: authTextInput,
          value: authPhone,
          onChange: (e) => setAuthPhone(e.target.value),
          ...focusRing()
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { style: authSubmitBtn, onClick: () => authSendOTP(), children: "Send OTP \u2192" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { textAlign: "center", fontSize: "11.5px", color: "var(--muted2)", marginTop: "14px", lineHeight: "1.6" }, children: [
        "Your stall is registered by an agent.",
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
        "Claimed your profile? Sign in here with the phone number on file to complete it."
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { textAlign: "center", fontSize: "12px", marginTop: "10px", fontFamily: "var(--fm)" }, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        "a",
        {
          href: "#",
          onClick: (e) => {
            e.preventDefault();
            authShowPinLogin();
          },
          style: authLink,
          children: "Already set a PIN? Sign in with PIN \u2192"
        }
      ) })
    ] });
  }
  function AuthPinLoginStep() {
    const { authPinLoginValue, setAuthPinLoginValue, authPinLogin, authGoBackFromPin } = usePlugPay();
    return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "auth-shell", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { textAlign: "center", marginBottom: "20px" }, children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: authIconWrap, children: "\u{1F511}" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { fontSize: "22px", fontWeight: 900, color: "var(--ink)", marginBottom: "4px" }, children: "Sign in with PIN" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { fontSize: "13px", color: "var(--muted)", lineHeight: "1.55" }, children: "Enter your 6-digit PIN to unlock your stall profile." })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { style: authLabel, children: "6-DIGIT PIN" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        "input",
        {
          type: "password",
          inputMode: "numeric",
          placeholder: "_ _ _ _ _ _",
          maxLength: 6,
          style: authCodeInput,
          value: authPinLoginValue,
          onChange: (e) => setAuthPinLoginValue(e.target.value),
          onKeyDown: (e) => {
            if (e.key === "Enter") authPinLogin();
          },
          ...focusRing()
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { style: authSubmitBtn, onClick: () => authPinLogin(), children: "Unlock my profile \u2192" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { textAlign: "center", fontSize: "12px", color: "var(--muted2)", marginTop: "14px", fontFamily: "var(--fm)" }, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        "a",
        {
          href: "#",
          onClick: (e) => {
            e.preventDefault();
            authGoBackFromPin();
          },
          style: authLink,
          children: "\u2190 Use OTP instead"
        }
      ) })
    ] });
  }
  function AuthSetPinStep() {
    const { authSetPinValue, setAuthSetPinValue, authSetPin } = usePlugPay();
    return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "auth-shell", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { textAlign: "center", marginBottom: "20px" }, children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: authIconWrap, children: "\u{1F511}" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { fontSize: "22px", fontWeight: 900, color: "var(--ink)", marginBottom: "4px" }, children: "Set a 6-digit PIN" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { fontSize: "13px", color: "var(--muted)", lineHeight: "1.55" }, children: "Use this PIN to unlock your stall profile next time \u2014 no OTP needed." })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { style: authLabel, children: "CHOOSE A 6-DIGIT PIN" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        "input",
        {
          type: "password",
          inputMode: "numeric",
          placeholder: "_ _ _ _ _ _",
          maxLength: 6,
          style: authCodeInput,
          value: authSetPinValue,
          onChange: (e) => setAuthSetPinValue(e.target.value),
          onKeyDown: (e) => {
            if (e.key === "Enter") authSetPin();
          },
          ...focusRing()
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { style: authSubmitBtn, onClick: () => authSetPin(), children: "Set PIN & open my profile \u2192" })
    ] });
  }
  function RegisterModal() {
    const { authStep, focusMerchantProfileTab } = usePlugPay();
    return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, { id: "modal-register", onExit: focusMerchantProfileTab, children: [
      authStep === "phone" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthPhoneStep, {}),
      authStep === "pinlogin" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthPinLoginStep, {}),
      authStep === "otp" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthOtpStep, {}),
      authStep === "setpin" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthSetPinStep, {})
    ] });
  }
  function SellerGate(props) {
    var pp = usePlugPay();
    return h(SellerPortalShell, { active: props.active, noDock: true },
      h("div", { style: { padding: 12 } }, h(DashSignIn, { msg: props.msg || "Sign in to your seller account to open your dashboard.", onClick: pp.openAuthModal }))
    );
  }

  /* ---- Portal shell and navigation ---- */
  var SP_TABS = [
    ["dashboard", "Dashboard", "/seller/dashboard"],
    ["catalogue", "Catalogue", "/seller/catalogue"],
    ["profile", "Profile", "/seller/profile"],
    ["building", "Building", "/seller/building"]
  ];
  function SellerBottomNav(props) {
    var active = props.active || "dashboard";

    return h("nav", {
      className: "seller-bottom-nav",
      "aria-label": "Seller navigation"
    },
      SP_TABS.map(function (tab) {
        return h("button", {
          key: tab[0],
          type: "button",
          className:
            "seller-bottom-nav-item" +
            (active === tab[0] ? " active" : ""),
          onClick: function () {
            window.location.replace("#" + tab[2]);
          }
        }, tab[1]);
      })
    );
  }
  function SellerPortalShell(props) {
    var pp = usePlugPay();
    var active = props.active;
    var showDock = (active === "dashboard" || active === "sales") && !props.noDock;
    return h(PortalShell, { shellClass: "sp-shell", wrapClass: "sp-wrap",
      header: h(TopBar, { title: "My Business", actions: h("button", { className: "tp-navbar-btn", style: { width: "auto", padding: "0 12px", fontSize: 10, fontWeight: 800 }, onClick: function () { pp.viewSellerProfile(); } }, "View profile") }),
      body: h("div", {
        style: {
          paddingBottom: 96
        }
      }, props.children),
      dock: showDock && h("div", { className: "sp-dock" }, h("button", { className: "sp-dock-btn rec", onClick: function () { pp.openModal("modal-record-sale"); } }, "\uFF0B Record a sale")),
      nav: h(SellerBottomNav, { active: active }) });
  }
  // Sales sub-pages live inside the same single seller shell (Sales tab)
  function AppShellSeller(props) {
    var pp = usePlugPay();
    if (!pp.merchantLoggedIn) return h(SellerGate, { active: "sales", msg: "Sign in to your seller account to continue." });
    return h(SellerPortalShell, { active: "sales" },
      h("div", { style: { padding: "16px 12px 40px" } },
        h("div", { className: "app-heading" }, h("div", null, h("h1", null, props.title), props.subtitle && h("p", null, props.subtitle))),
        h(WithSkeleton, { kind: "list", dep: props.title }, props.children)
      )
    );
  }
  function EditRow(props) {
    var _e = PR.useState(false), editing = _e[0], setEditing = _e[1];
    var _v = PR.useState(props.value), val = _v[0], setVal = _v[1];
    function start() { setVal(props.editValue != null ? props.editValue : props.value); setEditing(true); }
    function save() {
      var v = String(val).trim();
      if (props.required && !v) return;
      props.onSave(v);
      setEditing(false);
    }
    var Tag = props.options ? "select" : props.multiline ? "textarea" : "input";
    return h("div", { className: "tp-info-row", style: props.last ? { border: "none" } : undefined },
      props.icon && h("div", { className: "tp-info-ico", style: { background: props.bg || "#f8f1f7" } }, h("span", null, props.icon)),
      h("div", { className: "tp-info-text", style: { flex: 1, minWidth: 0 } },
        h("div", { className: "tp-info-label" }, props.label),
        editing
          ? h("div", null,
              h(Tag, { className: "plc-input", style: { marginTop: 6, minHeight: props.multiline ? 84 : undefined }, value: val, autoFocus: true, type: props.inputType, inputMode: props.inputMode, onChange: function (e) { setVal(e.target.value); } }, props.options ? [h("option", { key: "_", value: "" }, "Select\u2026")].concat(props.options.map(function (o) { return h("option", { key: o, value: o }, o); })) : undefined),
              h("div", { className: "sp-edit-actions" },
                h("button", { className: "sp-edit-btn on", onClick: save }, "Save"),
                h("button", { className: "sp-edit-btn", onClick: function () { setEditing(false); } }, "Cancel")))
          : h("div", { className: "tp-info-val", style: { whiteSpace: "pre-wrap", wordBreak: "break-word" } }, props.value || h("span", { style: { color: "var(--muted)" } }, "Not set"))
      ),
      !editing && (props.locked
        ? h("span", { className: "sp-lock", title: props.lockNote || "Managed by PlugPay" }, "\uD83D\uDD12 " + (props.lockNote || "Locked"))
        : h("button", { className: "sp-edit-btn", onClick: start }, "\u270F\uFE0F Edit"))
    );
  }
  function SellerHero(props) {
    var pp = usePlugPay();
    var sp = pp.sellerProfile;
    var _e = PR.useState(false), editing = _e[0], setEditing = _e[1];
    var _f = PR.useState(sp), form = _f[0], setForm = _f[1];
    function set(k, v) { var n = {}; n[k] = v; setForm(Object.assign({}, form, n)); }
    function save() {
      if (!form.bizName.trim()) { pp.showToast("Business name is required"); return; }
      pp.updateSellerProfile({ bizName: form.bizName.trim(), ownerName: form.ownerName.trim(), role: form.role.trim(), bio: form.bio.trim(), street: form.street.trim() });
      setEditing(false);
    }
    return h(PR.Fragment, null,
      h("div", { className: "tp-hero", style: { marginTop: 0 } },
        props.editable && h("button", { className: "sp-hero-edit", onClick: function () { setForm(sp); setEditing(!editing); } }, editing ? "\u2715 Close" : "\u270F\uFE0F Edit header"),
        h("div", { className: "tp-hero-avatar-wrap" }, h("div", { className: "tp-hero-avatar" }, (sp.bizName || "W").charAt(0).toUpperCase()), h("div", { className: "tp-hero-av-check" }, "\u2713")),
        h("div", { className: "tp-hero-name" }, sp.bizName),
        h("div", { className: "tp-hero-role" }, sp.ownerName + " \u00b7 " + sp.role),
        h("div", { className: "tp-hero-badge" }, h("span", { className: "tp-v-icon" }, "\u2713"), " Verified Seller Profile"),
        h("div", { className: "tp-hero-bio" }, sp.bio),
        h("div", { className: "tp-hero-loc" }, h("span", null, "\uD83D\uDCCD " + sp.street), h("span", null, pp.stallAssignment.building + ", " + pp.stallAssignment.loc)),
        h("div", { className: "tp-landlord-tag" }, h("span", { className: "tp-landlord-tick" + (pp.landlordVerifyPending ? " pending" : "") }, pp.landlordVerifyPending ? "\u23F3" : "\u2713"), " ", h("span", null, pp.landlordVerifyPending ? "Pending" : "Verified")),
        h("div", { className: "tp-hero-stats" },
          h("div", { className: "tp-hero-stat" }, h("div", { className: "tp-hero-stat-n" }, pp.sellerStats.sales), h("div", { className: "tp-hero-stat-l" }, "Sales")),
          h("div", { className: "tp-hero-stat" }, h("div", { className: "tp-hero-stat-n" }, "235"), h("div", { className: "tp-hero-stat-l" }, "Followers")),
          h("div", { className: "tp-hero-stat" }, h("div", { className: "tp-hero-stat-n" }, pp.sellerStats.reviewCount), h("div", { className: "tp-hero-stat-l" }, "Reviews")),
          h("div", { className: "tp-hero-stat" }, h("div", { className: "tp-hero-stat-n" }, pp.sellerStats.trust), h("div", { className: "tp-hero-stat-l" }, "Trust"))
        )
      ),
      editing && h("div", { className: "tp-card", style: { padding: 13 } },
        h("div", { className: "tp-section-title" }, "Edit header"),
        [["bizName", "Business name"], ["ownerName", "Owner name"], ["role", "Business type / role"], ["street", "Street location"]].map(function (f) {
          return h("label", { key: f[0], className: "plc-field", style: { display: "block", marginBottom: 10 } }, h("span", { className: "plc-label" }, f[1]), h("input", { className: "plc-input", list: f[0] === "role" ? "sp-roles" : undefined, value: form[f[0]], onChange: function (e) { set(f[0], e.target.value); } }));
        }),
        h("datalist", { id: "sp-roles" }, ["Electronics Retailer", "Fashion & Clothing", "Food & Groceries", "Hardware & Building", "Beauty & Cosmetics", "Furniture", "Services & Repairs", "Wholesaler"].map(function (o) { return h("option", { key: o, value: o }); })),
        h("label", { className: "plc-field", style: { display: "block", marginBottom: 10 } }, h("span", { className: "plc-label" }, "Short bio"), h("textarea", { className: "plc-input", style: { minHeight: 70 }, value: form.bio, onChange: function (e) { set("bio", e.target.value); } })),
        h("div", { className: "sp-lock-note" }, "\uD83D\uDD12 Verified badge, landlord verification, stall location and stats are set by PlugPay and your landlord \u2014 they can't be edited."),
        h("div", { className: "sp-edit-actions" }, h("button", { className: "sp-edit-btn on", onClick: save }, "Save changes"), h("button", { className: "sp-edit-btn", onClick: function () { setEditing(false); } }, "Cancel"))
      )
    );
  }
  function SellerPortalPage(props) {
    var pp = usePlugPay();
    if (!pp.merchantLoggedIn) return h(SellerGate, { active: props.tab });
    var tabRender = PP_registry.pages["seller.tab." + props.tab] || PP_registry.pages["seller.tab.dashboard"];
    var body = tabRender();
    return h(SellerPortalShell, { active: props.tab }, h(WithSkeleton, { kind: props.tab === "catalogue" ? "cards" : props.tab === "dashboard" ? "dash" : "list", dep: props.tab }, body));
  }

  /* ---- Dashboard tab ---- */
  function SellerReviewsCard() {
    var pp = usePlugPay();
    var st = pp.sellerStats;
    return h("div", { className: "tp-card", style: { padding: 14 } },
      h("div", { className: "tp-section-title" }, "Buyer reviews"),
      h("div", { className: "review-summary-row" },
        h("strong", null, st.avg.toFixed(1)),
        h("span", null, "\u2605"),
        h("span", null, st.reviewCount + " reviews")),
      h("button", { type: "button", className: "pp-btn secondary", onClick: function () { window.location.replace("#/seller/reviews"); } }, Ic("star", 14), "View reviews"));
  }
  function SellerPaymentOptions() {
    var pp = usePlugPay();
    var methods = pp.sellerProfile.paymentOptions || [];
    function addOption() {
      pp.updateSellerProfile({ paymentOptions: methods.concat({ id: "pay-" + Date.now().toString(36), method: "Paybill", number: "", accountName: "" }) });
    }
    function updateOption(id, patch) {
      pp.updateSellerProfile({ paymentOptions: methods.map(function (x) { return x.id === id ? Object.assign({}, x, patch) : x; }) });
    }
    function removeOption(id) {
      pp.updateSellerProfile({ paymentOptions: methods.filter(function (x) { return x.id !== id; }) });
    }
    return h(PR.Fragment, null,
      h("div", { className: "tp-pay-info-header", style: { padding: "0 13px 10px" } },
        h("div", { className: "tp-pay-info-title" }, "More payment options"),
        h("button", { className: "sp-edit-btn on", onClick: addOption }, "+ Add payment option")),
      methods.length === 0 && h("div", { className: "sp-payment-empty" }, "Add the payment methods buyers can use to pay you."),
      methods.map(function (p) {
        return h("div", { key: p.id, className: "sp-payment-option" },
          h("select", { className: "plc-input", value: p.method, onChange: function (e) { updateOption(p.id, { method: e.target.value }); } },
            ["Paybill", "Till number", "Send money", "Bank transfer"].map(function (x) { return h("option", { key: x, value: x }, x); })),
          h("input", { className: "plc-input", placeholder: "Account / number", defaultValue: p.number, onBlur: function (e) { if (e.target.value !== p.number) updateOption(p.id, { number: e.target.value }); } }),
          h("input", { className: "plc-input", placeholder: "Registered name", defaultValue: p.accountName, onBlur: function (e) { if (e.target.value !== p.accountName) updateOption(p.id, { accountName: e.target.value }); } }),
          h("button", { className: "sp-edit-btn danger", onClick: function () { removeOption(p.id); } }, "Remove"));
      }));
  }
  function SellerDashboardVouches() {
    var pp = usePlugPay();
    var _v = usePersisted("vouches", {
      people: [
        { id: "v1", name: "Peter Otieno", role: "Electronics seller", vouched: true },
        { id: "v2", name: "Amina Kibe", role: "Fashion seller", vouched: true },
        { id: "u1", name: "Samuel Kamau", role: "Mobile accessories", vouched: false }
      ]
    }), state = _v[0], setState = _v[1];
    var people = state.people || [];
    function setVouch(id, value) {
      setState({ people: people.map(function (x) { return x.id === id ? Object.assign({}, x, { vouched: value }) : x; }) });
      var who = people.filter(function (x) { return x.id === id; })[0];
      if (who) pp.showToast(value ? "You vouched for " + who.name + " \u2713" : "Vouch removed for " + who.name);
    }
    function col(title, list, mark, cls, empty) {
      return h("div", { className: "sp-vouch-column" },
        h("div", { className: "sp-vouch-heading" }, title + " (" + list.length + ")"),
        list.map(function (x) {
          return h("div", { className: "sp-vouch-person", key: x.id },
            h("span", { className: cls }, mark),
            h("div", { className: "sp-vouch-who" }, h("strong", null, x.name), h("small", null, x.role)),
            x.vouched
              ? h("button", { type: "button", className: "sp-edit-btn danger", onClick: function () { setVouch(x.id, false); } }, "Remove vouch")
              : h("button", { type: "button", className: "sp-edit-btn on", onClick: function () { setVouch(x.id, true); } }, "Vouch"));
        }),
        list.length === 0 && h("small", { className: "sp-vouch-empty" }, empty));
    }
    return h("div", { className: "dx-card" },
      h("div", { className: "dx-head" },
        h("div", { className: "dx-k", style: { margin: 0 } }, "Vouching"),
        h("span", { className: "dx-chip ok" }, people.filter(function (x) { return x.vouched; }).length + " vouched")),
      h("section", { className: "sp-vouch-summary" },
        col("Vouched sellers", people.filter(function (x) { return x.vouched; }), "\u2713", "sp-vouch-check", "No vouched sellers yet."),
        col("Yet to be vouched", people.filter(function (x) { return !x.vouched; }), "\u2022", "sp-vouch-pending", "Everyone is vouched.")));
  }
  var DashCtx = import_react.createContext(null);
  function SellerDashboardTabSection1() {
    var __c = import_react.useContext(DashCtx) || {}; var mode = __c.mode, setMode = __c.setMode, top = __c.top, todayName = __c.todayName;
    return h("div", { className: "dx-top" },
        h("div", null, h("div", { className: "dx-date" }, todayName), h("div", { className: "dx-h" }, "Overview")),
        h("div", { className: "dx-seg" }, ["daily", "weekly", "yearly"].map(function (m) { return h("button", { key: m, className: mode === m ? "on" : "", onClick: function () { setMode(m); } }, m === "daily" ? "Daily" : m === "weekly" ? "Weekly" : "Yearly"); })));
  }
  function SellerDashboardTabSection2() {
    var __c = import_react.useContext(DashCtx) || {}; var mode = __c.mode, money = __c.money, n = __c.n, k = __c.k, now = __c.now, yr = __c.yr, series = __c.series, cur = __c.cur, curN = __c.curN, maxAmt = __c.maxAmt, delta = __c.delta, W = __c.W, H = __c.H, bw = __c.bw;
    return h("div", { className: "dx-card" },
        h("div", { className: "dx-k" }, mode === "daily" ? "Sales \u00b7 this week (Mon\u2013Sun)" : mode === "weekly" ? "Sales \u00b7 last 6 weeks" : "Sales \u00b7 " + yr + " by month"),
        h("div", { className: "dx-big" }, money(cur)),
        delta !== null && h("div", { className: "dx-delta " + (delta >= 0 ? "up" : "down") }, (delta >= 0 ? "\u2191 " : "\u2193 ") + Math.abs(delta) + "% vs previous period"),
        h("svg", { className: "dx-chart", viewBox: "0 0 " + W + " " + (H + 18), preserveAspectRatio: "none" },
          series.map(function (s, j) {
            var bh = Math.max(2, s.amt / maxAmt * H);
            return h("g", { key: j },
              h("rect", { className: "dx-bar" + (s.latest ? " now" : ""), x: j * bw + bw * 0.2, y: H - bh, width: bw * 0.6, height: bh, rx: 3 }),
              h("text", { className: "dx-lbl", x: j * bw + bw / 2, y: H + 13, textAnchor: "middle" }, s.label));
          })),
        h("div", { className: "dx-mini" },
          h("div", null, h("b", null, curN), h("span", null, "Items sold")),
          h("div", null, h("b", null, money(curN ? cur / curN : 0)), h("span", null, "Avg. sale")),
          h("div", null, h("b", null, (series.filter(function (x) { return x.latest; })[0] || { n: 0 }).n), h("span", null, mode === "daily" ? "Today" : mode === "weekly" ? "This week" : "This month"))));
  }
  function SellerDashboardTabSection3() {
    var __c = import_react.useContext(DashCtx) || {}; var money = __c.money, k = __c.k, i = __c.i, cur = __c.cur, top = __c.top, topMax = __c.topMax;
    return h("div", { className: "dx-card" },
        h("div", { className: "dx-k" }, "Sales by product"),
        top.length === 0 ? h("div", { className: "dx-empty" }, "No sales in this period.") : top.map(function (t) {
          return h("div", { key: t.name, className: "dx-row" },
            h("div", { className: "dx-rowtop" }, h("span", { className: "dx-name" }, t.name), h("b", null, money(t.amt))),
            h("div", { className: "dx-track" }, h("i", { style: { width: Math.max(4, t.amt / topMax * 100) + "%" } })),
            h("div", { className: "dx-sub" }, t.units + (t.units === 1 ? " unit" : " units") + " \u00b7 " + (cur ? Math.round(t.amt / cur * 100) : 0) + "% of sales"));
        }));
  }
  function SellerDashboardTabSection4() {
    var __c = import_react.useContext(DashCtx) || {}; var money = __c.money, k = __c.k, i = __c.i, catAgg = __c.catAgg;
    return h("div", { className: "dx-card" },
        h("div", { className: "dx-k" }, "Sales by category"),
        Object.keys(catAgg).length === 0 ? h("div", { className: "dx-empty" }, "No categorised sales in this period.") : Object.keys(catAgg).sort(function (a, b) { return catAgg[b] - catAgg[a]; }).map(function (k) {
          var mx = Math.max.apply(null, Object.keys(catAgg).map(function (x) { return catAgg[x]; }));
          return h("div", { key: k, className: "dx-row" }, h("div", { className: "dx-rowtop" }, h("span", { className: "dx-name" }, k), h("b", null, money(catAgg[k]))), h("div", { className: "dx-track" }, h("i", { style: { width: Math.max(4, catAgg[k] / mx * 100) + "%" } })));
        }));
  }
  function SellerSalesSummary() {
    var pp = usePlugPay();
    var rc = pp.receiptsList || [], iv = pp.invoicesList || [];
    var all = rc.map(function (r) { return salesDocStatus("receipt", r); }).concat(iv.map(function (i) { return salesDocStatus("invoice", i); }));
    var complete = all.filter(function (x) { return x === "COMPLETE"; }).length;
    function cell(n, label) { return h("div", null, h("strong", null, n), h("span", null, label)); }
    return h("div", { className: "seller-sales-summary" }, cell(rc.length, "Receipts"), cell(iv.length, "Invoices"), cell(complete, "Complete"), cell(all.length - complete, "Pending"));
  }
  function SellerDashboardTabSection5() {
    var pp = usePlugPay();
    var receipts = pp.receiptsList || [], invoices = pp.invoicesList || [];
    function toRow(kind, d) {
      var isInv = kind === "invoice";
      return {
        key: isInv ? d.token : d.code,
        code: isInv ? (d.number || "Invoice \u00b7 " + (d.buyerName || "Buyer")) : d.code,
        state: salesDocStatus(kind, d),
        total: Number(d.total) || 0,
        to: isInv ? "/seller/invoices/" + encodeURIComponent(d.token) : "/seller/receipts/" + encodeURIComponent(d.code)
      };
    }
    function docCol(title, list) {
      return h("div", { className: "sp-document-column" },
        h("div", { className: "sp-document-heading" }, title),
        list.length === 0 && h("div", { className: "sales-doc-sub" }, "None yet"),
        list.map(function (r) {
          return h(Link, { key: r.key, to: r.to, className: "sp-document-row" },
            h("span", null, r.code),
            h("strong", null, "KSh " + r.total.toLocaleString()),
            h("em", { className: r.state === "COMPLETE" ? "complete" : "pending" }, r.state));
        }));
    }
    return h("div", { className: "dx-card" },
      h("div", { className: "dx-head" },
        h("div", { className: "dx-k", style: { margin: 0 } }, "Invoices & receipts"),
        h("span", { className: "dx-chip ok" }, (receipts.length + invoices.length) + " records")),
      h(SellerSalesSummary, null),
      h("div", { className: "sp-document-summary" },
        docCol("Receipts \u00b7 " + receipts.length, receipts.slice(0, 5).map(function (d) { return toRow("receipt", d); })),
        docCol("Invoices \u00b7 " + invoices.length, invoices.slice(0, 5).map(function (d) { return toRow("invoice", d); }))),
      h("div", { className: "dx-btns" },
        h(Link, { to: "/seller/receipts", className: "bd-btn fill" }, h("span", null, "View all sales"), h("span", { className: "a" }, "\u2192"))));
  }
  function SellerDashboardTabSection6() {
    var __c = import_react.useContext(DashCtx) || {}; var pp = __c.pp, k = __c.k, i = __c.i, stock = __c.stock, stockMax = __c.stockMax, lowCount = __c.lowCount;
    return h("div", { className: "dx-card" },
        h("div", { className: "dx-head" }, h("div", { className: "dx-k", style: { margin: 0 } }, "Stock levels"), h("span", { className: "dx-chip " + (lowCount ? "warn" : "ok") }, lowCount ? lowCount + " need restock" : "All healthy")),
        stock.map(function (c) {
          var st = c.stock === 0 ? "out" : c.stock <= 5 ? "low" : "ok";
          return h("div", { key: c.id, className: "dx-row" },
            h("div", { className: "dx-rowtop" }, h("span", { className: "dx-name" }, c.name), h("span", { className: "dx-st " + st }, c.stock === 0 ? "Out of stock" : c.stock + " left")),
            h("div", { className: "dx-track" }, h("i", { className: st, style: { width: Math.max(3, c.stock / stockMax * 100) + "%" } })));
        }),
        h("div", { className: "dx-btns" },
          h(Link, { to: "/seller/catalogue", className: "bd-btn fill" }, h("span", null, "Manage catalogue"), h("span", { className: "a" }, "\u2192")),
          h("button", { className: "bd-btn pill", onClick: function () { pp.openBuildingModal(pp.stallAssignment && pp.stallAssignment.building); } }, h("span", null, "View building"), h("span", { className: "a" }, "\u2192"))));
  }
  function SellerDashboardTabSection7() {
    var __c = import_react.useContext(DashCtx) || {}; var demo = __c.demo;
    return demo && h("div", { className: "dx-note" }, "Showing sample data. Record a sale and your real numbers appear here.");
  }
  function SellerDashboardTab() {
    var pp = usePlugPay();
    var _m = PR.useState("daily"), mode = _m[0], setMode = _m[1];
    var cat = pp.catalogueItems;
    var money = function (n) { return "KSh " + Math.round(n).toLocaleString(); };
    var rows = [];
    pp.sentReceipts.forEach(function (r) { (r.items || []).forEach(function (it) { rows.push({ name: it.name, amt: Number(it.price) || 0, qty: Number(it.qty) || 1, cat: it.category || (it.productId ? "" : "Not in catalogue"), at: new Date(r.createdAt) }); }); });
    var demo = rows.length === 0;
    if (demo && cat.length) {
      var seed = 7, rnd = function () { seed = (seed * 9301 + 49297) % 233280; return seed / 233280; };
      for (var d = 0; d < 800; d++) {
        var n = 1 + Math.floor(rnd() * 4);
        for (var k = 0; k < n; k++) {
          var p = cat[Math.floor(rnd() * rnd() * cat.length)];
          var dt = new Date(); dt.setHours(9 + Math.floor(rnd() * 9), 0, 0, 0); dt.setDate(dt.getDate() - d);
          rows.push({ name: p.name, amt: Number(p.price) || 0, qty: 1, cat: p.category, at: dt });
        }
      }
    }
    var DAY = 86400000, i, now = new Date(); now.setHours(0, 0, 0, 0);
    var addD = function (d0, n) { var x = new Date(d0); x.setDate(x.getDate() + n); return x; };
    var wkStart = addD(now, -((now.getDay() + 6) % 7));
    var DN = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"], MN = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    var starts = [], ends = [], labels = [], prevStart, prevEnd, yr = now.getFullYear();
    if (mode === "daily") {
      for (i = 0; i < 7; i++) { starts.push(addD(wkStart, i).getTime()); ends.push(addD(wkStart, i + 1).getTime()); labels.push(DN[i]); }
      prevStart = addD(wkStart, -7).getTime(); prevEnd = wkStart.getTime();
    } else if (mode === "weekly") {
      for (i = 0; i < 6; i++) { var ws = addD(wkStart, (i - 5) * 7); starts.push(ws.getTime()); ends.push(addD(ws, 7).getTime()); labels.push(ws.getDate() + " " + MN[ws.getMonth()]); }
      prevStart = addD(wkStart, -77).getTime(); prevEnd = starts[0];
    } else {
      for (i = 0; i < 12; i++) { starts.push(new Date(yr, i, 1).getTime()); ends.push(new Date(yr, i + 1, 1).getTime()); labels.push(MN[i]); }
      prevStart = new Date(yr - 1, 0, 1).getTime(); prevEnd = starts[0];
    }
    var count = starts.length, nowT = Date.now();
    var series = labels.map(function (l, idx) { return { amt: 0, n: 0, label: l, latest: nowT >= starts[idx] && nowT < ends[idx] }; });
    var catAgg = {}; var cur = 0, curN = 0, prev = 0, prod = {};
    rows.forEach(function (r) {
      var t = r.at.getTime();
      if (t >= prevStart && t < prevEnd) { prev += r.amt; return; }
      for (var bi = 0; bi < count; bi++) {
        if (t >= starts[bi] && t < ends[bi]) {
          series[bi].amt += r.amt; series[bi].n += (r.qty || 1); cur += r.amt; curN += (r.qty || 1);
          var q = prod[r.name] || (prod[r.name] = { name: r.name, units: 0, amt: 0 }); q.units += (r.qty || 1); q.amt += r.amt; var ck = r.cat || "General"; catAgg[ck] = (catAgg[ck] || 0) + r.amt;
          break;
        }
      }
    });
    var maxAmt = Math.max.apply(null, series.map(function (s) { return s.amt; }).concat([1]));
    var delta = prev > 0 ? Math.round((cur - prev) / prev * 100) : null;
    var top = Object.keys(prod).map(function (k) { return prod[k]; }).sort(function (a, b) { return b.amt - a.amt; }).slice(0, 6);
    var topMax = top.length ? top[0].amt : 1;
    var stock = cat.slice().sort(function (a, b) { return a.stock - b.stock; });
    var stockMax = Math.max.apply(null, cat.map(function (c) { return c.stock; }).concat([1]));
    var lowCount = cat.filter(function (c) { return c.stock <= 5; }).length;
    var W = 320, H = 110, bw = W / count;
    var todayName = new Date().toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long" });
    
    var __v = { pp: pp, _m: _m, mode: mode, setMode: setMode, cat: cat, money: money, rows: rows, demo: demo, seed: seed, rnd: rnd, d: d, n: n, k: k, p: p, dt: dt, DAY: DAY, i: i, now: now, addD: addD, wkStart: wkStart, DN: DN, MN: MN, starts: starts, ends: ends, labels: labels, prevStart: prevStart, prevEnd: prevEnd, yr: yr, ws: ws, count: count, nowT: nowT, series: series, catAgg: catAgg, cur: cur, curN: curN, prev: prev, prod: prod, maxAmt: maxAmt, delta: delta, top: top, topMax: topMax, stock: stock, stockMax: stockMax, lowCount: lowCount, W: W, H: H, bw: bw, todayName: todayName };
    return h(DashCtx.Provider, { value: __v }, h("div", { className: "dx" },
      h(Slot, { name: "seller.dashboard" })
    ));
  }

  /* ---- Catalogue tab ---- */
  function ProductForm(props) {
    var init = props.initial || { name: "", price: "", category: "", stock: "", image: "" };
    var _s = PR.useState(init), f = _s[0], setF = _s[1];
    var fileRef = PR.useRef(null);
    function set(k, v) { var n = {}; n[k] = v; setF(Object.assign({}, f, n)); }
    return h("div", { className: "tp-card", style: { padding: 13 } },
      h("div", { className: "tp-section-title" }, props.title),
      h("div", { className: "sp-img-up" },
        h("div", { className: "sp-img-prev", onClick: function () { fileRef.current && fileRef.current.click(); } }, f.image ? h("img", { src: f.image, alt: "", style: { width: "100%", height: "100%", objectFit: "cover" } }) : h("span", null, "\uD83D\uDCF7", h("br"), "Upload photo")),
        h("div", { style: { flex: 1 } },
          h("input", { ref: fileRef, type: "file", accept: "image/*", style: { display: "none" }, onChange: function (e) { var file = e.target.files && e.target.files[0]; if (file) readImage(file, function (d) { set("image", d); }); e.target.value = ""; } }),
          h("button", { className: "sp-edit-btn on", onClick: function () { fileRef.current && fileRef.current.click(); } }, f.image ? "Change image" : "Upload image"),
          f.image && h("button", { className: "sp-edit-btn", style: { marginLeft: 8 }, onClick: function () { set("image", ""); } }, "Remove image"),
          h("div", { className: "tp-section-body", style: { marginTop: 6 } }, "JPG or PNG. Shown to buyers on your catalogue."))
      ),
      h("label", { className: "plc-field", style: { display: "block", marginBottom: 10 } }, h("span", { className: "plc-label" }, "Product name"), h("input", { className: "plc-input", value: f.name, onChange: function (e) { set("name", e.target.value); }, placeholder: "e.g. Samsung Galaxy A15" })),
      h("div", { className: "sp-two" },
        h("label", { className: "plc-field" }, h("span", { className: "plc-label" }, "Price (KSh)"), h("input", { className: "plc-input", type: "number", min: 1, value: f.price, onChange: function (e) { set("price", e.target.value); } })),
        h("label", { className: "plc-field" }, h("span", { className: "plc-label" }, "Stock"), h("input", { className: "plc-input", type: "number", min: 0, value: f.stock, onChange: function (e) { set("stock", e.target.value); } }))
      ),
      h("label", { className: "plc-field", style: { display: "block", margin: "10px 0" } }, h("span", { className: "plc-label" }, "Category"), h("input", { className: "plc-input", value: f.category, onChange: function (e) { set("category", e.target.value); }, placeholder: "e.g. Phones" })),
      h("div", { className: "sp-edit-actions" },
        h("button", { className: "sp-edit-btn on", onClick: function () { props.onSubmit(f); } }, props.submitLabel),
        h("button", { className: "sp-edit-btn", onClick: props.onCancel }, "Cancel"))
    );
  }
  function SellerCatalogueTab() {
    var pp = usePlugPay();
    var _m = PR.useState(null), mode = _m[0], setMode = _m[1];
    var _f = PR.useState("All"), filter = _f[0], setFilter = _f[1];
    var items = pp.catalogueItems;
    var cats = ["All"].concat(Array.from(new Set(items.map(function (i) { return i.category; }))));
    var shown = filter === "All" ? items : items.filter(function (i) { return i.category === filter; });
    var editing = mode && mode !== "new" ? items.filter(function (i) { return i.id === mode; })[0] : null;
    return h("div", { style: { padding: 12 } },
      h("div", { className: "cat-merchant-bar" },
        h("button", { className: "cat-mb-btn cat-mb-primary", onClick: function () { setMode(mode === "new" ? null : "new"); } }, "\uFF0B Add Product"),
        h("span", { className: "cat-mb-btn", style: { textAlign: "center", cursor: "default" } }, items.length + " product" + (items.length === 1 ? "" : "s"))
      ),
      mode === "new" && h(ProductForm, { key: "new", title: "Add product", submitLabel: "Add product", onCancel: function () { setMode(null); }, onSubmit: function (f) { if (pp.addCatalogueItem(f)) setMode(null); } }),
      editing && h(ProductForm, { key: editing.id, title: "Edit product", submitLabel: "Save changes", initial: { name: editing.name, price: editing.price, category: editing.category, stock: String(editing.stock), image: editing.image }, onCancel: function () { setMode(null); }, onSubmit: function (f) {
        if (!f.name.trim() || !f.price) { pp.showToast("Enter a product name and price"); return; }
        pp.updateCatalogueItem(editing.id, { name: f.name.trim(), price: String(f.price), category: f.category.trim() || "General", stock: Number(f.stock) || 0, image: f.image });
        pp.showToast("Product updated \u2713"); setMode(null);
      } }),
      h("div", { className: "cat-filters" }, cats.map(function (c) {
        var n = c === "All" ? items.length : items.filter(function (i) { return i.category === c; }).length;
        return h("button", { key: c, className: "cat-filter" + (filter === c ? " on" : ""), onClick: function () { setFilter(c); } }, c + " (" + n + ")");
      })),
      shown.length === 0 && h(EmptyState, { icon: "package", title: filter === "All" ? "No products yet" : "Nothing in " + filter, sub: "Products you add here autofill your invoices and receipts, and feed your sales analytics.", action: mode === "new" ? null : { label: "Add product", onClick: function () { setMode("new"); } } }),
      h("div", { className: "cat-grid" }, shown.map(function (p) {
        return h("div", { key: p.id, className: "cat-item", style: { cursor: "default" } },
          h("div", { className: "cat-img" }, p.image ? h("img", { src: p.image, alt: p.name, style: { width: "100%", height: "100%", objectFit: "cover" } }) : p.icon),
          h("div", { className: "cat-body" },
            h("div", { className: "cat-name" }, p.name),
            h("div", { className: "cat-price" }, "KSh " + Number(p.price).toLocaleString()),
            h("div", { className: "cat-stock" }, (p.stock > 0 ? p.stock + " in stock" : "Out of stock") + " \u00b7 " + p.category),
            h("button", { className: "cat-sale-btn", disabled: p.stock <= 0, onClick: function () { pp.startSaleFromProduct(p); navigate("/seller/receipts/new"); } }, Ic("shopping-cart", 15), p.stock > 0 ? "Record sale" : "Out of stock"),
            h("div", { className: "catalogue-action-row", style: { marginTop: 8 } },
              h("button", { className: "sp-edit-btn", onClick: function () { setMode(p.id); window.scrollTo({ top: 0, behavior: "smooth" }); } }, "\u270F\uFE0F Edit"),
              h("button", { className: "sp-edit-btn danger", onClick: function () { pp.removeCatalogueItem(p.id); if (mode === p.id) setMode(null); } }, "Remove")))
        );
      }))
    );
  }

  /* ---- Profile tab ---- */
  var docFields = [
    { key: "idfront", name: "ID Front", icon: "\u{1FAAA}" },
    { key: "idback", name: "ID Back", icon: "\u{1FAAA}" },
    { key: "selfie", name: "Selfie", icon: "\u{1F933}" },
    { key: "biz", name: "Business License", icon: "\u{1F4C4}" },
    { key: "kra", name: "KRA PIN Certificate", icon: "\u{1F9FE}" }
  ];
  var emptyRiderRow = (id) => ({ id, name: "", phone: "", role: "Boda rider" });
  function StallRow() {
    var pp = usePlugPay();
    var cur = pp.stallAssignment;
    var BLD = ["Anniversary Towers", "Lonrho House", "Kencom House", "Odeon Cinema Bldg", "Other"];
    var _e = PR.useState(false), editing = _e[0], setEditing = _e[1];
    var _b = PR.useState(cur.building), b = _b[0], setB = _b[1];
    var _o = PR.useState(""), other = _o[0], setOther = _o[1];
    var _l = PR.useState(cur.loc), loc = _l[0], setLoc = _l[1];
    function start() { var known = BLD.indexOf(cur.building) > -1; setB(known ? cur.building : "Other"); setOther(known ? "" : cur.building); setLoc(cur.loc); setEditing(true); }
    function save() {
      var name = b === "Other" ? other.trim() : b;
      if (!name || !loc.trim()) { pp.showToast("Enter the building and stall"); return; }
      pp.changeStall(name, loc.trim());
      setEditing(false); pp.showToast("Stall / building updated \u2713");
    }
    return h("div", { className: "tp-info-row", style: { border: "none" } },
      h("div", { className: "tp-info-ico", style: { background: "#e3f2fd" } }, h("span", null, "\uD83C\uDFE2")),
      h("div", { className: "tp-info-text", style: { flex: 1, minWidth: 0 } },
        h("div", { className: "tp-info-label" }, "STALL / BUILDING"),
        editing
          ? h("div", null,
              h("select", { className: "plc-input", style: { marginTop: 6 }, value: b, onChange: function (e) { setB(e.target.value); } }, BLD.map(function (o) { return h("option", { key: o, value: o }, o); })),
              b === "Other" && h("input", { className: "plc-input", style: { marginTop: 6 }, placeholder: "Building name", value: other, onChange: function (e) { setOther(e.target.value); } }),
              h("input", { className: "plc-input", style: { marginTop: 6 }, placeholder: "Floor & stall (e.g. Floor 3, Stall 14)", value: loc, onChange: function (e) { setLoc(e.target.value); } }),
              h("div", { className: "sp-edit-actions" }, h("button", { className: "sp-edit-btn on", onClick: save }, "Save"), h("button", { className: "sp-edit-btn", onClick: function () { setEditing(false); } }, "Cancel")))
          : h("div", { className: "tp-info-val" }, cur.building + ", " + cur.loc)),
      !editing && h("button", { className: "sp-edit-btn", onClick: start }, "\u270F\uFE0F Edit"));
  }
  function useSellerProfileForm() {
    var pp = usePlugPay();
    var sp = pp.sellerProfile;
    var S = function (k) { return function (v) { var n = {}; n[k] = v; pp.updateSellerProfile(n); }; };
    var pm = sp.payMethod || "Paybill";
    var PMETHODS = ["Paybill", "Till number", "Send money", "Bank transfer"];
    var noAcct = pm === "Till number" || pm === "Send money";
    var YEARS = (function () { var a = [], y = new Date().getFullYear(); for (; y >= 1970; y--) a.push(String(y)); return a; })();
    return { pp: pp, sp: sp, S: S, pm: pm, PMETHODS: PMETHODS, noAcct: noAcct, YEARS: YEARS };
  }
  function SellerProfileHero() {
    var f = useSellerProfileForm(), pp = f.pp, sp = f.sp, S = f.S, pm = f.pm, PMETHODS = f.PMETHODS, noAcct = f.noAcct, YEARS = f.YEARS;
    return h(SellerHero, { editable: true });
  }
  function SellerProfileReviews() {
    var f = useSellerProfileForm(), pp = f.pp, sp = f.sp, S = f.S, pm = f.pm, PMETHODS = f.PMETHODS, noAcct = f.noAcct, YEARS = f.YEARS;
    return h(SellerReviewsCard, null);
  }
  function SellerProfileContact() {
    var f = useSellerProfileForm(), pp = f.pp, sp = f.sp, S = f.S, pm = f.pm, PMETHODS = f.PMETHODS, noAcct = f.noAcct, YEARS = f.YEARS;
    return h("div", { className: "tp-card tp-info-card" },
        h(EditRow, { icon: "\uD83D\uDCCD", bg: "#fff8e1", label: "LOCATION", value: sp.street, onSave: S("street"), required: true }),
        h(EditRow, { icon: "\uD83D\uDCDE", bg: "#f8f1f7", label: "PHONE", value: sp.phone, onSave: S("phone"), required: true, inputType: "tel" }),
        h(EditRow, { icon: "\uD83D\uDCC5", bg: "#ede7f6", label: "YEAR IN BUSINESS", value: sp.established, editValue: String(parseInt(sp.established, 10) || ""), options: YEARS, required: true, onSave: function (v) { var y = parseInt(v, 10), n = new Date().getFullYear() - y; pp.updateSellerProfile({ established: y + " \u00b7 " + (n <= 0 ? "Started this year" : n + (n === 1 ? " year" : " years") + " in business") }); } }),
        h(StallRow, null)
      );
  }
  function SellerProfileSocial() {
    var f = useSellerProfileForm(), pp = f.pp, sp = f.sp, S = f.S, pm = f.pm, PMETHODS = f.PMETHODS, noAcct = f.noAcct, YEARS = f.YEARS;
    return h("div", { className: "tp-card tp-info-card" },
        h("div", { className: "tp-section-title", style: { padding: "13px 13px 0" } }, "Social Media"),
        h(EditRow, { icon: "\uD83D\uDCAC", bg: "#25D36622", label: "WHATSAPP NUMBER", value: sp.whatsapp, onSave: S("whatsapp"), inputType: "tel" }),
        h(EditRow, { icon: "\uD83D\uDCF7", bg: "#fde7f3", label: "INSTAGRAM", value: sp.instagram, onSave: S("instagram") }),
        h(EditRow, { icon: "\uD83C\uDFB5", bg: "#00000014", label: "TIKTOK", value: sp.tiktok, onSave: S("tiktok") }),
        h(EditRow, { icon: "f", bg: "#1877F222", label: "FACEBOOK", value: sp.facebook, onSave: S("facebook"), last: true })
      );
  }
  function SellerProfilePayment() {
    var f = useSellerProfileForm(), pp = f.pp, sp = f.sp, S = f.S, pm = f.pm, PMETHODS = f.PMETHODS, noAcct = f.noAcct, YEARS = f.YEARS;
    return h("div", { className: "tp-card tp-info-card" },
        h("div", { className: "tp-pay-info-header", style: { padding: "13px 13px 0" } }, h("div", { className: "tp-pay-info-title" }, h("span", { className: "tp-pay-info-icon" }, "\uD83D\uDCB3"), " Payment Information"), h("div", { className: "tp-pay-info-badge" }, "M-Pesa")),
        h(EditRow, { icon: "\uD83D\uDCB1", bg: "#e8f5e9", label: "PAYMENT METHOD", value: pm, options: PMETHODS, required: true, onSave: S("payMethod") }),
        h(EditRow, { icon: "\uD83C\uDFE6", bg: "#f8f1f7", label: pm === "Till number" ? "TILL NUMBER" : pm === "Send money" ? "M-PESA PHONE" : pm === "Bank transfer" ? "BANK ACCOUNT NUMBER" : "PAYBILL NUMBER", value: sp.paybill, onSave: S("paybill"), required: true, last: noAcct }),
        !noAcct && h(EditRow, { icon: "\uD83D\uDD22", bg: "#e3f2fd", label: pm === "Bank transfer" ? "ACCOUNT NAME" : "ACCOUNT NUMBER", value: sp.account, onSave: S("account"), required: true, last: true }),
        h(SellerPaymentOptions, null)
      );
  }
  function SellerProfileAbout() {
    var f = useSellerProfileForm(), pp = f.pp, sp = f.sp, S = f.S, pm = f.pm, PMETHODS = f.PMETHODS, noAcct = f.noAcct, YEARS = f.YEARS;
    return h("div", { className: "tp-card tp-info-card" },
        h(EditRow, { label: "ABOUT THE BUSINESS", value: sp.about, onSave: S("about"), multiline: true, last: true })
      );
  }
  function SellerProfileCompliance() {
    var f = useSellerProfileForm(), pp = f.pp, sp = f.sp, S = f.S, pm = f.pm, PMETHODS = f.PMETHODS, noAcct = f.noAcct, YEARS = f.YEARS;
    return h("div", { className: "tp-card", style: { padding: 13 } },
        h("div", { className: "tp-section-title" }, "Compliance Documents"),
        h("div", { className: "tp-section-body", style: { marginBottom: 10 } }, "Kept on file for your own records \u2014 your landlord doesn\u2019t review these. Your Landlord Verified badge comes from your landlord confirming you occupy your stall."),
        docFields.map(function (d, i) {
          var st = pp.docStatus[d.key];
          return h("div", { key: d.key, className: "sp-doc-row" },
            h("div", { style: { flex: 1 } }, h("div", { className: "tp-doc-label" }, (d.icon || "") + " " + d.name), h("div", { className: "tp-doc-badge", style: { marginTop: 4 } }, st === "done" ? "\u2713 Uploaded" : st === "uploading" ? "Uploading\u2026" : "Not uploaded")),
            h("button", { className: "sp-edit-btn", onClick: function () { pp.fakeUpload(d.key, d.name); } }, st === "done" ? "Replace" : "Upload"));
        })
      );
  }
  function SellerProfileRiders() {
    var f = useSellerProfileForm(), pp = f.pp, sp = f.sp, S = f.S, pm = f.pm, PMETHODS = f.PMETHODS, noAcct = f.noAcct, YEARS = f.YEARS;
    return h("div", { className: "tp-card", style: { padding: 13 } },
        h("div", { className: "tp-section-title" }, "Trusted Riders & Errand People"),
        h("div", { className: "tp-section-body", style: { marginBottom: 10 } }, "People you've personally worked with and vouch for."),
        h("div", { className: "vouch-list" },
          [["Brian Otieno", "Boda rider", "\uD83C\uDFCD\uFE0F", "#185FA5"], ["Faith Nekesa", "Errand runner", "\uD83C\uDFC3", "#BA7517"]].map(function (r) {
            return h("div", { key: r[0], className: "vouch-item" }, h("div", { className: "vouch-av", style: { background: r[3] } }, r[2]), h("div", { className: "vouch-info" }, h("div", { className: "vouch-name" }, r[0]), h("div", { className: "vouch-sub" }, r[1] + " \u00b7 Added by you")), h("span", { className: "tp-info-label" }, "\u2713 Trusted"));
          }),
          pp.riders.map(function (r, i) {
            return h("div", { key: "n" + i, className: "vouch-item" }, h("div", { className: "vouch-av", style: { background: "#51104a" } }, r.role === "Errand runner" ? "\uD83C\uDFC3" : "\uD83C\uDFCD\uFE0F"), h("div", { className: "vouch-info" }, h("div", { className: "vouch-name" }, r.name), h("div", { className: "vouch-sub" }, r.role + " \u00b7 Added by you")), h("button", { className: "sp-edit-btn", onClick: function () { pp.removeRider(i); } }, "Remove"));
          })
        ),
        h("div", { className: "sp-lock-note", style: { marginTop: 12 } }, "Add a rider"),
        h("div", { className: "sp-rider-form" },
          h("input", { className: "plc-input", placeholder: "Name", value: pp.riderRows[0].name, onChange: function (e) { pp.updateRiderRow(pp.riderRows[0].id, { name: e.target.value }); } }),
          h("input", { className: "plc-input", placeholder: "Phone", value: pp.riderRows[0].phone, onChange: function (e) { pp.updateRiderRow(pp.riderRows[0].id, { phone: e.target.value }); } }),
          h("select", { className: "plc-input", value: pp.riderRows[0].role, onChange: function (e) { pp.updateRiderRow(pp.riderRows[0].id, { role: e.target.value }); } }, h("option", null, "Boda rider"), h("option", null, "Errand runner")),
          h("button", { className: "sp-edit-btn on", onClick: pp.saveTrustedRiders }, "+ Add")
        )
      );
  }
  function SellerProfileRelocate() {
    var f = useSellerProfileForm(), pp = f.pp, sp = f.sp, S = f.S, pm = f.pm, PMETHODS = f.PMETHODS, noAcct = f.noAcct, YEARS = f.YEARS;
    return h("div", { className: "tp-card", style: { padding: 13, marginBottom: 30 } },
        h("div", { className: "tp-section-title" }, "Relocate stall"),
        h("div", { className: "tp-section-body", style: { marginBottom: 10 } }, "Moving buildings? Submit the new stall for landlord verification."),
        h("div", { className: "sp-rider-form" },
          h("input", { className: "plc-input", placeholder: "New building", value: pp.vacateBuilding, onChange: function (e) { pp.setVacateBuilding(e.target.value); } }),
          h("input", { className: "plc-input", placeholder: "New stall (e.g. Floor 2, Stall 9)", value: pp.vacateStall, onChange: function (e) { pp.setVacateStall(e.target.value); } }),
          h("button", { className: "sp-edit-btn on", onClick: pp.confirmVacate }, "Submit"))
      );
  }
  function SellerProfileTab() { return h(Slot, { name: "seller.profile" }); }

  /* ---- Sales: record a sale, receipts, invoices ---- */
  var emptyItemRow = (id) => ({ id, name: "", price: "", productId: "", qty: 1, unit: "", category: "" });
  var REVIEW_WINDOW_MS = 6 * 60 * 60 * 1000;
  function receiptLink(c) { return appBase() + "#/r/" + encodeURIComponent(codeOf(c)); }
  function reviewLink(c) { return appBase() + "#/review/" + encodeURIComponent(codeOf(c)); }
  function invoiceLink(t) { return appBase() + "#/pay/" + encodeURIComponent(t); }
  function reviewStatus(r) {
    if (!r) return { state: "none", msLeft: 0 };
    if (r.review) return { state: "done", msLeft: 0 };
    if (!r.sentAt) return { state: "notsent", msLeft: 0 };
    var left = new Date(r.sentAt).getTime() + REVIEW_WINDOW_MS - Date.now();
    return left > 0 ? { state: "open", msLeft: left } : { state: "expired", msLeft: 0 };
  }
  function timeLeft(ms) {
    var m = Math.max(1, Math.ceil(ms / 60000)), hh = Math.floor(m / 60), mm = m % 60;
    return hh ? hh + "h " + mm + "m" : mm + "m";
  }
  function waReceiptText(r, seller) {
    return "Hi " + (r.buyerName || "there") + ", thanks for buying from " + seller + ". Here's your PlugPay receipt for KSh " + Number(r.total).toLocaleString() + ":\n" + receiptLink(r.code) + "\n\nHow did we do? Rate your purchase (one review per receipt, link open for 6 hours):\n" + reviewLink(r.code);
  }
  function waInvoiceText(inv, seller) {
    return "Hi " + (inv.buyerName || "there") + ", here's your PlugPay invoice from " + seller + " for KSh " + Number(inv.total).toLocaleString() + ":\n" + invoiceLink(inv.token);
  }
  function ppDemoSales() {
    var DAY = 86400000, now = Date.now();
    function ago(d, hrs) { return new Date(now - d * DAY - (hrs || 0) * 3600000).toISOString(); }
    function it(name, qty, unit) { return { name: name, qty: qty, unit: unit, price: qty * unit, productId: "", category: "" }; }
    function sum(items) { return items.reduce(function (t, i) { return t + i.price; }, 0); }
    function rc(code, ref, name, phone, items, days, status, sent) {
      return { code: code, demo: true, buyerName: name, buyerPhone: phone, paymentRef: ref, items: items, total: sum(items), createdAt: ago(days, 2), sentAt: sent ? ago(days, 1) : null, stockApplied: !!sent, review: null, docStatus: status };
    }
    function iv(num, name, phone, items, days, status) {
      return { token: num, number: num, demo: true, buyerName: name, buyerPhone: phone, source: "WhatsApp", items: items, total: sum(items), status: "PENDING", docStatus: status, createdAt: ago(days, 3) };
    }
    return {
      receipts: [
        rc("RCP-001", "TKA3F8M2QD", "Grace Wanjiku", "0712 345 601", [it("Samsung Galaxy A15", 1, 18500)], 1, "COMPLETE", true),
        rc("RCP-002", "TKA3F9L7ZX", "Brian Otieno", "0722 118 402", [it("Wireless Earbuds", 2, 2800), it("USB-C Charger 65W", 3, 1200)], 2, "COMPLETE", true),
        rc("RCP-003", "TKB1N4C6RW", "Faith Njeri", "0733 904 117", [it("Wireless Earbuds", 2, 2800), it("USB-C Charger 65W", 2, 1200), it("Phone screen replacement", 1, 6300)], 3, "COMPLETE", true),
        rc("RCP-004", "TKB2P7D9HS", "Samuel Kiptoo", "0745 660 230", [it("Wireless Earbuds", 2, 2800), it("Phone case", 2, 1000)], 4, "PENDING", false),
        rc("RCP-005", "TKB3Q5E1JV", "Mercy Akinyi", "0701 552 889", [it("USB-C Charger 65W", 5, 1200), it("Laptop bag", 1, 3500), it("Wireless mouse", 1, 2600)], 5, "PENDING", false)
      ],
      invoices: [
        iv("INV-001", "Daniel Mwangi", "0711 207 944", [it("Tecno Camon 20", 1, 22000), it("USB-C Charger 65W", 1, 1200), it("Phone case", 1, 1300)], 2, "COMPLETE"),
        iv("INV-002", "Esther Chebet", "0723 481 075", [it("Wireless Earbuds", 2, 2800), it("USB-C Charger 65W", 1, 1200), it("Power bank 10,000mAh", 1, 5000)], 3, "COMPLETE"),
        iv("INV-003", "Kevin Omondi", "0734 612 380", [it("SSD 256GB", 1, 6500), it("RAM 8GB DDR4", 1, 5200), it("Windows install & setup", 1, 3500), it("Laptop bag", 1, 3500)], 1, "PENDING"),
        iv("INV-004", "Lucy Wambui", "0768 190 523", [it("Wireless Earbuds", 2, 2800), it("Screen guard", 4, 1000)], 0, "PENDING")
      ]
    };
  }
  function ReceiptModal() {
    var pp = usePlugPay();
    var r = pp.receipt, isInv = r.kind === "invoice", sp = pp.sellerProfile;
    var closeStyle = { background: "rgba(255,255,255,.16)", color: "#fff", borderColor: "rgba(255,255,255,.65)" };
    function row(l, v, cls) { return h("div", { className: "rm-row" + (cls ? " " + cls : ""), key: l + v }, h("span", { className: "rm-lbl" }, l), h("span", { className: "rm-val" }, v)); }
    return h(Modal, { id: "modal-receipt", innerClassName: "receipt-modal", closeButtonStyle: closeStyle, onExit: pp.focusMerchantProfileTab },
      h("div", { className: "rm-top" },
        h("div", { className: "rm-icon" }, isInv ? "\uD83D\uDCC4" : "\uD83E\uDDFE"),
        h("div", { className: "rm-title" }, isInv ? "Invoice sent!" : "Receipt sent!"),
        h("div", { className: "rm-sub" }, isInv ? "Payment link delivered \u00b7 add the M-Pesa code once it's paid" : "Sale recorded \u00b7 Review link attached \u00b7 Stock updated")),
      h("div", { className: "rm-body" },
        h("div", { className: "rm-rows" },
          row("Seller", sp.bizName + " \u00b7 " + pp.stallAssignment.loc),
          row(isInv ? "Invoice" : "Receipt #", isInv ? "#" + String(r.code).toUpperCase() : r.code),
          row("Buyer", (r.name ? r.name + " \u00b7 " : "") + r.phone),
          r.items.map(function (it, i) { return h("div", { className: "rm-row item-row", key: i }, h("span", { className: "rm-lbl" }, it.name + (it.qty > 1 ? " \u00d7 " + it.qty : "")), h("span", { className: "rm-val" }, "KSh " + Number(it.price).toLocaleString())); }),
          row("Total", "KSh " + Number(r.total).toLocaleString(), "total")),
        h("div", { className: "rm-verified" },
          h("span", { style: { fontSize: "18px" } }, "\u2713"),
          h("div", null,
            h("div", { className: "rm-verified-text" }, "Sent to the buyer's WhatsApp"),
            h("div", { className: "rm-verified-text", style: { opacity: ".6", fontSize: "10px" } }, isInv ? "Not counted as a sale until it is paid and a receipt is sent" : "Review link is open for 6 hours \u00b7 one review per receipt"))),
        h("div", { className: "rm-actions" },
          h("button", { className: "rm-btn rmb-primary", onClick: function () { if (isInv) pp.resendInvoice(r.code); else pp.sendReceipt(r.code); } }, isInv ? "Resend on WhatsApp" : "Resend with review link"),
          h(ReceiptOpenButton, { isInv: isInv, code: r.code }),
          h(ReceiptDoneButton, null))));
  }
  function ReceiptOpenButton(props) {
    var pp = usePlugPay();
    return h("button", { className: "rm-btn rmb-secondary", onClick: function () { pp.closeModal("modal-receipt"); window.location.hash = props.isInv ? "#/seller/invoices" : "#/seller/receipts/" + encodeURIComponent(props.code); } }, props.isInv ? "View invoice" : "Open receipt");
  }
  function ReceiptDoneButton() {
    var pp = usePlugPay();
    return h("button", { className: "rm-btn rmb-secondary", onClick: function () { pp.closeModal("modal-receipt"); pp.focusMerchantProfileTab(); } }, "Done");
  }
  function RecordSaleModal() {
    const { rsName, setRsName, rsPhone, setRsPhone, rsCode, setRsCode, rsTotal, rsSubmitting, submitRecordSale, focusMerchantProfileTab, sellerProfile } = usePlugPay();
    const hasCode = rsCode.trim().length > 0;
    return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(
      Modal,
      {
        id: "modal-record-sale",
        innerClassName: "plc-modal",
        closeButtonStyle: { background: "rgba(255,255,255,.22)", color: "#fff", borderColor: "rgba(255,255,255,.65)" },
        onExit: focusMerchantProfileTab,
        children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "plc-head", style: { background: "#8b008b" }, children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "plc-title", children: "Record a sale" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "plc-sub", children: ["For ", sellerProfile.bizName, " \xB7 Add the M-Pesa code once it's paid to send a receipt, or leave it blank to send a payment-link invoice."] })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "plc-body", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "plc-field", children: [
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { className: "plc-label", children: "Buyer Name" }),
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
                "input",
                {
                  className: "plc-input",
                  type: "text",
                  placeholder: "e.g. John Kamau",
                  value: rsName,
                  onChange: (e) => setRsName(e.target.value)
                }
              )
            ] }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "plc-field", children: [
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { className: "plc-label", children: "Buyer Phone" }),
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
                "input",
                {
                  className: "plc-input",
                  type: "tel",
                  placeholder: "07XX XXX XXX",
                  value: rsPhone,
                  onChange: (e) => setRsPhone(e.target.value)
                }
              )
            ] }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemRowsField, { prefix: "rs" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "plc-total-row", children: [
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Total" }),
              /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
                "KSh ",
                rsTotal.toLocaleString()
              ] })
            ] }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "plc-field", children: [
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { className: "plc-label", children: "M-Pesa Transaction Code (optional)" }),
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
                "input",
                {
                  className: "plc-input",
                  type: "text",
                  style: { textTransform: "uppercase" },
                  placeholder: "e.g. SJK7H92LQA \u2014 leave blank to send an invoice instead",
                  value: rsCode,
                  onChange: (e) => setRsCode(e.target.value)
                }
              ),
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "icf-hint", style: { marginTop: 6, marginBottom: 0 }, children: hasCode ? "This will be recorded as a completed sale and a receipt will be sent." : "No code yet? This will send a payment-link invoice instead \u2014 add the code later to turn it into a receipt." })
            ] }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { className: "plc-submit", onClick: () => submitRecordSale(), disabled: rsSubmitting, children: rsSubmitting ? "Sending\u2026" : hasCode ? "Record sale & send receipt \u2192" : "Send invoice via WhatsApp \u2192" })
          ] })
        ]
      }
    );
  }
  function ItemRowsField(props) {
    var prefix = props.prefix, pp = usePlugPay();
    var items = pp.rsItems, cat = pp.catalogueItems, isReceipt = true;
    var listId = "cat-names-" + prefix;
    function patch(row, p) { pp.updateItemRow(prefix, row.id, p); }
    function fromProduct(row, p, qty) {
      patch(row, { productId: p.id, name: p.name, unit: String(p.price), qty: qty, price: String(Number(p.price) * qty), category: p.category });
    }
    function pick(row, id) {
      if (!id) { patch(row, { productId: "", category: "" }); return; }
      var p = cat.filter(function (x) { return x.id === id; })[0];
      if (p) fromProduct(row, p, Math.max(1, Number(row.qty) || 1));
    }
    function setName(row, v) {
      var m = cat.filter(function (x) { return x.name.toLowerCase() === v.trim().toLowerCase(); })[0];
      if (m) { fromProduct(row, m, Math.max(1, Number(row.qty) || 1)); return; }
      var linked = row.productId && cat.filter(function (x) { return x.id === row.productId && x.name === v; })[0];
      patch(row, { name: v, productId: linked ? row.productId : "", category: linked ? row.category : "" });
    }
    function setQty(row, v) { var q = Math.max(1, parseInt(v, 10) || 1); var u = Number(row.unit) || 0; patch(row, { qty: q, price: u ? String(u * q) : row.price }); }
    function setUnit(row, v) { var q = Number(row.qty) || 1; patch(row, { unit: v, price: v === "" ? "" : String((Number(v) || 0) * q) }); }
    return h("div", { className: "plc-field" },
      h("label", { className: "plc-label" }, "Products / Services"),
      cat.length === 0
        ? h("div", { className: "icf-hint" }, Ic("package"), h("span", null, "Your catalogue is empty. ", h(Link, { to: "/seller/catalogue" }, "Add products"), " to autofill items here."))
        : h("div", { className: "icf-hint" }, Ic("zap"), h("span", null, "Pick a product from your catalogue to autofill the name and price. This also keeps your sales analytics and stock accurate.")),
      h("datalist", { id: listId }, cat.map(function (c) { return h("option", { key: c.id, value: c.name }); })),
      items.map(function (row) {
        var p = row.productId ? cat.filter(function (x) { return x.id === row.productId; })[0] : null;
        var over = isReceipt && p && (Number(row.qty) || 1) > p.stock;
        var line = Number(row.price) || 0;
        return h("div", { key: row.id, className: "icf-row" + (p ? " linked" : "") },
          h("select", { className: "plc-input", value: row.productId || "", onChange: function (e) { pick(row, e.target.value); }, "aria-label": "Catalogue product" },
            h("option", { value: "" }, cat.length ? "Custom item (type below)" : "No catalogue products"),
            cat.map(function (c) { return h("option", { key: c.id, value: c.id, disabled: isReceipt && c.stock <= 0 }, c.name + " \u2014 KSh " + Number(c.price).toLocaleString() + (c.stock <= 0 ? " (out of stock)" : " (" + c.stock + " in stock)")); })),
          h("div", { className: "icf-line" },
            h("input", { className: "plc-input icf-name", type: "text", list: listId, placeholder: "Item name", value: row.name, onChange: function (e) { setName(row, e.target.value); } }),
            h("input", { className: "plc-input icf-qty", type: "number", min: 1, step: 1, title: "Quantity", "aria-label": "Quantity", value: row.qty == null ? 1 : row.qty, onChange: function (e) { setQty(row, e.target.value); } }),
            h("input", { className: "plc-input icf-unit", type: "number", min: 1, placeholder: "Unit KSh", title: "Unit price", "aria-label": "Unit price", value: row.unit == null ? "" : row.unit, onChange: function (e) { setUnit(row, e.target.value); } }),
            h("div", { className: "icf-total" }, "KSh " + line.toLocaleString()),
            h("button", { type: "button", className: "plc-item-remove", onClick: function () { pp.removeItemRow(prefix, row.id); }, title: "Remove item", "aria-label": "Remove item", style: { visibility: items.length > 1 ? "visible" : "hidden" } }, "\u2715")),
          p && !over && h("div", { className: "icf-tag" }, Ic("link", 12), "Linked to catalogue \u00b7 " + p.category + " \u00b7 " + p.stock + " in stock"),
          over && h("div", { className: "field-err" }, Ic("triangle-alert", 13), "Only " + p.stock + " in stock. Reduce the quantity."));
      }),
      h("button", { type: "button", className: "plc-add-item", onClick: function () { pp.addItemRow(prefix); } }, "\uFF0B Add another item"));
  }
  function sellerBadgeInfo(pp) {
    return { plugpay: true, landlord: !!pp.sellerProfile.llPhoneVerified };
  }
  function waDigits(phone) {
    var d = (phone || "").replace(/\D/g, "");
    if (!d) return "";
    if (d.charAt(0) === "0") return "254" + d.slice(1);
    if (d.length === 9) return "254" + d;
    return d;
  }
  function openWhatsApp(phone, text) {
    var url = "https://wa.me/" + waDigits(phone) + "?text=" + encodeURIComponent(text);
    try { window.open(url, "_blank", "noopener"); } catch (e) {}
  }
  function DocBadges(props) {
    var b = props.badges;
    return h("div", null,
      h("div", { className: "doc-badges" },
        b.plugpay && h("span", { className: "doc-badge on", title: "This seller verified their phone number with PlugPay." }, Ic("badge-check", 12), "PlugPay Verified"),
        b.landlord
          ? h("span", { className: "doc-badge on", title: "The building's landlord confirmed this seller's phone number and profile match the real stall owner." }, Ic("building-2", 12), "Verified")
          : h("span", { className: "doc-badge pending", title: "The landlord hasn't yet confirmed this seller's phone number and profile match the real stall owner." }, Ic("building-2", 12), "Pending")));
  }
  function DocTrader(props) {
    var sp = props.sp;
    return h("div", { className: "doc-trader" },
      h("div", { className: "doc-trader-av" }, initials(sp.bizName || "P")),
      h("div", null,
        h("div", { className: "doc-trader-name" }, sp.bizName),
        h("div", { className: "doc-trader-meta" },
          h("span", null, sp.role || "Seller"),
          sp.street && h("span", null, "\u00b7 " + sp.street),
          sp.phone && h("span", null, "\u00b7 " + sp.phone))));
  }
  function DocPayInfo(props) {
    var sp = props.sp;
    var pm = sp.payMethod || "Paybill";
    var noAcct = pm === "Till number" || pm === "Send money";
    var numLabel = pm === "Till number" ? "Till number" : pm === "Send money" ? "M-Pesa phone" : pm === "Bank transfer" ? "Bank account number" : "Paybill number";
    var acctLabel = pm === "Bank transfer" ? "Account name" : "Account number";
    return h("div", { className: "doc-sec" },
      h("div", { className: "doc-sec-h" }, Ic("credit-card", 13), "Payment information"),
      h("div", { className: "doc-pay-box" },
        h("div", { className: "doc-row" }, h("span", null, "Pay via"), h("strong", null, pm)),
        h("div", { className: "doc-row" }, h("span", null, numLabel), h("strong", null, sp.paybill || "\u2014")),
        !noAcct && h("div", { className: "doc-row" }, h("span", null, acctLabel), h("strong", null, sp.account || "\u2014"))));
  }
  function DocItems(props) {
    return h("div", { className: "doc-sec" },
      h("div", { className: "doc-sec-h" }, Ic("package", 13), "Products sold"),
      props.items.map(function (it, i) {
        var unit = it.unit || (it.qty ? it.price / it.qty : it.price);
        return h("div", { className: "doc-item", key: i },
          h("div", null, h("div", { className: "doc-item-name" }, it.name), (it.qty > 1) && h("div", { className: "doc-item-sub" }, it.qty + " \u00d7 KSh " + Number(unit).toLocaleString())),
          h("div", { className: "doc-item-amt" }, "KSh " + Number(it.price).toLocaleString()));
      }));
  }
  function ReviewChip(props) {
    var st = reviewStatus(props.r);
    if (st.state === "done") return h("span", { className: "rv-chip done" }, "\u2605 " + props.r.review.rating + " reviewed");
    if (st.state === "open") return h("span", { className: "rv-chip open" }, "Review open \u00b7 " + timeLeft(st.msLeft) + " left");
    if (st.state === "expired") return h("span", { className: "rv-chip exp" }, "Review window closed");
    return h("span", { className: "rv-chip wait" }, "Not sent yet");
  }
  function salesDocStatus(kind, d) {
    if (kind === "invoice") return d.status === "PAID" ? "COMPLETE" : (d.docStatus || "PENDING");
    return d.docStatus || "COMPLETE";
  }
  function InvoiceConvertBox(props) {
    var pp = props.pp, d = props.doc;
    var _c = PR.useState(""), code = _c[0], setCode = _c[1];
    var _b = PR.useState(false), busy = _b[0], setBusy = _b[1];
    return h("div", { className: "sales-code-box" },
      h("div", { className: "sales-code-label" }, "Add transaction code or paste the M-Pesa message to turn this invoice into a receipt"),
      h("textarea", { className: "plc-input", rows: 3, placeholder: "e.g. QGH7XYZ123 or the full M-Pesa message", value: code, onChange: function (e) { setCode(e.target.value); } }),
      h("button", { type: "button", className: "sp-edit-btn on", disabled: busy || !code.trim(), onClick: function () {
        setBusy(true);
        setTimeout(function () {
          setBusy(false);
          var rc = pp.convertInvoiceToReceipt(d.token, code);
          if (rc) { setCode(""); navigate("/seller/receipts/" + encodeURIComponent(rc)); }
        }, 400);
      } }, busy ? "Checking\u2026" : "Make receipt"));
  }
  function SalesDocCard(props) {
    var pp = props.pp, kind = props.kind, d = props.doc;
    var _o = PR.useState(false), open = _o[0], setOpen = _o[1];
    var isInvoice = kind === "invoice";
    var id = isInvoice ? d.token : d.code;
    var paid = isInvoice && d.status === "PAID";
    var status = salesDocStatus(kind, d);
    var complete = status === "COMPLETE";
    var receiptLink = isInvoice ? (paid && d.paymentRef ? "/seller/receipts/" + encodeURIComponent("#" + d.paymentRef) : null) : "/seller/receipts/" + encodeURIComponent(d.code);
    var fullLink = isInvoice ? "/seller/invoices/" + encodeURIComponent(id) : "/seller/receipts/" + encodeURIComponent(d.code);
    var items = d.items || [];
    return h("div", { className: "sales-doc" },
      h("div", { className: "sales-doc-head" },
        h("div", { className: "sales-doc-main" },
          h("strong", null, isInvoice ? "Invoice " + (d.number ? d.number + " " : "") + "\u00b7 " + (d.buyerName || "Buyer") : "Receipt " + d.code),
          h("div", { className: "sales-doc-sub" }, (isInvoice ? "" : (d.buyerName || "Buyer") + " \u00b7 ") + (d.buyerPhone || "") + " \u00b7 " + new Date(d.createdAt).toLocaleString()),
          !isInvoice && h("div", { style: { marginTop: 6 } }, h(ReviewChip, { r: d }))),
        h("div", { className: "sales-doc-right" },
          h("strong", null, "KSh " + Number(d.total || 0).toLocaleString()),
          h("span", { className: "sales-pill " + (complete ? "complete" : "pending") }, complete ? "COMPLETE" : "PENDING"))),
      h("div", { className: "sales-doc-actions" },
        h(Link, { to: fullLink, className: "sp-edit-btn on" }, "View full doc"),
        h("button", { type: "button", className: "sp-edit-btn", onClick: function () { setOpen(!open); } }, open ? "Hide" : "Quick view"),
        !paid && h("button", { type: "button", className: "sp-edit-btn", onClick: function () { pp.setDocumentStatus(kind, id, complete ? "PENDING" : "COMPLETE"); } }, complete ? "Mark pending" : "Mark complete"),
        !isInvoice && !d.sentAt && h("button", { type: "button", className: "sp-edit-btn", onClick: function () { pp.sendReceipt(d.code); } }, "Send receipt"),
        isInvoice && !paid && h("button", { type: "button", className: "sp-edit-btn", onClick: function () { pp.resendInvoice(d.token); } }, "Resend")),
      open && h("div", { className: "sales-doc-panel" },
        h("div", { className: "sales-doc-items" },
          items.map(function (it, i) {
            return h("div", { key: i, className: "sales-doc-item" }, h("span", null, it.name + " \u00d7 " + (it.qty || 1)), h("strong", null, "KSh " + Number(it.price || 0).toLocaleString()));
          }),
          h("div", { className: "sales-doc-item total" }, h("span", null, "Total"), h("strong", null, "KSh " + Number(d.total || 0).toLocaleString()))),
        d.paymentRef && h("div", { className: "sales-doc-sub", style: { marginTop: 8 } }, "M-Pesa code: " + d.paymentRef),
        d.mpesaMessage && h("div", { className: "sales-doc-msg" }, d.mpesaMessage),
        h("div", { className: "sales-doc-actions", style: { marginTop: 10 } },
          isInvoice && receiptLink && h(Link, { to: receiptLink, className: "sp-edit-btn on" }, "Open receipt"),
          isInvoice && h(Link, { to: "/pay/" + d.token, className: "sp-edit-btn" }, "Open payment link"))),
      isInvoice && !paid && h(InvoiceConvertBox, { pp: pp, doc: d }),
      paid && receiptLink && h("div", { className: "sales-doc-sub", style: { marginTop: 8 } }, "Paid \u00b7 receipt " + "#" + d.paymentRef + " created")
    );
  }
  function SellerSalesPage(props) {
    var pp = usePlugPay();
    var _m = PR.useState(props.mode || "receipts"), mode = _m[0], setMode = _m[1];
    var _f = PR.useState("all"), filter = _f[0], setFilter = _f[1];
    PR.useEffect(function () { setMode(props.mode || "receipts"); }, [props.mode]);
    if (!pp.merchantLoggedIn) return h(SellerGate, { active: "sales", msg: "Sign in to your seller account to view your sales." });
    var receipts = pp.receiptsList, invoices = pp.invoicesList;
    var all = receipts.map(function (r) { return salesDocStatus("receipt", r); }).concat(invoices.map(function (i) { return salesDocStatus("invoice", i); }));
    var completeCount = all.filter(function (x) { return x === "COMPLETE"; }).length;
    var pendingCount = all.length - completeCount;
    var kind = mode === "receipts" ? "receipt" : "invoice";
    var source = mode === "receipts" ? receipts : invoices;
    var shown = source.filter(function (d) { return filter === "all" || salesDocStatus(kind, d).toLowerCase() === filter; });
    var unsent = receipts.filter(function (r) { return !r.sentAt; }).length;
    var filters = [["all", "All"], ["pending", "Pending"], ["complete", "Complete"]];
    return h(AppShellSeller, { title: "Sales", subtitle: "View each receipt and invoice, mark it pending or complete, and turn paid invoices into receipts." },
      h("div", { className: "seller-sales-summary" },
        h("div", null, h("strong", null, receipts.length), h("span", null, "Receipts")),
        h("div", null, h("strong", null, invoices.length), h("span", null, "Invoices")),
        h("div", null, h("strong", null, completeCount), h("span", null, "Complete")),
        h("div", null, h("strong", null, pendingCount), h("span", null, "Pending"))),
      h("div", { className: "dx-seg", style: { marginBottom: 12 } },
        h("button", { className: mode === "receipts" ? "on" : "", onClick: function () { setMode("receipts"); } }, "Receipts (" + receipts.length + ")"),
        h("button", { className: mode === "invoices" ? "on" : "", onClick: function () { setMode("invoices"); } }, "Invoices (" + invoices.length + ")")),
      h("div", { className: "sales-filter" }, filters.map(function (f) {
        return h("button", { key: f[0], type: "button", className: filter === f[0] ? "on" : "", onClick: function () { setFilter(f[0]); } }, f[1]);
      })),
      mode === "receipts" && unsent > 0 && h("div", { className: "rv-note", style: { marginBottom: 12 } }, h("span", null, "\u26A0\uFE0F"), h("span", null, unsent + " receipt(s) not sent yet. Stock only drops once a receipt is sent to the buyer.")),
      h("section", { className: "sales-doc-list" },
        shown.map(function (d) { return h(SalesDocCard, { key: kind + (d.token || d.code), kind: kind, doc: d, pp: pp }); }),
        source.length > 0 && shown.length === 0 && h("div", { className: "ll-empty" }, "Nothing in this view."),
        mode === "receipts" && receipts.length === 0 && h(EmptyState, { icon: "receipt", title: "No receipts yet", sub: "Tap Record a sale, add the M-Pesa code, and the receipt goes to the buyer on WhatsApp with a review link.", action: { label: "Record a sale", onClick: function () { pp.openModal("modal-record-sale"); } } }),
        mode === "invoices" && invoices.length === 0 && h(EmptyState, { icon: "file-text", title: "No invoices yet", sub: "Record a sale without an M-Pesa code and it goes out as a payment-link invoice.", action: { label: "Record a sale", onClick: function () { pp.openModal("modal-record-sale"); } } })
      )
    );
  }
  function SaleRedirect() {
    var pp = usePlugPay();
    PR.useEffect(function () {
      window.location.replace("#/seller/dashboard");
      setTimeout(function () { if (pp.merchantLoggedIn) pp.openModal("modal-record-sale"); else pp.openAuthModal(); }, 200);
    }, []);
    return null;
  }
  function SellerReceiptDetailPage(props) {
    var pp = usePlugPay();
    var code = codeOf(props.code);
    var sale = pp.receiptsList.filter(function (r) { return codeOf(r.code) === code; })[0];
    if (!pp.merchantLoggedIn) return h(SellerGate, { active: "sales", msg: "Sign in to view this receipt." });
    if (!sale) return h(AppShellSeller, { title: "Receipt not found" }, h(ErrorState, { icon: "receipt", title: "Receipt not found", sub: "We couldn't find that receipt. It may have been removed.", backTo: "/seller/receipts", backLabel: "Back to sales" }));
    var sp = pp.sellerProfile, badges = sellerBadgeInfo(pp), st = reviewStatus(sale);
    var rComplete = salesDocStatus("receipt", sale) === "COMPLETE";
    return h(AppShellSeller, { title: "Receipt " + sale.code, subtitle: sale.sentAt ? "Sent " + relTime(sale.sentAt) + ". The review link went with it." : "Not sent yet. Send it to record the sale and update your stock." },
      h("div", { className: "doc-wrap" }, h("div", { className: "doc-card" },
        h("div", { className: "doc-band" },
          h("div", { className: "doc-band-top" }, h("div", { className: "doc-kind" }, Ic("receipt", 12), "PlugPay Receipt"), h("span", { className: "doc-status " + (rComplete ? "paid" : "pending") }, Ic(rComplete ? "badge-check" : "clock", 11), rComplete ? "Complete" : "Pending")),
          h("div", { className: "doc-amt" }, "KSh " + sale.total.toLocaleString()),
          h("div", { className: "doc-amt-label" }, "Paid by " + (sale.buyerName || "Buyer") + " \u00b7 " + new Date(sale.createdAt).toLocaleString())),
        h(DocTrader, { sp: sp }),
        h(DocBadges, { badges: badges }),
        h("div", { className: "doc-sec" }, h("div", { className: "doc-sec-h" }, Ic("user", 13), "Buyer & payment"),
          h("div", { className: "doc-row" }, h("span", null, "Buyer phone"), h("strong", null, sale.buyerPhone)),
          h("div", { className: "doc-row" }, h("span", null, "Payment ref"), h("strong", null, sale.paymentRef || codeOf(sale.code)))),
        h(DocItems, { items: sale.items }),
        h("div", { className: "doc-total-row" }, h("span", null, "Total paid"), h("strong", null, "KSh " + sale.total.toLocaleString())),
        h("div", { className: "doc-sec" }, h("div", { className: "doc-sec-h" }, Ic("star", 13), "Buyer review"),
          h("div", { style: { marginBottom: 8 } }, h(ReviewChip, { r: sale })),
          st.state === "done" && h("div", null, h("div", { className: "rev-stars-big" }, "\u2605".repeat(sale.review.rating) + "\u2606".repeat(5 - sale.review.rating)), sale.review.comment && h("div", { className: "rev-item-text" }, sale.review.comment)),
          st.state === "open" && h("div", { className: "doc-note", style: { padding: 0 } }, "The buyer can review once, within 6 hours of receiving this receipt."),
          st.state === "expired" && h("div", { className: "doc-note", style: { padding: 0 } }, "The 6-hour review window has closed. Reviews are one per receipt.")),
        h("div", { className: "doc-actions" },
          h("button", { className: "es-btn", onClick: function () { pp.sendReceipt(sale.code); } }, Ic("send", 14), sale.sentAt ? "Resend on WhatsApp" : "Send receipt on WhatsApp"),
          h(Link, { to: "/r/" + code, className: "es-btn alt" }, Ic("receipt", 14), "Public copy"),
          h("button", { className: "es-btn alt", onClick: function () { pp.setDocumentStatus("receipt", sale.code, rComplete ? "PENDING" : "COMPLETE"); } }, Ic(rComplete ? "clock" : "badge-check", 14), rComplete ? "Mark pending" : "Mark complete"),
          h("button", { className: "es-btn alt", onClick: function () { pp.copyText(reviewLink(sale.code), "Review link copied"); } }, Ic("star", 14), "Copy review link")),
        h("div", { className: "app-actions", style: { padding: "0 20px 18px" } }, h(Link, { to: "/seller/receipts", className: "pp-btn secondary" }, "Back to sales"))
      ))
    );
  }
  function SellerInvoiceDetailPage(props) {
    var pp = usePlugPay();
    var inv = pp.invoicesList.filter(function (x) { return x.token === props.token; })[0];
    if (!pp.merchantLoggedIn) return h(SellerGate, { active: "sales", msg: "Sign in to view this invoice." });
    if (!inv) return h(AppShellSeller, { title: "Invoice not found" }, h(ErrorState, { icon: "file-text", title: "Invoice not found", sub: "We couldn't find that invoice. It may have been removed.", backTo: "/seller/invoices", backLabel: "Back to sales" }));
    var sp = pp.sellerProfile, badges = sellerBadgeInfo(pp);
    var paid = inv.status === "PAID";
    var complete = salesDocStatus("invoice", inv) === "COMPLETE";
    return h(AppShellSeller, { title: "Invoice" + (inv.number ? " " + inv.number : ""), subtitle: paid ? "Paid. A receipt was created from this invoice." : "Awaiting payment. Paste the M-Pesa code or message below once the buyer pays." },
      h("div", { className: "doc-wrap" }, h("div", { className: "doc-card" },
        h("div", { className: "doc-band" },
          h("div", { className: "doc-band-top" }, h("div", { className: "doc-kind" }, Ic("file-text", 12), "PlugPay Invoice"), h("span", { className: "doc-status " + (complete ? "paid" : "pending") }, Ic(complete ? "badge-check" : "clock", 11), complete ? "Complete" : "Pending")),
          h("div", { className: "doc-amt" }, "KSh " + Number(inv.total || 0).toLocaleString()),
          h("div", { className: "doc-amt-label" }, "Billed to " + (inv.buyerName || "Buyer") + " \u00b7 " + new Date(inv.createdAt).toLocaleString())),
        h(DocTrader, { sp: sp }),
        h(DocBadges, { badges: badges }),
        h("div", { className: "doc-sec" }, h("div", { className: "doc-sec-h" }, Ic("user", 13), "Buyer & payment"),
          inv.number && h("div", { className: "doc-row" }, h("span", null, "Invoice no."), h("strong", null, inv.number)),
          h("div", { className: "doc-row" }, h("span", null, "Buyer phone"), h("strong", null, inv.buyerPhone || "\u2014")),
          h("div", { className: "doc-row" }, h("span", null, "Payment"), h("strong", null, paid ? "Paid" : "Awaiting payment")),
          inv.paymentRef && h("div", { className: "doc-row" }, h("span", null, "M-Pesa code"), h("strong", null, inv.paymentRef))),
        !paid && h(DocPayInfo, { sp: sp }),
        h(DocItems, { items: inv.items || [] }),
        h("div", { className: "doc-total-row" }, h("span", null, paid ? "Total paid" : "Total due"), h("strong", null, "KSh " + Number(inv.total || 0).toLocaleString())),
        !paid && h("div", { style: { padding: "0 20px 14px" } }, h(InvoiceConvertBox, { pp: pp, doc: inv })),
        h("div", { className: "doc-actions" },
          !paid && h("button", { className: "es-btn", onClick: function () { pp.setDocumentStatus("invoice", inv.token, complete ? "PENDING" : "COMPLETE"); } }, Ic(complete ? "clock" : "badge-check", 14), complete ? "Mark pending" : "Mark complete"),
          !paid && h("button", { className: "es-btn alt", onClick: function () { pp.resendInvoice(inv.token); } }, Ic("send", 14), "Resend on WhatsApp"),
          h(Link, { to: "/pay/" + inv.token, className: "es-btn alt" }, Ic("link", 14), "Payment link"),
          paid && inv.paymentRef && h(Link, { to: "/seller/receipts/" + encodeURIComponent("#" + inv.paymentRef), className: "es-btn alt" }, Ic("receipt", 14), "Open receipt")),
        h("div", { className: "app-actions", style: { padding: "0 20px 18px" } }, h(Link, { to: "/seller/invoices", className: "pp-btn secondary" }, "Back to sales"))
      ))
    );
  }

  /* ---- Buyer-facing links: public receipt, review, pay invoice ---- */
  function PublicReceiptPage(props) {
    var pp = usePlugPay();
    var code = codeOf(props.code);
    var sale = pp.receiptsList.filter(function (r) { return codeOf(r.code) === code; })[0];
    if (!sale || !sale.sentAt) return h(PublicShellX, { title: "Receipt not found" }, h(ErrorState, { icon: "receipt", title: "Receipt unavailable", sub: "This receipt link is no longer valid.", backTo: "/", backLabel: "Return home" }));
    var sp = pp.sellerProfile, badges = sellerBadgeInfo(pp), st = reviewStatus(sale);
    return h(PublicShellX, { title: "PlugPay receipt", subtitle: sp.bizName + " \u00b7 " + sale.code },
      h("div", { className: "doc-wrap" }, h("div", { className: "doc-card" },
        h("div", { className: "doc-thanks" }, h("div", { className: "ic-big" }, Ic("badge-check", 24)), h("h3", null, "Thank you for shopping with " + sp.bizName + "!"), h("p", null, "Your payment of KSh " + sale.total.toLocaleString() + " was received and confirmed.")),
        h(DocTrader, { sp: sp }),
        h(DocBadges, { badges: badges }),
        h("div", { className: "doc-sec" }, h("div", { className: "doc-sec-h" }, Ic("credit-card", 13), "Payment confirmation"),
          h("div", { className: "doc-row" }, h("span", null, "Receipt no."), h("strong", null, sale.code)),
          h("div", { className: "doc-row" }, h("span", null, "Payment ref"), h("strong", null, sale.paymentRef || "\u2014")),
          h("div", { className: "doc-row" }, h("span", null, "Date"), h("strong", null, new Date(sale.createdAt).toLocaleString())),
          h("div", { className: "doc-row" }, h("span", null, "Buyer phone"), h("strong", null, sale.buyerPhone))),
        h(DocItems, { items: sale.items }),
        h("div", { className: "doc-total-row" }, h("span", null, "Total paid"), h("strong", null, "KSh " + sale.total.toLocaleString())),
        h("div", { className: "doc-review" }, h("div", { className: "doc-review-ic" }, Ic("star", 16)), h("div", { className: "doc-review-txt" },
          st.state === "open" ? h(PR.Fragment, null, h("b", null, "How was your experience?"), "Rate " + sp.bizName + ". This link closes in " + timeLeft(st.msLeft) + ".")
          : st.state === "done" ? h(PR.Fragment, null, h("b", null, "Thanks for your review"), "You rated this purchase " + sale.review.rating + " of 5.")
          : h(PR.Fragment, null, h("b", null, "Review window closed"), "Reviews can be left within 6 hours of receiving the receipt."))),
        h("div", { className: "doc-actions" },
          st.state === "open" && h(Link, { to: "/review/" + code, className: "es-btn" }, Ic("star", 14), "Leave a review"),
          h("button", { className: "es-btn alt", onClick: function () { openWhatsApp(sp.whatsapp || sp.phone, "Hi " + sp.bizName + ", I have a question about my order " + sale.code); } }, Ic("message-circle", 14), "Message seller")),
        h("div", { className: "doc-note" }, "This receipt was generated by PlugPay on behalf of " + sp.bizName + ". Keep it as proof of payment.")
      ))
    );
  }
  var QUICK_REVIEW = [["Quality", "Great quality products."], ["Quick delivery", "Quick delivery."], ["Great customer service", "Great customer service."], ["Improve service", "Service could be improved."]];
  function ReviewPage(props) {
    var pp = usePlugPay();
    var code = codeOf(props.code);
    var sale = pp.receiptsList.filter(function (r) { return codeOf(r.code) === code; })[0];
    var _r = PR.useState(0), rating = _r[0], setRating = _r[1];
    var _c = PR.useState(""), comment = _c[0], setComment = _c[1];
    var _e = PR.useState(""), err = _e[0], setErr = _e[1];
    if (!sale || !sale.sentAt) {
      return h(PublicShellX, { title: "Review link not found" },
        h("div", { className: "app-card" },
          h("div", { className: "app-card-title" }, "We couldn't find a receipt for this link."),
          h("div", { className: "app-card-sub" }, "Double check the link your seller sent you, or ask them to resend it."),
          h("div", { className: "app-actions" }, h(Link, { to: "/", className: "pp-btn secondary" }, "Return home"))));
    }
    var sp = pp.sellerProfile, st = reviewStatus(sale);
    if (st.state === "done") {
      return h(PublicShellX, { title: "Review submitted", subtitle: sp.bizName + " \u00b7 Receipt " + sale.code },
        h("section", { className: "app-card review-public" },
          h("div", { className: "app-card-title" }, "Thanks for rating your purchase"),
          h("div", { className: "rev-stars-big", style: { margin: "8px 0" } }, "\u2605".repeat(sale.review.rating) + "\u2606".repeat(5 - sale.review.rating)),
          sale.review.comment && h("div", { className: "rev-item-text" }, sale.review.comment),
          h("div", { className: "doc-note", style: { padding: "10px 0 0" } }, "Each receipt can be reviewed once."),
          h("div", { className: "app-actions" }, h(Link, { to: "/r/" + code, className: "pp-btn secondary" }, "Back to receipt"))));
    }
    if (st.state === "expired") {
      return h(PublicShellX, { title: "Review window closed", subtitle: sp.bizName + " \u00b7 Receipt " + sale.code },
        h("section", { className: "app-card review-public" },
          h("div", { className: "app-card-title" }, "This review link has expired"),
          h("div", { className: "app-card-sub" }, "Reviews can be left within 6 hours of getting your receipt."),
          h("div", { className: "app-actions" }, h(Link, { to: "/r/" + code, className: "pp-btn secondary" }, "Back to receipt"))));
    }
    function toggleChip(phrase) {
      setErr("");
      setComment(function (c) {
        if (c.indexOf(phrase) > -1) return c.replace(phrase, "").replace(/\s{2,}/g, " ").trim();
        return (c.trim() ? c.trim() + " " : "") + phrase;
      });
    }
    function submit() {
      var res = pp.submitReview(sale.code, { rating: rating, comment: comment });
      if (!res.ok) setErr(res.reason === "norating" ? "Tap a star to rate first." : res.reason === "expired" ? "The 6-hour review window has closed." : res.reason === "done" ? "This receipt was already reviewed." : "Couldn't submit your review.");
    }
    var LABELS = ["", "Poor", "Fair", "Good", "Very good", "Excellent"];
    return h(PublicShellX, { title: "Rate your purchase", subtitle: sp.bizName + " \u00b7 Receipt " + sale.code + " \u00b7 KSh " + sale.total.toLocaleString() },
      h("section", { className: "app-card review-public" },
        h("div", { className: "rv-note", style: { marginBottom: 6 } }, h("span", null, "\u23F1"), h("span", null, "One review per receipt. This link closes in " + timeLeft(st.msLeft) + ".")),
        h("div", { className: "star-picker" }, [1, 2, 3, 4, 5].map(function (n) { return h("button", { key: n, className: "star-btn" + (n <= rating ? " on" : ""), "aria-label": n + " star" + (n > 1 ? "s" : ""), onClick: function () { setRating(n); setErr(""); } }, "\u2605"); })),
        h("div", { className: "star-picker-label" }, rating ? rating + " of 5 \u00b7 " + LABELS[rating] : "Tap a star to rate"),
        h("div", { className: "rv-quick-h" }, "Quick comments"),
        h("div", { className: "rv-quick" }, QUICK_REVIEW.map(function (q) {
          return h("button", { key: q[0], type: "button", className: "rv-qc" + (comment.indexOf(q[1]) > -1 ? " on" : ""), onClick: function () { toggleChip(q[1]); } }, q[0]);
        })),
        h("textarea", { className: "pp-textarea", style: { marginTop: 12 }, placeholder: "Add more detail (optional)", value: comment, onChange: function (e) { setComment(e.target.value); } }),
        err && h("div", { className: "field-err", role: "alert" }, Ic("triangle-alert", 13), err),
        h("div", { className: "app-actions" }, h("button", { className: "pp-btn primary", onClick: submit }, "Submit review"))
      )
    );
  }
  function PayInvoicePage(props) {
    var pp = usePlugPay();
    var invoice = pp.invoicesList.filter(function (x) { return x.token === props.token; })[0];
    if (!invoice) return h(PublicShellX, { title: "Invoice not found" }, h(ErrorState, { icon: "file-text", title: "Invoice unavailable", sub: "This invoice is no longer available or the link is wrong.", backTo: "/", backLabel: "Return home" }));
    var sp = pp.sellerProfile, badges = sellerBadgeInfo(pp);
    var paid = invoice.status === "PAID";
    return h(PublicShellX, { title: "PlugPay invoice", subtitle: sp.bizName + " \u00b7 " + (paid ? "Paid" : "Awaiting payment") },
      h("div", { className: "doc-wrap" }, h("div", { className: "doc-card" },
        h("div", { className: "doc-band" },
          h("div", { className: "doc-band-top" }, h("div", { className: "doc-kind" }, Ic("file-text", 12), "PlugPay Invoice"), h("span", { className: "doc-status " + (paid ? "paid" : "pending") }, Ic(paid ? "badge-check" : "clock", 11), paid ? "Paid" : "Pending")),
          h("div", { className: "doc-amt" }, "KSh " + invoice.total.toLocaleString()),
          h("div", { className: "doc-amt-label" }, "Requested from " + invoice.buyerName + " \u00b7 " + new Date(invoice.createdAt).toLocaleString())),
        h(DocTrader, { sp: sp }),
        h(DocBadges, { badges: badges }),
        h("div", { className: "doc-sec" }, h("div", { className: "doc-sec-h" }, Ic("user", 13), "Bill to"),
          h("div", { className: "doc-row" }, h("span", null, "Buyer"), h("strong", null, invoice.buyerName)),
          h("div", { className: "doc-row" }, h("span", null, "Phone"), h("strong", null, invoice.buyerPhone)),
          h("div", { className: "doc-row" }, h("span", null, "Sent via"), h("strong", null, invoice.source))),
        !paid && h(DocPayInfo, { sp: sp }),
        h(DocItems, { items: invoice.items }),
        h("div", { className: "doc-total-row" }, h("span", null, paid ? "Total paid" : "Total due"), h("strong", null, "KSh " + invoice.total.toLocaleString())),
        h("div", { className: "doc-actions" },
          !paid && h("button", { className: "es-btn", onClick: function () { pp.showToast("Opening M-Pesa to pay " + sp.bizName + "\u2026"); } }, Ic("credit-card", 14), "Pay via M-Pesa"),
          paid && invoice.paymentRef && h(Link, { to: "/r/" + encodeURIComponent(invoice.paymentRef), className: "es-btn" }, Ic("receipt", 14), "View receipt"),
          h("button", { className: "es-btn alt", onClick: function () { openWhatsApp(sp.whatsapp || sp.phone, "Hi " + sp.bizName + ", I'm following up on invoice for KSh " + invoice.total.toLocaleString()); } }, Ic("message-circle", 14), "Message seller")),
        h("div", { className: "doc-note" }, paid ? "This invoice has been paid and a receipt was issued to the buyer." : "This is a pending payment-link invoice. It only becomes a confirmed sale once the seller marks it as paid with the M-Pesa code.")
      ))
    );
  }

  /* ---- Wiring: registers this group's modals, slots, pages and routes ---- */
  PP_ROUTES.push(
    ["/seller/dashboard", "seller-dashboard"],
    ["/seller/invoices", "seller-invoices"],
    ["/seller/invoices/new", "seller-sale-new"],
    [/^\/seller\/invoices\/(.+)$/, "seller-invoice-detail", "token"],
    ["/seller/receipts", "seller-receipts"],
    ["/seller/receipts/new", "seller-sale-new"],
    [/^\/seller\/receipts\/(.+)$/, "seller-receipt-detail", "code"],
    ["/seller/reviews", "seller-reviews"],
    ["/seller/profile", "seller-profile"],
    ["/seller/catalogue", "seller-catalogue"],
    ["/seller/building", "seller-building"],
    [/^\/review\/(.+)$/, "review", "code"],
    [/^\/r\/(.+)$/, "public-receipt", "code"],
    [/^\/pay\/(.+)$/, "pay", "token"]
  );
  PP_registry.register("modals", "receipt", ReceiptModal, 60);
  PP_registry.register("modals", "record-sale", RecordSaleModal, 70);
  PP_registry.register("modals", "register", RegisterModal, 80);
  PP_registry.register("seller.profile", "hero", SellerProfileHero, 10);
  PP_registry.register("seller.profile", "reviews", SellerProfileReviews, 20);
  PP_registry.register("seller.profile", "contact", SellerProfileContact, 30);
  PP_registry.register("seller.profile", "social", SellerProfileSocial, 40);
  PP_registry.register("seller.profile", "payment", SellerProfilePayment, 50);
  PP_registry.register("seller.profile", "about", SellerProfileAbout, 60);
  PP_registry.register("seller.profile", "compliance", SellerProfileCompliance, 70);
  PP_registry.register("seller.profile", "riders", SellerProfileRiders, 80);
  PP_registry.register("seller.profile", "relocate", SellerProfileRelocate, 90);
  [["dashboard", SellerDashboardTab], ["profile", SellerProfileTab], ["catalogue", SellerCatalogueTab], ["reviews", ReviewsTab], ["building", BuildingTab]].forEach(function (t) { PP_registry.registerPage("seller.tab." + t[0], function () { return h(t[1], null); }); });
  ["dashboard", "catalogue", "building", "profile", "reviews"].forEach(function (t) { PP_registry.registerPage("seller-" + t, function () { return h(SellerPortalPage, { tab: t }); }); });
  PP_registry.registerPage("seller-invoices", function () { return h(SellerSalesPage, { mode: "invoices" }); });
  PP_registry.registerPage("seller-receipts", function () { return h(SellerSalesPage, { mode: "receipts" }); });
  PP_registry.registerPage("seller-sale-new", function () { return h(SaleRedirect, null); });
  PP_registry.registerPage("seller-receipt-detail", function (r) { return h(SellerReceiptDetailPage, { code: r.code }); });
  PP_registry.registerPage("seller-invoice-detail", function (r) { return h(SellerInvoiceDetailPage, { token: r.token }); });
  PP_registry.registerPage("review", function (r) { return h(ReviewPage, { code: r.code }); });
  PP_registry.registerPage("public-receipt", function (r) { return h(PublicReceiptPage, { code: r.code }); });
  PP_registry.registerPage("pay", function (r) { return h(PayInvoicePage, { token: r.token }); });
  PP_registry.register("seller.dashboard", "s1", SellerDashboardTabSection1, 10);
  PP_registry.register("seller.dashboard", "s2", SellerDashboardTabSection2, 20);
  PP_registry.register("seller.dashboard", "s3", SellerDashboardTabSection3, 30);
  PP_registry.register("seller.dashboard", "s4", SellerDashboardTabSection4, 40);
  PP_registry.register("seller.dashboard", "s5", SellerDashboardTabSection5, 50);
  PP_registry.register("seller.dashboard", "s6", SellerDashboardTabSection6, 60);
  PP_registry.register("seller.dashboard", "s7", SellerDashboardTabSection7, 70);
  PP_registry.register("seller.dashboard", "s8", SellerDashboardVouches, 65);