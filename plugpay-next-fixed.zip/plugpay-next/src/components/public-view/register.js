import { h } from "../common/h.js";
import { PP_registry } from "../common/registry.js";
import { PP_ROUTES } from "../common/routing.js";
import { MerchantModal } from "./MerchantModal.js";
import { SellerPublicPage } from "./SellerPublicPage.js";
import { ProfileTabSection1, ProfileTabSection2, ProfileTabSection3, ProfileTabSection4, ProfileTabSection5, ProfileTabSection6, ProfileTabSection7 } from "./tabs/ProfileTab.js";

/* ---- Wiring: registers this group's modals, slots, pages and routes ---- */
PP_ROUTES.push(
  [/^\/sellers\/(.+)$/, "seller-public", "id"]
);

PP_registry.register("modals", "merchant", MerchantModal, 30);

PP_registry.registerPage("seller-public", function (r) { return h(SellerPublicPage, { id: r.id }); });

PP_registry.register("merchant.profile", "s1", ProfileTabSection1, 10);

PP_registry.register("merchant.profile", "s2", ProfileTabSection2, 20);

PP_registry.register("merchant.profile", "s3", ProfileTabSection3, 30);

PP_registry.register("merchant.profile", "s4", ProfileTabSection4, 40);

PP_registry.register("merchant.profile", "s5", ProfileTabSection5, 50);

PP_registry.register("merchant.profile", "s6", ProfileTabSection6, 60);

PP_registry.register("merchant.profile", "s7", ProfileTabSection7, 70);
