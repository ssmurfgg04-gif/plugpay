/* Seller authentication is now backed by Supabase Phone Auth through the Next.js API. */
import * as import_react from 'react';
import { apiFetch, setAuthToken } from '../../../lib/backend.js';

export function useSellerAuth(ctx) {
  const { openModal, showToast } = ctx;
  const [merchantLoggedIn, setMerchantLoggedIn] = import_react.useState(false);
  const [authMethod, setAuthMethodState] = import_react.useState('whatsapp');
  const [authStep, setAuthStep] = import_react.useState('phone');
  const [authPhone, setAuthPhone] = import_react.useState('');
  const [authOtp, setAuthOtp] = import_react.useState('');
  const [authPinLoginValue, setAuthPinLoginValue] = import_react.useState('');
  const [authSetPinValue, setAuthSetPinValue] = import_react.useState('');
  const [authHasPin, setAuthHasPin] = import_react.useState(false);
  const finishLoginRef = import_react.useRef(null);

  import_react.useEffect(() => {
    apiFetch('/api/auth/session').then(() => setMerchantLoggedIn(true)).catch(() => setMerchantLoggedIn(false));
  }, []);

  const authSetMethod = import_react.useCallback((m) => { setAuthMethodState(m); setAuthPhone(''); }, []);
  const openAuthModal = import_react.useCallback(() => {
    ctx.claimTokenRef.current = null; ctx.setClaimInfo(null); setAuthStep('phone'); setAuthPhone(''); setAuthOtp(''); setAuthPinLoginValue(''); setAuthSetPinValue(''); authSetMethod('whatsapp'); openModal('modal-register');
  }, [authSetMethod, openModal]);
  const requireSellerLogin = import_react.useCallback((actionLabel) => {
    if (!merchantLoggedIn) { showToast('Sign in to your seller account to ' + actionLabel); openAuthModal(); return false; }
    return true;
  }, [merchantLoggedIn, openAuthModal, showToast]);
  const authSendOTP = import_react.useCallback(async () => {
    const val = authPhone.trim(); if (!val) { showToast('Enter your phone number'); return; }
    try { await apiFetch('/api/auth/otp/start', { method:'POST', body:JSON.stringify({phone:val,role:'seller',method:authMethod}) }); showToast(`OTP sent to ${val} ✓`); setAuthStep('otp'); }
    catch(e){ showToast(e.message); }
  }, [authMethod, authPhone, showToast]);
  const authVerifyOTP = import_react.useCallback(async () => {
    try {
      const r = await apiFetch('/api/auth/otp/verify', { method:'POST', body:JSON.stringify({phone:authPhone,token:authOtp,role:'seller'}) });
      setAuthToken(r.access_token); setAuthHasPin(!!r.user?.has_pin); setAuthStep('setpin'); showToast('Verified ✓');
    } catch(e){ showToast(e.message); }
  }, [authOtp, authPhone, showToast]);
  const authSetPin = import_react.useCallback(async () => {
    if (!/^\d{6}$/.test(authSetPinValue.trim())) { showToast('Enter a 6-digit PIN'); return; }
    try { await apiFetch('/api/auth/pin/set', { method:'POST', body:JSON.stringify({pin:authSetPinValue.trim()}) }); setAuthHasPin(true); showToast('PIN set ✓'); finishLoginRef.current && finishLoginRef.current(); }
    catch(e){ showToast(e.message); }
  }, [authSetPinValue, showToast]);
  const authShowPinLogin = import_react.useCallback(() => setAuthStep('pinlogin'), []);
  const authGoBackFromPin = import_react.useCallback(() => setAuthStep('phone'), []);
  const authPinLogin = import_react.useCallback(async () => {
    if (!authPhone.trim() || !/^\d{6}$/.test(authPinLoginValue.trim())) { showToast('Enter your phone number and 6-digit PIN'); return; }
    try { const r=await apiFetch('/api/auth/pin/login',{method:'POST',body:JSON.stringify({phone:authPhone,pin:authPinLoginValue})}); setAuthToken(r.access_token); setMerchantLoggedIn(true); showToast('Unlocked ✓'); finishLoginRef.current && finishLoginRef.current(); }
    catch(e){ showToast(e.message); }
  }, [authPhone, authPinLoginValue, showToast]);
  const authGoBack = import_react.useCallback(() => setAuthStep('phone'), []);
  return { finishLoginRef,setMerchantLoggedIn,setAuthStep,setAuthOtp,setAuthPinLoginValue,setAuthSetPinValue,setAuthMethodState,setAuthPhone,merchantLoggedIn,requireSellerLogin,openAuthModal,authMethod,authSetMethod,authStep,authPhone,setAuthPhone,authOtp,setAuthOtp,authPinLoginValue,setAuthPinLoginValue,authSetPinValue,setAuthSetPinValue,authSendOTP,authVerifyOTP,authSetPin,authShowPinLogin,authGoBackFromPin,authPinLogin,authGoBack };
}
