import { reviewStatus } from "../../../../data/sales.js";
import { initials } from "../../../../lib/utils.js";
import { h } from "../../../common/h.js";
import { Ic } from "../../../common/ui.js";

/* ---- Sales: record a sale, receipts, invoices ---- */
export function timeLeft(ms) {
  var m = Math.max(1, Math.ceil(ms / 60000)), hh = Math.floor(m / 60), mm = m % 60;
  return hh ? hh + "h " + mm + "m" : mm + "m";
}

export function sellerBadgeInfo(pp) {
  return { plugpay: true, landlord: !!pp.sellerProfile.llPhoneVerified };
}

export function DocBadges(props) {
  var b = props.badges;
  return h("div", null,
    h("div", { className: "doc-badges" },
      b.plugpay && h("span", { className: "doc-badge on", title: "This seller verified their phone number with PlugPay." }, Ic("badge-check", 12), "PlugPay Verified"),
      b.landlord
        ? h("span", { className: "doc-badge on", title: "The building's landlord confirmed this seller's phone number and profile match the real stall owner." }, Ic("building-2", 12), "Verified")
        : h("span", { className: "doc-badge pending", title: "The landlord hasn't yet confirmed this seller's phone number and profile match the real stall owner." }, Ic("building-2", 12), "Pending")));
}

export function DocTrader(props) {
  var sp = props.sp;
  return h("div", { className: "doc-trader" },
    h("div", { className: "doc-trader-av" }, initials(sp.bizName || "P")),
    h("div", null,
      h("div", { className: "doc-trader-name" }, sp.bizName),
      h("div", { className: "doc-trader-meta" },
        h("span", null, sp.role || "Seller"),
        sp.street && h("span", null, "\u00b7 " + sp.street),
        sp.phone && h("span", null, "\u00b7 " + sp.phone))));
}

export function DocPayInfo(props) {
  var sp = props.sp;
  var pm = sp.payMethod || "Paybill";
  var noAcct = pm === "Till number" || pm === "Send money";
  var numLabel = pm === "Till number" ? "Till number" : pm === "Send money" ? "M-Pesa phone" : pm === "Bank transfer" ? "Bank account number" : "Paybill number";
  var acctLabel = pm === "Bank transfer" ? "Account name" : "Account number";
  return h("div", { className: "doc-sec" },
    h("div", { className: "doc-sec-h" }, Ic("credit-card", 13), "Payment information"),
    h("div", { className: "doc-pay-box" },
      h("div", { className: "doc-row" }, h("span", null, "Pay via"), h("strong", null, pm)),
      h("div", { className: "doc-row" }, h("span", null, numLabel), h("strong", null, sp.paybill || "\u2014")),
      !noAcct && h("div", { className: "doc-row" }, h("span", null, acctLabel), h("strong", null, sp.account || "\u2014"))));
}

export function DocItems(props) {
  return h("div", { className: "doc-sec" },
    h("div", { className: "doc-sec-h" }, Ic("package", 13), "Products sold"),
    props.items.map(function (it, i) {
      var unit = it.unit || (it.qty ? it.price / it.qty : it.price);
      return h("div", { className: "doc-item", key: i },
        h("div", null, h("div", { className: "doc-item-name" }, it.name), (it.qty > 1) && h("div", { className: "doc-item-sub" }, it.qty + " \u00d7 KSh " + Number(unit).toLocaleString())),
        h("div", { className: "doc-item-amt" }, "KSh " + Number(it.price).toLocaleString()));
    }));
}

export function ReviewChip(props) {
  var st = reviewStatus(props.r);
  if (st.state === "done") return h("span", { className: "rv-chip done" }, "\u2605 " + props.r.review.rating + " reviewed");
  if (st.state === "open") return h("span", { className: "rv-chip open" }, "Review open \u00b7 " + timeLeft(st.msLeft) + " left");
  if (st.state === "expired") return h("span", { className: "rv-chip exp" }, "Review window closed");
  return h("span", { className: "rv-chip wait" }, "Not sent yet");
}

export function salesDocStatus(kind, d) {
  if (kind === "invoice") return d.status === "PAID" ? "COMPLETE" : (d.docStatus || "PENDING");
  return d.docStatus || "COMPLETE";
}
