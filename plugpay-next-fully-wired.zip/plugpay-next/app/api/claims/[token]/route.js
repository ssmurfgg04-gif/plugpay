import { adminDb, requireUser, json, body, cleanPhone } from '../../../../src/server/supabase.js';

export async function GET(_request, ctx) {
  const { token } = await ctx.params;
  const db = adminDb();
  const r = await db.from('claims').select('*, buildings(id,name,address), stalls(id,stall_number,floors(label,floor_number)), sellers(id,business_name,owner_name,phone)').eq('token', token).maybeSingle();
  if (r.error) return json({ error: r.error.message }, 500);
  if (!r.data) return json({ error: 'Claim not found' }, 404);
  if (r.data.expires_at && new Date(r.data.expires_at) < new Date()) return json({ error: 'Claim expired' }, 410);
  return json({ claim: r.data });
}

// Completes the seller side of an agent-created claim after the seller signs in.
// It creates the normalized seller/stall assignment records; the landlord can then verify it.
export async function POST(request, ctx) {
  const { token } = await ctx.params;
  const auth = await requireUser(request);
  if (auth.error) return auth.error;
  const x = await body(request);
  const db = adminDb();
  const claim = await db.from('claims').select('*').eq('token', token).maybeSingle();
  if (claim.error) return json({ error: claim.error.message }, 500);
  if (!claim.data) return json({ error: 'Claim not found' }, 404);
  if (claim.data.expires_at && new Date(claim.data.expires_at) < new Date()) return json({ error: 'Claim expired' }, 410);
  if (claim.data.status === 'revoked') return json({ error: 'Claim revoked' }, 409);

  const phone = cleanPhone(x.phone || auth.user.phone || claim.data.phone);
  if (phone && cleanPhone(claim.data.phone) !== phone) return json({ error: 'This claim is tied to a different phone number' }, 403);

  let seller = null;
  if (claim.data.seller_id) {
    const sr = await db.from('sellers').select('*').eq('id', claim.data.seller_id).maybeSingle();
    seller = sr.data;
  }
  const patch = {
    user_id: auth.user.id,
    business_name: String(x.businessName || seller?.business_name || 'New seller').trim(),
    owner_name: String(x.ownerName || seller?.owner_name || auth.user.user_metadata?.full_name || 'Seller').trim(),
    phone: phone || cleanPhone(auth.user.phone),
    category: x.category || seller?.category || null,
  };
  if (!seller) {
    const sr = await db.from('sellers').upsert(patch, { onConflict: 'user_id' }).select('*').single();
    if (sr.error) return json({ error: sr.error.message }, 400);
    seller = sr.data;
    await db.from('claims').update({ seller_id: seller.id }).eq('id', claim.data.id);
  } else {
    const sr = await db.from('sellers').update(patch).eq('id', seller.id).select('*').single();
    if (sr.error) return json({ error: sr.error.message }, 400);
    seller = sr.data;
  }

  const existing = await db.from('stall_assignments').select('*').eq('seller_id', seller.id).is('ended_at', null).maybeSingle();
  if (existing.data && existing.data.stall_id !== claim.data.stall_id) {
    await db.from('stall_assignments').update({ ended_at: new Date().toISOString() }).eq('id', existing.data.id);
  }
  const assignmentPayload = { seller_id: seller.id, stall_id: claim.data.stall_id, status: 'pending', assigned_by: claim.data.agent_id || auth.user.id };
  let assignment = await db.from('stall_assignments').select('*').eq('seller_id', seller.id).is('ended_at', null).maybeSingle();
  if (assignment.data) {
    const updated = await db.from('stall_assignments').update(assignmentPayload).eq('id', assignment.data.id).select('*').single();
    assignment = updated;
  } else {
    assignment = await db.from('stall_assignments').insert(assignmentPayload).select('*').single();
  }
  if (assignment.error) return json({ error: assignment.error.message }, 400);

  await db.from('claims').update({ seller_id: seller.id, status: 'claimed', claimed_at: new Date().toISOString() }).eq('id', claim.data.id);
  await db.from('stalls').update({ status: 'pending' }).eq('id', claim.data.stall_id);
  return json({ ok: true, seller, assignment: assignment.data });
}
