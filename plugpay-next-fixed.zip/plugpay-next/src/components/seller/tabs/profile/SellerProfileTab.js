import { usePlugPay } from "../../../../store/context.js";
import { PR, h } from "../../../common/h.js";
import { Slot } from "../../../common/registry.js";
import { EditRow } from "./EditRow.js";
import { SellerHero } from "./SellerHero.js";
import { SellerPaymentOptions } from "./SellerPaymentOptions.js";
import { SellerReviewsCard } from "./SellerReviewsCard.js";

/* ---- Profile tab ---- */
var docFields = [
  { key: "idfront", name: "ID Front", icon: "\u{1FAAA}" },
  { key: "idback", name: "ID Back", icon: "\u{1FAAA}" },
  { key: "selfie", name: "Selfie", icon: "\u{1F933}" },
  { key: "biz", name: "Business License", icon: "\u{1F4C4}" },
  { key: "kra", name: "KRA PIN Certificate", icon: "\u{1F9FE}" }
];

function StallRow() {
  var pp = usePlugPay();
  var cur = pp.stallAssignment;
  var BLD = ["Anniversary Towers", "Lonrho House", "Kencom House", "Odeon Cinema Bldg", "Other"];
  var _e = PR.useState(false), editing = _e[0], setEditing = _e[1];
  var _b = PR.useState(cur.building), b = _b[0], setB = _b[1];
  var _o = PR.useState(""), other = _o[0], setOther = _o[1];
  var _l = PR.useState(cur.loc), loc = _l[0], setLoc = _l[1];
  function start() { var known = BLD.indexOf(cur.building) > -1; setB(known ? cur.building : "Other"); setOther(known ? "" : cur.building); setLoc(cur.loc); setEditing(true); }
  function save() {
    var name = b === "Other" ? other.trim() : b;
    if (!name || !loc.trim()) { pp.showToast("Enter the building and stall"); return; }
    pp.changeStall(name, loc.trim());
    setEditing(false); pp.showToast("Stall / building updated \u2713");
  }
  return h("div", { className: "tp-info-row", style: { border: "none" } },
    h("div", { className: "tp-info-ico", style: { background: "#e3f2fd" } }, h("span", null, "\uD83C\uDFE2")),
    h("div", { className: "tp-info-text", style: { flex: 1, minWidth: 0 } },
      h("div", { className: "tp-info-label" }, "STALL / BUILDING"),
      editing
        ? h("div", null,
            h("select", { className: "plc-input", style: { marginTop: 6 }, value: b, onChange: function (e) { setB(e.target.value); } }, BLD.map(function (o) { return h("option", { key: o, value: o }, o); })),
            b === "Other" && h("input", { className: "plc-input", style: { marginTop: 6 }, placeholder: "Building name", value: other, onChange: function (e) { setOther(e.target.value); } }),
            h("input", { className: "plc-input", style: { marginTop: 6 }, placeholder: "Floor & stall (e.g. Floor 3, Stall 14)", value: loc, onChange: function (e) { setLoc(e.target.value); } }),
            h("div", { className: "sp-edit-actions" }, h("button", { className: "sp-edit-btn on", onClick: save }, "Save"), h("button", { className: "sp-edit-btn", onClick: function () { setEditing(false); } }, "Cancel")))
        : h("div", { className: "tp-info-val" }, cur.building + ", " + cur.loc)),
    !editing && h("button", { className: "sp-edit-btn", onClick: start }, "\u270F\uFE0F Edit"));
}

function useSellerProfileForm() {
  var pp = usePlugPay();
  var sp = pp.sellerProfile;
  var S = function (k) { return function (v) { var n = {}; n[k] = v; pp.updateSellerProfile(n); }; };
  var pm = sp.payMethod || "Paybill";
  var PMETHODS = ["Paybill", "Till number", "Send money", "Bank transfer"];
  var noAcct = pm === "Till number" || pm === "Send money";
  var YEARS = (function () { var a = [], y = new Date().getFullYear(); for (; y >= 1970; y--) a.push(String(y)); return a; })();
  return { pp: pp, sp: sp, S: S, pm: pm, PMETHODS: PMETHODS, noAcct: noAcct, YEARS: YEARS };
}

export function SellerProfileHero() {
  var f = useSellerProfileForm(), pp = f.pp, sp = f.sp, S = f.S, pm = f.pm, PMETHODS = f.PMETHODS, noAcct = f.noAcct, YEARS = f.YEARS;
  return h(SellerHero, { editable: true });
}

export function SellerProfileReviews() {
  var f = useSellerProfileForm(), pp = f.pp, sp = f.sp, S = f.S, pm = f.pm, PMETHODS = f.PMETHODS, noAcct = f.noAcct, YEARS = f.YEARS;
  return h(SellerReviewsCard, null);
}

export function SellerProfileContact() {
  var f = useSellerProfileForm(), pp = f.pp, sp = f.sp, S = f.S, pm = f.pm, PMETHODS = f.PMETHODS, noAcct = f.noAcct, YEARS = f.YEARS;
  return h("div", { className: "tp-card tp-info-card" },
      h(EditRow, { icon: "\uD83D\uDCCD", bg: "#fff8e1", label: "LOCATION", value: sp.street, onSave: S("street"), required: true }),
      h(EditRow, { icon: "\uD83D\uDCDE", bg: "#f8f1f7", label: "PHONE", value: sp.phone, onSave: S("phone"), required: true, inputType: "tel" }),
      h(EditRow, { icon: "\uD83D\uDCC5", bg: "#ede7f6", label: "YEAR IN BUSINESS", value: sp.established, editValue: String(parseInt(sp.established, 10) || ""), options: YEARS, required: true, onSave: function (v) { var y = parseInt(v, 10), n = new Date().getFullYear() - y; pp.updateSellerProfile({ established: y + " \u00b7 " + (n <= 0 ? "Started this year" : n + (n === 1 ? " year" : " years") + " in business") }); } }),
      h(StallRow, null)
    );
}

export function SellerProfileSocial() {
  var f = useSellerProfileForm(), pp = f.pp, sp = f.sp, S = f.S, pm = f.pm, PMETHODS = f.PMETHODS, noAcct = f.noAcct, YEARS = f.YEARS;
  return h("div", { className: "tp-card tp-info-card" },
      h("div", { className: "tp-section-title", style: { padding: "13px 13px 0" } }, "Social Media"),
      h(EditRow, { icon: "\uD83D\uDCAC", bg: "#25D36622", label: "WHATSAPP NUMBER", value: sp.whatsapp, onSave: S("whatsapp"), inputType: "tel" }),
      h(EditRow, { icon: "\uD83D\uDCF7", bg: "#fde7f3", label: "INSTAGRAM", value: sp.instagram, onSave: S("instagram") }),
      h(EditRow, { icon: "\uD83C\uDFB5", bg: "#00000014", label: "TIKTOK", value: sp.tiktok, onSave: S("tiktok") }),
      h(EditRow, { icon: "f", bg: "#1877F222", label: "FACEBOOK", value: sp.facebook, onSave: S("facebook"), last: true })
    );
}

export function SellerProfilePayment() {
  var f = useSellerProfileForm(), pp = f.pp, sp = f.sp, S = f.S, pm = f.pm, PMETHODS = f.PMETHODS, noAcct = f.noAcct, YEARS = f.YEARS;
  return h("div", { className: "tp-card tp-info-card" },
      h("div", { className: "tp-pay-info-header", style: { padding: "13px 13px 0" } }, h("div", { className: "tp-pay-info-title" }, h("span", { className: "tp-pay-info-icon" }, "\uD83D\uDCB3"), " Payment Information"), h("div", { className: "tp-pay-info-badge" }, "M-Pesa")),
      h(EditRow, { icon: "\uD83D\uDCB1", bg: "#e8f5e9", label: "PAYMENT METHOD", value: pm, options: PMETHODS, required: true, onSave: S("payMethod") }),
      h(EditRow, { icon: "\uD83C\uDFE6", bg: "#f8f1f7", label: pm === "Till number" ? "TILL NUMBER" : pm === "Send money" ? "M-PESA PHONE" : pm === "Bank transfer" ? "BANK ACCOUNT NUMBER" : "PAYBILL NUMBER", value: sp.paybill, onSave: S("paybill"), required: true, last: noAcct }),
      !noAcct && h(EditRow, { icon: "\uD83D\uDD22", bg: "#e3f2fd", label: pm === "Bank transfer" ? "ACCOUNT NAME" : "ACCOUNT NUMBER", value: sp.account, onSave: S("account"), required: true, last: true }),
      h(SellerPaymentOptions, null)
    );
}

export function SellerProfileAbout() {
  var f = useSellerProfileForm(), pp = f.pp, sp = f.sp, S = f.S, pm = f.pm, PMETHODS = f.PMETHODS, noAcct = f.noAcct, YEARS = f.YEARS;
  return h("div", { className: "tp-card tp-info-card" },
      h(EditRow, { label: "ABOUT THE BUSINESS", value: sp.about, onSave: S("about"), multiline: true, last: true })
    );
}

export function SellerProfileCompliance() {
  var f = useSellerProfileForm(), pp = f.pp, sp = f.sp, S = f.S, pm = f.pm, PMETHODS = f.PMETHODS, noAcct = f.noAcct, YEARS = f.YEARS;
  return h("div", { className: "tp-card", style: { padding: 13 } },
      h("div", { className: "tp-section-title" }, "Compliance Documents"),
      h("div", { className: "tp-section-body", style: { marginBottom: 10 } }, "Kept on file for your own records \u2014 your landlord doesn\u2019t review these. Your Landlord Verified badge comes from your landlord confirming you occupy your stall."),
      docFields.map(function (d, i) {
        var st = pp.docStatus[d.key];
        return h("div", { key: d.key, className: "sp-doc-row" },
          h("div", { style: { flex: 1 } }, h("div", { className: "tp-doc-label" }, (d.icon || "") + " " + d.name), h("div", { className: "tp-doc-badge", style: { marginTop: 4 } }, st === "done" ? "\u2713 Uploaded" : st === "uploading" ? "Uploading\u2026" : "Not uploaded")),
          h("button", { className: "sp-edit-btn", onClick: function () { pp.fakeUpload(d.key, d.name); } }, st === "done" ? "Replace" : "Upload"));
      })
    );
}

export function SellerProfileRiders() {
  var f = useSellerProfileForm(), pp = f.pp, sp = f.sp, S = f.S, pm = f.pm, PMETHODS = f.PMETHODS, noAcct = f.noAcct, YEARS = f.YEARS;
  return h("div", { className: "tp-card", style: { padding: 13 } },
      h("div", { className: "tp-section-title" }, "Trusted Riders & Errand People"),
      h("div", { className: "tp-section-body", style: { marginBottom: 10 } }, "People you've personally worked with and vouch for."),
      h("div", { className: "vouch-list" },
        [["Brian Otieno", "Boda rider", "\uD83C\uDFCD\uFE0F", "#185FA5"], ["Faith Nekesa", "Errand runner", "\uD83C\uDFC3", "#BA7517"]].map(function (r) {
          return h("div", { key: r[0], className: "vouch-item" }, h("div", { className: "vouch-av", style: { background: r[3] } }, r[2]), h("div", { className: "vouch-info" }, h("div", { className: "vouch-name" }, r[0]), h("div", { className: "vouch-sub" }, r[1] + " \u00b7 Added by you")), h("span", { className: "tp-info-label" }, "\u2713 Trusted"));
        }),
        pp.riders.map(function (r, i) {
          return h("div", { key: "n" + i, className: "vouch-item" }, h("div", { className: "vouch-av", style: { background: "#51104a" } }, r.role === "Errand runner" ? "\uD83C\uDFC3" : "\uD83C\uDFCD\uFE0F"), h("div", { className: "vouch-info" }, h("div", { className: "vouch-name" }, r.name), h("div", { className: "vouch-sub" }, r.role + " \u00b7 Added by you")), h("button", { className: "sp-edit-btn", onClick: function () { pp.removeRider(i); } }, "Remove"));
        })
      ),
      h("div", { className: "sp-lock-note", style: { marginTop: 12 } }, "Add a rider"),
      h("div", { className: "sp-rider-form" },
        h("input", { className: "plc-input", placeholder: "Name", value: pp.riderRows[0].name, onChange: function (e) { pp.updateRiderRow(pp.riderRows[0].id, { name: e.target.value }); } }),
        h("input", { className: "plc-input", placeholder: "Phone", value: pp.riderRows[0].phone, onChange: function (e) { pp.updateRiderRow(pp.riderRows[0].id, { phone: e.target.value }); } }),
        h("select", { className: "plc-input", value: pp.riderRows[0].role, onChange: function (e) { pp.updateRiderRow(pp.riderRows[0].id, { role: e.target.value }); } }, h("option", null, "Boda rider"), h("option", null, "Errand runner")),
        h("button", { className: "sp-edit-btn on", onClick: pp.saveTrustedRiders }, "+ Add")
      )
    );
}

export function SellerProfileRelocate() {
  var f = useSellerProfileForm(), pp = f.pp, sp = f.sp, S = f.S, pm = f.pm, PMETHODS = f.PMETHODS, noAcct = f.noAcct, YEARS = f.YEARS;
  return h("div", { className: "tp-card", style: { padding: 13, marginBottom: 30 } },
      h("div", { className: "tp-section-title" }, "Relocate stall"),
      h("div", { className: "tp-section-body", style: { marginBottom: 10 } }, "Moving buildings? Submit the new stall for landlord verification."),
      h("div", { className: "sp-rider-form" },
        h("input", { className: "plc-input", placeholder: "New building", value: pp.vacateBuilding, onChange: function (e) { pp.setVacateBuilding(e.target.value); } }),
        h("input", { className: "plc-input", placeholder: "New stall (e.g. Floor 2, Stall 9)", value: pp.vacateStall, onChange: function (e) { pp.setVacateStall(e.target.value); } }),
        h("button", { className: "sp-edit-btn on", onClick: pp.confirmVacate }, "Submit"))
    );
}

export function SellerProfileTab() { return h(Slot, { name: "seller.profile" }); }
