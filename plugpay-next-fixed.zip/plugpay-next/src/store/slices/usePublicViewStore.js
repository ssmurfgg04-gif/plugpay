/* usePublicViewStore — "publicView" group of the PlugPay store, extracted from PlugPayProvider.
   Statements are the original ones, in their original relative order. Names owned by other groups arrive through the shared
   per-render context object (ctx): groups that run earlier are destructured below, groups that run later are read lazily as ctx.name. */
import * as import_react from "react";
import { merchants } from "../../data/directory.js";
import { buildStallProfile, buildViewedSeller } from "../../data/stallProfiles.js";
import { ppSlug, sameNumber } from "../../lib/utils.js";
import { usePersisted } from "../usePersisted.js";

export function usePublicViewStore(ctx) {
    const { isOpen, openModal, showToast } = ctx;
    const [merchantTab, setMerchantTab] = (0, import_react.useState)("profile");
    const [viewedSeller, setViewedSeller] = (0, import_react.useState)(null);
    const openMerchantModal = (0, import_react.useCallback)(() => {
      setViewedSeller(null);
      openModal("modal-merchant");
    }, [openModal]);
    const openMerchantModalOnReviews = (0, import_react.useCallback)(() => {
      setViewedSeller(null);
      openModal("modal-merchant");
      setMerchantTab("reviews");
    }, [openModal]);
    const focusMerchantProfileTab = (0, import_react.useCallback)(() => {
      if (isOpen("modal-merchant")) setMerchantTab("profile");
    }, [isOpen]);
    const [following, setFollowing] = (0, import_react.useState)(false);
    const toggleFollowMerchant = (0, import_react.useCallback)(() => {
      setFollowing((f) => {
        const nv = !f;
        showToast(nv ? "Following Wanjiku Electronics \u2713" : "Unfollowed Wanjiku Electronics");
        return nv;
      });
    }, [showToast]);
    const viewSellerProfile = (0, import_react.useCallback)(() => {
      setViewedSeller(null);
      openModal("modal-merchant");
      setMerchantTab("profile");
    }, [openModal]);
    const [stallHistory, setStallHistory] = usePersisted("stallhistory", []);
    const normLoc = (x) => String(x || "").toLowerCase().replace(/ground floor/, "g").replace(/floor\s*/, "").replace(/[^a-z0-9]/g, "");
    const locFromSub = (sub) => { const m = /(ground floor|floor\s*\w+),\s*stall\s*\w+/i.exec(String(sub || "")); return m ? m[0] : ""; };
    const streetOf = (building) => { const a = ctx.lbAccounts.filter((x) => x.name.trim().toLowerCase() === String(building || "").trim().toLowerCase())[0]; return a ? a.street : "Nairobi CBD"; };
    const showSeller = (d) => {
      setViewedSeller(buildViewedSeller({ street: streetOf(d.building), ...d }));
      setMerchantTab("profile");
      openModal("modal-merchant");
      window.setTimeout(() => { document.querySelectorAll(".tpModal, .tpModal .tp-body").forEach((el) => { el.scrollTop = 0; }); }, 60);
    };
    const openOwnProfile = () => { setViewedSeller(null); setMerchantTab("profile"); openModal("modal-merchant"); window.setTimeout(() => { document.querySelectorAll(".tpModal, .tpModal .tp-body").forEach((el) => { el.scrollTop = 0; }); }, 60); };
    const viewStallProfile = (stall, floor, building, merchant) => {
      const p = buildStallProfile({ obMerchantList: ctx.obMerchantList }, { stall, floor, building, merchant: merchant || null });
      const sameBuilding = String(p.building).trim().toLowerCase() === ctx.stallAssignment.building.trim().toLowerCase();
      if (sameBuilding && normLoc(p.loc) === normLoc(ctx.stallAssignment.loc)) { openOwnProfile(); return; }
      const bid = ctx.lbIdByName(p.building);
      const lists = bid ? (ctx.lbData[bid] || ctx.emptyLb) : ctx.emptyLb;
      const at = (l) => l.filter((t) => normLoc(locFromSub(t.sub)) === normLoc(p.loc))[0];
      const tv = at(lists.verified), tp = at(lists.pending);
      const t = tv || tp;
      if (t && t.phone && sameNumber(t.phone, ctx.sellerProfile.phone)) { openOwnProfile(); return; }
      const owner = t ? t.name : p.owner;
      const dir = merchants.filter((m) => m.name === owner && m.sub.indexOf(p.building) > -1)[0];
      const claimed = p.registered && ctx.agentClaims.some((c) => c.verified && sameNumber(c.phone, p.phone));
      const verified = t ? !!tv : dir ? dir.badgeClass === "rcb-verified" : p.registered ? claimed : p.verified;
      const catSrc = dir ? dir.sub.split(" \u00b7 ")[0] : t ? String(t.sub).replace(/^Claims\s*/i, "").split(" \u00b7 ").filter((x) => !locFromSub(x))[0] : p.cat;
      showSeller({ biz: t || dir ? owner : p.biz, owner, cat: catSrc || p.cat, loc: p.loc, building: p.building, verified, phone: (t && t.phone) || p.phone, rating: dir ? dir.rating : p.rating, sales: dir && dir.sales, reviews: dir ? dir.reviews : p.reviews, vouches: dir && dir.vouches, years: p.years, photos: p.photos, registered: p.registered });
    };
    const openSellerRef = (ref) => {
      const own = sameNumber(ref.phone, ctx.sellerProfile.phone) || (ref.name && ref.name === ctx.sellerProfile.ownerName);
      if (own) { openOwnProfile(); return; }
      const dir = merchants.filter((x) => x.name === ref.name)[0];
      if (dir) { openDirectorySeller(dir); return; }
      const raw = String(ref.sub || "").replace(/^Claims\s*/i, "");
      const parts = raw.split(" \u00b7 ");
      const loc = locFromSub(raw);
      const cat = parts.filter((x) => x && !locFromSub(x))[0] || "Retail";
      const building = ref.building || ctx.stallAssignment.building;
      showSeller({ biz: ref.name, owner: ref.name, cat, loc: loc || "Stall not listed", building, verified: !!ref.verified, phone: ref.phone || "" });
    };
    const openDirectorySeller = (m) => {
      const name = m.name || m.owner;
      const dir = merchants.filter((x) => x.name === name)[0];
      if (!dir) { openOwnProfile(); return; }
      const parts = dir.sub.split(" \u00b7 ");
      if (dir.name === ctx.sellerProfile.ownerName) { openOwnProfile(); return; }
      showSeller({ biz: dir.name, owner: dir.name, cat: parts[0], building: parts[1], loc: parts[2], verified: dir.badgeClass === "rcb-verified", rating: dir.rating, sales: dir.sales, reviews: dir.reviews, vouches: dir.vouches });
    };
    /* Loads a seller into the shared profile state WITHOUT opening the modal (used by the /sellers/:id page). */
    const loadSellerPage = (id) => {
      const k = ppSlug(id);
      if (k && ppSlug(ctx.sellerProfile.ownerName) === k) { setViewedSeller(null); setMerchantTab("profile"); return true; }
      const dir = merchants.filter((x) => ppSlug(x.name) === k)[0];
      if (!dir) return false;
      const parts = dir.sub.split(" \u00b7 ");
      setViewedSeller(buildViewedSeller({ street: streetOf(parts[1]), biz: dir.name, owner: dir.name, cat: parts[0], building: parts[1], loc: parts[2], verified: dir.badgeClass === "rcb-verified", rating: dir.rating, sales: dir.sales, reviews: dir.reviews, vouches: dir.vouches }));
      setMerchantTab("profile");
      return true;
    };
    return {
      setStallHistory,
      viewedSeller,
      loadSellerPage,
      openDirectorySeller,
      openSellerRef,
      stallHistory,
      merchantTab,
      setMerchantTab,
      openMerchantModal,
      openMerchantModalOnReviews,
      focusMerchantProfileTab,
      following,
      toggleFollowMerchant,
      viewSellerProfile,
      viewStallProfile
    };
}
