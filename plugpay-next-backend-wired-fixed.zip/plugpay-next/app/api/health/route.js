import { json } from '../../../src/server/supabase.js';
export async function GET() { return json({ ok: true, service: 'plugpay', timestamp: new Date().toISOString() }); }
