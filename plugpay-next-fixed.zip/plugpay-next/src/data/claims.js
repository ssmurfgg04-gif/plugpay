import { appBase } from "../lib/router.js";

export function claimLink(t) { return appBase() + "/claim/" + encodeURIComponent(t); }

export function waClaimText(c) {
    return "Hi " + (c.ownerName || "there") + ", you've been added to PlugPay" + (c.businessName ? " as " + c.businessName : "") + " at " + c.buildingName + " (" + c.loc + "). Tap to claim your stall and sign in:\n" + claimLink(c.token);
  }
