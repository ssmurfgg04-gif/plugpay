import * as import_jsx_runtime from "../../ppJsxRuntime.js";
import { usePlugPay } from "../../store/context.js";

export function PhoneDemo() {
  const { openMerchantModal, openInvoiceInProfile, openReceiptInProfile, openMerchantModalOnReviews, showToast } = usePlugPay();
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "hero-phone-shot", children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "wa-phone", children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "wa-screen", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "wa-header", onClick: () => openMerchantModal(), children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "wa-avatar", children: "WE" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "wa-header-name", children: "Wanjiku Electronics" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "wa-header-status", children: "online" })
        ] })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "wa-body", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "wa-day", children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "TODAY" }) }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "wa-bubble-out", children: [
          "Hi! Is the Samsung Galaxy A15 still available? Saw it on your status and TikTok page \u{1F440}",
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { className: "wa-time", children: [
            "9:41",
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "wa-check", children: "\u2713\u2713" })
          ] })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "wa-sys", children: "\u{1F512} 72-hour messaging window opened" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "wa-card", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "wa-card-h", children: "\u2705 Verified profile shared automatically" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { padding: "0 11px 4px", color: "#fff", fontSize: "12px", fontWeight: "800" }, children: "Wanjiku Electronics" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "wa-stars", children: "\u2605\u2605\u2605\u2605\u2605 4.8 \xB7 156 reviews \xB7 312 sales" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "wa-card-badge", children: "\u2713 ID-verified seller" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "wa-card-sent", children: "Sent via PlugPay" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { className: "wa-card-btn", onClick: () => openMerchantModal(), children: "View full profile" })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "wa-bubble-in", children: [
          "Yes, 4 in stock \u{1F60A} Let me get you an invoice.",
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "wa-time", children: "9:42" })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "wa-bubble-out", children: [
          "I would like to buy it, send payment details",
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { className: "wa-time", children: [
            "9:42",
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "wa-check", children: "\u2713\u2713" })
          ] })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "wa-card", style: { cursor: "pointer" }, onClick: () => openInvoiceInProfile(), children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "wa-card-h", children: "\u{1F4C4} Invoice from Wanjiku Electronics" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "wa-card-row", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Samsung Galaxy A15" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "KSh 18,500" })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "wa-card-row total", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Total due" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "KSh 18,500" })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "wa-card-row", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Pay to" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Till 174379" })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "wa-card-note", children: "Send the M-Pesa confirmation message here once it's paid \u2014 I'll record it and send your receipt." }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "wa-card-sent", children: "Sent via PlugPay" })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "wa-card", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "wa-card-note", style: { padding: "11px 11px 8px", color: "#e9edef", fontSize: "11.5px" }, children: "Need it delivered? I can connect you with a verified PlugPay runner, or you're welcome to pick it up yourself at Anniversary Towers, Fl. 3." }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { padding: "0 9px 9px", display: "flex", flexDirection: "column", gap: "6px" }, children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
              "button",
              {
                className: "wa-quick-btn",
                style: { marginTop: "0" },
                onClick: () => showToast("Matching you with a nearby verified runner\u2026"),
                children: "\u{1F6F5} Connect me with a runner"
              }
            ),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
              "button",
              {
                className: "wa-quick-btn",
                style: { marginTop: "0" },
                onClick: () => showToast("Pickup confirmed \u2014 no runner needed"),
                children: "\u{1F9CD} I'll pick it up"
              }
            )
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "wa-card-sent", children: "Sent via PlugPay" })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "wa-bubble-out", children: [
          "I'll pick it up myself, thanks",
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { className: "wa-time", children: [
            "9:43",
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "wa-check", children: "\u2713\u2713" })
          ] })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "wa-sys", children: "\u{1F9CD} Pickup confirmed \u2014 no runner needed" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "wa-sys", children: "\u{1F4B5} Buyer pays KSh 18,500 to Till 174379 \u2014 outside the app" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "wa-bubble-out", children: [
          "Sent! Confirmation code TGH5K9P2Q",
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { className: "wa-time", children: [
            "9:44",
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "wa-check", children: "\u2713\u2713" })
          ] })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "wa-card", style: { cursor: "pointer" }, onClick: () => openReceiptInProfile(), children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "wa-card-h", children: "\u{1F4C4} Receipt \xB7 #00849" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "wa-card-row", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Samsung Galaxy A15" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "KSh 18,500" })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "wa-card-row total", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Total paid" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "KSh 18,500" })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "wa-card-row", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "M-Pesa code" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "TGH5K9P2Q" })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "wa-card-badge", children: "\u2713 Sale recorded by Jane \xB7 Trust score updating" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "wa-card-sent", children: "Sent via PlugPay" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
            "button",
            {
              className: "wa-card-btn",
              onClick: (e) => {
                e.stopPropagation();
                openMerchantModalOnReviews();
              },
              children: "Leave a review"
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "wa-scroll-hint" })
    ] }) }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "wa-caption", children: "\u2191 scroll to see the full sale, receipt to review \u2191" })
  ] });
}
