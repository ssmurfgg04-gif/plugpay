import { h } from "../common/h.js";
import { PP_registry } from "../common/registry.js";
import { PP_ROUTES } from "../common/routing.js";
import { BuildingTab } from "../public-view/tabs/BuildingTab.js";
import { ReviewsTab } from "../public-view/tabs/ReviewsTab.js";
import { RegisterModal } from "./auth/RegisterModal.js";
import { PayInvoicePage } from "./buyer-pages/PayInvoicePage.js";
import { PublicReceiptPage } from "./buyer-pages/PublicReceiptPage.js";
import { ReviewPage } from "./buyer-pages/ReviewPage.js";
import { ReceiptModal } from "./modals/ReceiptModal.js";
import { RecordSaleModal } from "./modals/RecordSaleModal.js";
import { SellerPortalPage } from "./shell/SellerPortalPage.js";
import { SellerCatalogueTab } from "./tabs/catalogue/SellerCatalogueTab.js";
import { SellerDashboardTab, SellerDashboardTabSection1, SellerDashboardTabSection2, SellerDashboardTabSection3, SellerDashboardTabSection4, SellerDashboardTabSection5, SellerDashboardTabSection6, SellerDashboardTabSection7 } from "./tabs/dashboard/SellerDashboardTab.js";
import { SellerDashboardVouches } from "./tabs/dashboard/SellerDashboardVouches.js";
import { SellerProfileAbout, SellerProfileCompliance, SellerProfileContact, SellerProfileHero, SellerProfilePayment, SellerProfileRelocate, SellerProfileReviews, SellerProfileRiders, SellerProfileSocial, SellerProfileTab } from "./tabs/profile/SellerProfileTab.js";
import { SellerInvoiceDetailPage } from "./tabs/sales/SellerInvoiceDetailPage.js";
import { SellerReceiptDetailPage } from "./tabs/sales/SellerReceiptDetailPage.js";
import { SaleRedirect, SellerSalesPage } from "./tabs/sales/SellerSalesPage.js";

/* ---- Wiring: registers this group's modals, slots, pages and routes ---- */
PP_ROUTES.push(
  ["/seller/dashboard", "seller-dashboard"],
  ["/seller/invoices", "seller-invoices"],
  ["/seller/invoices/new", "seller-sale-new"],
  [/^\/seller\/invoices\/(.+)$/, "seller-invoice-detail", "token"],
  ["/seller/receipts", "seller-receipts"],
  ["/seller/receipts/new", "seller-sale-new"],
  [/^\/seller\/receipts\/(.+)$/, "seller-receipt-detail", "code"],
  ["/seller/reviews", "seller-reviews"],
  ["/seller/profile", "seller-profile"],
  ["/seller/catalogue", "seller-catalogue"],
  ["/seller/building", "seller-building"],
  [/^\/review\/(.+)$/, "review", "code"],
  [/^\/r\/(.+)$/, "public-receipt", "code"],
  [/^\/pay\/(.+)$/, "pay", "token"]
);

PP_registry.register("modals", "receipt", ReceiptModal, 60);

PP_registry.register("modals", "record-sale", RecordSaleModal, 70);

PP_registry.register("modals", "register", RegisterModal, 80);

PP_registry.register("seller.profile", "hero", SellerProfileHero, 10);

PP_registry.register("seller.profile", "reviews", SellerProfileReviews, 20);

PP_registry.register("seller.profile", "contact", SellerProfileContact, 30);

PP_registry.register("seller.profile", "social", SellerProfileSocial, 40);

PP_registry.register("seller.profile", "payment", SellerProfilePayment, 50);

PP_registry.register("seller.profile", "about", SellerProfileAbout, 60);

PP_registry.register("seller.profile", "compliance", SellerProfileCompliance, 70);

PP_registry.register("seller.profile", "riders", SellerProfileRiders, 80);

PP_registry.register("seller.profile", "relocate", SellerProfileRelocate, 90);

[["dashboard", SellerDashboardTab], ["profile", SellerProfileTab], ["catalogue", SellerCatalogueTab], ["reviews", ReviewsTab], ["building", BuildingTab]].forEach(function (t) { PP_registry.registerPage("seller.tab." + t[0], function () { return h(t[1], null); }); });

["dashboard", "catalogue", "building", "profile", "reviews"].forEach(function (t) { PP_registry.registerPage("seller-" + t, function () { return h(SellerPortalPage, { tab: t }); }); });

PP_registry.registerPage("seller-invoices", function () { return h(SellerSalesPage, { mode: "invoices" }); });

PP_registry.registerPage("seller-receipts", function () { return h(SellerSalesPage, { mode: "receipts" }); });

PP_registry.registerPage("seller-sale-new", function () { return h(SaleRedirect, null); });

PP_registry.registerPage("seller-receipt-detail", function (r) { return h(SellerReceiptDetailPage, { code: r.code }); });

PP_registry.registerPage("seller-invoice-detail", function (r) { return h(SellerInvoiceDetailPage, { token: r.token }); });

PP_registry.registerPage("review", function (r) { return h(ReviewPage, { code: r.code }); });

PP_registry.registerPage("public-receipt", function (r) { return h(PublicReceiptPage, { code: r.code }); });

PP_registry.registerPage("pay", function (r) { return h(PayInvoicePage, { token: r.token }); });

PP_registry.register("seller.dashboard", "s1", SellerDashboardTabSection1, 10);

PP_registry.register("seller.dashboard", "s2", SellerDashboardTabSection2, 20);

PP_registry.register("seller.dashboard", "s3", SellerDashboardTabSection3, 30);

PP_registry.register("seller.dashboard", "s4", SellerDashboardTabSection4, 40);

PP_registry.register("seller.dashboard", "s5", SellerDashboardTabSection5, 50);

PP_registry.register("seller.dashboard", "s6", SellerDashboardTabSection6, 60);

PP_registry.register("seller.dashboard", "s7", SellerDashboardTabSection7, 70);

PP_registry.register("seller.dashboard", "s8", SellerDashboardVouches, 65);
