import { PP_registry } from "../common/registry.js";
import { FabQuick } from "./FabQuick.js";
import { QuickModal } from "./QuickModal.js";

/* ---- Wiring: registers this group's modals, slots, pages and routes ---- */
PP_registry.register("modals", "quick", QuickModal, 50);

PP_registry.register("landing", "fab", FabQuick, 90);
