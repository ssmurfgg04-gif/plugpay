/* useOnboardingMerchants — "onbMerchants" group of the PlugPay store, extracted from PlugPayProvider.
   Statements are the original ones, in their original relative order. Names owned by other groups arrive through the shared
   per-render context object (ctx): groups that run earlier are destructured below, groups that run later are read lazily as ctx.name. */
import * as import_react from "react";
import { initials } from "../../../lib/utils.js";

export function useOnboardingMerchants(ctx) {
    const { obBldgName, obEditingMerchantId, obMerchantIdRef, obMerchantList, obNewBiz, obNewExtra, obNewFloor, obNewName, obNewPhone, obNewStallNum, obNewType, setObEditingMerchantId, setObMerchantList, setObNewBiz, setObNewExtra, setObNewFloor, setObNewName, setObNewPhone, setObNewStallNum, setObNewType, showToast } = ctx;
    const obAddMerchant = (0, import_react.useCallback)(() => {
      if (!obNewBiz.trim()) {
        showToast("Enter business name");
        return false;
      }
      if (!obNewName.trim()) {
        showToast("Enter owner name");
        return false;
      }
      if (!obNewPhone.trim()) {
        showToast("Enter phone number");
        return false;
      }
      if (!obNewStallNum.trim()) {
        showToast("Enter stall number");
        return false;
      }
      const colors = [
        "#3B3DB8",
        "#185FA5",
        "#8b008b"
      ];
      if (obEditingMerchantId) {
        setObMerchantList(
          (l) => l.map(
            (m) => m.id === obEditingMerchantId ? { ...m, biz: obNewBiz, ownerName: obNewName, phone: obNewPhone, floor: obNewFloor, stallNum: obNewStallNum, type: obNewType, extra: obNewExtra, initials: initials(obNewName) } : m
          )
        );
        ctx.claimsApiRef.current && ctx.claimsApiRef.current.upsert({ id: obEditingMerchantId, biz: obNewBiz, ownerName: obNewName, phone: obNewPhone, floor: obNewFloor, stallNum: obNewStallNum, type: obNewType }, obBldgName);
        showToast("Merchant profile updated \u2713 \u2014 " + obNewBiz);
        setObEditingMerchantId(null);
      } else {
        const color = colors[obMerchantList.length % colors.length];
        const nm = {
          id: "ob-" + obMerchantIdRef.current++,
          biz: obNewBiz,
          ownerName: obNewName,
          phone: obNewPhone,
          floor: obNewFloor,
          stallNum: obNewStallNum,
          type: obNewType,
          extra: obNewExtra,
          initials: initials(obNewName),
          color,
          status: "invited"
        };
        setObMerchantList((l) => [...l, nm]);
        ctx.claimsApiRef.current && ctx.claimsApiRef.current.upsert(nm, obBldgName);
        showToast(`${obNewBiz} registered \u2713 Claim link sent to ${obNewPhone} on WhatsApp`);
      }
      setObNewName("");
      setObNewPhone("");
      setObNewStallNum("");
      setObNewFloor("G");
      setObNewBiz("");
      setObNewType("Fashion");
      setObNewExtra({});
      return true;
    }, [obBldgName, obEditingMerchantId, obMerchantList.length, obNewBiz, obNewFloor, obNewName, obNewPhone, obNewStallNum, obNewType, obNewExtra, showToast]);
    const obStartEditMerchant = (0, import_react.useCallback)(
      (id) => {
        const m = obMerchantList.find((x) => x.id === id);
        if (!m) return;
        setObEditingMerchantId(id);
        setObNewBiz(m.biz);
        setObNewName(m.ownerName);
        setObNewPhone(m.phone);
        setObNewStallNum(m.stallNum);
        setObNewFloor(m.floor);
        setObNewType(m.type);
        setObNewExtra(m.extra || {});
      },
      [obMerchantList]
    );
    const obCancelEditMerchant = (0, import_react.useCallback)(() => {
      setObEditingMerchantId(null);
      setObNewName("");
      setObNewPhone("");
      setObNewStallNum("");
      setObNewFloor("G");
      setObNewBiz("");
      setObNewType("Fashion");
      setObNewExtra({});
    }, []);
    const obPrefillNewMerchantStall = (0, import_react.useCallback)((floor, stallNum) => {
      setObEditingMerchantId(null);
      setObNewBiz("");
      setObNewName("");
      setObNewPhone("");
      setObNewType("Fashion");
      setObNewExtra({});
      setObNewFloor(floor);
      setObNewStallNum(stallNum);
    }, []);
    const obRemoveMerchant = (0, import_react.useCallback)(
      (id) => {
        const m = obMerchantList.find((x) => x.id === id);
        setObMerchantList((l) => l.filter((x) => x.id !== id));
        if (obEditingMerchantId === id) obCancelEditMerchant();
        if (m) showToast(`${m.biz} removed from this building`);
      },
      [obCancelEditMerchant, obEditingMerchantId, obMerchantList, showToast]
    );
    return {
      obAddMerchant,
      obStartEditMerchant,
      obCancelEditMerchant,
      obPrefillNewMerchantStall,
      obRemoveMerchant
    };
}
