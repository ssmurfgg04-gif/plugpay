import * as import_jsx_runtime from "../../../ppJsxRuntime.js";
import { usePlugPay } from "../../../store/context.js";
import { authCodeInput, authIconWrap, authLabel, authSubmitBtn, focusRing } from "./authStyles.js";

export function AuthSetPinStep() {
  const { authSetPinValue, setAuthSetPinValue, authSetPin } = usePlugPay();
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "auth-shell", children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { textAlign: "center", marginBottom: "20px" }, children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: authIconWrap, children: "\u{1F511}" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { fontSize: "22px", fontWeight: 900, color: "var(--ink)", marginBottom: "4px" }, children: "Set a 6-digit PIN" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { fontSize: "13px", color: "var(--muted)", lineHeight: "1.55" }, children: "Use this PIN to unlock your stall profile next time \u2014 no OTP needed." })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { style: authLabel, children: "CHOOSE A 6-DIGIT PIN" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      "input",
      {
        type: "password",
        inputMode: "numeric",
        placeholder: "_ _ _ _ _ _",
        maxLength: 6,
        style: authCodeInput,
        value: authSetPinValue,
        onChange: (e) => setAuthSetPinValue(e.target.value),
        onKeyDown: (e) => {
          if (e.key === "Enter") authSetPin();
        },
        ...focusRing()
      }
    ),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { style: authSubmitBtn, onClick: () => authSetPin(), children: "Set PIN & open my profile \u2192" })
  ] });
}
