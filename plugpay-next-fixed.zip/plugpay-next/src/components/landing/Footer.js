import * as import_jsx_runtime from "../../ppJsxRuntime.js";
import { usePlugPay } from "../../store/context.js";
import { LOGO_DATA_URI } from "../common/ui.js";

export function Footer() {
  const { doSearch, openAuthModal, openMerchantModal, openModal, showToast } = usePlugPay();
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", { children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "wrap footer-grid", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "footer-brand", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", { src: LOGO_DATA_URI, alt: "PlugPay", style: { height: "19px", width: "auto", display: "block" } }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "footer-desc", children: "The trust layer for Kenya's market traders. Turn every sale into permanent, public proof of who you are as a merchant." })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "footer-col", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "footer-col-h", children: "Product" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", { href: "#breakthrough", children: "How it works" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", { href: "#contrast", children: "Features" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", { href: "#pricing", children: "Pricing" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", { href: "#", onClick: (e) => {
          e.preventDefault();
          doSearch("");
        }, children: "Find buildings" })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "footer-col", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "footer-col-h", children: "Merchants" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", { href: "#", onClick: (e) => {
          e.preventDefault();
          openAuthModal();
        }, children: "Sign in to your stall" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", { href: "#", onClick: (e) => {
          e.preventDefault();
          openMerchantModal();
        }, children: "Sample profile" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", { href: "#", onClick: (e) => {
          e.preventDefault();
          openModal("modal-quick");
        }, children: "POS demo" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", { href: "#", onClick: (e) => {
          e.preventDefault();
          showToast("Seller guide coming soon");
        }, children: "Seller guide" })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "footer-col", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "footer-col-h", children: "Company" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", { href: "#friction", children: "Our story" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", { href: "#", onClick: (e) => {
          e.preventDefault();
          showToast("Privacy policy coming soon");
        }, children: "Privacy policy" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", { href: "#", onClick: (e) => {
          e.preventDefault();
          showToast("Terms of service coming soon");
        }, children: "Terms of service" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", { href: "#", onClick: (e) => {
          e.preventDefault();
          showToast("Opening WhatsApp\u2026");
        }, children: "Contact us" })
      ] })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "wrap footer-bottom", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "foot-copy", children: "\xA9 2026 PlugPay \xB7 Nairobi, Kenya" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "foot-tagline", children: "Built for Kenya's market traders \xB7 Every stall deserves a name" })
    ] })
  ] });
}
