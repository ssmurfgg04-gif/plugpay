import * as import_react from "react";
import * as import_jsx_runtime from "../../../ppJsxRuntime.js";
import { usePlugPay } from "../../../store/context.js";
import { h } from "../../common/h.js";
import { Slot } from "../../common/registry.js";
import { useSV } from "../useSV.js";

var ProfCtx = import_react.createContext(null);

export function ProfileTabSection1() {
  var __c = import_react.useContext(ProfCtx) || {}; var sellerProfile = __c.sellerProfile;
  return (0, import_jsx_runtime.jsxs)("div", { className: "tp-card tp-info-card", style: { margin: "9px 9px 0" }, children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-info-row", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-info-ico", style: { background: "#fff8e1" }, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "\u{1F4CD}" }) }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-info-text", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-info-label", children: "LOCATION" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-info-val", children: sellerProfile.street })
        ] })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-info-row", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-info-ico", style: { background: "#f8f1f7" }, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "\u{1F4DE}" }) }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-info-text", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-info-label", children: "PHONE" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-info-val", children: sellerProfile.phone })
        ] })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-info-row", style: { border: "none" }, children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-info-ico", style: { background: "#ede7f6" }, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "\u{1F4C5}" }) }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-info-text", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-info-label", children: "ESTABLISHED" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-info-val", children: sellerProfile.established })
        ] })
      ] })
    ] });
}

export function ProfileTabSection2() {
  var __c = import_react.useContext(ProfCtx) || {}; var showToast = __c.showToast, sellerProfile = __c.sellerProfile;
  return (0, import_jsx_runtime.jsxs)("div", { className: "tp-card", style: { margin: "9px 9px 0", padding: "13px" }, children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-section-title", children: "Social Media" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-social-list", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-social-row", onClick: () => showToast("Opening WhatsApp\u2026"), children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "tp-social-ico", style: { background: "#25D36622", color: "#1a8a4a" }, children: "\u{1F4AC}" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "tp-social-handle", children: sellerProfile.whatsapp })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-social-row", onClick: () => showToast("Opening Instagram\u2026"), children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "tp-social-ico", style: { background: "#f58529", color: "#fff" }, children: "\u{1F4F7}" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "tp-social-handle", children: sellerProfile.instagram })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-social-row", onClick: () => showToast("Opening TikTok\u2026"), children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "tp-social-ico", style: { background: "#00000014", color: "#000" }, children: "\u{1F3B5}" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "tp-social-handle", children: sellerProfile.tiktok })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-social-row", onClick: () => showToast("Opening Facebook\u2026"), children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "tp-social-ico", style: { background: "#1877F222", color: "#1877F2" }, children: "f" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "tp-social-handle", children: sellerProfile.facebook })
        ] })
      ] })
    ] });
}

export function ProfileTabSection3() {
  var __c = import_react.useContext(ProfCtx) || {}; var showToast = __c.showToast, copyText = __c.copyText, sellerProfile = __c.sellerProfile;
  return sellerProfile.paybill && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-card tp-pay-info-card", style: { margin: "9px 9px 0" }, children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-pay-info-header", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-pay-info-title", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "tp-pay-info-icon", children: "\u{1F4B3}" }),
          " Payment Information"
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-pay-info-badge", children: "M-Pesa" })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-pay-info-rows", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-pay-info-row", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-pay-info-ico", style: { background: "#f8f1f7" }, children: "\u{1F3E6}" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-pay-info-text", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-pay-info-label", children: "PAYBILL NUMBER" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-pay-info-val", children: sellerProfile.paybill })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { className: "tp-copy-btn", onClick: () => copyText(sellerProfile.paybill, "Paybill copied!"), children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Copy" }) })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-pay-info-row", style: { border: "none" }, children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-pay-info-ico", style: { background: "#e3f2fd" }, children: "\u{1F522}" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-pay-info-text", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-pay-info-label", children: "ACCOUNT NUMBER" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-pay-info-val", children: sellerProfile.account })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { className: "tp-copy-btn", onClick: () => copyText(sellerProfile.account, "Account copied!"), children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Copy" }) })
        ] })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", { className: "tp-pay-now-btn", onClick: () => showToast("Opening M-Pesa payment for " + sellerProfile.bizName + "\u2026"), children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Pay via M-Pesa" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "tp-pay-arrow", children: "\u2192" })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-pay-note", children: [
        "Send to Paybill ",
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: sellerProfile.paybill }),
        ", Account ",
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: sellerProfile.account }),
        ", then ask the seller for your receipt."
      ] })
    ] });
}

export function ProfileTabSection4() {
  var __c = import_react.useContext(ProfCtx) || {}; var sellerProfile = __c.sellerProfile;
  return (0, import_jsx_runtime.jsxs)("div", { className: "tp-card", style: { margin: "9px 9px 0", padding: "13px" }, children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-section-title", children: "About the Business" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-section-body", children: sellerProfile.about })
    ] });
}

export function ProfileTabSection5() {
  var __c = import_react.useContext(ProfCtx) || {}; var sv = __c.sv;
  return (0, import_jsx_runtime.jsxs)("div", { className: "tp-card", style: { margin: "9px 9px 9px", padding: "13px" }, children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-section-title", children: "Verification Documents" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-docs-grid", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-doc-item", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-doc-label", children: "ID FRONT" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-doc-badge", children: sv.own || !sv.pending ? "\u2713 Verified" : "\u23F3 Pending" })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-doc-item", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-doc-label", children: "ID BACK" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-doc-badge", children: sv.own || !sv.pending ? "\u2713 Verified" : "\u23F3 Pending" })
        ] })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-doc-item tp-doc-wide", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-doc-label", children: "BUSINESS LICENSE" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-doc-badge", children: sv.own || !sv.pending ? "\u2713 Verified" : "\u23F3 Pending" })
      ] })
    ] });
}

export function ProfileTabSection6() {
  var __c = import_react.useContext(ProfCtx) || {}; var sv = __c.sv;
  return !sv.own && h("div", { className: "tp-card public-trusted-people", style: { margin: "9px 9px 9px", padding: "13px" } },
      h("div", { className: "tp-section-title" }, "Runners & Errand People"),
      h("div", { className: "tp-section-body" }, "People this seller has worked with."),
      h("div", { className: "vouch-list" }, [["Brian Otieno", "Boda rider", "\uD83C\uDFCD\uFE0F"], ["Faith Nekesa", "Errand runner", "\uD83C\uDFC3"]].map(function (person) {
        return h("div", { className: "vouch-item", key: person[0] },
          h("div", { className: "vouch-av" }, person[2]),
          h("div", { className: "vouch-info" }, h("div", { className: "vouch-name" }, person[0]), h("div", { className: "vouch-sub" }, person[1])));
      })));
}

export function ProfileTabSection7() {
  var __c = import_react.useContext(ProfCtx) || {}; var riders = __c.riders, sv = __c.sv;
  return sv.own && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-card", style: { margin: "9px 9px 9px", padding: "13px" }, children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-section-title", children: "Trusted Riders & Errand People" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-section-body", style: { marginBottom: "10px" }, children: "People this seller has personally worked with and vouches for." }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "vouch-list", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "vouch-item", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "vouch-av", style: { background: "#185FA5" }, children: "\u{1F3CD}\uFE0F" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "vouch-info", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "vouch-name", children: "Brian Otieno" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "vouch-sub", children: "Boda rider \xB7 Added by this seller" })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { style: { fontSize: "11px", fontWeight: 700, color: "#8b008b", fontFamily: "var(--fm)", whiteSpace: "nowrap" }, children: "\u2713 Trusted" })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "vouch-item", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "vouch-av", style: { background: "#BA7517" }, children: "\u{1F3C3}" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "vouch-info", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "vouch-name", children: "Faith Nekesa" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "vouch-sub", children: "Errand runner \xB7 Added by this seller" })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { style: { fontSize: "11px", fontWeight: 700, color: "#8b008b", fontFamily: "var(--fm)", whiteSpace: "nowrap" }, children: "\u2713 Trusted" })
        ] }),
        riders.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "vouch-item", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "vouch-av", style: { background: "#51104a" }, children: r.role === "Errand runner" ? "\u{1F3C3}" : "\u{1F3CD}\uFE0F" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "vouch-info", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "vouch-name", children: r.name }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "vouch-sub", children: [
              r.role,
              " \xB7 Added by this seller"
            ] })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { style: { fontSize: "11px", fontWeight: 700, color: "#8b008b", fontFamily: "var(--fm)", whiteSpace: "nowrap" }, children: "\u2713 Trusted" })
        ] }, i))
      ] })
    ] });
}

export function ProfileTab({ onViewCatalogue }) {
  const { showToast, copyText, riders } = usePlugPay();
  const sv = useSV();
  const sellerProfile = sv.profile;
  
  var __v = { onViewCatalogue: onViewCatalogue, showToast: showToast, copyText: copyText, riders: riders, sv: sv, sellerProfile: sellerProfile };
  return h(ProfCtx.Provider, { value: __v }, (0, import_jsx_runtime.jsx)("div", { className: "modal-tab-body on", style: { padding: "0" }, children: h(Slot, { name: "merchant.profile" }) }));
}
