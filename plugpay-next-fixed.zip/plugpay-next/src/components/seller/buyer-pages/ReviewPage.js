import { reviewStatus } from "../../../data/sales.js";
import { codeOf } from "../../../lib/utils.js";
import { usePlugPay } from "../../../store/context.js";
import { PR, h } from "../../common/h.js";
import { Link } from "../../common/routing.js";
import { PublicShellX } from "../../common/shells.js";
import { Ic } from "../../common/ui.js";
import { timeLeft } from "../tabs/sales/salesShared.js";

var QUICK_REVIEW = [["Quality", "Great quality products."], ["Quick delivery", "Quick delivery."], ["Great customer service", "Great customer service."], ["Improve service", "Service could be improved."]];

export function ReviewPage(props) {
  var pp = usePlugPay();
  var code = codeOf(props.code);
  var sale = pp.receiptsList.filter(function (r) { return codeOf(r.code) === code; })[0];
  var _r = PR.useState(0), rating = _r[0], setRating = _r[1];
  var _c = PR.useState(""), comment = _c[0], setComment = _c[1];
  var _e = PR.useState(""), err = _e[0], setErr = _e[1];
  if (!sale || !sale.sentAt) {
    return h(PublicShellX, { title: "Review link not found" },
      h("div", { className: "app-card" },
        h("div", { className: "app-card-title" }, "We couldn't find a receipt for this link."),
        h("div", { className: "app-card-sub" }, "Double check the link your seller sent you, or ask them to resend it."),
        h("div", { className: "app-actions" }, h(Link, { to: "/", className: "pp-btn secondary" }, "Return home"))));
  }
  var sp = pp.sellerProfile, st = reviewStatus(sale);
  if (st.state === "done") {
    return h(PublicShellX, { title: "Review submitted", subtitle: sp.bizName + " \u00b7 Receipt " + sale.code },
      h("section", { className: "app-card review-public" },
        h("div", { className: "app-card-title" }, "Thanks for rating your purchase"),
        h("div", { className: "rev-stars-big", style: { margin: "8px 0" } }, "\u2605".repeat(sale.review.rating) + "\u2606".repeat(5 - sale.review.rating)),
        sale.review.comment && h("div", { className: "rev-item-text" }, sale.review.comment),
        h("div", { className: "doc-note", style: { padding: "10px 0 0" } }, "Each receipt can be reviewed once."),
        h("div", { className: "app-actions" }, h(Link, { to: "/r/" + code, className: "pp-btn secondary" }, "Back to receipt"))));
  }
  if (st.state === "expired") {
    return h(PublicShellX, { title: "Review window closed", subtitle: sp.bizName + " \u00b7 Receipt " + sale.code },
      h("section", { className: "app-card review-public" },
        h("div", { className: "app-card-title" }, "This review link has expired"),
        h("div", { className: "app-card-sub" }, "Reviews can be left within 6 hours of getting your receipt."),
        h("div", { className: "app-actions" }, h(Link, { to: "/r/" + code, className: "pp-btn secondary" }, "Back to receipt"))));
  }
  function toggleChip(phrase) {
    setErr("");
    setComment(function (c) {
      if (c.indexOf(phrase) > -1) return c.replace(phrase, "").replace(/\s{2,}/g, " ").trim();
      return (c.trim() ? c.trim() + " " : "") + phrase;
    });
  }
  function submit() {
    var res = pp.submitReview(sale.code, { rating: rating, comment: comment });
    if (!res.ok) setErr(res.reason === "norating" ? "Tap a star to rate first." : res.reason === "expired" ? "The 6-hour review window has closed." : res.reason === "done" ? "This receipt was already reviewed." : "Couldn't submit your review.");
  }
  var LABELS = ["", "Poor", "Fair", "Good", "Very good", "Excellent"];
  return h(PublicShellX, { title: "Rate your purchase", subtitle: sp.bizName + " \u00b7 Receipt " + sale.code + " \u00b7 KSh " + sale.total.toLocaleString() },
    h("section", { className: "app-card review-public" },
      h("div", { className: "rv-note", style: { marginBottom: 6 } }, h("span", null, "\u23F1"), h("span", null, "One review per receipt. This link closes in " + timeLeft(st.msLeft) + ".")),
      h("div", { className: "star-picker" }, [1, 2, 3, 4, 5].map(function (n) { return h("button", { key: n, className: "star-btn" + (n <= rating ? " on" : ""), "aria-label": n + " star" + (n > 1 ? "s" : ""), onClick: function () { setRating(n); setErr(""); } }, "\u2605"); })),
      h("div", { className: "star-picker-label" }, rating ? rating + " of 5 \u00b7 " + LABELS[rating] : "Tap a star to rate"),
      h("div", { className: "rv-quick-h" }, "Quick comments"),
      h("div", { className: "rv-quick" }, QUICK_REVIEW.map(function (q) {
        return h("button", { key: q[0], type: "button", className: "rv-qc" + (comment.indexOf(q[1]) > -1 ? " on" : ""), onClick: function () { toggleChip(q[1]); } }, q[0]);
      })),
      h("textarea", { className: "pp-textarea", style: { marginTop: 12 }, placeholder: "Add more detail (optional)", value: comment, onChange: function (e) { setComment(e.target.value); } }),
      err && h("div", { className: "field-err", role: "alert" }, Ic("triangle-alert", 13), err),
      h("div", { className: "app-actions" }, h("button", { className: "pp-btn primary", onClick: submit }, "Submit review"))
    )
  );
}
