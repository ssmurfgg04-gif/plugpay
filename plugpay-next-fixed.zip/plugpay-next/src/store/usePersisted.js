import * as import_react from "react";

export function usePersisted(key, initial) {
    var k = "pp6:" + key;
    var st = (0, import_react.useState)(function () {
      try { var raw = window.localStorage.getItem(k); if (raw) return JSON.parse(raw); } catch (e) {}
      return typeof initial === "function" ? initial() : initial;
    });
    (0, import_react.useEffect)(function () { try { window.localStorage.setItem(k, JSON.stringify(st[0])); } catch (e) {} }, [st[0]]);
    (0, import_react.useEffect)(function () {
      function on(e) { if (e.key === k && e.newValue) { try { st[1](JSON.parse(e.newValue)); } catch (err) {} } }
      window.addEventListener("storage", on);
      return function () { window.removeEventListener("storage", on); };
    }, []);
    return st;
  }
