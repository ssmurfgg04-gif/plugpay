import { replaceRoute } from "../../../lib/router.js";
import { usePlugPay } from "../../../store/context.js";
import { h } from "../../common/h.js";
import { DashSignIn, PortalShell, TopBar } from "../../common/shells.js";
import { WithSkeleton } from "../../common/states.js";

export function SellerGate(props) {
  var pp = usePlugPay();
  return h(SellerPortalShell, { active: props.active, noDock: true },
    h("div", { style: { padding: 12 } }, h(DashSignIn, { msg: props.msg || "Sign in to your seller account to open your dashboard.", onClick: pp.openAuthModal }))
  );
}

/* ---- Portal shell and navigation ---- */
var SP_TABS = [
  ["dashboard", "Dashboard", "/seller/dashboard"],
  ["catalogue", "Catalogue", "/seller/catalogue"],
  ["profile", "Profile", "/seller/profile"],
  ["building", "Building", "/seller/building"]
];

function SellerBottomNav(props) {
  var active = props.active || "dashboard";

  return h("nav", {
    className: "seller-bottom-nav",
    "aria-label": "Seller navigation"
  },
    SP_TABS.map(function (tab) {
      return h("button", {
        key: tab[0],
        type: "button",
        className:
          "seller-bottom-nav-item" +
          (active === tab[0] ? " active" : ""),
        onClick: function () {
          replaceRoute(tab[2]);
        }
      }, tab[1]);
    })
  );
}

export function SellerPortalShell(props) {
  var pp = usePlugPay();
  var active = props.active;
  var showDock = (active === "dashboard" || active === "sales") && !props.noDock;
  return h(PortalShell, { shellClass: "sp-shell", wrapClass: "sp-wrap",
    header: h(TopBar, { title: "My Business", actions: h("button", { className: "tp-navbar-btn", style: { width: "auto", padding: "0 12px", fontSize: 10, fontWeight: 800 }, onClick: function () { pp.viewSellerProfile(); } }, "View profile") }),
    body: h("div", {
      style: {
        paddingBottom: 96
      }
    }, props.children),
    dock: showDock && h("div", { className: "sp-dock" }, h("button", { className: "sp-dock-btn rec", onClick: function () { pp.openModal("modal-record-sale"); } }, "\uFF0B Record a sale")),
    nav: h(SellerBottomNav, { active: active }) });
}

// Sales sub-pages live inside the same single seller shell (Sales tab)
export function AppShellSeller(props) {
  var pp = usePlugPay();
  if (!pp.merchantLoggedIn) return h(SellerGate, { active: "sales", msg: "Sign in to your seller account to continue." });
  return h(SellerPortalShell, { active: "sales" },
    h("div", { style: { padding: "16px 12px 40px" } },
      h("div", { className: "app-heading" }, h("div", null, h("h1", null, props.title), props.subtitle && h("p", null, props.subtitle))),
      h(WithSkeleton, { kind: "list", dep: props.title }, props.children)
    )
  );
}
