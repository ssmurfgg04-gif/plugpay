/* Verbatim behavior of the bundle's patched react/jsx-runtime: emoji in string children become inline SVG icons. */
import * as Real from "react/jsx-runtime";

const __TXT_TYPES = { option: 1, textarea: 1, title: 1, text: 1, tspan: 1, style: 1, script: 1 };

function __ppFixStr(str, type, keyBase) {
  var re = window.__ppEmojiRe; re.lastIndex = 0;
  if (!re.test(str)) return str; re.lastIndex = 0;
  if (__TXT_TYPES[type]) return str.replace(re, function (m, c) { return window.__PP_EMAP[c] ? "" : m; });
  var out = [], last = 0, m, n = 0;
  while ((m = re.exec(str))) {
    var name = window.__PP_EMAP[m[1]];
    if (!name) continue;
    if (m.index > last) out.push(str.slice(last, m.index));
    out.push(Real.jsx("span", { className: "pp-ic", dangerouslySetInnerHTML: { __html: window.__ppIcon(name) } }, keyBase + "i" + (n++)));
    last = m.index + m[0].length;
  }
  if (n === 0) return str;
  if (last < str.length) out.push(str.slice(last));
  return out;
}

export function __ppFixChildren(ch, type) {
  if (typeof ch === "string") return __ppFixStr(ch, type, "e");
  if (Array.isArray(ch)) {
    var changed = false;
    var r = ch.map(function (c, i) { if (typeof c === "string") { var f = __ppFixStr(c, type, "e" + i); if (f !== c) changed = true; return f; } return c; });
    return changed ? r : ch;
  }
  return ch;
}
if (typeof window !== "undefined") window.__ppFixChildren = __ppFixChildren;

function fix(type, config) {
  if (config && config.children != null && typeof type === "string") {
    var c = __ppFixChildren(config.children, type);
    if (c !== config.children) config = Object.assign({}, config, { children: c });
  }
  return config;
}
export const Fragment = Real.Fragment;
export function jsx(type, config, key) { return Real.jsx(type, fix(type, config), key); }
export function jsxs(type, config, key) { return Real.jsxs(type, fix(type, config), key); }
