import * as import_jsx_runtime from "../../../ppJsxRuntime.js";
import { usePlugPay } from "../../../store/context.js";

/* ---- Stages (buildings, floors and stalls, merchants, review) ---- */
export function Step1Building({ active = true }) {
  const { obBldgName, setObBldgName, obFloorsCount, setObFloorsCount, obFloorStalls, setObFloorStall, obTotalStalls } = usePlugPay();
  const n = Math.min(30, Math.max(0, parseInt(obFloorsCount) || 0));
  const floorKeys = Array.from({ length: n }, (_, i) => i === 0 ? "G" : String(i));
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: `ob-step${active ? " active" : ""}`, children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ob-step-label", children: "Step 1 of 2 \xB7 Building Info" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ob-section-title", children: "Building details" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ob-section-desc", children: "Enter the building's name, location, and contact. This becomes the building's permanent PlugPay listing." }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ob-field", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { className: "ob-label", children: "Building Name" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", { className: "ob-input", type: "text", placeholder: "e.g. Anniversary Towers", value: obBldgName, onChange: (e) => setObBldgName(e.target.value) })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ob-field", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { className: "ob-label", children: "Street / Location" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", { className: "ob-input", type: "text", placeholder: "e.g. Mama Ngina Street, Nairobi CBD" })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ob-field", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { className: "ob-label", children: "Google Maps Link \u2014 pinpoint exact location" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", { className: "ob-input", type: "url", placeholder: "https://maps.app.goo.gl/\u2026", inputMode: "url" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { fontSize: "10.5px", color: "var(--muted2)", fontFamily: "var(--fm)", marginTop: "6px", lineHeight: "1.5" }, children: [
        "\u{1F4CD} Open Google Maps, drop a pin, tap ",
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Share \u2192 Copy link" }),
        ", then paste here."
      ] })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ob-section-divider", style: { marginTop: "6px" }, children: "\u{1F3E2} Floors & Stalls" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ob-section-desc", style: { marginBottom: "10px" }, children: "Set the number of floors first, then enter how many stalls are on each floor. The total updates automatically." }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ob-field", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { className: "ob-label", children: "Number of Floors" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        "input",
        {
          className: "ob-input",
          type: "number",
          placeholder: "e.g. 6",
          min: 1,
          max: 30,
          value: obFloorsCount,
          onChange: (e) => setObFloorsCount(e.target.value)
        }
      )
    ] }),
    floorKeys.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { display: "flex", flexDirection: "column", gap: "0", border: "1.5px solid var(--border)", borderRadius: "var(--r6)", overflow: "hidden", marginBottom: "10px" }, children: floorKeys.map((k, i) => {
      var _a;
      return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(
        "div",
        {
          style: { display: "flex", alignItems: "center", justifyContent: "space-between", gap: "10px", padding: "9px 12px", borderTop: i === 0 ? "none" : "1px solid var(--border)" },
          children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { style: { fontSize: "12.5px", fontWeight: 700, color: "var(--ink)" }, children: k === "G" ? "Ground Floor" : `Floor ${k}` }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
              "input",
              {
                type: "number",
                min: 0,
                placeholder: "Stalls",
                style: { width: "90px", padding: "6px 10px", border: "1.5px solid var(--border2)", borderRadius: "var(--r6)", fontSize: "13px", fontFamily: "var(--fb)", textAlign: "right" },
                value: (_a = obFloorStalls[k]) != null ? _a : "",
                onChange: (e) => setObFloorStall(k, e.target.value)
              }
            )
          ]
        },
        k
      );
    }) }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { display: "flex", alignItems: "center", justifyContent: "space-between", background: "var(--accent-bg)", border: "1.5px solid var(--accent-bg2)", borderRadius: "var(--r6)", padding: "11px 14px", marginBottom: "14px" }, children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { style: { fontFamily: "var(--fm)", fontSize: "11px", fontWeight: 700, color: "var(--accent)", textTransform: "uppercase", letterSpacing: ".06em" }, children: "Total stalls" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { style: { fontFamily: "var(--fm)", fontSize: "22px", fontWeight: 900, color: "var(--accent)" }, children: obTotalStalls })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ob-section-divider", style: { marginTop: "6px" }, children: "\u{1F3E2} Landlord account" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ob-section-desc", style: { marginBottom: "10px" }, children: "This sets up an individual account for the building's landlord \u2014 they can sign in anytime to add more stall owners and complete monthly verification." }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ob-field", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { className: "ob-label", children: "Landlord / Manager Name" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", { className: "ob-input", type: "text", placeholder: "e.g. Samuel Kariuki" })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ob-row-2", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ob-field", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { className: "ob-label", children: "Landlord Phone" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", { className: "ob-input", type: "tel", placeholder: "07XX XXX XXX" })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ob-field", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { className: "ob-label", children: "Landlord Email" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", { className: "ob-input", type: "email", placeholder: "landlord@email.com" })
      ] })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ob-field", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { className: "ob-label", children: "Building Category" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", { className: "ob-select", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Mixed retail (clothing + electronics + food)" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Fashion & Textiles" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Electronics & Hardware" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Food & Groceries" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "General Market" })
      ] })
    ] })
  ] });
}
