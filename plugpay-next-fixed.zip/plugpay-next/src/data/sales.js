import { appBase } from "../lib/router.js";
import { codeOf } from "../lib/utils.js";

export var emptyRiderRow = (id) => ({ id, name: "", phone: "", role: "Boda rider" });

export var emptyItemRow = (id) => ({ id, name: "", price: "", productId: "", qty: 1, unit: "", category: "" });

export var REVIEW_WINDOW_MS = 6 * 60 * 60 * 1000;

export function receiptLink(c) { return appBase() + "/r/" + encodeURIComponent(codeOf(c)); }

export function reviewLink(c) { return appBase() + "/review/" + encodeURIComponent(codeOf(c)); }

export function invoiceLink(t) { return appBase() + "/pay/" + encodeURIComponent(t); }

export function reviewStatus(r) {
    if (!r) return { state: "none", msLeft: 0 };
    if (r.review) return { state: "done", msLeft: 0 };
    if (!r.sentAt) return { state: "notsent", msLeft: 0 };
    var left = new Date(r.sentAt).getTime() + REVIEW_WINDOW_MS - Date.now();
    return left > 0 ? { state: "open", msLeft: left } : { state: "expired", msLeft: 0 };
  }

export function waReceiptText(r, seller) {
    return "Hi " + (r.buyerName || "there") + ", thanks for buying from " + seller + ". Here's your PlugPay receipt for KSh " + Number(r.total).toLocaleString() + ":\n" + receiptLink(r.code) + "\n\nHow did we do? Rate your purchase (one review per receipt, link open for 6 hours):\n" + reviewLink(r.code);
  }

export function waInvoiceText(inv, seller) {
    return "Hi " + (inv.buyerName || "there") + ", here's your PlugPay invoice from " + seller + " for KSh " + Number(inv.total).toLocaleString() + ":\n" + invoiceLink(inv.token);
  }

export function ppDemoSales() {
    var DAY = 86400000, now = Date.now();
    function ago(d, hrs) { return new Date(now - d * DAY - (hrs || 0) * 3600000).toISOString(); }
    function it(name, qty, unit) { return { name: name, qty: qty, unit: unit, price: qty * unit, productId: "", category: "" }; }
    function sum(items) { return items.reduce(function (t, i) { return t + i.price; }, 0); }
    function rc(code, ref, name, phone, items, days, status, sent) {
      return { code: code, demo: true, buyerName: name, buyerPhone: phone, paymentRef: ref, items: items, total: sum(items), createdAt: ago(days, 2), sentAt: sent ? ago(days, 1) : null, stockApplied: !!sent, review: null, docStatus: status };
    }
    function iv(num, name, phone, items, days, status) {
      return { token: num, number: num, demo: true, buyerName: name, buyerPhone: phone, source: "WhatsApp", items: items, total: sum(items), status: "PENDING", docStatus: status, createdAt: ago(days, 3) };
    }
    return {
      receipts: [
        rc("RCP-001", "TKA3F8M2QD", "Grace Wanjiku", "0712 345 601", [it("Samsung Galaxy A15", 1, 18500)], 1, "COMPLETE", true),
        rc("RCP-002", "TKA3F9L7ZX", "Brian Otieno", "0722 118 402", [it("Wireless Earbuds", 2, 2800), it("USB-C Charger 65W", 3, 1200)], 2, "COMPLETE", true),
        rc("RCP-003", "TKB1N4C6RW", "Faith Njeri", "0733 904 117", [it("Wireless Earbuds", 2, 2800), it("USB-C Charger 65W", 2, 1200), it("Phone screen replacement", 1, 6300)], 3, "COMPLETE", true),
        rc("RCP-004", "TKB2P7D9HS", "Samuel Kiptoo", "0745 660 230", [it("Wireless Earbuds", 2, 2800), it("Phone case", 2, 1000)], 4, "PENDING", false),
        rc("RCP-005", "TKB3Q5E1JV", "Mercy Akinyi", "0701 552 889", [it("USB-C Charger 65W", 5, 1200), it("Laptop bag", 1, 3500), it("Wireless mouse", 1, 2600)], 5, "PENDING", false)
      ],
      invoices: [
        iv("INV-001", "Daniel Mwangi", "0711 207 944", [it("Tecno Camon 20", 1, 22000), it("USB-C Charger 65W", 1, 1200), it("Phone case", 1, 1300)], 2, "COMPLETE"),
        iv("INV-002", "Esther Chebet", "0723 481 075", [it("Wireless Earbuds", 2, 2800), it("USB-C Charger 65W", 1, 1200), it("Power bank 10,000mAh", 1, 5000)], 3, "COMPLETE"),
        iv("INV-003", "Kevin Omondi", "0734 612 380", [it("SSD 256GB", 1, 6500), it("RAM 8GB DDR4", 1, 5200), it("Windows install & setup", 1, 3500), it("Laptop bag", 1, 3500)], 1, "PENDING"),
        iv("INV-004", "Lucy Wambui", "0768 190 523", [it("Wireless Earbuds", 2, 2800), it("Screen guard", 4, 1000)], 0, "PENDING")
      ]
    };
  }
