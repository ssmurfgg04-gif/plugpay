import * as import_react from 'react';
import { navigate } from '../../../lib/router.js';
import { apiFetch, setAuthToken } from '../../../lib/backend.js';

export function useLandlordAuth(ctx) {
  const { openModal, closeModal, showToast } = ctx;
  const [llMethod,setLlMethodState]=import_react.useState('sms'); const [llStep,setLlStep]=import_react.useState('phone'); const [llAuthed,setLlAuthed]=import_react.useState(false);
  const [llPhone,setLlPhone]=import_react.useState(''); const [llOtp,setLlOtp]=import_react.useState(''); const [llPinLoginPhone,setLlPinLoginPhone]=import_react.useState(''); const [llPinLoginPin,setLlPinLoginPin]=import_react.useState(''); const [llSetPinValue,setLlSetPinValue]=import_react.useState(''); const [llHasPin,setLlHasPin]=import_react.useState(false);
  import_react.useEffect(()=>{ apiFetch('/api/auth/session').then(()=>setLlAuthed(true)).catch(()=>setLlAuthed(false)); },[]);
  const llSetMethod=m=>{setLlMethodState(m);setLlPhone('');};
  const openLandlordModal=import_react.useCallback(()=>{if(llAuthed){navigate('/landlord/dashboard');return;}setLlStep('phone');setLlPhone('');setLlOtp('');setLlPinLoginPhone('');setLlPinLoginPin('');setLlSetPinValue('');llSetMethod('sms');openModal('modal-landlord');},[llAuthed,openModal]);
  const llSendOTP=import_react.useCallback(async()=>{if(!llPhone.trim()){showToast('Enter your phone number');return;}try{await apiFetch('/api/auth/otp/start',{method:'POST',body:JSON.stringify({phone:llPhone,role:'landlord',method:llMethod})});showToast('OTP sent ✓');setLlStep('otp');}catch(e){showToast(e.message);}},[llPhone,llMethod,showToast]);
  const llGoBack=()=>setLlStep('phone'); const enter=()=>{setLlAuthed(true);closeModal('modal-landlord');navigate('/landlord/dashboard');};
  const llVerifyOTP=import_react.useCallback(async()=>{try{const r=await apiFetch('/api/auth/otp/verify',{method:'POST',body:JSON.stringify({phone:llPhone,token:llOtp,role:'landlord'})});setAuthToken(r.access_token);setLlStep('setpin');showToast('Verified ✓');}catch(e){showToast(e.message);}},[llPhone,llOtp,showToast]);
  const llSetPin=import_react.useCallback(async()=>{if(!/^\d{6}$/.test(llSetPinValue.trim())){showToast('Enter a 6-digit PIN');return;}try{await apiFetch('/api/auth/pin/set',{method:'POST',body:JSON.stringify({pin:llSetPinValue})});setLlHasPin(true);showToast('PIN set ✓');enter();}catch(e){showToast(e.message);}},[llSetPinValue,showToast]);
  const llShowPinLogin=()=>setLlStep('pinlogin'); const llGoBackFromPin=()=>setLlStep('phone');
  const llPinLogin=import_react.useCallback(async()=>{if(!llPinLoginPhone.trim()||!/^\d{6}$/.test(llPinLoginPin.trim())){showToast('Enter your phone number and 6-digit PIN');return;}try{const r=await apiFetch('/api/auth/pin/login',{method:'POST',body:JSON.stringify({phone:llPinLoginPhone,pin:llPinLoginPin})});setAuthToken(r.access_token);showToast('Signed in ✓');enter();}catch(e){showToast(e.message);}},[llPinLoginPhone,llPinLoginPin,showToast]);
  return {llMethod,llSetMethod,llStep,llAuthed,openLandlordModal,llPhone,setLlPhone,llOtp,setLlOtp,llPinLoginPhone,setLlPinLoginPhone,llPinLoginPin,setLlPinLoginPin,llSetPinValue,setLlSetPinValue,llSendOTP,llGoBack,llVerifyOTP,llSetPin,llShowPinLogin,llGoBackFromPin,llPinLogin};
}
