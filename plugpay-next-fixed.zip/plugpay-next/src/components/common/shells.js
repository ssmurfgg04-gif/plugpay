import { PR, h } from "./h.js";
import { Link, PP_CONFIG, goBack } from "./routing.js";
import { WithSkeleton } from "./states.js";
import { LOGO_DATA_URI } from "./ui.js";

export function DashSignIn(props) {
  return h("div", { className: "app-card" },
    h("div", { className: "app-card-title" }, "Sign in required"),
    h("div", { className: "app-card-sub" }, props.msg),
    h("div", { className: "app-actions" }, h("button", { className: "pp-btn primary", onClick: props.onClick }, "Sign in"))
  );
}

/* Generic portal frame: header / body / dock / nav are slots. */
export function TopBar(p) {
  var back = h("button", { className: p.variant === "app" ? "modal-back pg-back" : "tp-navbar-btn", "aria-label": "Back", onClick: goBack }, "\u2190");
  var close = h("button", { className: "modal-close pg-x", "aria-label": "Close", onClick: goBack }, "\u2715");
  if (p.variant === "app") return h("header", { className: "app-topbar" }, h("div", { className: "app-topbar-inner" }, back, h(Link, { to: "/", className: "app-brand" }, h("img", { src: LOGO_DATA_URI, alt: "PlugPay" })), h("div", { className: "app-role" }, p.title), close));
  return h("div", { className: "tp-navbar-fixed" }, back, h("div", { className: "tp-navbar-title" }, p.title), h("div", { className: "sp-right" }, p.actions, close));
}

export function PortalShell(p) {
  var kids = [h("div", { className: "sp-sticky" }, p.header), p.body, p.dock, p.nav];
  if (p.wrapClass) return h("div", { className: p.shellClass }, h.apply(null, ["div", { className: p.wrapClass }].concat(kids)));
  return h.apply(null, ["div", { className: p.shellClass }].concat(kids));
}

export function AppShellX(props) {
  var role = props.role;
  return h(PortalShell, { shellClass: "app-shell", header: h(TopBar, { variant: "app", title: role + " portal" }),
    body: h("main", { className: "app-main" },
      h("div", { className: "app-heading" }, h("div", null, h("div", { className: "eyebrow" }, role + " workspace"), h("h1", null, props.title), props.subtitle && h("p", null, props.subtitle))),
      h(WithSkeleton, { kind: "list", dep: props.title }, props.children)),
    nav: h(PortalBottomNav, { items: PP_CONFIG.nav[role === "Agent" ? "agent" : "landlord"], active: props.active, role: role }) });
}

export function PublicShellX(props) {
  var children = props.children, title = props.title, subtitle = props.subtitle;
  return h("div", { className: "public-inner-shell" },
    h("header", { className: "inner-public-header" },
      h("button", { className: "modal-back pg-back", "aria-label": "Back", onClick: goBack }, "\u2190"),
      h(Link, { to: "/", className: "inner-brand" }, h("img", { src: LOGO_DATA_URI, alt: "PlugPay" })),
      h("button", { className: "modal-close pg-x", "aria-label": "Close", onClick: goBack }, "\u2715")
    ),
    (title || subtitle) && h("div", { className: "inner-page-heading" },
      h("div", { className: "eyebrow" }, "PlugPay"),
      title && h("h1", null, title),
      subtitle && h("p", null, subtitle)
    ),
    children
  );
}

function BottomNav(props) {
  return h("nav", { className: props.className, "aria-label": props.label, style: props.style },
    props.items.map(function (it) {
      var cls = props.itemClass + (props.active === it[0] ? " on" : "");
      return props.onSelect
        ? h("button", { key: it[0], type: "button", className: cls, onClick: function () { props.onSelect(it[0], it); } }, it[1])
        : h(Link, { key: it[0], to: it[2], className: cls }, it[1]);
    }));
}

function PortalBottomNav(p) {
  return h(BottomNav, { className: p.role === "Agent" ? "agent-bottom-nav" : "landlord-bottom-nav", itemClass: "pbn-item", style: { gridTemplateColumns: "repeat(" + p.items.length + ", 1fr)" }, active: p.active, items: p.items });
}

export function RouteSheet(props) {
  PR.useEffect(function () { document.body.style.overflow = "hidden"; return function () { document.body.style.overflow = ""; }; }, []);
  var exit = props.onClose || goBack;
  return h("div", { className: "modal-overlay on", style: { zIndex: 900 } },
    h("div", { className: props.innerClassName || "modal" },
      !props.hideBar && h("div", { className: "modal-bar" },
        h("button", { className: "modal-back", "aria-label": "Back", onClick: exit }, "\u2190"),
        h("button", { className: "modal-close", "aria-label": "Close", onClick: exit }, "\u2715")),
      props.children));
}

export function NotFoundPage(props) {
  return h(PublicShellX, { title: props.title }, h("div", { className: "app-card" }, h("div", { className: "app-card-sub" }, props.sub), h("div", { className: "app-actions" }, h(Link, { to: props.to || "/search", className: "pp-btn primary" }, props.cta || "Search PlugPay"))));
}
