-- ═══════════════════════════════════════════════════════════════════════════════════════════
-- PlugPay — complete Supabase schema (single file, safe to re-run)
--
-- HOW TO USE
--   1. Supabase dashboard → SQL Editor → New query → paste this whole file → Run.
--   2. Authentication → Providers → enable "Phone" (needs an SMS provider; for development you can
--      skip this and use DEV_AUTH=true, see .env.example).
--   3. Copy Project URL, anon key and service_role key into .env.local (see .env.example).
--
-- WHAT IT CREATES  18 tables, 5 enums, indexes, updated_at triggers, a profile-on-signup trigger,
--   row-level security, the atomic sale/invoice functions, and the lockdown that keeps the public
--   anon key away from your data (the app only talks to the database through its own API).
-- ═══════════════════════════════════════════════════════════════════════════════════════════

create extension if not exists pgcrypto;

-- Enum types (guarded so the file can be re-run)
do $$ begin create type public.app_role as enum ('seller','agent','landlord','admin'); exception when duplicate_object then null; end $$;
do $$ begin create type public.verification_status as enum ('pending','verified','revoked'); exception when duplicate_object then null; end $$;
do $$ begin create type public.claim_status as enum ('invited','claimed','verified','expired','revoked'); exception when duplicate_object then null; end $$;
do $$ begin create type public.document_status as enum ('pending','complete'); exception when duplicate_object then null; end $$;
do $$ begin create type public.invoice_status as enum ('pending','paid','cancelled','expired'); exception when duplicate_object then null; end $$;







create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  phone text,
  email text,
  full_name text,
  roles public.app_role[] not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.buildings (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  address text not null,
  floors integer not null default 1 check (floors > 0),
  category text,
  maps_url text,
  owner_id uuid references public.profiles(id) on delete set null,
  agent_id uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.floors (
  id uuid primary key default gen_random_uuid(),
  building_id uuid not null references public.buildings(id) on delete cascade,
  label text not null,
  floor_number integer not null,
  created_at timestamptz not null default now(),
  unique(building_id, floor_number)
);

create table if not exists public.stalls (
  id uuid primary key default gen_random_uuid(),
  building_id uuid not null references public.buildings(id) on delete cascade,
  floor_id uuid not null references public.floors(id) on delete cascade,
  stall_number text not null,
  status text not null default 'vacant' check (status in ('vacant','occupied','pending')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(floor_id, stall_number)
);

create table if not exists public.sellers (
  id uuid primary key default gen_random_uuid(),
  user_id uuid unique references public.profiles(id) on delete set null,
  business_name text not null,
  owner_name text not null,
  phone text not null,
  whatsapp text,
  category text,
  role text,
  bio text,
  address text,
  established_year integer,
  about text,
  instagram text,
  tiktok text,
  facebook text,
  pay_method text,
  paybill text,
  account_number text,
  verification_status public.verification_status not null default 'pending',
  verification_note text,
  verified_by uuid references public.profiles(id) on delete set null,
  verified_at timestamptz,
  trust_score numeric(5,2) not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.sellers add column if not exists pay_method text;

create table if not exists public.stall_assignments (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid not null references public.sellers(id) on delete cascade,
  stall_id uuid not null references public.stalls(id) on delete restrict,
  status public.verification_status not null default 'pending',
  assigned_by uuid references public.profiles(id) on delete set null,
  verified_by uuid references public.profiles(id) on delete set null,
  verified_at timestamptz,
  started_at timestamptz not null default now(),
  ended_at timestamptz,
  created_at timestamptz not null default now()
);

create unique index if not exists one_active_assignment_per_seller on public.stall_assignments(seller_id) where ended_at is null;
create unique index if not exists one_active_assignment_per_stall on public.stall_assignments(stall_id) where ended_at is null;

create table if not exists public.seller_documents (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid not null references public.sellers(id) on delete cascade,
  kind text not null,
  storage_path text,
  status public.document_status not null default 'pending',
  uploaded_at timestamptz not null default now(),
  verified_at timestamptz,
  verified_by uuid references public.profiles(id) on delete set null
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid not null references public.sellers(id) on delete cascade,
  name text not null,
  description text,
  category text,
  image_url text,
  price_minor bigint not null check (price_minor >= 0),
  currency char(3) not null default 'KES',
  stock integer not null default 0 check (stock >= 0),
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.invoices (
  id uuid primary key default gen_random_uuid(),
  token text unique not null,
  seller_id uuid not null references public.sellers(id) on delete restrict,
  buyer_name text not null,
  buyer_phone text not null,
  status public.invoice_status not null default 'pending',
  document_status public.document_status not null default 'pending',
  total_minor bigint not null check (total_minor >= 0),
  currency char(3) not null default 'KES',
  payment_ref text,
  created_at timestamptz not null default now(),
  paid_at timestamptz,
  expires_at timestamptz
);

create table if not exists public.invoice_items (
  id uuid primary key default gen_random_uuid(),
  invoice_id uuid not null references public.invoices(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  name_snapshot text not null,
  category_snapshot text,
  qty integer not null check (qty > 0),
  unit_price_minor bigint not null check (unit_price_minor >= 0),
  line_total_minor bigint not null check (line_total_minor >= 0)
);

create table if not exists public.sales (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid not null references public.sellers(id) on delete restrict,
  invoice_id uuid references public.invoices(id) on delete set null,
  buyer_name text not null,
  buyer_phone text not null,
  payment_ref text unique,
  total_minor bigint not null check (total_minor >= 0),
  currency char(3) not null default 'KES',
  status text not null default 'confirmed' check (status in ('confirmed','pending','cancelled')),
  document_status public.document_status not null default 'complete',
  created_at timestamptz not null default now(),
  sent_at timestamptz
);

create table if not exists public.sale_items (
  id uuid primary key default gen_random_uuid(),
  sale_id uuid not null references public.sales(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  name_snapshot text not null,
  category_snapshot text,
  qty integer not null check (qty > 0),
  unit_price_minor bigint not null check (unit_price_minor >= 0),
  line_total_minor bigint not null check (line_total_minor >= 0)
);

create table if not exists public.receipts (
  id uuid primary key default gen_random_uuid(),
  sale_id uuid unique not null references public.sales(id) on delete cascade,
  code text unique not null,
  sent_at timestamptz,
  review_expires_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.reviews (
  id uuid primary key default gen_random_uuid(),
  receipt_id uuid unique not null references public.receipts(id) on delete cascade,
  seller_id uuid not null references public.sellers(id) on delete cascade,
  buyer_name text,
  rating integer not null check (rating between 1 and 5),
  comment text,
  created_at timestamptz not null default now()
);

create table if not exists public.vouches (
  id uuid primary key default gen_random_uuid(),
  voucher_id uuid not null references public.sellers(id) on delete cascade,
  vouchee_id uuid not null references public.sellers(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique(voucher_id, vouchee_id)
);

create table if not exists public.claims (
  id uuid primary key default gen_random_uuid(),
  token text unique not null,
  seller_id uuid references public.sellers(id) on delete cascade,
  stall_id uuid references public.stalls(id) on delete set null,
  agent_id uuid references public.profiles(id) on delete set null,
  building_id uuid references public.buildings(id) on delete set null,
  phone text not null,
  status public.claim_status not null default 'invited',
  expires_at timestamptz,
  claimed_at timestamptz,
  verified_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.riders (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid not null references public.sellers(id) on delete cascade,
  name text not null,
  phone text,
  trusted boolean not null default false,
  created_at timestamptz not null default now()
);

-- Transitional browser-state bridge. It allows the current UI to become server-backed
-- without rewriting every existing visual component in one release. Core business records
-- remain normalized above.
create table if not exists public.ui_state (
  owner_id uuid not null references public.profiles(id) on delete cascade,
  state_key text not null,
  state jsonb not null,
  updated_at timestamptz not null default now(),
  primary key(owner_id, state_key)
);

create index if not exists buildings_name_idx on public.buildings using gin (to_tsvector('simple', coalesce(name,'') || ' ' || coalesce(address,'')));
create index if not exists sellers_search_idx on public.sellers using gin (to_tsvector('simple', coalesce(business_name,'') || ' ' || coalesce(owner_name,'') || ' ' || coalesce(category,'')));
create index if not exists products_seller_idx on public.products(seller_id);
create index if not exists claims_phone_idx on public.claims(phone);
create index if not exists sales_seller_created_idx on public.sales(seller_id, created_at desc);
create index if not exists reviews_seller_idx on public.reviews(seller_id, created_at desc);
create index if not exists invoices_seller_created_idx on public.invoices(seller_id, created_at desc);
create index if not exists invoice_items_invoice_idx on public.invoice_items(invoice_id);
create index if not exists sale_items_sale_idx on public.sale_items(sale_id);
create index if not exists stall_assignments_seller_idx on public.stall_assignments(seller_id);
create index if not exists stalls_building_idx on public.stalls(building_id);
create index if not exists profiles_phone_idx on public.profiles(phone);

create or replace function public.touch_updated_at() returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end; $$;

drop trigger if exists profiles_touch on public.profiles;
create trigger profiles_touch before update on public.profiles for each row execute function public.touch_updated_at();
drop trigger if exists buildings_touch on public.buildings;
create trigger buildings_touch before update on public.buildings for each row execute function public.touch_updated_at();
drop trigger if exists stalls_touch on public.stalls;
create trigger stalls_touch before update on public.stalls for each row execute function public.touch_updated_at();
drop trigger if exists sellers_touch on public.sellers;
create trigger sellers_touch before update on public.sellers for each row execute function public.touch_updated_at();
drop trigger if exists products_touch on public.products;
create trigger products_touch before update on public.products for each row execute function public.touch_updated_at();

-- Keep profile row synchronized when Supabase Auth creates a user.
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles(id, phone, email, full_name)
  values(new.id, case when new.phone is null or new.phone = '' then null when left(new.phone,1) = '+' then new.phone else '+' || new.phone end, new.email, coalesce(new.raw_user_meta_data->>'full_name',''))
  on conflict (id) do update set phone=excluded.phone, email=excluded.email;
  return new;
end; $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.buildings enable row level security;
alter table public.floors enable row level security;
alter table public.stalls enable row level security;
alter table public.sellers enable row level security;
alter table public.stall_assignments enable row level security;
alter table public.seller_documents enable row level security;
alter table public.products enable row level security;
alter table public.invoices enable row level security;
alter table public.invoice_items enable row level security;
alter table public.sales enable row level security;
alter table public.sale_items enable row level security;
alter table public.receipts enable row level security;
alter table public.reviews enable row level security;
alter table public.vouches enable row level security;
alter table public.claims enable row level security;
alter table public.riders enable row level security;
alter table public.ui_state enable row level security;

-- Public reads are deliberately limited to discovery-safe data. Server routes use the
-- service role for writes after ownership checks.
drop policy if exists "public read seller directory" on public.sellers;
create policy "public read seller directory" on public.sellers for select using (true);
drop policy if exists "public read buildings" on public.buildings;
create policy "public read buildings" on public.buildings for select using (true);
drop policy if exists "public read products" on public.products;
create policy "public read products" on public.products for select using (active = true);
drop policy if exists "public read reviews" on public.reviews;
create policy "public read reviews" on public.reviews for select using (true);
drop policy if exists "own profile" on public.profiles;
create policy "own profile" on public.profiles for select using (auth.uid() = id);
drop policy if exists "own ui state" on public.ui_state;
create policy "own ui state" on public.ui_state for all using (auth.uid() = owner_id) with check (auth.uid() = owner_id);

-- Service-role API performs business writes; direct client writes are intentionally absent.

-- Atomic sale creation used by the API. The client never supplies the final total.
create or replace function public.create_sale_atomic(
  p_seller_id uuid,
  p_buyer_name text,
  p_buyer_phone text,
  p_payment_ref text,
  p_items jsonb,
  p_send boolean default true
) returns jsonb
language plpgsql security definer set search_path=public
as $$
declare
  v_sale_id uuid := gen_random_uuid();
  v_receipt_id uuid := gen_random_uuid();
  v_code text;
  v_total bigint := 0;
  item jsonb;
  v_product uuid;
  v_qty integer;
  v_unit bigint;
  v_stock integer;
begin
  if p_buyer_name is null or trim(p_buyer_name) = '' or p_buyer_phone is null or trim(p_buyer_phone) = '' then raise exception 'Buyer name and phone are required'; end if;
  if p_items is null or jsonb_array_length(p_items) = 0 then raise exception 'At least one sale item is required'; end if;
  if p_payment_ref is not null and exists(select 1 from sales where payment_ref = upper(trim(p_payment_ref))) then raise exception 'Payment reference already exists'; end if;

  for item in select * from jsonb_array_elements(p_items) loop
    v_product := nullif(item->>'productId','')::uuid;
    v_qty := greatest(1, coalesce((item->>'qty')::integer,1));
    if v_product is not null then
      select price_minor, stock into v_unit, v_stock from products where id=v_product and seller_id=p_seller_id and active=true for update;
      if not found then raise exception 'Product not found'; end if;
      if v_stock < v_qty then raise exception 'Not enough stock for product %', v_product; end if;
    else
      v_unit := round(((item->>'price')::numeric) * 100);
      if v_unit < 0 then raise exception 'Invalid price'; end if;
    end if;
    v_total := v_total + v_unit * v_qty;
  end loop;

  insert into sales(id,seller_id,buyer_name,buyer_phone,payment_ref,total_minor,status,document_status,sent_at)
  values(v_sale_id,p_seller_id,trim(p_buyer_name),trim(p_buyer_phone),nullif(upper(trim(p_payment_ref)),''),v_total,'confirmed','complete',case when p_send then now() else null end);

  for item in select * from jsonb_array_elements(p_items) loop
    v_product := nullif(item->>'productId','')::uuid;
    v_qty := greatest(1, coalesce((item->>'qty')::integer,1));
    if v_product is not null then
      select price_minor into v_unit from products where id=v_product and seller_id=p_seller_id for update;
      update products set stock=stock-v_qty where id=v_product;
    else
      v_unit := round(((item->>'price')::numeric) * 100);
    end if;
    insert into sale_items(sale_id,product_id,name_snapshot,category_snapshot,qty,unit_price_minor,line_total_minor)
    values(v_sale_id,v_product,coalesce(item->>'name','Item'),item->>'category',v_qty,v_unit,v_unit*v_qty);
  end loop;

  v_code := '#' || coalesce(upper(trim(p_payment_ref)), upper(substr(replace(v_sale_id::text,'-',''),1,10)));
  insert into receipts(id,sale_id,code,sent_at,review_expires_at) values(v_receipt_id,v_sale_id,v_code,case when p_send then now() else null end,case when p_send then now()+interval '6 hours' else null end);
  return jsonb_build_object('sale_id',v_sale_id,'receipt_id',v_receipt_id,'code',v_code,'total_minor',v_total);
end; $$;

create or replace function public.create_invoice_atomic(
  p_seller_id uuid,
  p_buyer_name text,
  p_buyer_phone text,
  p_items jsonb
) returns jsonb
language plpgsql security definer set search_path=public
as $$
declare v_invoice_id uuid:=gen_random_uuid(); v_token text:='inv'||substr(replace(v_invoice_id::text,'-',''),1,16); v_total bigint:=0; item jsonb; v_product uuid; v_qty integer; v_unit bigint;
begin
  if jsonb_array_length(p_items)=0 then raise exception 'At least one invoice item is required'; end if;
  for item in select * from jsonb_array_elements(p_items) loop
    v_product:=nullif(item->>'productId','')::uuid; v_qty:=greatest(1,coalesce((item->>'qty')::integer,1));
    if v_product is not null then select price_minor into v_unit from products where id=v_product and seller_id=p_seller_id and active=true; if not found then raise exception 'Product not found'; end if;
    else v_unit:=round(((item->>'price')::numeric)*100); end if;
    v_total:=v_total+v_unit*v_qty;
  end loop;
  insert into invoices(id,token,seller_id,buyer_name,buyer_phone,total_minor,status,document_status,expires_at) values(v_invoice_id,v_token,p_seller_id,trim(p_buyer_name),trim(p_buyer_phone),v_total,'pending','pending',now()+interval '7 days');
  for item in select * from jsonb_array_elements(p_items) loop
    v_product:=nullif(item->>'productId','')::uuid; v_qty:=greatest(1,coalesce((item->>'qty')::integer,1));
    if v_product is not null then select price_minor into v_unit from products where id=v_product and seller_id=p_seller_id; else v_unit:=round(((item->>'price')::numeric)*100); end if;
    insert into invoice_items(invoice_id,product_id,name_snapshot,category_snapshot,qty,unit_price_minor,line_total_minor) values(v_invoice_id,v_product,coalesce(item->>'name','Item'),item->>'category',v_qty,v_unit,v_unit*v_qty);
  end loop;
  return jsonb_build_object('invoice_id',v_invoice_id,'token',v_token,'total_minor',v_total);
end; $$;

-- ═══════════════ LOCKDOWN (formerly 002_lockdown.sql) ═══════════════
-- PlugPay: run AFTER 001_initial.sql.
-- The browser never talks to Supabase directly: every request goes through the Next.js API, which uses the
-- service-role key. The anon key is public (it ships in NEXT_PUBLIC_*), so remove everything it and signed-in
-- users could do straight against PostgREST: reading all seller columns (user_id, verification_note, ...) and
-- calling the SECURITY DEFINER sale/invoice functions to forge sales and receipts for any seller.
revoke all on all tables in schema public from anon, authenticated;
revoke all on all sequences in schema public from anon, authenticated;
revoke execute on all functions in schema public from public, anon, authenticated;
alter default privileges in schema public revoke all on tables from anon, authenticated;
alter default privileges in schema public revoke all on sequences from anon, authenticated;
alter default privileges in schema public revoke execute on functions from public, anon, authenticated;
grant execute on all functions in schema public to service_role;
