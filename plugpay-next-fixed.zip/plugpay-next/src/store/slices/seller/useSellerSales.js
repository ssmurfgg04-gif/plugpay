/* useSellerSales — "sellerSales" group of the PlugPay store, extracted from PlugPayProvider.
   Statements are the original ones, in their original relative order. Names owned by other groups arrive through the shared
   per-render context object (ctx): groups that run earlier are destructured below, groups that run later are read lazily as ctx.name. */
import * as import_react from "react";
import { emptyItemRow, ppDemoSales } from "../../../data/sales.js";
import { usePersisted } from "../../usePersisted.js";

export function useSellerSales(ctx) {
    const { openModal } = ctx;
    const openInvoiceInProfile = (0, import_react.useCallback)(() => {
      openModal("modal-merchant");
      openModal("modal-record-sale");
    }, [openModal]);
    const openReceiptInProfile = (0, import_react.useCallback)(() => {
      openModal("modal-merchant");
      openModal("modal-record-sale");
    }, [openModal]);
    const stockRef = (0, import_react.useRef)([]);
    const invoicesListRef = (0, import_react.useRef)([]);
    const rsIdRef = (0, import_react.useRef)(1);
    const [rsName, setRsName] = (0, import_react.useState)("");
    const [rsPhone, setRsPhone] = (0, import_react.useState)("");
    const [rsCode, setRsCode] = (0, import_react.useState)("");
    const [rsItems, setRsItems] = (0, import_react.useState)([emptyItemRow(0)]);
    const [rsSubmitting, setRsSubmitting] = (0, import_react.useState)(false);
    const [receipt, setReceipt] = (0, import_react.useState)({ kind: "receipt", code: "", name: "", rawPhone: "", phone: "", items: [], total: 0 });
    const addItemRow = (0, import_react.useCallback)((prefix) => {
      setRsItems((r) => [...r, emptyItemRow(rsIdRef.current++)]);
    }, []);
    const removeItemRow = (0, import_react.useCallback)((prefix, id) => {
      setRsItems((r) => r.length <= 1 ? r : r.filter((i) => i.id !== id));
    }, []);
    const updateItemRow = (0, import_react.useCallback)((prefix, id, patch) => {
      setRsItems((r) => r.map((i) => i.id === id ? { ...i, ...patch } : i));
    }, []);
    const rsTotal = rsItems.reduce((s, i) => s + (Number(i.price) || 0), 0);
    const startSaleFromProduct = (0, import_react.useCallback)((p) => {
      setRsName("");
      setRsPhone("");
      setRsCode("");
      setRsItems([{ id: rsIdRef.current++, name: p.name, price: String(p.price), productId: p.id, qty: 1, unit: String(p.price), category: p.category }]);
    }, []);
    const [receiptsList, setReceiptsList] = usePersisted("receipts", () => ppDemoSales().receipts);
    const [invoicesList, setInvoicesList] = usePersisted("invoices", () => ppDemoSales().invoices);
    (0, import_react.useEffect)(() => {
      try {
        if (window.localStorage.getItem("pp6:demoSalesSeeded")) return;
        window.localStorage.setItem("pp6:demoSalesSeeded", "1");
      } catch (e) { return; }
      const d = ppDemoSales();
      setReceiptsList((l) => l.concat(d.receipts.filter((x) => !l.some((y) => y.code === x.code))));
      setInvoicesList((l) => l.concat(d.invoices.filter((x) => !l.some((y) => y.token === x.token))));
    }, []);
    return {
      stockRef,
      invoicesListRef,
      invoicesList,
      receiptsList,
      rsItems,
      rsName,
      rsPhone,
      rsCode,
      setReceiptsList,
      setReceipt,
      setInvoicesList,
      setRsName,
      setRsPhone,
      setRsCode,
      setRsItems,
      rsIdRef,
      openInvoiceInProfile,
      openReceiptInProfile,
      rsTotal,
      rsSubmitting,
      addItemRow,
      removeItemRow,
      updateItemRow,
      startSaleFromProduct,
      receipt
    };
}
