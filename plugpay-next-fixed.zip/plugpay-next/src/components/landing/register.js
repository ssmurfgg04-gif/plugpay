import { PP_registry } from "../common/registry.js";
import { Contrast } from "./Contrast.js";
import { FAQ } from "./FAQ.js";
import { Footer } from "./Footer.js";
import { Friction } from "./Friction.js";
import { Hero } from "./Hero.js";
import { HowItWorks } from "./HowItWorks.js";
import { Navbar } from "./Navbar.js";
import { Pricing } from "./Pricing.js";

/* ---- Wiring: registers this group's modals, slots, pages and routes ---- */
PP_registry.register("landing", "navbar", Navbar, 10);

PP_registry.register("landing", "hero", Hero, 20);

PP_registry.register("landing", "friction", Friction, 30);

PP_registry.register("landing", "how", HowItWorks, 40);

PP_registry.register("landing", "contrast", Contrast, 50);

PP_registry.register("landing", "pricing", Pricing, 60);

PP_registry.register("landing", "faq", FAQ, 70);

PP_registry.register("landing", "footer", Footer, 80);
