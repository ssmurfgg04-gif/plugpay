import { navigate } from "../../lib/router.js";
import { ppSlug } from "../../lib/utils.js";
import { usePlugPay } from "../../store/context.js";
import { BuildingViewContainer } from "./BuildingViewContainer.js";
import { ppResolveBuilding } from "./buildingData.js";
import { PR, h } from "../common/h.js";
import { NotFoundPage, RouteSheet } from "../common/shells.js";

export function BuildingPage(props) {
  var pp = usePlugPay();
  var found = ppResolveBuilding(props.id, pp.lbAccounts, pp.agentBuildings);
  PR.useEffect(function () { pp.setBldgFloor("G"); }, [props.id]);
  if (!found) return h(NotFoundPage, { title: "Building not found", sub: "We couldn't find a building at this link." });
  return h(RouteSheet, null, h(BuildingViewContainer, { id: props.id, onMerchantSelect: function (m) { navigate("/sellers/" + ppSlug(m.name)); } }));
}
