# Changes made while checking this build

1. `app/[[...slug]]/ClientRoot.jsx` — the app now mounts inside `<div id="root">`.
   `app/globals.css` has 68 selectors of the form `#root > nav.nav`, `#root > section.hero`, ... (the landing page's
   brand colour `--mint:#8b008b` and white button text). Nothing created `#root`, so none of them matched.
2. `src/components/public-view/tabs/ProfileTab.js` line 188 — `jsxs` -> `jsx` for a single (non-array) child.
   Production React ignores this; `npm run dev` logged "Static children should always be an array" on every page.
3. `package.json` — `next` set to `16.3.8` (patched release; `npm audit` reports 0 vulnerabilities).
4. `app/api/auth/logout/route.js` and `app/api/auth/session/route.js` — the import of `src/server/supabase.js` had one `../`
   too many (5 instead of 4), so `next build` failed with "Module not found". Fixed; all 28 files under `app/` now resolve.

Verified: `npm install`, `next build` (26 routes: the app + 24 API routes) and booting the served pages.
Data API routes need the Supabase values from `.env.example` (they return 500 "Supabase environment is not configured" without them).

## Backend wiring check (end to end against a real Postgres + PostgREST)

Found and fixed:
5. `src/server/supabase.js` — the `Query` helper had no `then()`, so every `await db.from(...).select/insert/update/upsert(...)`
   returned the unexecuted query object and never contacted the database. Added `then()`. (Before this, only `rpc()` calls worked.)
6. `app/api/auth/otp/verify` and `app/api/auth/pin/login` — expected `data.session`, but Supabase Auth's REST API returns the
   session flat (`access_token`, `user`, ...); only supabase-js wraps it. Sign-in always failed. Now accepts both shapes.
7. All dynamic API routes (`seller/catalogue/[id]`, `seller/sales/[token]`, `seller/receipts/[code]`, `reviews/[id]`,
   `buildings/[id]`, `buildings/[id]/stalls`, `claims/[token]`, `sellers/[sellerId]`) — `params` is a Promise in Next 15+/16;
   now `await ctx.params`.
8. `cleanPhone()` — now normalises to E.164 (`0712 345 678` -> `+254712345678`); Supabase phone auth rejects local formats and
   the UI sends numbers as typed.
9. `app/api/landlord/verify` — any signed-in user could verify any stall assignment (including their own). Now requires the
   building's `owner_id` or `agent_id`.
10. the lockdown section of `supabase/schema.sql` (was `002_lockdown.sql`) — anon/authenticated roles could call `create_sale_atomic` / `create_invoice_atomic` directly
   (forging sales and receipts for any seller) and read all `sellers` columns. Revoked.

Known gaps (not fixed): buyer-facing pages `/r/[code]`, `/pay/[token]`, `/review/[code]` read only the seller's own browser/`ui_state`,
so a buyer opening the link on their own phone sees "not found" (there is no public invoice-by-token API route, and the pages do
not call `/api/seller/receipts/[code]`). Demo records (RCP-001, INV-001 ...) are still seeded into real seller accounts.
The UI does not yet call `/api/claims`, `/api/landlord/verify` or `/api/buildings/[id]/stalls`.

## Dev login (temporary)
`DEV_AUTH=true` (see `.env.example`) turns on a fixed login for development: **OTP `123456`** and **PIN `121212`** work for ANY phone
number, and no SMS provider is needed. Implemented in `src/server/devAuth.js` and called from `auth/otp/start`, `auth/otp/verify`
and `auth/pin/login`. It creates/updates the Supabase user through the Auth admin API (service-role key), so everything downstream
(RLS, profiles, sellers, tokens) is the real thing.
It is an authentication bypass: with the flag on, anyone who knows a seller's phone number can log in as them. It is off unless
`DEV_AUTH=true`, and forced off when `VERCEL_ENV=production`. Delete `devAuth.js`, its three call sites and the env line before launch.

## Full schema + buyer side wired (this release)
- `supabase/schema.sql` — the complete Supabase schema in ONE re-runnable file (18 tables, enums, indexes, triggers, RLS, atomic sale/invoice
  functions, lockdown). Replaces `db/001_initial.sql` + `db/002_lockdown.sql`. Verified on a brand-new database, run twice, and as an upgrade of an
  older database. New: `sellers.pay_method` (Paybill / Till number / Send money, shown on invoices); `profiles.phone` stored as +254… always.
- Buyer links now work on the buyer's own phone: new public routes `GET /api/public/receipts/[code]` and `GET /api/public/invoices/[token]`
  (buyer phone masked, no internal ids); `/r/…`, `/pay/…` and `/review/…` fetch them when the document isn't in the viewer's browser;
  the buyer's review is submitted straight to `/api/reviews`. `/api/seller/receipts/[code]` used to return raw rows (buyer phone, ids): fixed.
- `PUT /api/seller/profile` accepts partial edits (before, changing only the bio returned 400) and saves the payment method.
- The seller profile now loads from the `sellers` table at sign-in and on page load (it used to be demo defaults), so what the seller sees is what the buyer sees.
- `usePersisted` data-loss bug: it pushed local/demo state to the server before the first read finished, so opening the app on a second device could overwrite
  the seller's saved receipts/invoices. Now it never writes until the first read succeeds, a failed read changes nothing, and new accounts start empty.
- Paid invoices showed "Pending" on the pay page (it checked `PAID`, the seller's list uses `COMPLETE`): fixed.

Still not wired to the backend (UI uses local state only): agent claims (`/api/claims`), stall creation (`/api/buildings/[id]/stalls`),
landlord stall verification (`/api/landlord/verify`), vouches, riders.
