"use client";
import dynamic from "next/dynamic";
/* The original app is fully client-side (localStorage, window, hash/path router), so it mounts client-only. */
const PlugPay = dynamic(() => import("../../src/PlugPayApp.jsx"), { ssr: false });
/* The stylesheet's landing/brand rules are all scoped to "#root > …" (68 selectors), as in the original page where the app mounted into <div id="root">. Keep that id on the mount point. */
export default function ClientRoot() { return <div id="root"><PlugPay /></div>; }
