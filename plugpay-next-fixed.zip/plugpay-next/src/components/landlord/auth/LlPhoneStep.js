import * as import_jsx_runtime from "../../../ppJsxRuntime.js";
import { usePlugPay } from "../../../store/context.js";
import { llAuthIconWrap, llAuthLabel, llAuthLink, llAuthSubmitBtn, llAuthTextInput, llFocusRing } from "./llAuthStyles.js";

export function LlPhoneStep() {
  const { llMethod, llSetMethod, llPhone, setLlPhone, llSendOTP, llShowPinLogin } = usePlugPay();
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { padding: "32px" }, children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { textAlign: "center", marginBottom: "20px" }, children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: llAuthIconWrap, children: "\u{1F3E2}" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { fontSize: "22px", fontWeight: 900, color: "var(--ink)", marginBottom: "4px" }, children: "Landlord sign-in" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { fontSize: "13px", color: "var(--muted)", lineHeight: "1.55" }, children: "Enter your email or phone number. We'll verify you're the registered owner or property manager for your building(s)." })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "method-toggle", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { type: "button", className: `method-toggle-btn${llMethod === "sms" ? " active" : ""}`, onClick: () => llSetMethod("sms"), children: "\u{1F4F1} SMS" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { type: "button", className: `method-toggle-btn${llMethod === "email" ? " active" : ""}`, onClick: () => llSetMethod("email"), children: "\u2709\uFE0F Email" })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { style: llAuthLabel, children: llMethod === "email" ? "EMAIL ADDRESS" : "PHONE NUMBER" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      "input",
      {
        type: llMethod === "email" ? "email" : "tel",
        placeholder: llMethod === "email" ? "you@email.com" : "07XX XXX XXX",
        style: llAuthTextInput,
        value: llPhone,
        onChange: (e) => setLlPhone(e.target.value),
        ...llFocusRing()
      }
    ),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { style: llAuthSubmitBtn, onClick: () => llSendOTP(), children: "Send OTP \u2192" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { textAlign: "center", fontSize: "11.5px", color: "var(--muted2)", marginTop: "14px", lineHeight: "1.6" }, children: "Only verified landlords & property managers can access trader verification." }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { textAlign: "center", fontSize: "12px", marginTop: "10px", fontFamily: "var(--fm)" }, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      "a",
      {
        href: "#",
        onClick: (e) => {
          e.preventDefault();
          llShowPinLogin();
        },
        style: llAuthLink,
        children: "Already set a PIN? Sign in with phone + PIN \u2192"
      }
    ) })
  ] });
}
