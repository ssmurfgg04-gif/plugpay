import { reviewLink, reviewStatus } from "../../../../data/sales.js";
import { codeOf } from "../../../../lib/utils.js";
import { usePlugPay } from "../../../../store/context.js";
import { h } from "../../../common/h.js";
import { Link } from "../../../common/routing.js";
import { ErrorState } from "../../../common/states.js";
import { Ic, relTime } from "../../../common/ui.js";
import { AppShellSeller, SellerGate } from "../../shell/SellerShell.js";
import { DocBadges, DocItems, DocTrader, ReviewChip, salesDocStatus, sellerBadgeInfo } from "./salesShared.js";

export function SellerReceiptDetailPage(props) {
  var pp = usePlugPay();
  var code = codeOf(props.code);
  var sale = pp.receiptsList.filter(function (r) { return codeOf(r.code) === code; })[0];
  if (!pp.merchantLoggedIn) return h(SellerGate, { active: "sales", msg: "Sign in to view this receipt." });
  if (!sale) return h(AppShellSeller, { title: "Receipt not found" }, h(ErrorState, { icon: "receipt", title: "Receipt not found", sub: "We couldn't find that receipt. It may have been removed.", backTo: "/seller/receipts", backLabel: "Back to sales" }));
  var sp = pp.sellerProfile, badges = sellerBadgeInfo(pp), st = reviewStatus(sale);
  var rComplete = salesDocStatus("receipt", sale) === "COMPLETE";
  return h(AppShellSeller, { title: "Receipt " + sale.code, subtitle: sale.sentAt ? "Sent " + relTime(sale.sentAt) + ". The review link went with it." : "Not sent yet. Send it to record the sale and update your stock." },
    h("div", { className: "doc-wrap" }, h("div", { className: "doc-card" },
      h("div", { className: "doc-band" },
        h("div", { className: "doc-band-top" }, h("div", { className: "doc-kind" }, Ic("receipt", 12), "PlugPay Receipt"), h("span", { className: "doc-status " + (rComplete ? "paid" : "pending") }, Ic(rComplete ? "badge-check" : "clock", 11), rComplete ? "Complete" : "Pending")),
        h("div", { className: "doc-amt" }, "KSh " + sale.total.toLocaleString()),
        h("div", { className: "doc-amt-label" }, "Paid by " + (sale.buyerName || "Buyer") + " \u00b7 " + new Date(sale.createdAt).toLocaleString())),
      h(DocTrader, { sp: sp }),
      h(DocBadges, { badges: badges }),
      h("div", { className: "doc-sec" }, h("div", { className: "doc-sec-h" }, Ic("user", 13), "Buyer & payment"),
        h("div", { className: "doc-row" }, h("span", null, "Buyer phone"), h("strong", null, sale.buyerPhone)),
        h("div", { className: "doc-row" }, h("span", null, "Payment ref"), h("strong", null, sale.paymentRef || codeOf(sale.code)))),
      h(DocItems, { items: sale.items }),
      h("div", { className: "doc-total-row" }, h("span", null, "Total paid"), h("strong", null, "KSh " + sale.total.toLocaleString())),
      h("div", { className: "doc-sec" }, h("div", { className: "doc-sec-h" }, Ic("star", 13), "Buyer review"),
        h("div", { style: { marginBottom: 8 } }, h(ReviewChip, { r: sale })),
        st.state === "done" && h("div", null, h("div", { className: "rev-stars-big" }, "\u2605".repeat(sale.review.rating) + "\u2606".repeat(5 - sale.review.rating)), sale.review.comment && h("div", { className: "rev-item-text" }, sale.review.comment)),
        st.state === "open" && h("div", { className: "doc-note", style: { padding: 0 } }, "The buyer can review once, within 6 hours of receiving this receipt."),
        st.state === "expired" && h("div", { className: "doc-note", style: { padding: 0 } }, "The 6-hour review window has closed. Reviews are one per receipt.")),
      h("div", { className: "doc-actions" },
        h("button", { className: "es-btn", onClick: function () { pp.sendReceipt(sale.code); } }, Ic("send", 14), sale.sentAt ? "Resend on WhatsApp" : "Send receipt on WhatsApp"),
        h(Link, { to: "/r/" + code, className: "es-btn alt" }, Ic("receipt", 14), "Public copy"),
        h("button", { className: "es-btn alt", onClick: function () { pp.setDocumentStatus("receipt", sale.code, rComplete ? "PENDING" : "COMPLETE"); } }, Ic(rComplete ? "clock" : "badge-check", 14), rComplete ? "Mark pending" : "Mark complete"),
        h("button", { className: "es-btn alt", onClick: function () { pp.copyText(reviewLink(sale.code), "Review link copied"); } }, Ic("star", 14), "Copy review link")),
      h("div", { className: "app-actions", style: { padding: "0 20px 18px" } }, h(Link, { to: "/seller/receipts", className: "pp-btn secondary" }, "Back to sales"))
    ))
  );
}
