import { PR, h } from "./h.js";

/* ---- Slot and page registry (how each group plugs itself in) ---- */
export var PP_registry = { slots: {}, pages: {},
  register: function (slot, id, comp, order) {
    var l = (this.slots[slot] || []).filter(function (x) { return x.id !== id; });
    l.push({ id: id, comp: comp, order: order == null ? 100 : order });
    l.sort(function (a, b) { return a.order - b.order; });
    this.slots[slot] = l;
  },
  registerPage: function (name, render) { this.pages[name] = render; },
  list: function (slot) { return this.slots[slot] || []; } };

class SlotBoundary extends PR.Component {
  constructor(p) { super(p); this.state = { err: null }; }
  static getDerivedStateFromError(e) { return { err: e }; }
  componentDidCatch(e) { console.error("[slot:" + this.props.id + "]", e); }
  render() { return this.state.err ? null : this.props.children; }
}

export function Slot(props) {
  return h(PR.Fragment, null, PP_registry.list(props.name).map(function (x) { return h(SlotBoundary, { key: x.id, id: x.id }, h(x.comp, props.props || null)); }));
}
