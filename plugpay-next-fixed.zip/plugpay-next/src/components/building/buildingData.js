import { buildings, merchants } from "../../data/directory.js";
import { ppSlug } from "../../lib/utils.js";

/* One lookup for every building the app knows: public directory, landlord accounts, agent-onboarded buildings. */
export function ppResolveBuilding(id, accounts, agentList) {
  var k = ppSlug(id);
  if (!k) return null;
  var b = buildings.filter(function (x) { return ppSlug(x.name) === k; })[0];
  if (b) return b;
  var a = (accounts || []).filter(function (x) { return ppSlug(x.name) === k; })[0];
  if (a) return { type: "building", name: a.name, street: a.street, floors: a.floors, stalls: a.totalStalls || a.stalls, registered: null, pct: null };
  var g = (agentList || []).filter(function (x) { return ppSlug(x.name) === k; })[0];
  if (g) return { type: "building", name: g.name, street: g.street, floors: g.floorsCount, stalls: g.stalls, registered: g.merchants, pct: g.stalls ? Math.round(g.merchants / g.stalls * 100) : null };
  return null;
}

export function ppBuildingMerchants(name) {
  return merchants.filter(function (m) { return String(m.sub).indexOf(name) > -1; }).map(function (m) {
    var parts = String(m.sub).split(" \u00B7 ");
    return { initials: m.initials, color: m.color, name: m.name, sub: parts.filter(function (x) { return x !== name; }).join(" \u00B7 "), rating: m.rating, rev: m.reviews };
  });
}
