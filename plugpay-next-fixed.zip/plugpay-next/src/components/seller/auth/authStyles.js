/* ---- Auth: sign in and register ---- */
export var authIconWrap = {
  width: "56px",
  height: "56px",
  borderRadius: "50%",
  background: "var(--accent-bg)",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  fontSize: "26px",
  margin: "0 auto 12px"
};

export var authLabel = {
  fontSize: "11px",
  fontWeight: 700,
  color: "var(--muted)",
  fontFamily: "var(--fm)",
  display: "block",
  marginBottom: "6px",
  textTransform: "uppercase",
  letterSpacing: ".06em"
};

export var authTextInput = {
  width: "100%",
  padding: "13px 14px",
  border: "1.5px solid var(--border2)",
  borderRadius: "var(--r6)",
  fontSize: "16px",
  fontFamily: "var(--fb)",
  outline: "none",
  background: "var(--bg)",
  transition: "border-color .2s",
  marginBottom: "16px"
};

export var authCodeInput = {
  width: "100%",
  padding: "16px 14px",
  border: "1.5px solid var(--border2)",
  borderRadius: "var(--r6)",
  fontSize: "28px",
  fontFamily: "var(--fm)",
  outline: "none",
  background: "var(--bg)",
  transition: "border-color .2s",
  marginBottom: "16px",
  letterSpacing: "10px",
  textAlign: "center"
};

export var authSubmitBtn = {
  width: "100%",
  padding: "14px",
  borderRadius: "100px",
  background: "var(--grad)",
  color: "#fff",
  fontFamily: "var(--fb)",
  fontSize: "15px",
  fontWeight: 800,
  border: "none",
  cursor: "pointer"
};

export var authLink = {
  color: "var(--accent)",
  textDecoration: "none",
  fontWeight: 700
};

export function focusRing() {
  return {
    onFocus: (e) => e.currentTarget.style.borderColor = "var(--accent)",
    onBlur: (e) => e.currentTarget.style.borderColor = "var(--border2)"
  };
}
