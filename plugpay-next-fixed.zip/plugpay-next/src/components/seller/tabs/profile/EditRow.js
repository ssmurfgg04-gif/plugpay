import { PR, h } from "../../../common/h.js";

export function EditRow(props) {
  var _e = PR.useState(false), editing = _e[0], setEditing = _e[1];
  var _v = PR.useState(props.value), val = _v[0], setVal = _v[1];
  function start() { setVal(props.editValue != null ? props.editValue : props.value); setEditing(true); }
  function save() {
    var v = String(val).trim();
    if (props.required && !v) return;
    props.onSave(v);
    setEditing(false);
  }
  var Tag = props.options ? "select" : props.multiline ? "textarea" : "input";
  return h("div", { className: "tp-info-row", style: props.last ? { border: "none" } : undefined },
    props.icon && h("div", { className: "tp-info-ico", style: { background: props.bg || "#f8f1f7" } }, h("span", null, props.icon)),
    h("div", { className: "tp-info-text", style: { flex: 1, minWidth: 0 } },
      h("div", { className: "tp-info-label" }, props.label),
      editing
        ? h("div", null,
            h(Tag, { className: "plc-input", style: { marginTop: 6, minHeight: props.multiline ? 84 : undefined }, value: val, autoFocus: true, type: props.inputType, inputMode: props.inputMode, onChange: function (e) { setVal(e.target.value); } }, props.options ? [h("option", { key: "_", value: "" }, "Select\u2026")].concat(props.options.map(function (o) { return h("option", { key: o, value: o }, o); })) : undefined),
            h("div", { className: "sp-edit-actions" },
              h("button", { className: "sp-edit-btn on", onClick: save }, "Save"),
              h("button", { className: "sp-edit-btn", onClick: function () { setEditing(false); } }, "Cancel")))
        : h("div", { className: "tp-info-val", style: { whiteSpace: "pre-wrap", wordBreak: "break-word" } }, props.value || h("span", { style: { color: "var(--muted)" } }, "Not set"))
    ),
    !editing && (props.locked
      ? h("span", { className: "sp-lock", title: props.lockNote || "Managed by PlugPay" }, "\uD83D\uDD12 " + (props.lockNote || "Locked"))
      : h("button", { className: "sp-edit-btn", onClick: start }, "\u270F\uFE0F Edit"))
  );
}
