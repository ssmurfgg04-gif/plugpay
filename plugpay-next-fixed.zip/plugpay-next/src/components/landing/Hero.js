import * as import_jsx_runtime from "../../ppJsxRuntime.js";
import { PhoneDemo } from "./PhoneDemo.js";
import { ResultsSection } from "../search/ResultsSection.js";
import { SearchBar } from "../search/SearchBar.js";

export function Hero() {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", { className: "hero", children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "wrap", children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "hero-copy", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "hero-badge", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "hero-dots", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { style: { background: "#51104a" }, children: "A" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { style: { background: "#534AB7" }, children: "P" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { style: { background: "#BA7517" }, children: "G" })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Join 1,400+ traders live in Nairobi CBD" })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", { children: [
        "The trust layer for ",
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "Kenya's WhatsApp commerce." })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "hero-p", children: "PlugPay verifies every seller from commercial buildings, anchors every sale to a real receipt, and turns your WhatsApp chat into a storefront buyers can actually trust \u2014 no app, no upfront risk." }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "hero-search-wrap search-container", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchBar, {}),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultsSection, {})
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "hero-stats", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "hstat", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hstat-n", children: "687" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hstat-l", children: "Verified merchants" })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "hstat", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hstat-n", children: "12" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hstat-l", children: "Buildings mapped" })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "hstat", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hstat-n", children: "4.8\u2605" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hstat-l", children: "Avg merchant rating" })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "hstat", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hstat-n", children: "KSh12M" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hstat-l", children: "Platform GMV/month" })
        ] })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { className: "hero-note", children: [
        "Send invoice and receipt to customers whatsapp.",
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
        "Receive reviews even from physical sales."
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hero-rule" })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hero-visual", children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneDemo, {}) })
  ] }) });
}
