import { navigate } from "../../../../lib/router.js";
import { usePlugPay } from "../../../../store/context.js";
import { h } from "../../../common/h.js";
import { AppShellX, DashSignIn } from "../../../common/shells.js";
import { AddBuildingCard } from "./AddBuildingCard.js";

export function LandlordBuildingsPage() {
  var pp = usePlugPay();
  if (!pp.llAuthed) return h(AppShellX, { role: "Landlord", active: "buildings", title: "My buildings" }, h(DashSignIn, { msg: "Sign in to view your buildings.", onClick: pp.openLandlordModal }));
  return h(AppShellX, { role: "Landlord", active: "buildings", title: "My buildings", subtitle: "One login, one separate account per building." },
    h("div", { className: "app-list" },
      pp.lbAccounts.map(function (a) {
        var d = pp.lbData[a.id] || { pending: [], verified: [], vacant: [] };
        var on = a.id === pp.lbActive.id;
        return h("div", { className: "app-list-row", key: a.id },
          h("div", { className: "app-list-main" }, h("div", { className: "app-list-name" }, a.name + (on ? " \u00b7 open" : "")), h("div", { className: "app-list-meta" }, a.street + " \u00b7 " + a.totalStalls + " stalls \u00b7 " + d.verified.length + " verified \u00b7 " + d.pending.length + " pending")),
          h("button", { className: "pp-btn " + (on ? "secondary" : "primary"), onClick: function () { pp.lbSwitch(a.id); if (on) pp.openBuildingModal(a.name); else navigate("/landlord/dashboard"); } }, on ? "View" : "Open account"));
      })),
    h(AddBuildingCard, null)
  );
}
