import * as import_jsx_runtime from "../../../ppJsxRuntime.js";
import { usePlugPay } from "../../../store/context.js";
import { Modal } from "../../common/Modal.js";
import { LlOtpStep } from "./LlOtpStep.js";
import { LlPhoneStep } from "./LlPhoneStep.js";
import { LlPinLoginStep } from "./LlPinLoginStep.js";
import { LlSetPinStep } from "./LlSetPinStep.js";

export function LandlordModal() {
  const { llStep } = usePlugPay();
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, { id: "modal-landlord", children: [
    llStep === "phone" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LlPhoneStep, {}),
    llStep === "pinlogin" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LlPinLoginStep, {}),
    llStep === "otp" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LlOtpStep, {}),
    llStep === "setpin" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LlSetPinStep, {})
  ] });
}
