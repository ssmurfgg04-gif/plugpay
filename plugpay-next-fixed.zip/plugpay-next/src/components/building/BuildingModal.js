import { usePlugPay } from "../../store/context.js";
import { BuildingViewContainer } from "./BuildingViewContainer.js";
import { Modal } from "../common/Modal.js";
import { h } from "../common/h.js";

export function BuildingModal() {
  var pp = usePlugPay();
  return h(Modal, { id: "modal-building", onExit: pp.focusMerchantProfileTab }, h(BuildingViewContainer, { id: pp.bldgId }));
}
