import { usePlugPay } from "../../store/context.js";
import { Modal } from "../common/Modal.js";
import { h } from "../common/h.js";
import { MerchantProfileBody } from "./MerchantProfileBody.js";

export function MerchantModal() {
  var pp = usePlugPay();
  return h(Modal, { id: "modal-merchant", innerClassName: "modal tpModal", hideCloseButton: true }, h(MerchantProfileBody, { onClose: function () { pp.closeModal("modal-merchant"); } }));
}
