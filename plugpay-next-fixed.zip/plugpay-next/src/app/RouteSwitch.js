import { usePlugPay } from "../store/context.js";
import { PR, h } from "../components/common/h.js";
import { PP_registry, Slot } from "../components/common/registry.js";
import { parseRoute, useHashRoute } from "../components/common/routing.js";
import { LandingPage } from "../components/landing/LandingPage.js";

function GlobalModals() { return h(Slot, { name: "modals" }); }

export function RouteSwitch() {
  var route = useHashRoute();
  var parsed = parseRoute(route);
  var pp = usePlugPay();
  PR.useEffect(function () {
    ["modal-merchant", "modal-building", "modal-quick", "modal-receipt", "modal-record-sale", "modal-register", "modal-landlord", "modal-admit-seller", "modal-onboard", "modal-stall"].forEach(function (id) { pp.closeModal(id); });
  }, [route]);
  var content;
  if (parsed.page === "home") {
    content = h(LandingPage, null);
    return h(PR.Fragment, null, content, h(GlobalModals, null));
  }
  var render = PP_registry.pages[parsed.page];
  content = render ? render(parsed) : h(LandingPage, null);
  return h(PR.Fragment, null, content, h(GlobalModals, null));
}
