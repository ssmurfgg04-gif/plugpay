import * as import_jsx_runtime from "../../ppJsxRuntime.js";
import { usePlugPay } from "../../store/context.js";
import { LOGO_DATA_URI } from "../common/ui.js";

export function Navbar() {
  const { openLandlordModal, openAuthModal } = usePlugPay();
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", { className: "nav", children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "nav-inner", children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "nav-top", children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", { href: "#", className: "logo", children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", { src: LOGO_DATA_URI, alt: "PlugPay", style: { height: "16px", width: "auto", display: "block" } }) }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "nav-links", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", { href: "#friction", children: "Problem" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", { href: "#breakthrough", children: "How it works" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", { href: "#contrast", children: "Why PlugPay" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", { href: "#pricing", children: "Pricing" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", { href: "#", onClick: (e) => {
        e.preventDefault();
        openLandlordModal();
      }, children: "List a building" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", { href: "#", onClick: (e) => {
        e.preventDefault();
        openAuthModal();
      }, children: "Sign in" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", { href: "/seller/dashboard", children: "Seller dashboard" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", { href: "/landlord/dashboard", children: "Landlord dashboard" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", { href: "/agent/claims", children: "Agent claims" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", { href: "/search", children: "Search" })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", { href: "#", className: "nav-cta", onClick: (e) => {
      e.preventDefault();
      openAuthModal();
    }, children: "Join us" })
  ] }) }) });
}
