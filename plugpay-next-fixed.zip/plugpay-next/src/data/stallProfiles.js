export var STALL_POOL = [["Njeri Fashions", "Fashion"], ["Kamau Electronics", "Electronics"], ["Otieno Hardware", "Hardware"], ["Wambui Beauty Hub", "Beauty"], ["Mama Ann Foods", "Food"], ["Salim Mobile Accessories", "Electronics"], ["Achieng Textiles", "Fashion"], ["Mwangi Tools & Fittings", "Hardware"], ["Zawadi Cosmetics", "Beauty"], ["Kip Sneakers", "Fashion"]];

export var STALL_PRODUCTS = {
    Fashion: [["Ankara dress", 1800], ["Men's shirt", 1200], ["Kitenge skirt", 950]],
    Electronics: [["Phone charger", 450], ["Bluetooth earbuds", 1500], ["Power bank 10,000mAh", 1900]],
    Hardware: [["Claw hammer", 650], ["Padlock", 400], ["Paint 4L", 2200]],
    Beauty: [["Shea butter 250ml", 600], ["Hair oil", 450], ["Body lotion 400ml", 550]],
    Food: [["Chapati (10)", 250], ["Mandazi pack", 100], ["Samosas (6)", 180]],
    Other: [["Everyday essentials", 500], ["Bestseller", 800], ["Gift set", 1200]]
  };

export function hashStr(s) { var x = 7; for (var i = 0; i < s.length; i++) x = (x * 31 + s.charCodeAt(i)) % 100003; return x; }

export function buildStallProfile(pp, sp) {
    var st = sp.stall, hsh = hashStr(sp.floor + ":" + st.id);
    var reg = sp.merchant || (pp.obMerchantList || []).filter(function (m) { return m.floor === sp.floor && String(parseInt(m.stallNum, 10)) === String(parseInt(st.id, 10)); })[0];
    var named = st.n && st.n.indexOf("Stall ") !== 0 ? st.n : "";
    var pool = STALL_POOL[hsh % STALL_POOL.length];
    var biz = reg ? reg.biz : (named || pool[0]);
    var cat = reg ? reg.type : (named ? "Retail" : pool[1]);
    var ex = (reg && reg.extra) || {};
    return {
      biz: biz, owner: reg ? reg.ownerName : (named ? named : biz.split(" ")[0] + " (owner)"), cat: cat,
      loc: (sp.floor === "G" ? "Ground floor" : "Floor " + sp.floor) + ", Stall " + st.id, building: sp.building || "Anniversary Towers",
      verified: st.s === "v" || (reg && reg.status === "done"), rating: (4.2 + (hsh % 8) / 10).toFixed(1), reviews: 8 + (hsh % 60), years: ex.years || (1 + hsh % 9),
      phone: reg ? reg.phone : "", photos: ex.photos || [], products: STALL_PRODUCTS[cat] || STALL_PRODUCTS.Other, registered: !!reg
    };
  }

export var CAT_ICON = { Fashion: "\uD83D\uDC57", Electronics: "\uD83D\uDCF1", Hardware: "\uD83D\uDD27", Beauty: "\uD83D\uDC84", Food: "\uD83C\uDF72", Other: "\uD83D\uDCE6" };

export function slugOf(s) { return String(s || "").toLowerCase().replace(/[^a-z0-9]+/g, ""); }

export function buildViewedSeller(d) {
    var hs = hashStr((d.building || "") + "|" + (d.loc || "") + "|" + (d.owner || d.biz));
    var cat = d.cat || "Retail";
    var avg = Number(d.rating) || 4.2 + (hs % 8) / 10;
    var reviewCount = Number(d.reviews) || 8 + (hs % 60);
    var sales = Number(d.sales) || 20 + (hs % 400);
    var vouches = Number(d.vouches) || 3 + (hs % 25);
    var trust = Math.min(99, Math.round(53 + (avg / 5) * 25 + Math.min(15, sales / 20) + Math.min(12, vouches / 4)));
    var n5 = Math.round(reviewCount * 0.74), n4 = Math.round(reviewCount * 0.15), n3 = Math.round(reviewCount * 0.06), n2 = Math.round(reviewCount * 0.03);
    var dist = { 5: n5, 4: n4, 3: n3, 2: n2, 1: Math.max(0, reviewCount - n5 - n4 - n3 - n2) };
    var years = Number(d.years) || 1 + (hs % 9);
    var slug = slugOf(d.biz);
    var stockBase = STALL_PRODUCTS[cat] || STALL_PRODUCTS.Other;
    return {
      key: (d.building || "") + "|" + (d.loc || ""),
      verified: !!d.verified,
      registered: !!d.registered,
      assignment: { building: d.building || "", loc: d.loc || "" },
      stats: { avg: avg, reviewCount: reviewCount, sales: sales, vouches: vouches, trust: trust, dist: dist, followers: 40 + (hs % 300) },
      profile: {
        bizName: d.biz, ownerName: d.owner || d.biz, role: cat === "Retail" ? "Retail Trader" : cat + " Retailer",
        bio: cat + " seller at " + d.building + ". In business for " + years + " year" + (years > 1 ? "s" : "") + ".",
        street: (d.street || "Nairobi CBD"), phone: d.phone || "Not shared", whatsapp: d.phone || "Not shared",
        established: (2026 - years) + " \u00b7 " + years + " year" + (years > 1 ? "s" : "") + " in business",
        instagram: "@" + slug, tiktok: "@" + slug, facebook: "/" + d.biz.replace(/\s+/g, ""),
        paybill: "", account: "",
        about: d.biz + " sells " + cat.toLowerCase() + " products from " + d.loc + ", " + d.building + ". Message the seller on WhatsApp to place an order.",
        llPhoneVerified: !!d.verified
      },
      catalogue: stockBase.map(function (p, i) { return { id: "v" + i, icon: CAT_ICON[cat] || CAT_ICON.Other, image: "", name: p[0], price: p[1], stock: 4 + ((hs + i * 7) % 20), category: cat }; })
    };
  }
