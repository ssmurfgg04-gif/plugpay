import * as import_jsx_runtime from "../../ppJsxRuntime.js";
import { usePlugPay } from "../../store/context.js";

export function ResultCard({ result }) {
  return result.type === "merchant" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MerchantCard, { r: result }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuildingCard, { r: result });
}

function MerchantCard({ r }) {
  const { openDirectorySeller } = usePlugPay();
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "res-card", onClick: () => openDirectorySeller(r), children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "rc-top", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rc-av", style: { background: r.color }, children: r.initials }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "rc-info", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rc-name", children: r.name }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rc-sub", children: r.sub }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `rc-badge ${r.badgeClass}`, children: r.badge })
      ] })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "rc-stats", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "rcs", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "rcs-n", children: [
          r.rating,
          "\u2605"
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rcs-l", children: "Rating" })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "rcs", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rcs-n", children: r.sales }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rcs-l", children: "Sales" })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "rcs", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rcs-n", children: r.reviews }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rcs-l", children: "Reviews" })
      ] })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { className: "rc-btn", children: "View profile \u2192" })
  ] });
}

var MINI_STALLS = ["t", "v", "b", "e", "v", "b", "t", "e", "v", "b", "e", "b"];

function BuildingCard({ r }) {
  const { openBuildingModal } = usePlugPay();
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "res-card bldg", onClick: () => openBuildingModal(r.name), children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "rc-top", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rc-av", style: { background: "var(--grad)", borderRadius: "var(--r4)" }, children: "\u{1F3E2}" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "rc-info", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rc-name", children: r.name }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rc-sub", children: r.sub })
      ] })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "floor-mini", children: MINI_STALLS.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `fm-stall ${s === "e" ? "fms-vac" : "fms-occ"}` }, i)) }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "rc-stats", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "rcs", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rcs-n", children: r.registered }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rcs-l", children: "Registered" })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "rcs", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rcs-n", children: r.floors }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rcs-l", children: "Floors" })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "rcs", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "rcs-n", children: [
          r.pct,
          "%"
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rcs-l", children: "Covered" })
      ] })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { className: "rc-btn bd-btn-mini", children: "View building \u2192" })
  ] });
}
