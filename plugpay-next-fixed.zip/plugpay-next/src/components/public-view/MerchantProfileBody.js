import { usePlugPay } from "../../store/context.js";
import { PR, h } from "../common/h.js";
import { PublicSellerBottomNavigation } from "./PublicSellerBottomNavigation.js";
import { PublicSellerProfileHeader } from "./PublicSellerProfileHeader.js";
import { BuildingTab } from "./tabs/BuildingTab.js";
import { CatalogueTab } from "./tabs/CatalogueTab.js";
import { ProfileTab } from "./tabs/ProfileTab.js";
import { ReviewsTab } from "./tabs/ReviewsTab.js";

/* The ONE public seller profile. Modal and /sellers/:id page both render this. */
export function MerchantProfileBody(props) {
  var pp = usePlugPay();
  var tab = pp.merchantTab, setTab = pp.setMerchantTab;
  return h(PR.Fragment, null,
    h("div", { className: "tp-navbar-fixed" },
      h("button", { className: "tp-navbar-btn", onClick: props.onClose, "aria-label": "Back" }, "\u2190"),
      h("div", { className: "tp-navbar-title" }, ""),
      h("button", { className: "modal-close", "aria-label": "Close", onClick: props.onClose }, "\u2715")),
    h("div", { className: "tp-body public-seller-profile" },
      tab === "profile" && h(PublicSellerProfileHeader, { seller: pp.viewedSeller }),
      tab === "profile" && h(ProfileTab, { onViewCatalogue: function () { setTab("catalogue"); } }),
      tab === "catalogue" && h(CatalogueTab, null),
      tab === "reviews" && h(ReviewsTab, null),
      tab === "building" && h(BuildingTab, null)),
    h(PublicSellerBottomNavigation, { active: tab, onChange: setTab }));
}
