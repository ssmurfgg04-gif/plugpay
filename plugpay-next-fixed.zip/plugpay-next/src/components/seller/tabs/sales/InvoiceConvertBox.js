import { navigate } from "../../../../lib/router.js";
import { PR, h } from "../../../common/h.js";

export function InvoiceConvertBox(props) {
  var pp = props.pp, d = props.doc;
  var _c = PR.useState(""), code = _c[0], setCode = _c[1];
  var _b = PR.useState(false), busy = _b[0], setBusy = _b[1];
  return h("div", { className: "sales-code-box" },
    h("div", { className: "sales-code-label" }, "Add transaction code or paste the M-Pesa message to turn this invoice into a receipt"),
    h("textarea", { className: "plc-input", rows: 3, placeholder: "e.g. QGH7XYZ123 or the full M-Pesa message", value: code, onChange: function (e) { setCode(e.target.value); } }),
    h("button", { type: "button", className: "sp-edit-btn on", disabled: busy || !code.trim(), onClick: function () {
      setBusy(true);
      setTimeout(function () {
        setBusy(false);
        var rc = pp.convertInvoiceToReceipt(d.token, code);
        if (rc) { setCode(""); navigate("/seller/receipts/" + encodeURIComponent(rc)); }
      }, 400);
    } }, busy ? "Checking\u2026" : "Make receipt"));
}
