import * as import_jsx_runtime from "../../../ppJsxRuntime.js";
import { usePlugPay } from "../../../store/context.js";

/* ---- Agent sign-in gate ---- */
export function AgentGate() {
  const {
    obAgentMethod,
    obAgentSetMethod,
    obAgentPhoneStep,
    obAgentPhone,
    setObAgentPhone,
    obAgentOtp,
    setObAgentOtp,
    obAgentSending,
    obAgentVerifying,
    obAgentSendOtp,
    obAgentVerifyOtp,
    closeModal,
    openLandlordModal
  } = usePlugPay();
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ob-agent-gate", children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ob-agent-icon", children: "\u{1F4CD}" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ob-agent-title", children: "Agent sign-in required" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ob-agent-sub", children: "Verify with your email or phone to onboard a building. Every stall you register is tied to your agent ID for accountability." }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "method-toggle", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { type: "button", className: `method-toggle-btn${obAgentMethod === "sms" ? " active" : ""}`, onClick: () => obAgentSetMethod("sms"), children: "\u{1F4F1} SMS" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { type: "button", className: `method-toggle-btn${obAgentMethod === "email" ? " active" : ""}`, onClick: () => obAgentSetMethod("email"), children: "\u2709\uFE0F Email" })
    ] }),
    obAgentPhoneStep ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { className: "ob-agent-label", children: obAgentMethod === "email" ? "Email Address" : "Phone Number" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        "input",
        {
          className: "ob-agent-input",
          type: obAgentMethod === "email" ? "email" : "tel",
          placeholder: obAgentMethod === "email" ? "you@email.com" : "07XX XXX XXX",
          value: obAgentPhone,
          onChange: (e) => setObAgentPhone(e.target.value),
          onKeyDown: (e) => {
            if (e.key === "Enter") obAgentSendOtp();
          }
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { className: "ob-agent-btn", onClick: () => obAgentSendOtp(), disabled: obAgentSending, children: obAgentSending ? "Sending\u2026" : "Send OTP \u2192" })
    ] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { className: "ob-agent-label", children: "One-Time Code" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        "input",
        {
          className: "ob-agent-otp-input",
          type: "tel",
          placeholder: "_ _ _ _ _ _",
          maxLength: 6,
          value: obAgentOtp,
          onChange: (e) => setObAgentOtp(e.target.value),
          onKeyDown: (e) => {
            if (e.key === "Enter") obAgentVerifyOtp();
          }
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { className: "ob-agent-btn", onClick: () => obAgentVerifyOtp(), disabled: obAgentVerifying, children: obAgentVerifying ? "Verifying\u2026" : "Verify & continue \u2192" })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { textAlign: "center", marginTop: "18px", paddingTop: "16px", borderTop: "1px solid var(--border)" }, children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { fontSize: "11.5px", color: "var(--muted2)", marginBottom: "8px" }, children: "Own or manage this building instead?" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        "a",
        {
          href: "#",
          onClick: (e) => {
            e.preventDefault();
            closeModal("modal-onboard");
            openLandlordModal();
          },
          style: { display: "inline-flex", alignItems: "center", gap: "6px", fontSize: "12.5px", fontWeight: 700, color: "var(--accent)", textDecoration: "none", fontFamily: "var(--fb)" },
          children: "\u{1F3E2} Sign in as landlord \u2192"
        }
      )
    ] })
  ] });
}
