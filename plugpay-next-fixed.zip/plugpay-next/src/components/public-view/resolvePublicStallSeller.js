export function resolvePublicStallSeller(stall) {
  if (stall && stall.n && String(stall.n).trim()) return null;
  return { biz: "Wanjiku Electronics", ownerName: "Jane Wanjiku", type: "Electronics", phone: "", status: "done" };
}
