# Changes made while checking this build

1. `app/[[...slug]]/ClientRoot.jsx` — the app now mounts inside `<div id="root">`.
   `app/globals.css` has 68 selectors of the form `#root > nav.nav`, `#root > section.hero`, ... (the landing page's
   brand colour `--mint:#8b008b` and white button text). Nothing created `#root`, so none of them matched.
2. `src/components/public-view/tabs/ProfileTab.js` line 188 — `jsxs` -> `jsx` for a single (non-array) child.
   Production React ignores this; `npm run dev` logged "Static children should always be an array" on every page.
