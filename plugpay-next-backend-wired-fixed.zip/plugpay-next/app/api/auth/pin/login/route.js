import { json, body, cleanPhone, authPasswordLogin } from '../../../../../src/server/supabase.js';
import { devAuthEnabled, devSession, DEV_PIN } from '../../../../../src/server/devAuth.js';
export async function POST(request) {
  const { phone, pin } = await body(request); const normalized = cleanPhone(phone);
  if (!normalized || !/^\d{6}$/.test(String(pin || ''))) return json({ error: 'Phone and 6-digit PIN are required' }, 400);
  // DEV ONLY: the fixed PIN 121212 opens any account (creating it if needed); a PIN the user set themselves still works too.
  const dev = devAuthEnabled() && String(pin) === DEV_PIN;
  const { data, error } = dev ? await devSession(normalized) : await authPasswordLogin(normalized, String(pin));
  const session = data?.session || (data?.access_token ? data : null);
  if (error || !session) return json({ error: error?.message || 'Invalid PIN' }, 401);
  return json({ ok: true, access_token: session.access_token, refresh_token: session.refresh_token, expires_at: session.expires_at, user: { id: data.user.id, phone: normalized } });
}
