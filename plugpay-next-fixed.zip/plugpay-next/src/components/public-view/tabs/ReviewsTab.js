import { initials } from "../../../lib/utils.js";
import { usePlugPay } from "../../../store/context.js";
import { h } from "../../common/h.js";
import { relTime } from "../../common/ui.js";
import { useSV } from "../useSV.js";

var REVIEWS = [
  {
    initials: "JK",
    bg: "#1e3a5f",
    fg: "#60a5fa",
    name: "James Kamau",
    date: "2 days ago",
    stars: 5,
    text: "Bought a Samsung Galaxy. Genuine product, great price. Comes with 30-day warranty as promised. Fast delivery too.",
    receipt: "#01201"
  },
  {
    initials: "FO",
    bg: "#380b33",
    fg: "#e557d6",
    name: "Faith Otieno",
    date: "1 week ago",
    stars: 5,
    text: "Best electronics shop in Moi Avenue. Honest seller, original products. Will definitely come back.",
    receipt: "#01187"
  },
  {
    initials: "BN",
    bg: "#3c1f6e",
    fg: "#a78bfa",
    name: "Brian Njoroge",
    date: "2 weeks ago",
    stars: 4,
    text: "Good laptop at fair price. Would have preferred original box but overall happy with the purchase.",
    receipt: "#01156"
  }
];

export function ReviewsTab() {
  var pp = usePlugPay();
  var sv = useSV();
  var st = sv.stats;
  var fresh = sv.reviews.map(function (r) {
    return { initials: initials(r.buyerName || "Buyer"), bg: "#380b33", fg: "#e557d6", name: r.buyerName || "Verified buyer", date: relTime(r.at), stars: r.rating, text: r.comment || "Left a star rating.", receipt: r.code };
  });
  var list = sv.own ? fresh.concat(REVIEWS) : REVIEWS.slice(0, Math.min(REVIEWS.length, st.reviewCount));
  var rounded = Math.round(st.avg);
  return h("div", { className: "modal-tab-body on", style: { padding: "12px" } },
    h("div", { className: "rev-summary" },
      h("div", { style: { textAlign: "center", flexShrink: 0 } },
        h("div", { className: "rev-big-num" }, st.avg.toFixed(1)),
        h("div", { className: "rev-stars-big" }, "\u2605".repeat(rounded) + "\u2606".repeat(5 - rounded)),
        h("div", { className: "rev-sub" }, st.reviewCount + " reviews")),
      h("div", { className: "rev-bars" }, [5, 4, 3, 2, 1].map(function (n) {
        var c = st.dist[n] || 0, pct = Math.round(c / st.reviewCount * 100);
        return h("div", { className: "rev-bar-row", key: n }, h("span", { className: "rev-bar-lbl" }, n), h("div", { className: "rev-bar-track" }, h("div", { className: "rev-bar-fill", style: { width: pct + "%" } })), h("span", { className: "rev-bar-ct" }, c));
      }))),
    h("div", { className: "rev-list" }, list.map(function (r) {
      return h("div", { className: "rev-item", key: r.name + r.receipt },
        h("div", { className: "rev-item-top" },
          h("div", { className: "rev-item-av", style: { background: r.bg, color: r.fg } }, r.initials),
          h("div", null, h("div", { className: "rev-item-name" }, r.name), h("div", { className: "rev-item-date" }, r.date)),
          h("div", { className: "rev-item-stars" }, "\u2605".repeat(r.stars), r.stars < 5 && h("span", { style: { color: "#ccc" } }, "\u2605".repeat(5 - r.stars)))),
        h("div", { className: "rev-item-text" }, r.text),
        h("div", { className: "rev-verified" }, "\u2713 Verified buyer \u00b7 Receipt " + r.receipt));
    })));
}
