import { usePlugPay } from "../../../../store/context.js";
import { h } from "../../../common/h.js";

/* ---- Dashboard, buildings, sellers and stalls pages ---- */
export function LbSwitcher() {
  var pp = usePlugPay();
  return h("div", { className: "lb-switch" },
    h("div", { className: "lb-switch-l" }, "Building account"),
    h("div", { className: "lb-chips" }, pp.lbAccounts.map(function (a) {
      return h("button", { key: a.id, className: "lb-chip" + (a.id === pp.lbActive.id ? " on" : ""), onClick: function () { pp.lbSwitch(a.id); } }, a.name);
    })));
}
