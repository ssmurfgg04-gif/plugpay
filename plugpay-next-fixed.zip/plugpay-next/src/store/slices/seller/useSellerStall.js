/* useSellerStall — "sellerStall" group of the PlugPay store, extracted from PlugPayProvider.
   Statements are the original ones, in their original relative order. Names owned by other groups arrive through the shared
   per-render context object (ctx): groups that run earlier are destructured below, groups that run later are read lazily as ctx.name. */
import * as import_react from "react";
import { usePersisted } from "../../usePersisted.js";

export function useSellerStall(ctx) {
    const { showToast } = ctx;
    const [docStatus, setDocStatus] = (0, import_react.useState)({});
    const fakeUpload = (0, import_react.useCallback)(
      (key, name) => {
        if (docStatus[key] === "done") {
          showToast(`${name} already uploaded \u2713`);
          return;
        }
        setDocStatus((s) => ({ ...s, [key]: "uploading" }));
        setTimeout(() => {
          setDocStatus((s) => ({ ...s, [key]: "done" }));
          showToast(`${name} uploaded successfully \u2713`);
        }, 1200);
      },
      [docStatus, showToast]
    );
    const [showVacateForm, setShowVacateForm] = (0, import_react.useState)(false);
    const [vacateBuilding, setVacateBuilding] = (0, import_react.useState)("");
    const [vacateStall, setVacateStall] = (0, import_react.useState)("");
    const [stallAssignment, setStallAssignment] = usePersisted("stall2", { building: "Anniversary Towers", loc: "Floor 3, Stall 305" });
    return {
      stallAssignment,
      vacateBuilding,
      vacateStall,
      setVacateBuilding,
      setVacateStall,
      setShowVacateForm,
      setStallAssignment,
      docStatus,
      fakeUpload
    };
}
