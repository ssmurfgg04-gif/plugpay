import { PR, h } from "./h.js";
import { Link } from "./routing.js";
import { Ic } from "./ui.js";

function useLoading(ms, dep) {
  var _s = PR.useState(true), loading = _s[0], setLoading = _s[1];
  PR.useEffect(function () { setLoading(true); var t = setTimeout(function () { setLoading(false); }, ms); return function () { clearTimeout(t); }; }, [dep]);
  return loading;
}

function Sk(props) { return h("div", { className: "sk " + (props.cls || ""), style: Object.assign({ width: props.w, height: props.h }, props.style || {}) }); }

function SkeletonView(props) {
  var kind = props.kind || "list", i;
  if (kind === "dash") return h("div", { className: "sk-wrap", "aria-busy": "true", "aria-label": "Loading" },
    h(Sk, { w: "40%", h: 18 }), h("div", { style: { height: 10 } }),
    h("div", { className: "sk-card" }, h(Sk, { w: "30%", h: 12 }), h(Sk, { w: "60%", h: 30, style: { margin: "10px 0" } }), h(Sk, { w: "100%", h: 110 })),
    h("div", { className: "sk-card" }, [0, 1, 2].map(function (n) { return h("div", { key: n, style: { marginBottom: 12 } }, h(Sk, { w: "70%", h: 12 }), h(Sk, { w: "100%", h: 8, style: { marginTop: 8 } })); })));
  if (kind === "cards") return h("div", { className: "sk-wrap", "aria-busy": "true" }, h("div", { className: "sk-grid" }, [0, 1, 2, 3].map(function (n) { return h("div", { key: n, className: "sk-card" }, h(Sk, { w: "100%", h: 90 }), h(Sk, { w: "80%", h: 12, style: { marginTop: 10 } }), h(Sk, { w: "50%", h: 12 })); })));
  if (kind === "profile") return h("div", { "aria-busy": "true" }, h("div", { className: "sm-head" }, h("div", { className: "sm-top" }, h(Sk, { w: 62, h: 62, cls: "sk-circle", style: { background: "rgba(255,255,255,.35)" } }), h("div", { style: { flex: 1 } }, h(Sk, { w: "70%", h: 18, style: { background: "rgba(255,255,255,.35)" } }), h(Sk, { w: "50%", h: 12, style: { background: "rgba(255,255,255,.35)" } })))),
    h("div", { className: "sm-body" }, h(Sk, { w: "100%", h: 60 }), h("div", { style: { height: 14 } }), h("div", { className: "sk-row" }, [0, 1, 2].map(function (n) { return h(Sk, { key: n, w: 110, h: 110 }); })), h("div", { style: { height: 14 } }), h(Sk, { w: "100%", h: 44 }), h(Sk, { w: "100%", h: 44, style: { marginTop: 8 } })));
  return h("div", { className: "sk-wrap", "aria-busy": "true", "aria-label": "Loading" }, [0, 1, 2].map(function (n) {
    return h("div", { key: n, className: "sk-card" }, h("div", { className: "sk-row" }, h(Sk, { w: 40, h: 40, cls: "sk-circle" }), h("div", { style: { flex: 1 } }, h(Sk, { w: "60%", h: 13 }), h(Sk, { w: "40%", h: 11 })), h(Sk, { w: 60, h: 24 })));
  }));
}

export function WithSkeleton(props) {
  var loading = useLoading(props.ms || 450, props.dep);
  return loading ? h(SkeletonView, { kind: props.kind }) : props.children;
}

export function EmptyState(props) {
  var act = props.action;
  return h("div", { className: "es", role: "status" },
    h("div", { className: "es-ic" }, Ic(props.icon || "inbox")),
    h("div", { className: "es-t" }, props.title),
    props.sub && h("div", { className: "es-s" }, props.sub),
    act && (act.to ? h(Link, { to: act.to, className: "es-btn" }, Ic("plus"), act.label) : h("button", { className: "es-btn", onClick: act.onClick }, Ic("plus"), act.label)));
}

export function ErrorState(props) {
  return h("div", { className: "er", role: "alert" },
    h("div", { className: "er-ic" }, Ic(props.icon || "triangle-alert")),
    h("div", { className: "er-t" }, props.title || "Something went wrong"),
    h("div", { className: "er-s" }, props.sub || "We couldn't load this. Check your connection and try again."),
    props.onRetry && h("button", { className: "es-btn", onClick: props.onRetry }, Ic("refresh-cw"), props.retryLabel || "Try again"),
    props.backTo && h(Link, { to: props.backTo, className: "es-btn alt", style: { marginTop: 8 } }, props.backLabel || "Go back"));
}

export var PPBoundary = (function () {
  function B(p) { PR.Component.call(this, p); this.state = { err: null }; }
  B.prototype = Object.create(PR.Component.prototype); B.prototype.constructor = B;
  B.getDerivedStateFromError = function (e) { return { err: e }; };
  B.prototype.componentDidCatch = function (e) { try { console.error("PlugPay UI error:", e); } catch (_) {} };
  B.prototype.render = function () {
    var self = this;
    if (this.state.err) return h("div", { style: { maxWidth: 520, margin: "60px auto", padding: 16 } },
      h(ErrorState, { title: "This screen hit a snag", sub: "The page failed to render. Your data is safe - reload to continue.", onRetry: function () { self.setState({ err: null }); }, retryLabel: "Try again", backTo: "/", backLabel: "Back to home" }));
    return this.props.children;
  };
  return B;
})();
