import { replaceRoute } from "../../../../lib/router.js";
import { usePlugPay } from "../../../../store/context.js";
import { PR, h } from "../../../common/h.js";
import { EmptyState } from "../../../common/states.js";
import { AppShellSeller, SellerGate } from "../../shell/SellerShell.js";
import { SalesDocCard } from "./SalesDocCard.js";
import { salesDocStatus } from "./salesShared.js";

export function SellerSalesPage(props) {
  var pp = usePlugPay();
  var _m = PR.useState(props.mode || "receipts"), mode = _m[0], setMode = _m[1];
  var _f = PR.useState("all"), filter = _f[0], setFilter = _f[1];
  PR.useEffect(function () { setMode(props.mode || "receipts"); }, [props.mode]);
  if (!pp.merchantLoggedIn) return h(SellerGate, { active: "sales", msg: "Sign in to your seller account to view your sales." });
  var receipts = pp.receiptsList, invoices = pp.invoicesList;
  var all = receipts.map(function (r) { return salesDocStatus("receipt", r); }).concat(invoices.map(function (i) { return salesDocStatus("invoice", i); }));
  var completeCount = all.filter(function (x) { return x === "COMPLETE"; }).length;
  var pendingCount = all.length - completeCount;
  var kind = mode === "receipts" ? "receipt" : "invoice";
  var source = mode === "receipts" ? receipts : invoices;
  var shown = source.filter(function (d) { return filter === "all" || salesDocStatus(kind, d).toLowerCase() === filter; });
  var unsent = receipts.filter(function (r) { return !r.sentAt; }).length;
  var filters = [["all", "All"], ["pending", "Pending"], ["complete", "Complete"]];
  return h(AppShellSeller, { title: "Sales", subtitle: "View each receipt and invoice, mark it pending or complete, and turn paid invoices into receipts." },
    h("div", { className: "seller-sales-summary" },
      h("div", null, h("strong", null, receipts.length), h("span", null, "Receipts")),
      h("div", null, h("strong", null, invoices.length), h("span", null, "Invoices")),
      h("div", null, h("strong", null, completeCount), h("span", null, "Complete")),
      h("div", null, h("strong", null, pendingCount), h("span", null, "Pending"))),
    h("div", { className: "dx-seg", style: { marginBottom: 12 } },
      h("button", { className: mode === "receipts" ? "on" : "", onClick: function () { setMode("receipts"); } }, "Receipts (" + receipts.length + ")"),
      h("button", { className: mode === "invoices" ? "on" : "", onClick: function () { setMode("invoices"); } }, "Invoices (" + invoices.length + ")")),
    h("div", { className: "sales-filter" }, filters.map(function (f) {
      return h("button", { key: f[0], type: "button", className: filter === f[0] ? "on" : "", onClick: function () { setFilter(f[0]); } }, f[1]);
    })),
    mode === "receipts" && unsent > 0 && h("div", { className: "rv-note", style: { marginBottom: 12 } }, h("span", null, "\u26A0\uFE0F"), h("span", null, unsent + " receipt(s) not sent yet. Stock only drops once a receipt is sent to the buyer.")),
    h("section", { className: "sales-doc-list" },
      shown.map(function (d) { return h(SalesDocCard, { key: kind + (d.token || d.code), kind: kind, doc: d, pp: pp }); }),
      source.length > 0 && shown.length === 0 && h("div", { className: "ll-empty" }, "Nothing in this view."),
      mode === "receipts" && receipts.length === 0 && h(EmptyState, { icon: "receipt", title: "No receipts yet", sub: "Tap Record a sale, add the M-Pesa code, and the receipt goes to the buyer on WhatsApp with a review link.", action: { label: "Record a sale", onClick: function () { pp.openModal("modal-record-sale"); } } }),
      mode === "invoices" && invoices.length === 0 && h(EmptyState, { icon: "file-text", title: "No invoices yet", sub: "Record a sale without an M-Pesa code and it goes out as a payment-link invoice.", action: { label: "Record a sale", onClick: function () { pp.openModal("modal-record-sale"); } } })
    )
  );
}

export function SaleRedirect() {
  var pp = usePlugPay();
  PR.useEffect(function () {
    replaceRoute("/seller/dashboard");
    setTimeout(function () { if (pp.merchantLoggedIn) pp.openModal("modal-record-sale"); else pp.openAuthModal(); }, 200);
  }, []);
  return null;
}
