import { json } from '../../../../src/server/supabase.js';
export async function POST() { return json({ ok: true }); }
