import { json, body, cleanPhone, authSignInOtp } from '../../../../../src/server/supabase.js';
import { devAuthEnabled, devEnsureUser } from '../../../../../src/server/devAuth.js';
export async function POST(request) {
  const { phone, role = 'seller' } = await body(request);
  const normalized = cleanPhone(phone);
  if (!normalized) return json({ error: 'Phone number is required' }, 400);
  if (devAuthEnabled()) { // DEV ONLY: no SMS; the OTP is always 123456
    const made = await devEnsureUser(normalized, role);
    if (made.error) return json({ error: made.error.message }, 400);
    return json({ ok: true, phone: normalized, role, dev: true, devOtp: '123456' });
  }
  const { error } = await authSignInOtp(normalized, { requested_role: role });
  if (error) return json({ error: error.message }, 400);
  return json({ ok: true, phone: normalized, role });
}
