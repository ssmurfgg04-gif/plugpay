import { h } from "../common/h.js";

/* ---- Landlord data and helpers ---- */
export function LlStatus(props) { return h("span", { className: "pp-status" + (props.ok ? "" : " pending") }, props.ok ? "VERIFIED" : "PENDING"); }
