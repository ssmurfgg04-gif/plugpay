import { BuildingModal } from "./BuildingModal.js";
import { BuildingPage } from "./BuildingPage.js";
import { h } from "../common/h.js";
import { PP_registry } from "../common/registry.js";
import { PP_ROUTES } from "../common/routing.js";

/* ---- Wiring: registers this group's modals, slots, pages and routes ---- */
PP_ROUTES.push(
  [/^\/buildings\/(.+)$/, "building-public", "id"]
);

PP_registry.register("modals", "building", BuildingModal, 40);

PP_registry.registerPage("building-public", function (r) { return h(BuildingPage, { id: r.id }); });
