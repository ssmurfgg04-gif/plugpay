import * as import_jsx_runtime from "../../ppJsxRuntime.js";
import { usePlugPay } from "../../store/context.js";
import { PR, h } from "./h.js";
import { Ic } from "./ui.js";

export function Toast() {
  const { toast } = usePlugPay();
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `toast${toast ? " on" : ""}`, id: "toast", children: toast });
}

export function NetBanner() {
  var _s = PR.useState(typeof navigator !== "undefined" ? navigator.onLine : true), online = _s[0], setOnline = _s[1];
  PR.useEffect(function () {
    var on = function () { setOnline(true); }, off = function () { setOnline(false); };
    window.addEventListener("online", on); window.addEventListener("offline", off);
    return function () { window.removeEventListener("online", on); window.removeEventListener("offline", off); };
  }, []);
  if (online) return null;
  return h("div", { className: "net-banner", role: "alert" }, Ic("wifi-off"), h("span", null, "You're offline. Changes won't sync until you reconnect."), h("button", { onClick: function () { setOnline(navigator.onLine); } }, "Retry"));
}
