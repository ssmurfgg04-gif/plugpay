import { usePlugPay } from "../../../../store/context.js";
import { BuildingViewContainer } from "../../../building/BuildingViewContainer.js";
import { h } from "../../../common/h.js";

export function LandlordBuildingView() {
  var pp = usePlugPay();
  return h("div", { className: "ll-building-view", style: { borderRadius: 18, overflow: "hidden", border: "1px solid var(--border)", background: "#fff", marginBottom: 14 } },
    h(BuildingViewContainer, { id: pp.lbActive.name, landlord: true }));
}
