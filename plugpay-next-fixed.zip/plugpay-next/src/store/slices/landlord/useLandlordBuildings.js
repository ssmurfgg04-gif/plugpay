/* useLandlordBuildings — "landlordBuildings" group of the PlugPay store, extracted from PlugPayProvider.
   Statements are the original ones, in their original relative order. Names owned by other groups arrive through the shared
   per-render context object (ctx): groups that run earlier are destructured below, groups that run later are read lazily as ctx.name. */
import * as import_react from "react";
import { initialLbAccounts, initialLbData } from "../../../data/landlord.js";
import { sameNumber } from "../../../lib/utils.js";
import { usePersisted } from "../../usePersisted.js";

export function useLandlordBuildings(ctx) {
    const { sellerProfile, setSellerProfile, showToast } = ctx;
    const emptyLb = { pending: [], verified: [], vacated: [], vacant: [], onPlugPay: 0 };
    const [lbAccounts, setLbAccounts] = usePersisted("lbaccounts", initialLbAccounts);
    const [lbData, setLbData] = usePersisted("lbdata", initialLbData);
    const [lbActiveId, setLbActiveId] = (0, import_react.useState)("lb1");
    const lbActive = lbAccounts.filter((a) => a.id === lbActiveId)[0] || lbAccounts[0];
    const lbCur = lbData[lbActive.id] || emptyLb;
    const pendingTraders = lbCur.pending;
    const verifiedTraders = lbCur.verified;
    const vacatedTraders = lbCur.vacated;
    const vacantStalls = lbCur.vacant;
    const updLb = (id, patch) => setLbData((d) => {
      const cur = d[id] || emptyLb;
      const p = typeof patch === "function" ? patch(cur) : patch;
      return { ...d, [id]: { ...cur, ...p } };
    });
    const lbIdByName = (name) => {
      const n = String(name || "").trim().toLowerCase();
      const a = lbAccounts.filter((x) => x.name.trim().toLowerCase() === n)[0];
      return a ? a.id : null;
    };
    const lbSwitch = (id) => {
      const a = lbAccounts.filter((x) => x.id === id)[0];
      if (!a) return;
      setLbActiveId(id);
      showToast(`Switched to ${a.name} \u2014 its own landlord account`);
    };
    const ensureLbAccount = (name, street, stalls) => {
      if (!String(name || "").trim() || lbIdByName(name)) return;
      const id = "lb" + Date.now().toString(36);
      setLbAccounts((a) => [...a, { id, name: name.trim(), street: street || "Nairobi CBD", totalStalls: Number(stalls) || 0 }]);
      setLbData((d) => ({ ...d, [id]: { ...emptyLb } }));
    };
    const llAddBuilding = (name, street, stalls) => {
      if (!String(name || "").trim()) { showToast("Enter the building name"); return false; }
      if (lbIdByName(name)) { showToast("You already manage a building with that name"); return false; }
      const id = "lb" + Date.now().toString(36);
      setLbAccounts((a) => [...a, { id, name: name.trim(), street: String(street || "").trim() || "Nairobi CBD", totalStalls: Number(stalls) || 0 }]);
      setLbData((d) => ({ ...d, [id]: { ...emptyLb } }));
      setLbActiveId(id);
      showToast(`${name.trim()} added \u2014 it has its own landlord account \u2713`);
      return true;
    };
    const landlordVerifyPending = !sellerProfile.llPhoneVerified;
    const llVerifyTrader = (id) => {
      const t = pendingTraders.filter((p) => p.id === id)[0];
      if (!t) return;
      updLb(lbActive.id, (cur) => ({ pending: cur.pending.filter((x) => x.id !== id), verified: [{ ...t, badge: "\u2713 Verified" }, ...cur.verified] }));
      if (t.phone && sameNumber(t.phone, sellerProfile.phone)) setSellerProfile((p) => ({ ...p, llPhoneVerified: true }));
      showToast(`${t.name} verified \u2713`);
    };
    return {
      lbAccounts,
      lbIdByName,
      lbData,
      emptyLb,
      ensureLbAccount,
      updLb,
      lbActive,
      lbSwitch,
      llAddBuilding,
      landlordVerifyPending,
      pendingTraders,
      verifiedTraders,
      vacatedTraders,
      vacantStalls,
      llVerifyTrader
    };
}
