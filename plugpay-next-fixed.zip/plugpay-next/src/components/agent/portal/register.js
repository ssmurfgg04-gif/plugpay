import { ClaimPage } from "../claim/ClaimPage.js";
import { AgentBuildingsPage } from "./AgentBuildingsPage.js";
import { AgentClaimsPage } from "./AgentClaimsPage.js";
import { h } from "../../common/h.js";
import { PP_registry } from "../../common/registry.js";
import { PP_ROUTES } from "../../common/routing.js";

/* ---- Wiring: registers this group's modals, slots, pages and routes ---- */
PP_ROUTES.push(
  ["/agent", "agent-buildings"],
  ["/agent/buildings", "agent-buildings"],
  ["/agent/claims", "agent-claims"],
  [/^\/claim\/(.+)$/, "claim", "token"]
);

PP_registry.registerPage("agent-buildings", function () { return h(AgentBuildingsPage, null); });

PP_registry.registerPage("agent-claims", function () { return h(AgentClaimsPage, null); });

PP_registry.registerPage("claim", function (r) { return h(ClaimPage, { token: r.token }); });
