/* useBuildingStore — "building" group of the PlugPay store, extracted from PlugPayProvider.
   Statements are the original ones, in their original relative order. Names owned by other groups arrive through the shared
   per-render context object (ctx): groups that run earlier are destructured below, groups that run later are read lazily as ctx.name. */
import * as import_react from "react";

export function useBuildingStore(ctx) {
    const { openModal } = ctx;
    const [bldgFloor, setBldgFloor] = (0, import_react.useState)("G");
    const [bldgId, setBldgId] = (0, import_react.useState)(null);
    const openBuildingModal = (0, import_react.useCallback)((id) => {
      setBldgId(typeof id === "string" ? id : null);
      openModal("modal-building");
      setBldgFloor("G");
    }, [openModal]);
    return {
      bldgFloor,
      setBldgFloor,
      bldgId,
      openBuildingModal
    };
}
