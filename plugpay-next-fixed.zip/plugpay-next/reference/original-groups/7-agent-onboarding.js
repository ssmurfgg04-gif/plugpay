
  /* ============================================================================
     AGENT ONBOARDING (gate and all stages)
     ============================================================================ */

  /* ---- Agent sign-in gate ---- */
  function AgentGate() {
    const {
      obAgentMethod,
      obAgentSetMethod,
      obAgentPhoneStep,
      obAgentPhone,
      setObAgentPhone,
      obAgentOtp,
      setObAgentOtp,
      obAgentSending,
      obAgentVerifying,
      obAgentSendOtp,
      obAgentVerifyOtp,
      closeModal,
      openLandlordModal
    } = usePlugPay();
    return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ob-agent-gate", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ob-agent-icon", children: "\u{1F4CD}" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ob-agent-title", children: "Agent sign-in required" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ob-agent-sub", children: "Verify with your email or phone to onboard a building. Every stall you register is tied to your agent ID for accountability." }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "method-toggle", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { type: "button", className: `method-toggle-btn${obAgentMethod === "sms" ? " active" : ""}`, onClick: () => obAgentSetMethod("sms"), children: "\u{1F4F1} SMS" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { type: "button", className: `method-toggle-btn${obAgentMethod === "email" ? " active" : ""}`, onClick: () => obAgentSetMethod("email"), children: "\u2709\uFE0F Email" })
      ] }),
      obAgentPhoneStep ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { className: "ob-agent-label", children: obAgentMethod === "email" ? "Email Address" : "Phone Number" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
          "input",
          {
            className: "ob-agent-input",
            type: obAgentMethod === "email" ? "email" : "tel",
            placeholder: obAgentMethod === "email" ? "you@email.com" : "07XX XXX XXX",
            value: obAgentPhone,
            onChange: (e) => setObAgentPhone(e.target.value),
            onKeyDown: (e) => {
              if (e.key === "Enter") obAgentSendOtp();
            }
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { className: "ob-agent-btn", onClick: () => obAgentSendOtp(), disabled: obAgentSending, children: obAgentSending ? "Sending\u2026" : "Send OTP \u2192" })
      ] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { className: "ob-agent-label", children: "One-Time Code" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
          "input",
          {
            className: "ob-agent-otp-input",
            type: "tel",
            placeholder: "_ _ _ _ _ _",
            maxLength: 6,
            value: obAgentOtp,
            onChange: (e) => setObAgentOtp(e.target.value),
            onKeyDown: (e) => {
              if (e.key === "Enter") obAgentVerifyOtp();
            }
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { className: "ob-agent-btn", onClick: () => obAgentVerifyOtp(), disabled: obAgentVerifying, children: obAgentVerifying ? "Verifying\u2026" : "Verify & continue \u2192" })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { textAlign: "center", marginTop: "18px", paddingTop: "16px", borderTop: "1px solid var(--border)" }, children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { fontSize: "11.5px", color: "var(--muted2)", marginBottom: "8px" }, children: "Own or manage this building instead?" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
          "a",
          {
            href: "#",
            onClick: (e) => {
              e.preventDefault();
              closeModal("modal-onboard");
              openLandlordModal();
            },
            style: { display: "inline-flex", alignItems: "center", gap: "6px", fontSize: "12.5px", fontWeight: 700, color: "var(--accent)", textDecoration: "none", fontFamily: "var(--fb)" },
            children: "\u{1F3E2} Sign in as landlord \u2192"
          }
        )
      ] })
    ] });
  }

  /* ---- Stages (buildings, floors and stalls, merchants, review) ---- */
  var seedObMerchants = [
    { id: "seed-jane", biz: "Jane Mwangi", ownerName: "Jane Mwangi", phone: "0712 345 678", floor: "3", stallNum: "14", type: "Fashion", initials: "JM", color: "#51104a", status: "done" },
    { id: "seed-peter", biz: "Peter Otieno", ownerName: "Peter Otieno", phone: "0723 456 789", floor: "3", stallNum: "12", type: "Electronics", initials: "PO", color: "#185FA5", status: "done" },
    { id: "seed-david", biz: "David Mutua", ownerName: "David Mutua", phone: "0734 567 890", floor: "2", stallNum: "5", type: "Hardware", initials: "DM", color: "#6B3DB8", status: "pending" }
  ];
  function Step1Building({ active = true }) {
    const { obBldgName, setObBldgName, obFloorsCount, setObFloorsCount, obFloorStalls, setObFloorStall, obTotalStalls } = usePlugPay();
    const n = Math.min(30, Math.max(0, parseInt(obFloorsCount) || 0));
    const floorKeys = Array.from({ length: n }, (_, i) => i === 0 ? "G" : String(i));
    return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: `ob-step${active ? " active" : ""}`, children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ob-step-label", children: "Step 1 of 2 \xB7 Building Info" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ob-section-title", children: "Building details" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ob-section-desc", children: "Enter the building's name, location, and contact. This becomes the building's permanent PlugPay listing." }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ob-field", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { className: "ob-label", children: "Building Name" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", { className: "ob-input", type: "text", placeholder: "e.g. Anniversary Towers", value: obBldgName, onChange: (e) => setObBldgName(e.target.value) })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ob-field", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { className: "ob-label", children: "Street / Location" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", { className: "ob-input", type: "text", placeholder: "e.g. Mama Ngina Street, Nairobi CBD" })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ob-field", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { className: "ob-label", children: "Google Maps Link \u2014 pinpoint exact location" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", { className: "ob-input", type: "url", placeholder: "https://maps.app.goo.gl/\u2026", inputMode: "url" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { fontSize: "10.5px", color: "var(--muted2)", fontFamily: "var(--fm)", marginTop: "6px", lineHeight: "1.5" }, children: [
          "\u{1F4CD} Open Google Maps, drop a pin, tap ",
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Share \u2192 Copy link" }),
          ", then paste here."
        ] })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ob-section-divider", style: { marginTop: "6px" }, children: "\u{1F3E2} Floors & Stalls" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ob-section-desc", style: { marginBottom: "10px" }, children: "Set the number of floors first, then enter how many stalls are on each floor. The total updates automatically." }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ob-field", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { className: "ob-label", children: "Number of Floors" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
          "input",
          {
            className: "ob-input",
            type: "number",
            placeholder: "e.g. 6",
            min: 1,
            max: 30,
            value: obFloorsCount,
            onChange: (e) => setObFloorsCount(e.target.value)
          }
        )
      ] }),
      floorKeys.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { display: "flex", flexDirection: "column", gap: "0", border: "1.5px solid var(--border)", borderRadius: "var(--r6)", overflow: "hidden", marginBottom: "10px" }, children: floorKeys.map((k, i) => {
        var _a;
        return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(
          "div",
          {
            style: { display: "flex", alignItems: "center", justifyContent: "space-between", gap: "10px", padding: "9px 12px", borderTop: i === 0 ? "none" : "1px solid var(--border)" },
            children: [
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { style: { fontSize: "12.5px", fontWeight: 700, color: "var(--ink)" }, children: k === "G" ? "Ground Floor" : `Floor ${k}` }),
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
                "input",
                {
                  type: "number",
                  min: 0,
                  placeholder: "Stalls",
                  style: { width: "90px", padding: "6px 10px", border: "1.5px solid var(--border2)", borderRadius: "var(--r6)", fontSize: "13px", fontFamily: "var(--fb)", textAlign: "right" },
                  value: (_a = obFloorStalls[k]) != null ? _a : "",
                  onChange: (e) => setObFloorStall(k, e.target.value)
                }
              )
            ]
          },
          k
        );
      }) }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { display: "flex", alignItems: "center", justifyContent: "space-between", background: "var(--accent-bg)", border: "1.5px solid var(--accent-bg2)", borderRadius: "var(--r6)", padding: "11px 14px", marginBottom: "14px" }, children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { style: { fontFamily: "var(--fm)", fontSize: "11px", fontWeight: 700, color: "var(--accent)", textTransform: "uppercase", letterSpacing: ".06em" }, children: "Total stalls" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { style: { fontFamily: "var(--fm)", fontSize: "22px", fontWeight: 900, color: "var(--accent)" }, children: obTotalStalls })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ob-section-divider", style: { marginTop: "6px" }, children: "\u{1F3E2} Landlord account" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ob-section-desc", style: { marginBottom: "10px" }, children: "This sets up an individual account for the building's landlord \u2014 they can sign in anytime to add more stall owners and complete monthly verification." }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ob-field", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { className: "ob-label", children: "Landlord / Manager Name" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", { className: "ob-input", type: "text", placeholder: "e.g. Samuel Kariuki" })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ob-row-2", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ob-field", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { className: "ob-label", children: "Landlord Phone" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", { className: "ob-input", type: "tel", placeholder: "07XX XXX XXX" })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ob-field", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { className: "ob-label", children: "Landlord Email" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", { className: "ob-input", type: "email", placeholder: "landlord@email.com" })
        ] })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ob-field", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { className: "ob-label", children: "Building Category" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", { className: "ob-select", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Mixed retail (clothing + electronics + food)" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Fashion & Textiles" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Electronics & Hardware" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Food & Groceries" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "General Market" })
        ] })
      ] })
    ] });
  }
  function StallGrid({
    stalls,
    renderCell,
    onStallClick,
    cellMinWidth = 52,
    maxHeight = 320,
    emptyMessage = "No stalls on this floor yet."
  }) {
    if (stalls.length === 0) {
      return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "stall-grid-empty", children: emptyMessage });
    }
    const scrollable = stalls.length > 24;
    return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      "div",
      {
        className: `stall-grid-scroll${scrollable ? " scroll" : ""}`,
        style: scrollable ? { maxHeight } : void 0,
        children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "stall-grid", style: { ["--stall-min"]: `${cellMinWidth}px` }, children: stalls.map((s) => {
          var _a;
          const cell = renderCell(s);
          const active = (_a = cell.clickable) != null ? _a : Boolean(onStallClick);
          return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
            "div",
            {
              className: `sg-cell${cell.className ? ` ${cell.className}` : ""}${active ? "" : " sg-static"}`,
              style: cell.style,
              title: cell.title,
              onClick: active ? () => onStallClick == null ? void 0 : onStallClick(s) : void 0,
              children: cell.label
            },
            s.id
          );
        }) })
      }
    );
  }
  var FALLBACK_FLOOR_KEYS = ["G", "1", "2", "3", "4", "5"];
  var MIN_GRID_SIZE = 12;
  function StallSellerCard(props) {
    var pp = usePlugPay();
    var ex = pp.obNewExtra || {};
    var setEx = function (k, v) { var n = Object.assign({}, ex); n[k] = v; pp.setObNewExtra(n); };
    var field = function (label, val, on, ph, type) {
      return h("div", { className: "ob-field" }, h("label", { className: "ob-label" }, label), h("input", { className: "ob-input", type: type || "text", placeholder: ph, value: val || "", onChange: function (e) { on(e.target.value); } }));
    };
    var pm = pp.obPayMethod;
    var photos = ex.photos || [];
    var fileRef = PR.useRef(null);
    var _pe = PR.useState(""), phErr = _pe[0], setPhErr = _pe[1];
    var _pb = PR.useState(false), photoBusy = _pb[0], setPhotoBusy = _pb[1];
    function addPhotos(fl) {
      var list = Array.prototype.slice.call(fl || []);
      if (!list.length) return;
      var room = 6 - photos.length;
      if (room <= 0) { setPhErr("Maximum 6 photos. Remove one to add another."); return; }
      var notImg = list.filter(function (f) { return !/^image\//.test(f.type); });
      var big = list.filter(function (f) { return /^image\//.test(f.type) && f.size > 8 * 1024 * 1024; });
      var ok = list.filter(function (f) { return /^image\//.test(f.type) && f.size <= 8 * 1024 * 1024; });
      var msg = [];
      if (notImg.length) msg.push(notImg.length + " file(s) skipped: only JPG or PNG images are allowed.");
      if (big.length) msg.push(big.length + " photo(s) skipped: larger than 8 MB.");
      if (ok.length > room) { msg.push("Only " + room + " more photo(s) fit; extras were skipped."); ok = ok.slice(0, room); }
      setPhErr(msg.join(" "));
      if (!ok.length) return;
      setPhotoBusy(true);
      var got = [], failed = 0, done = 0;
      ok.forEach(function (f, idx) {
        try { readImage(f, function (d) { if (d) got[idx] = d; else failed++; if (++done === ok.length) fin(); }); }
        catch (err) { failed++; if (++done === ok.length) fin(); }
      });
      function fin() {
        setPhotoBusy(false);
        var add = got.filter(Boolean);
        if (failed) setPhErr((msg.length ? msg.join(" ") + " " : "") + failed + " photo(s) could not be read. Try again.");
        if (add.length) setEx("photos", photos.concat(add));
      }
    }
    return h("div", { className: "ob-stall-action-card" },
      h("div", { className: "ob-stall-action-head" },
        h("span", null, (props.merchant ? "\u270F\uFE0F Edit seller" : "\u2795 Register seller") + " \u2014 " + floorLabel(props.action.floor) + ", Stall " + props.action.stallNum),
        h("button", { className: "ob-stall-action-close", onClick: props.onClose, "aria-label": "Close card" }, "\u2715")),
      h("div", { className: "ob-row-2" },
        field("Business name", pp.obNewBiz, pp.setObNewBiz, "e.g. Jane's Fashion Hub"),
        field("Owner name", pp.obNewName, pp.setObNewName, "e.g. Jane Mwangi")),
      h("div", { className: "ob-row-2" },
        field("WhatsApp / Phone", pp.obNewPhone, pp.setObNewPhone, "07XX XXX XXX", "tel"),
        h("div", { className: "ob-field" }, h("label", { className: "ob-label" }, "Category"),
          h("select", { className: "ob-select", value: pp.obNewType, onChange: function (e) { pp.setObNewType(e.target.value); } }, ["Fashion", "Electronics", "Food", "Hardware", "Beauty", "Other"].map(function (o) { return h("option", { key: o }, o); })))),
      h("details", { className: "ob-more", open: !!(ex.nid || ex.email || ex.years || ex.payNo || (ex.photos && ex.photos.length)) },
        h("summary", null, "More details \u2014 ID, payment & shop photos (optional)"),
        h("div", { className: "ob-seg" },
          h("div", { className: "ob-seg-h" }, Ic("id-card"), "Identity & business"),
          h("div", { className: "ob-row-2" }, field("National ID", ex.nid, function (v) { setEx("nid", v); }, "e.g. 28456789"), field("Email", ex.email, function (v) { setEx("email", v); }, "merchant@email.com", "email")),
          field("Years in business", ex.years, function (v) { setEx("years", v); }, "e.g. 4", "number")),
        h("div", { className: "ob-seg" },
          h("div", { className: "ob-seg-h" }, Ic("credit-card"), "Payment information"),
          h("div", { className: "ob-seg-sub" }, "Where this seller receives customer payments."),
          h("div", { className: "ob-field" }, h("label", { className: "ob-label" }, "Payment method"),
            h("select", { className: "ob-select", value: pm, onChange: function (e) { pp.setObPayMethod(e.target.value); } }, h("option", { value: "till" }, "M-Pesa Till Number"), h("option", { value: "paybill" }, "M-Pesa Paybill"), h("option", { value: "bank" }, "Bank Account"))),
          h("div", { className: "ob-row-2" },
            field(pm === "bank" ? "Account number" : pm === "paybill" ? "Paybill number" : "Till number", ex.payNo, function (v) { setEx("payNo", v); }, "e.g. 5263710"),
            field(pm === "bank" ? "Bank name" : "Registered name", ex.payName, function (v) { setEx("payName", v); }, "As registered"))),
        h("div", { className: "ob-seg" },
          h("div", { className: "ob-seg-h" }, Ic("camera"), "Shop photos"),
          h("div", { className: "ob-seg-sub" }, "Add up to 6 photos of the stall front and stock. Buyers see these on the seller's profile."),
          photos.length === 0 && h("div", { className: "ph-empty" }, Ic("image", 22), "No photos yet. Tap the box below to add some."),
          h("div", { className: "ph-grid" },
            photos.map(function (src, i) { return h("div", { className: "ph-item", key: i }, h("img", { src: src, alt: "Shop photo " + (i + 1) }), h("button", { type: "button", className: "ph-x", "aria-label": "Remove photo " + (i + 1), onClick: function () { setEx("photos", photos.filter(function (_, k) { return k !== i; })); setPhErr(""); } }, Ic("x", 12))); }),
            photos.length < 6 && h("button", { type: "button", className: "ph-add", onClick: function () { fileRef.current && fileRef.current.click(); } }, Ic("image-plus"), photoBusy ? "Adding\u2026" : "Add photo")),
          h("input", { ref: fileRef, type: "file", accept: "image/*", multiple: true, style: { display: "none" }, onChange: function (e) { addPhotos(e.target.files); e.target.value = ""; } }),
          h("div", { className: "ph-count" }, photos.length + " / 6 photos"),
          phErr && h("div", { className: "field-err", role: "alert" }, Ic("triangle-alert", 13), phErr)),
        h("div", { className: "ob-doc-note" }, "A claim link is sent to the WhatsApp number above the moment you register the seller. It opens the sign-in page; documents are added by the seller after they claim.")),
      h("div", { className: "ob-stall-action-row" },
        h("button", { className: "ob-add-merchant-btn", onClick: props.onSave }, props.merchant ? "\uD83D\uDCBE Save changes" : "\uFF0B Register seller"),
        props.merchant && h("button", { className: "ob-stall-action-profile", onClick: function () { pp.viewStallProfile({ id: props.action.stallNum, n: props.merchant.biz, s: "v" }, props.action.floor, pp.obBldgName || "New building", props.merchant); } }, Ic("user", 14), "Profile"),
        props.merchant && h("button", { className: "ob-stall-action-remove", onClick: props.onRemove }, Ic("trash-2", 14), "Remove")));
  }
  function ObReview() {
    var pp = usePlugPay();
    var list = pp.obMerchantList;
    return h(PR.Fragment, null,
      h("div", { className: "ob-section-divider" }, "\u2705 Ready to publish"),
      h("div", { className: "ob-summary-card" },
        h("div", { className: "ob-summary-row" }, h("span", { className: "ob-summary-label" }, "Building"), h("span", { className: "ob-summary-val" }, (pp.obBldgName || "\u2014") + " \u00b7 " + (pp.obFloorsCount || "\u2014") + " floors \u00b7 " + pp.obTotalStalls + " stalls")),
        h("div", { className: "ob-summary-row" }, h("span", { className: "ob-summary-label" }, "Sellers registered"), h("span", { className: "ob-summary-val" }, list.length))),
      list.length > 0 && h("div", { className: "ob-merchant-list", style: { marginTop: 10 } }, list.map(function (m) {
        return h("div", { key: m.id, className: "ob-merchant-row" },
          h("div", { className: "ob-merchant-av", style: { background: m.color } }, m.initials),
          h("div", { style: { flex: 1, minWidth: 0 } }, h("div", { className: "ob-merchant-name" }, m.biz), h("div", { className: "ob-merchant-stall" }, floorLabel(m.floor) + ", Stall " + m.stallNum + " \u00b7 " + m.type)));
      })),
      h("div", { style: { textAlign: "center", marginTop: 12, fontSize: 11, color: "var(--muted)", fontFamily: "var(--fm)" } }, "Or send a self-registration link: ", h("strong", { style: { color: "var(--accent)" } }, "plug.pay/join/anniversary-towers")),
      h("div", { className: "ob-doc-note", style: { marginTop: 10 } }, "\u26A1 Publishing goes live for every seller above at once. Buyers can then search this building and see all registered merchants."));
  }
  function Step4StallsConfirm({ active = true }) {
    var _a;
    const {
      obBldgName,
      obFloorsCount,
      obFloorStalls,
      obTotalStalls,
      obMerchantList,
      obStartEditMerchant,
      obCancelEditMerchant,
      obPrefillNewMerchantStall,
      obRemoveMerchant,
      obAddMerchant,
      obNewBiz,
      setObNewBiz,
      obNewName,
      setObNewName,
      obNewPhone,
      setObNewPhone,
      obNewType,
      setObNewType,
      obGoToStep
    } = usePlugPay();
    const n = Math.min(30, Math.max(0, parseInt(obFloorsCount) || 0));
    const floorKeys = n > 0 ? Array.from({ length: n }, (_, i) => i === 0 ? "G" : String(i)) : FALLBACK_FLOOR_KEYS;
    const [gridFloor, setGridFloor] = (0, import_react3.useState)((_a = floorKeys[0]) != null ? _a : "G");
    const [action, setAction] = (0, import_react3.useState)(null);
    const safeGridFloor = floorKeys.includes(gridFloor) ? gridFloor : floorKeys[0];
    const floorMerchants = obMerchantList.filter((m) => m.floor === safeGridFloor);
    const merchantByStall = {};
    floorMerchants.forEach((m) => {
      const num = parseInt(m.stallNum, 10);
      merchantByStall[Number.isFinite(num) && num > 0 ? String(num) : m.stallNum] = m;
    });
    const enteredCount = parseInt(obFloorStalls[safeGridFloor] || "0", 10) || 0;
    const maxOccupied = floorMerchants.reduce((mx, m) => Math.max(mx, parseInt(m.stallNum, 10) || 0), 0);
    const gridSize = Math.max(enteredCount, maxOccupied, MIN_GRID_SIZE);
    const gridStalls = Array.from({ length: gridSize }, (_, i) => {
      const num = String(i + 1);
      const m = merchantByStall[num];
      return { id: num, n: m == null ? void 0 : m.biz, s: m ? "t" : "e" };
    });
    const merchantCount = obMerchantList.length;
    const pct = merchantCount > 0 ? 100 : 60;
    const actionMerchant = (action == null ? void 0 : action.merchantId) ? obMerchantList.find((m) => m.id === action.merchantId) : void 0;
    function openStallAction(s) {
      const m = merchantByStall[s.id];
      if (m) {
        obStartEditMerchant(m.id);
        setAction({ floor: safeGridFloor, stallNum: s.id, merchantId: m.id });
      } else {
        obPrefillNewMerchantStall(safeGridFloor, s.id);
        setAction({ floor: safeGridFloor, stallNum: s.id });
      }
    }
    function closeAction() {
      obCancelEditMerchant();
      setAction(null);
    }
    function saveAction() {
      if (obAddMerchant()) setAction(null);
    }
    function removeAction() {
      if (action == null ? void 0 : action.merchantId) obRemoveMerchant(action.merchantId);
      setAction(null);
    }
    return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: `ob-step${active ? " active" : ""}`, id: "ob-step-4", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ob-step-label", children: "Step 2 of 2 \xB7 Map stalls & register sellers" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ob-section-title", children: "Map stalls & register sellers" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ob-section-desc", children: "Tap a vacant stall to register the seller there, or an occupied one to edit or remove them. Then publish everyone at once." }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ob-section-divider", style: { marginTop: "2px" }, children: "\u{1F5FA} Stall Map" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ob-field", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { className: "ob-label", children: "Select Floor" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
          "select",
          {
            className: "ob-select",
            value: safeGridFloor,
            onChange: (e) => {
              setGridFloor(e.target.value);
              closeAction();
            },
            children: floorKeys.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: k, children: floorLabel(k) }, k))
          }
        )
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "bldg-legend", style: { marginBottom: "10px" }, children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "bl-dot", style: { background: "var(--accent-bg)", border: "1px solid #c798c2" } }),
          "Occupied \u2014 tap to edit or remove"
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "bl-dot", style: { background: "var(--bg)", border: "1px solid var(--border)" } }),
          "Vacant \u2014 tap to admit a seller"
        ] })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        StallGrid,
        {
          stalls: gridStalls,
          onStallClick: openStallAction,
          renderCell: (s) => ({
            className: stallClass[s.s],
            clickable: true,
            title: s.s === "e" ? `Stall ${s.id} \u2014 vacant` : `${s.n} \u2014 Stall ${s.id}`,
            label: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: stallNameClass[s.s], children: s.id })
          })
        }
      ),
      enteredCount === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { fontSize: "10.5px", color: "var(--muted2)", fontFamily: "var(--fm)", textAlign: "center", marginTop: "6px" }, children: [
        floorLabel(safeGridFloor),
        "'s stall count isn't set yet \u2014 showing ",
        MIN_GRID_SIZE,
        " placeholder stalls. Set the exact count in Step 1."
      ] }),
      action && h(StallSellerCard, { action: action, merchant: actionMerchant, onClose: closeAction, onSave: saveAction, onRemove: removeAction }),
      h(ObReview, null)
    ] });
  }
  var STEP_META = {
    1: { title: "\u{1F4CD} Onboard a Building", sub: "Step 1 of 2 \xB7 Building details", pip: 1 },
    4: { title: "\u{1F4CD} Onboard a Building", sub: "Step 2 of 2 \xB7 Map stalls & register sellers", pip: 2 }
  };
  function OnboardFlow() {
    var _a;
    const { obAgentGate, obStep_, obStep, obMerchantList } = usePlugPay();
    const meta = (_a = STEP_META[obStep_]) != null ? _a : STEP_META[1];
    return obAgentGate ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AgentGate, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ob-header", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ob-title", children: meta.title }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ob-sub", children: meta.sub }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ob-steps-bar", children: [1, 2].map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `ob-step-pip${p <= meta.pip ? " active" : ""}` }, p)) })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ob-body", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Step1Building, { active: obStep_ === 1 }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Step4StallsConfirm, { active: obStep_ === 4 })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ob-footer", children: [
        obStep_ > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { className: "ob-btn-back", onClick: () => obStep(-1), children: "\u2190 Back" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { className: "ob-btn-primary", onClick: () => obStep(1), children: obStep_ === 4 ? `Publish ${obMerchantList.length} seller${obMerchantList.length === 1 ? "" : "s"} \u{1F680}` : "Save & Continue \u2192" })
      ] })
    ] });
  }

  /* ---- Entry: modal and page ---- */
  function OnboardModal() {
    return h(Modal, { id: "modal-onboard", innerClassName: "ob-modal" }, h(OnboardFlow, null));
  }
  function AgentOnboardingPage() {
    var pp = usePlugPay();
    PR.useEffect(function () { pp.openOnboard(); pp.closeModal("modal-onboard"); }, []);
    return h(RouteSheet, { innerClassName: "ob-modal", onClose: function () { navigate("/agent/buildings"); } }, h(OnboardFlow, null));
  }

  /* ---- Wiring: registers this group's modals, slots, pages and routes ---- */
  PP_ROUTES.push(
    ["/agent/onboarding", "agent-onboarding"]
  );
  PP_registry.register("modals", "onboard", OnboardModal, 100);
  PP_registry.registerPage("agent-onboarding", function () { return h(AgentOnboardingPage, null); });