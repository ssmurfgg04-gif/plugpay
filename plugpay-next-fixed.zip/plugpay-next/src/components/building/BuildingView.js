import { FloorMap } from "./FloorMap.js";
import { PR, h } from "../common/h.js";

/* Presentational: no context, no modal. Reusable by modal, page, landlord, agent. */
export function BuildingView(p) {
  var legend = h("div", { className: "bldg-legend" },
    h("span", null, h("span", { className: "bl-dot", style: { background: "var(--accent-bg)", border: "1px solid #c798c2" } }), "Occupied"),
    h("span", null, h("span", { className: "bl-dot", style: { background: "var(--bg)", border: "1px solid var(--border)" } }), "Vacant"));
  return h(PR.Fragment, null,
    h("div", { className: "bldg-hero bldg-hero-redesign" }, h("div", { className: "bh-inner" },
      h("div", { className: "bh-name" }, "\uD83C\uDFE2 " + p.name),
      h("div", { className: "bh-addr" }, p.address),
      h("div", { className: "bldg-hero-grid" }, p.stats.map(function (x) {
        return h("div", { className: "bldg-hero-cell", key: x.l }, h("div", { className: "bldg-hero-n" }, x.n), h("div", { className: "bldg-hero-l" }, x.l));
      })))),
    h("div", { className: "bldg-body" },
      h(FloorMap, { className: "bldg-map-section", title: "Floor map \u2014 click a stall to view merchant", titleClass: "bldg-map-label", tabs: p.tabs, floors: p.floors, floor: p.floor, onFloorChange: p.onFloorChange, onStallSelect: p.onStallSelect,
        subtitle: p.subtitle, subtitleClass: "bldg-map-sub",
        isClickable: p.isClickable || function (st) { return st.s !== "e"; }, stallTitle: p.stallTitle || function (st) { return st.s === "e" ? "Vacant" : "Occupied \u2014 tap to view seller profile"; }, footer: legend }),
      p.merchants.length > 0 && h("div", { style: { marginTop: "20px" } },
        h("div", { className: "bldg-map-label" }, "Top merchants"),
        h("div", { className: "bldg-merch-list" }, p.merchants.map(function (m) {
          return h("div", { className: "bml-item", key: m.name, onClick: function () { p.onMerchantSelect(m); } },
            h("div", { className: "bml-av", style: { background: m.color } }, m.initials),
            h("div", { className: "bml-info" }, h("div", { className: "bml-name" }, m.name), h("div", { className: "bml-sub" }, m.sub)),
            h("div", { className: "bml-rating" }, m.rating, "\u2605", h("span", { className: "bml-rev" }, " (", m.rev, ")")));
        })))));
}
