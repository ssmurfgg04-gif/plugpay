import { NetBanner, Toast } from "./feedback.js";
import { PP_registry } from "./registry.js";
import { PP_ROUTES } from "./routing.js";

/* ---- Store: lives in ./store (PlugPayProvider composes one hook per group) ---- */

/* ---- Wiring: registers this group's modals, slots, pages and routes ---- */
PP_ROUTES.push(
  ["/", "home"]
);

PP_registry.register("modals", "toast", Toast, 10);

PP_registry.register("modals", "net", NetBanner, 20);
