import { usePlugPay } from "../../store/context.js";
import { h } from "../common/h.js";
import { PublicShellX } from "../common/shells.js";
import { EmptyState } from "../common/states.js";

export function SearchPage() {
  var pp = usePlugPay();
  return h(PublicShellX, { title: "Search PlugPay", subtitle: "Find a verified seller or a connected commercial building." },
    h("div", { className: "public-content" },
      h("div", { className: "public-search-box" }, h("div", { className: "public-search-row" },
        h("input", { className: "pp-input", value: pp.query, onChange: function (e) { pp.setQuery(e.target.value); }, placeholder: "Search seller, business or building", onKeyDown: function (e) { if (e.key === "Enter") pp.doSearch(); } }),
        h("button", { className: "pp-btn primary", onClick: function () { pp.doSearch(); } }, "Search")
      )),
      pp.resultsShown && h("div", { className: "public-count" }, pp.resultsMeta),
      h("div", { className: "public-result-grid" }, pp.shownResults.map(function (r, i) {
        return h("div", { className: "public-result", key: i, style: { cursor: "pointer" }, onClick: function () { if (r.type === "merchant") pp.viewSellerProfile(); else pp.openBuildingModal(r.name); } },
          h("div", { className: "public-result-title" }, r.name),
          h("div", { className: "public-result-meta" }, r.sub)
        );
      })),
      pp.resultsShown && pp.shownResults.length === 0 && h(EmptyState, { icon: "search", title: "No matches found", sub: "Try a different seller, business or building name." })
    )
  );
}
