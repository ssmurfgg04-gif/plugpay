import { OnboardFlow } from "./OnboardFlow.js";
import { Modal } from "../../common/Modal.js";
import { h } from "../../common/h.js";

/* ---- Entry: modal and page ---- */
export function OnboardModal() {
  return h(Modal, { id: "modal-onboard", innerClassName: "ob-modal" }, h(OnboardFlow, null));
}
