import { AgentOnboardingPage } from "./AgentOnboardingPage.js";
import { OnboardModal } from "./OnboardModal.js";
import { h } from "../../common/h.js";
import { PP_registry } from "../../common/registry.js";
import { PP_ROUTES } from "../../common/routing.js";

/* ---- Wiring: registers this group's modals, slots, pages and routes ---- */
PP_ROUTES.push(
  ["/agent/onboarding", "agent-onboarding"]
);

PP_registry.register("modals", "onboard", OnboardModal, 100);

PP_registry.registerPage("agent-onboarding", function () { return h(AgentOnboardingPage, null); });
