import * as import_jsx_runtime from "../../../ppJsxRuntime.js";
import { usePlugPay } from "../../../store/context.js";
import { authCodeInput, authIconWrap, authLabel, authLink, authSubmitBtn, focusRing } from "./authStyles.js";

export function AuthPinLoginStep() {
  const { authPinLoginValue, setAuthPinLoginValue, authPinLogin, authGoBackFromPin } = usePlugPay();
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "auth-shell", children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { textAlign: "center", marginBottom: "20px" }, children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: authIconWrap, children: "\u{1F511}" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { fontSize: "22px", fontWeight: 900, color: "var(--ink)", marginBottom: "4px" }, children: "Sign in with PIN" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { fontSize: "13px", color: "var(--muted)", lineHeight: "1.55" }, children: "Enter your 6-digit PIN to unlock your stall profile." })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { style: authLabel, children: "6-DIGIT PIN" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      "input",
      {
        type: "password",
        inputMode: "numeric",
        placeholder: "_ _ _ _ _ _",
        maxLength: 6,
        style: authCodeInput,
        value: authPinLoginValue,
        onChange: (e) => setAuthPinLoginValue(e.target.value),
        onKeyDown: (e) => {
          if (e.key === "Enter") authPinLogin();
        },
        ...focusRing()
      }
    ),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { style: authSubmitBtn, onClick: () => authPinLogin(), children: "Unlock my profile \u2192" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { textAlign: "center", fontSize: "12px", color: "var(--muted2)", marginTop: "14px", fontFamily: "var(--fm)" }, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      "a",
      {
        href: "#",
        onClick: (e) => {
          e.preventDefault();
          authGoBackFromPin();
        },
        style: authLink,
        children: "\u2190 Use OTP instead"
      }
    ) })
  ] });
}
