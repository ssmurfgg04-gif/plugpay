import { merchants } from "../../data/directory.js";
import { ppSlug } from "../../lib/utils.js";
import { usePlugPay } from "../../store/context.js";
import { PR, h } from "../common/h.js";
import { goBack } from "../common/routing.js";
import { NotFoundPage, RouteSheet } from "../common/shells.js";
import { MerchantProfileBody } from "./MerchantProfileBody.js";

export function SellerPublicPage(props) {
  var pp = usePlugPay();
  var k = ppSlug(props.id);
  var found = merchants.some(function (m) { return ppSlug(m.name) === k; }) || ppSlug(pp.sellerProfile.ownerName) === k;
  PR.useLayoutEffect(function () { if (found) pp.loadSellerPage(props.id); }, [props.id]);
  if (!found) return h(NotFoundPage, { title: "Seller not found", sub: "We couldn't find a seller at this link." });
  return h(RouteSheet, { innerClassName: "modal tpModal", hideBar: true }, h(MerchantProfileBody, { onClose: goBack }));
}
