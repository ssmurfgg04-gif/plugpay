/* PlugPayProvider — composes the store hooks. Each hook owns one group of state and actions; they share one context object
   that is created fresh on every render, so late-bound calls resolve exactly as they did when everything lived in one function. */
import * as import_jsx_runtime from "../ppJsxRuntime.js";
import { PlugPayContext } from "./context.js";
import { buildContextValue } from "./contextValue.js";
import { useCoreStore } from "./slices/useCoreStore.js";
import { usePublicViewStore } from "./slices/usePublicViewStore.js";
import { useSearchStore } from "./slices/useSearchStore.js";
import { useBuildingStore } from "./slices/useBuildingStore.js";
import { useSellerRiders } from "./slices/seller/useSellerRiders.js";
import { useSellerAuth } from "./slices/seller/useSellerAuth.js";
import { useSellerStall } from "./slices/seller/useSellerStall.js";
import { useSellerSales } from "./slices/seller/useSellerSales.js";
import { useSellerCatalogue } from "./slices/seller/useSellerCatalogue.js";
import { useSellerProfile } from "./slices/seller/useSellerProfile.js";
import { useSellerRecords } from "./slices/seller/useSellerRecords.js";
import { useOnboardingState } from "./slices/onboarding/useOnboardingState.js";
import { useOnboardingAgentAuth } from "./slices/onboarding/useOnboardingAgentAuth.js";
import { useOnboardingBuilding } from "./slices/onboarding/useOnboardingBuilding.js";
import { useOnboardingMerchants } from "./slices/onboarding/useOnboardingMerchants.js";
import { useAgentClaims } from "./slices/agent/useAgentClaims.js";
import { useLandlordBuildings } from "./slices/landlord/useLandlordBuildings.js";
import { useLandlordAuth } from "./slices/landlord/useLandlordAuth.js";
import { useLandlordAdmitSeller } from "./slices/landlord/useLandlordAdmitSeller.js";

export function PlugPayProvider({ children }) {
    const ctx = {};
    Object.assign(ctx, useCoreStore(ctx));
    Object.assign(ctx, usePublicViewStore(ctx));
    Object.assign(ctx, useSearchStore(ctx));
    Object.assign(ctx, useBuildingStore(ctx));
    Object.assign(ctx, useSellerRiders(ctx));
    Object.assign(ctx, useSellerAuth(ctx));
    Object.assign(ctx, useSellerStall(ctx));
    Object.assign(ctx, useSellerSales(ctx));
    Object.assign(ctx, useSellerCatalogue(ctx));
    Object.assign(ctx, useSellerProfile(ctx));
    Object.assign(ctx, useSellerRecords(ctx));
    Object.assign(ctx, useOnboardingState(ctx));
    Object.assign(ctx, useOnboardingAgentAuth(ctx));
    Object.assign(ctx, useOnboardingBuilding(ctx));
    Object.assign(ctx, useOnboardingMerchants(ctx));
    Object.assign(ctx, useAgentClaims(ctx));
    Object.assign(ctx, useLandlordBuildings(ctx));
    Object.assign(ctx, useLandlordAuth(ctx));
    Object.assign(ctx, useLandlordAdmitSeller(ctx));

    const value = buildContextValue(ctx);
    return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlugPayContext.Provider, { value, children });
}
