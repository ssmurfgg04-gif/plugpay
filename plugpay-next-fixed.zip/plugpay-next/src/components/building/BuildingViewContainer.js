import { buildings } from "../../data/directory.js";
import { usePlugPay } from "../../store/context.js";
import { BuildingView } from "./BuildingView.js";
import { ppBuildingMerchants, ppResolveBuilding } from "./buildingData.js";
import { FLOOR_TABS, floorStallLabel, floors } from "./floors.js";
import { h } from "../common/h.js";
import { resolvePublicStallSeller } from "../public-view/resolvePublicStallSeller.js";

/* Container: the ONE building view. Modal, /buildings/:id page, seller Building tab, search, landlord and agent all render this. */
export function BuildingViewContainer(p) {
  var pp = usePlugPay();
  var ll = !!p.landlord;
  var b = ppResolveBuilding(p.id, pp.lbAccounts, pp.agentBuildings) || (p.id ? { name: String(p.id), street: "", registered: null, stalls: null, pct: null } : buildings[0]);
  var dash = function (v, suffix) { return v == null ? "\u2014" : String(v) + (suffix || ""); };
  var stats = [{ n: dash(b.registered), l: "Merchants" }, { n: dash(b.stalls), l: "Total stalls" }, { n: "4.7\u2605", l: "Avg rating" }, { n: dash(b.pct, "%"), l: "Coverage" }];
  var street = b.street || (b.sub ? String(b.sub).split(" \u00B7 ")[0] : "");
  return h(BuildingView, { name: b.name, address: (street ? street + " \u00B7 " : "") + "Nairobi CBD", stats: stats, tabs: FLOOR_TABS, floors: floors, floor: pp.bldgFloor, onFloorChange: pp.setBldgFloor,
    onStallSelect: function (st) {
      if (st.s === "e") return ll ? pp.llOpenAdmitSeller(st.id, floorStallLabel(pp.bldgFloor, st.id)) : pp.showToast("This stall is vacant");
      return pp.viewStallProfile(st, pp.bldgFloor, b.name, resolvePublicStallSeller(st) || undefined);
    },
    isClickable: ll ? function () { return true; } : undefined,
    stallTitle: ll ? function (st) { return st.s === "e" ? "Vacant \u2014 tap to admit a seller" : "Occupied \u2014 tap to view seller profile"; } : undefined,
    subtitle: ll ? "Select a stall to admit, verify, view or vacate a seller." : undefined,
    merchants: ppBuildingMerchants(b.name), onMerchantSelect: p.onMerchantSelect || pp.openDirectorySeller });
}
