import { usePlugPay } from "../../../../store/context.js";
import { h } from "../../../common/h.js";
import { AppShellX, DashSignIn } from "../../../common/shells.js";
import { EmptyState } from "../../../common/states.js";
import { LlStatus } from "../../LlStatus.js";
import { landlordVacateSeller } from "../../landlordVacateSeller.js";
import { LbSwitcher } from "../dashboard/LbSwitcher.js";

export function LandlordSellersPage() {
  var pp = usePlugPay();
  if (!pp.llAuthed) return h(AppShellX, { role: "Landlord", active: "sellers", title: "Sellers & verification" }, h(DashSignIn, { msg: "Sign in to review your sellers.", onClick: pp.openLandlordModal }));
  var total = pp.pendingTraders.length + pp.verifiedTraders.length;
  var sp = pp.sellerProfile, spVerified = !!sp.llPhoneVerified, here = pp.stallAssignment.building.trim().toLowerCase() === pp.lbActive.name.trim().toLowerCase();
  return h(AppShellX, { role: "Landlord", active: "sellers", title: pp.lbActive.name, subtitle: "Verify each seller who claims a stall. Pending until you do." },
    h(LbSwitcher, null),
    here && h("div", { className: "app-card", style: { marginBottom: 14 } },
      h("div", { className: "app-list-row", style: { border: 0, padding: 0 } },
        h("div", { className: "app-list-main" }, h("div", { className: "app-list-name" }, sp.bizName), h("div", { className: "app-list-meta" }, sp.ownerName + " \u00b7 " + sp.phone + " \u00b7 " + pp.stallAssignment.loc)),
        h(LlStatus, { ok: spVerified })),
      h("div", { className: "app-actions" },
        spVerified
          ? h("button", { className: "pp-btn danger", onClick: function () { pp.setLandlordPhoneVerified(false); } }, "Set back to Pending")
          : h("button", { className: "pp-btn primary", onClick: function () { pp.setLandlordPhoneVerified(true); } }, "Verify"))),
    h("div", { className: "app-list" },
      pp.pendingTraders.map(function (t) {
        return h("div", { className: "app-list-row", key: t.id },
          h("div", { className: "app-list-main" }, h("div", { className: "app-list-name" }, t.name), h("div", { className: "app-list-meta" }, t.sub)),
          h("div", { style: { display: "flex", gap: 8, alignItems: "center" } }, h(LlStatus, { ok: false }), h("button", { className: "pp-btn primary", onClick: function () { pp.llVerifyTrader(t.id); } }, "Verify")));
      }),
      pp.verifiedTraders.map(function (t) {
        return h("div", { className: "app-list-row", key: t.id },
          h("div", { className: "app-list-main" }, h("div", { className: "app-list-name" }, t.name), h("div", { className: "app-list-meta" }, t.sub)),
          h("div", { style: { display: "flex", gap: 8, alignItems: "center" } }, h(LlStatus, { ok: true }), h("button", { className: "pp-btn danger", onClick: function () { landlordVacateSeller(pp, t); } }, "Mark vacated")));
      }),
      total === 0 && h(EmptyState, { icon: "store", title: "No sellers in this building", sub: "Admit a seller from a vacant stall to get started." })
    )
  );
}
