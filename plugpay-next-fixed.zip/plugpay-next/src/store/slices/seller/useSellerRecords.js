/* useSellerRecords — "sellerRecords" group of the PlugPay store, extracted from PlugPayProvider.
   Statements are the original ones, in their original relative order. Names owned by other groups arrive through the shared
   per-render context object (ctx): groups that run earlier are destructured below, groups that run later are read lazily as ctx.name. */
import { emptyItemRow, reviewStatus, waInvoiceText, waReceiptText } from "../../../data/sales.js";
import { codeOf } from "../../../lib/utils.js";
import { openWhatsApp } from "../../../lib/whatsapp.js";

export function useSellerRecords(ctx) {
    const { catalogueItems, closeModal, invoicesList, openModal, receiptsList, rsCode, rsIdRef, rsItems, rsName, rsPhone, sellerProfile, setCatalogueItems, setInvoicesList, setReceipt, setReceiptsList, setRsCode, setRsItems, setRsName, setRsPhone, showToast } = ctx;
    const sentReceipts = receiptsList.filter((r) => r.sentAt && !r.demo);
    const sellerReviews = receiptsList.filter((r) => r.review).map((r) => r.review).sort((a, b) => new Date(b.at) - new Date(a.at));
    const sellerStats = (() => {
      const sum = sellerReviews.reduce((t, r) => t + r.rating, 0);
      const reviewCount = 156 + sellerReviews.length;
      const avg = (4.8 * 156 + sum) / reviewCount;
      const sales = 105 + sentReceipts.length;
      const trust = Math.min(99, Math.round(53 + (avg / 5) * 25 + Math.min(18, sales / 15)));
      const dist = { 5: 128, 4: 17, 3: 7, 2: 3, 1: 1 };
      sellerReviews.forEach((r) => { dist[r.rating] = (dist[r.rating] || 0) + 1; });
      return { avg, reviewCount, sales, trust, dist };
    })();
    const decrementStock = (items) => setCatalogueItems((c) => c.map((x) => {
      const sold = items.filter((i) => i.productId === x.id).reduce((t, i) => t + (Number(i.qty) || 1), 0);
      return sold ? { ...x, stock: Math.max(0, x.stock - sold) } : x;
    }));
    const stockShort = (items) => items.filter((i) => {
      const p = i.productId && catalogueItems.filter((x) => x.id === i.productId)[0];
      return p && (Number(i.qty) || 1) > p.stock;
    });
    const maskPhone = (p) => String(p).replace(/(\d{4}).*(\d{3})/, "$1 *** $2");
    const submitRecordSale = () => {
      const items = rsItems.filter((i) => i.name.trim() || i.price);
      if (!rsName.trim() || !rsPhone.trim() || items.length === 0) {
        showToast("Please fill all fields");
        return;
      }
      if (items.some((i) => !i.name.trim() || Number(i.price) <= 0)) {
        showToast("Add a name and price for every item");
        return;
      }
      const clean = items.map((i) => ({ name: i.name, price: Number(i.price), productId: i.productId || "", qty: Number(i.qty) || 1, unit: Number(i.unit) || Number(i.price), category: i.category || "" }));
      const total = clean.reduce((t, i) => t + i.price, 0);
      const now = new Date().toISOString();
      const hasCode = rsCode.trim().length > 0;
      if (hasCode) {
        const short = stockShort(clean);
        if (short.length) { showToast("Not enough stock for " + short[0].name); return; }
        const code = "#" + rsCode.trim().toUpperCase();
        if (receiptsList.some((r) => r.code === code)) { showToast("A receipt with that M-Pesa code already exists"); return; }
        const rc = { code, buyerName: rsName, buyerPhone: rsPhone, paymentRef: rsCode.trim().toUpperCase(), items: clean, total, createdAt: now, sentAt: now, stockApplied: true, review: null };
        setReceiptsList((l) => [rc, ...l]);
        decrementStock(clean);
        openWhatsApp(rc.buyerPhone, waReceiptText(rc, sellerProfile.bizName));
        setReceipt({ kind: "receipt", code, name: rsName, rawPhone: rsPhone, phone: maskPhone(rsPhone), items: clean, total });
        showToast(`Receipt sent to ${rsName} on WhatsApp \u2713 Review link attached`);
      } else {
        const token = "inv" + Date.now().toString(36);
        const inv = { token, buyerName: rsName, buyerPhone: rsPhone, source: "WhatsApp", items: clean, total, status: "PENDING", createdAt: now };
        setInvoicesList((l) => [inv, ...l]);
        openWhatsApp(inv.buyerPhone, waInvoiceText(inv, sellerProfile.bizName));
        setReceipt({ kind: "invoice", code: token, name: rsName, rawPhone: rsPhone, phone: maskPhone(rsPhone), items: clean, total });
        showToast(`Invoice sent to ${rsName} on WhatsApp \u2713`);
      }
      setRsName("");
      setRsPhone("");
      setRsCode("");
      setRsItems([emptyItemRow(rsIdRef.current++)]);
      closeModal("modal-record-sale");
      openModal("modal-receipt");
    };
    const resendInvoice = (token) => {
      const inv = invoicesList.filter((x) => x.token === token)[0];
      if (!inv) return;
      openWhatsApp(inv.buyerPhone, waInvoiceText(inv, sellerProfile.bizName));
      showToast(`Invoice resent to ${inv.buyerName} on WhatsApp`);
    };
    const convertInvoiceToReceipt = (token, code) => {
      const inv = invoicesList.filter((x) => x.token === token)[0];
      if (!inv) { showToast("Invoice not found"); return null; }
      if (!code || !code.trim()) { showToast("Enter the M-Pesa code or paste the payment message"); return null; }
      const rawCode = code.trim().toUpperCase();
      const found = rawCode.match(/\b(?=[A-Z0-9]*\d)(?=[A-Z0-9]*[A-Z])[A-Z0-9]{10}\b/);
      const ref = found ? found[0] : (/\s/.test(rawCode) ? "" : rawCode);
      if (!ref) { showToast("Could not find an M-Pesa code in that message"); return null; }
      const receiptCode = "#" + ref;
      if (receiptsList.some((r) => r.code === receiptCode)) { showToast("A receipt with that M-Pesa code already exists"); return null; }
      setInvoicesList((l) => l.map((x) => x.token === token ? { ...x, status: "PAID", docStatus: "COMPLETE", paymentRef: ref } : x));
      setReceiptsList((l) => [{ code: receiptCode, buyerName: inv.buyerName, buyerPhone: inv.buyerPhone, paymentRef: ref, mpesaMessage: /\s/.test(rawCode) ? code.trim() : "", items: inv.items, total: inv.total, createdAt: new Date().toISOString(), sentAt: null, stockApplied: false, review: null }, ...l]);
      showToast(`Marked as paid \u2713 Send the receipt to ${inv.buyerName} to complete the sale`);
      return receiptCode;
    };
    const setDocumentStatus = (kind, id, status) => {
      if (kind === "invoice") setInvoicesList((l) => l.map((x) => x.token === id ? { ...x, docStatus: status } : x));
      else setReceiptsList((l) => l.map((x) => x.code === id ? { ...x, docStatus: status } : x));
      showToast(status === "COMPLETE" ? "Marked as complete \u2713" : "Marked as pending");
    };
    const sendReceipt = (code) => {
      const c = codeOf(code);
      const r = receiptsList.filter((x) => codeOf(x.code) === c)[0];
      if (!r) { showToast("Receipt not found"); return false; }
      const now = new Date().toISOString();
      if (!r.stockApplied) {
        const short = stockShort(r.items);
        if (short.length) { showToast("Not enough stock for " + short[0].name + " \u2014 update your catalogue first"); return false; }
        decrementStock(r.items);
      }
      const sentAt = r.sentAt || now;
      setReceiptsList((l) => l.map((x) => x.code === r.code ? { ...x, sentAt, stockApplied: true } : x));
      openWhatsApp(r.buyerPhone, waReceiptText({ ...r, sentAt }, sellerProfile.bizName));
      showToast(r.sentAt ? `Receipt resent to ${r.buyerName || "buyer"} \u2713` : `Receipt sent to ${r.buyerName || "buyer"} \u2713 Stock updated, review link attached`);
      return true;
    };
    const submitReview = (code, data) => {
      const c = codeOf(code);
      const r = receiptsList.filter((x) => codeOf(x.code) === c)[0];
      if (!r) return { ok: false, reason: "notfound" };
      const st = reviewStatus(r);
      if (st.state === "done") return { ok: false, reason: "done" };
      if (st.state === "notsent") return { ok: false, reason: "notsent" };
      if (st.state === "expired") return { ok: false, reason: "expired" };
      if (!data || !data.rating) return { ok: false, reason: "norating" };
      const rev = { id: "rv" + Date.now().toString(36), code: r.code, buyerName: r.buyerName, rating: data.rating, comment: String(data.comment || "").trim(), at: new Date().toISOString() };
      setReceiptsList((l) => l.map((x) => x.code === r.code ? { ...x, review: rev } : x));
      showToast("Thanks for your review \u2713");
      return { ok: true };
    };
    return {
      sentReceipts,
      sellerReviews,
      sellerStats,
      sendReceipt,
      submitReview,
      resendInvoice,
      submitRecordSale,
      convertInvoiceToReceipt,
      setDocumentStatus
    };
}
