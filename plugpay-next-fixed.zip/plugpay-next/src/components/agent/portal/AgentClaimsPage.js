import { claimLink } from "../../../data/claims.js";
import { usePlugPay } from "../../../store/context.js";
import { h } from "../../common/h.js";
import { AppShellX } from "../../common/shells.js";
import { EmptyState } from "../../common/states.js";

export function AgentClaimsPage() {
  var pp = usePlugPay();
  return h(AppShellX, { role: "Agent", active: "claims", title: "Seller claim links", subtitle: "A claim link goes to each seller's WhatsApp as soon as you register them. It opens the sign-in page." },
    h("div", { className: "app-list" },
      pp.agentClaims.filter(function (c) { return c.source !== "landlord"; }).map(function (c) {
        return h("div", { className: "app-card", key: c.id },
          h("div", { className: "app-list-row", style: { border: 0, padding: 0 } },
            h("div", { className: "app-list-main" }, h("div", { className: "app-list-name" }, c.businessName || "Unnamed seller"), h("div", { className: "app-list-meta" }, c.ownerName + " \u00b7 " + (c.phone || "No phone") + " \u00b7 " + c.buildingName + " \u00b7 " + c.loc)),
            h("span", { className: "pp-status" + (c.status !== "INVITED" ? "" : " pending") }, c.status === "INVITED" ? "LINK SENT" : "CLAIMED")),
          c.status === "INVITED" && h("div", { className: "app-actions" },
            h("button", { className: "pp-btn primary", onClick: function () { pp.resendClaim(c.token); } }, "Resend on WhatsApp"),
            h("button", { className: "pp-btn secondary", onClick: function () { pp.copyText(claimLink(c.token), "Claim link copied"); } }, "Copy link")));
      }),
      pp.agentClaims.filter(function (c) { return c.source !== "landlord"; }).length === 0 && h(EmptyState, { icon: "mail", title: "No claim links yet", sub: "Register a seller in a building and their claim link is sent to WhatsApp automatically.", action: { label: "Onboard a building", onClick: pp.openOnboard } })
    )
  );
}
