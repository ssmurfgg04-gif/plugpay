
  /* ============================================================================
     QUICK ACTION
     ============================================================================ */
  function FabQuick() {
    const { openModal } = usePlugPay();
    return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { className: "fab-quick", onClick: () => openModal("modal-quick"), title: "Quick actions", "aria-label": "Quick actions", children: "\u26A1" });
  }
  function QuickModal() {
    const { closeModal, openModal, openMerchantModal, openBuildingModal, openOnboard, openAuthModal, showToast, requireSellerLogin, sellerProfile } = usePlugPay();
    const go = (fn) => {
      closeModal("modal-quick");
      fn();
    };
    return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, { id: "modal-quick", children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "qa-modal", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "qa-modal-title", children: "Quick actions" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "qa-modal-sub", children: "What would you like to do?" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "qa-list", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "qa-item", onClick: () => go(() => { if (requireSellerLogin("record a sale")) openModal("modal-record-sale"); }), children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "qa-ico qi1", children: "\u{1F9FE}" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "qa-label", children: "Record a sale" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "qa-desc", children: "Send a receipt on WhatsApp, or an invoice if it isn't paid yet" })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "qa-arr", children: "\u2192" })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "qa-item", onClick: () => go(() => openMerchantModal()), children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "qa-ico qi2", children: "\u{1F464}" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "qa-label", children: "View merchant profile" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "qa-desc", children: sellerProfile.ownerName + " \xB7 " + sellerProfile.bizName })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "qa-arr", children: "\u2192" })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "qa-item", onClick: () => go(() => openBuildingModal()), children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "qa-ico qi3", children: "\u{1F3E2}" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "qa-label", children: "Browse building map" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "qa-desc", children: "Anniversary Towers \xB7 72 stalls \xB7 58 registered" })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "qa-arr", children: "\u2192" })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "qa-item", onClick: () => go(() => openOnboard()), children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "qa-ico qi4", style: { background: "#EEEDFE" }, children: "\u{1F4CD}" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "qa-label", children: "Onboard a building" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "qa-desc", children: "Register a new building with stalls & merchants" })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "qa-arr", children: "\u2192" })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "qa-item", onClick: () => go(() => openAuthModal()), children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "qa-ico qi4", children: "\u{1F510}" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "qa-label", children: "Sign in to your stall" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "qa-desc", children: "Enter your number to access your profile" })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "qa-arr", children: "\u2192" })
        ] }),
      ] })
    ] }) });
  }

  /* ---- Wiring: registers this group's modals, slots, pages and routes ---- */
  PP_registry.register("modals", "quick", QuickModal, 50);
  PP_registry.register("landing", "fab", FabQuick, 90);