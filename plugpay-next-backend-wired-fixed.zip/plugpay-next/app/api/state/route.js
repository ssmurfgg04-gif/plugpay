import { adminDb, requireUser, json, body } from '../../../src/server/supabase.js';
export async function GET(request) {
  const auth = await requireUser(request); if (auth.error) return auth.error;
  const key = new URL(request.url).searchParams.get('key');
  if (!key || key.length > 120) return json({ error: 'Invalid state key' }, 400);
  const db = adminDb(); const { data, error } = await db.from('ui_state').select('state').eq('owner_id', auth.user.id).eq('state_key', key).maybeSingle();
  if (error) return json({ error: error.message }, 500); return json({ state: data?.state ?? null });
}
export async function PUT(request) {
  const auth = await requireUser(request); if (auth.error) return auth.error;
  const { key, state } = await body(request);
  if (!key || key.length > 120) return json({ error: 'Invalid state key' }, 400);
  const db = adminDb(); const { error } = await db.from('ui_state').upsert({ owner_id: auth.user.id, state_key: key, state: state ?? null, updated_at: new Date().toISOString() }, { onConflict: 'owner_id,state_key' });
  if (error) return json({ error: error.message }, 500); return json({ ok: true });
}
