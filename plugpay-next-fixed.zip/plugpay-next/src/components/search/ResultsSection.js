import * as import_jsx_runtime from "../../ppJsxRuntime.js";
import { usePlugPay } from "../../store/context.js";
import { ResultCard } from "./ResultCards.js";

export function ResultsSection() {
  const { resultsShown, resultsTitle, resultsMeta, shownResults, hasMore, moreHint, filter, setFilter, loadMore } = usePlugPay();
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `results-section results-container${resultsShown ? " on" : ""}`, id: "results-section", children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "results-inner", children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "results-header", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "results-title", id: "results-title", children: resultsTitle }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "results-meta", id: "results-meta", children: resultsMeta })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { display: "flex", gap: "8px" }, children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { className: `rf${filter === "all" ? " on" : ""}`, onClick: () => setFilter("all"), children: "All" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { className: `rf${filter === "merchant" ? " on" : ""}`, onClick: () => setFilter("merchant"), children: "Merchants" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { className: `rf${filter === "building" ? " on" : ""}`, onClick: () => setFilter("building"), children: "Buildings" })
      ] })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "results-grid", id: "results-grid", children: shownResults.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultCard, { result: r }, r.name + i)) }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "load-more-wrap", id: "load-more-wrap", style: { display: hasMore ? "block" : "none" }, children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { className: "load-more-btn", onClick: () => loadMore(), children: "Show more results \u2192" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "load-more-hint", id: "load-more-hint", children: hasMore ? moreHint : "" })
    ] })
  ] }) });
}
