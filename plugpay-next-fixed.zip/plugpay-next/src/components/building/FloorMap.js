import { StallGrid } from "../agent/onboarding/StallGrid.js";
import { stallClass, stallNameClass } from "./floors.js";
import { h } from "../common/h.js";

export function FloorMap(props) {
  return h("div", { className: props.className },
    props.title && h("div", { className: props.titleClass }, props.title),
    props.subtitle && h("div", { className: props.subtitleClass }, props.subtitle),
    h("div", { className: "bldg-floor-tabs" }, props.tabs.map(function (f) {
      return h("button", { key: f.key, className: "bft" + (props.floor === f.key ? " on" : ""), onClick: function () { props.onFloorChange(f.key); } }, f.label);
    })),
    h(StallGrid, { stalls: props.floors[props.floor] || [], onStallClick: props.onStallSelect,
      renderCell: function (st) { return { className: stallClass[st.s], clickable: props.isClickable(st), title: props.stallTitle(st), label: h("span", { className: stallNameClass[st.s] }, st.id) }; } }),
    props.footer);
}
