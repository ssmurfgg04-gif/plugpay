import * as import_jsx_runtime from "../../../ppJsxRuntime.js";
import { usePlugPay } from "../../../store/context.js";
import { llAuthCodeInput, llAuthIconWrap, llAuthLabel, llAuthLink, llAuthSubmitBtn, llAuthTextInput, llFocusRing } from "./llAuthStyles.js";

export function LlPinLoginStep() {
  const { llPinLoginPhone, setLlPinLoginPhone, llPinLoginPin, setLlPinLoginPin, llPinLogin, llGoBackFromPin } = usePlugPay();
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { padding: "32px" }, children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { textAlign: "center", marginBottom: "20px" }, children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: llAuthIconWrap, children: "\u{1F511}" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { fontSize: "22px", fontWeight: 900, color: "var(--ink)", marginBottom: "4px" }, children: "Sign in with PIN" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { fontSize: "13px", color: "var(--muted)", lineHeight: "1.55" }, children: "Enter your phone number and 6-digit PIN." })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { style: llAuthLabel, children: "PHONE NUMBER" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      "input",
      {
        type: "tel",
        placeholder: "07XX XXX XXX",
        style: { ...llAuthTextInput, marginBottom: "14px" },
        value: llPinLoginPhone,
        onChange: (e) => setLlPinLoginPhone(e.target.value),
        ...llFocusRing()
      }
    ),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { style: llAuthLabel, children: "6-DIGIT PIN" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      "input",
      {
        type: "password",
        inputMode: "numeric",
        placeholder: "_ _ _ _ _ _",
        maxLength: 6,
        style: llAuthCodeInput,
        value: llPinLoginPin,
        onChange: (e) => setLlPinLoginPin(e.target.value),
        onKeyDown: (e) => {
          if (e.key === "Enter") llPinLogin();
        },
        ...llFocusRing()
      }
    ),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { style: llAuthSubmitBtn, onClick: () => llPinLogin(), children: "Sign in \u2192" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { textAlign: "center", fontSize: "12px", color: "var(--muted2)", marginTop: "14px", fontFamily: "var(--fm)" }, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      "a",
      {
        href: "#",
        onClick: (e) => {
          e.preventDefault();
          llGoBackFromPin();
        },
        style: llAuthLink,
        children: "\u2190 Use OTP instead"
      }
    ) })
  ] });
}
