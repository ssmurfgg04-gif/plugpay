import { usePlugPay } from "../../../../store/context.js";
import { h } from "../../../common/h.js";
import { Slot } from "../../../common/registry.js";
import { AppShellX, DashSignIn } from "../../../common/shells.js";

export function LandlordDashboardPage() {
  var pp = usePlugPay();
  if (!pp.llAuthed) return h(AppShellX, { role: "Landlord", active: "dashboard", title: "Landlord dashboard" }, h(DashSignIn, { msg: "Sign in to your landlord account to view your dashboard.", onClick: pp.openLandlordModal }));
  return h(AppShellX, { role: "Landlord", active: "dashboard", title: pp.lbActive.name, subtitle: "Manage your building, sellers, verification and vacant stalls." }, h(Slot, { name: "landlord.dashboard" }));
}
