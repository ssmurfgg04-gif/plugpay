/* useOnboardingState — "onbState" group of the PlugPay store, extracted from PlugPayProvider.
   Statements are the original ones, in their original relative order. Names owned by other groups arrive through the shared
   per-render context object (ctx): groups that run earlier are destructured below, groups that run later are read lazily as ctx.name. */
import * as import_react from "react";
import { seedObMerchants } from "../../../data/onboarding.js";

export function useOnboardingState(ctx) {
    const [obAgentGate, setObAgentGate] = (0, import_react.useState)(true);
    const [obAgentMethod, setObAgentMethodState] = (0, import_react.useState)("sms");
    const [obAgentPhoneStep, setObAgentPhoneStep] = (0, import_react.useState)(true);
    const [obAgentPhone, setObAgentPhone] = (0, import_react.useState)("");
    const [obAgentOtp, setObAgentOtp] = (0, import_react.useState)("");
    const [obAgentSending, setObAgentSending] = (0, import_react.useState)(false);
    const [obAgentVerifying, setObAgentVerifying] = (0, import_react.useState)(false);
    const [obStep_, setObStep_] = (0, import_react.useState)(1);
    const [obBldgName, setObBldgName] = (0, import_react.useState)("");
    const [obFloorsCount, setObFloorsCount] = (0, import_react.useState)("6");
    const [obFloorStalls, setObFloorStallsState] = (0, import_react.useState)({});
    const [obPayMethod, setObPayMethod] = (0, import_react.useState)("till");
    const [obMerchantList, setObMerchantList] = (0, import_react.useState)(seedObMerchants);
    const obMerchantIdRef = (0, import_react.useRef)(1);
    const [obEditingMerchantId, setObEditingMerchantId] = (0, import_react.useState)(null);
    const [obNewName, setObNewName] = (0, import_react.useState)("");
    const [obNewPhone, setObNewPhone] = (0, import_react.useState)("");
    const [obNewStallNum, setObNewStallNum] = (0, import_react.useState)("");
    const [obNewFloor, setObNewFloor] = (0, import_react.useState)("G");
    const [obNewBiz, setObNewBiz] = (0, import_react.useState)("");
    const [obNewType, setObNewType] = (0, import_react.useState)("Fashion");
    const [obNewExtra, setObNewExtra] = (0, import_react.useState)({});
    return {
      obMerchantList,
      setObAgentMethodState,
      setObAgentPhone,
      setObAgentGate,
      setObAgentPhoneStep,
      setObAgentOtp,
      setObMerchantList,
      setObEditingMerchantId,
      setObStep_,
      obAgentPhone,
      obAgentMethod,
      setObAgentSending,
      obAgentOtp,
      setObAgentVerifying,
      setObFloorStallsState,
      obFloorStalls,
      obStep_,
      obBldgName,
      obFloorsCount,
      obNewBiz,
      obNewName,
      obNewPhone,
      obNewStallNum,
      obEditingMerchantId,
      obNewFloor,
      obNewType,
      obNewExtra,
      obMerchantIdRef,
      setObNewName,
      setObNewPhone,
      setObNewStallNum,
      setObNewFloor,
      setObNewBiz,
      setObNewType,
      setObNewExtra,
      obAgentGate,
      obAgentPhoneStep,
      obAgentSending,
      obAgentVerifying,
      setObBldgName,
      setObFloorsCount,
      obPayMethod,
      setObPayMethod
    };
}
