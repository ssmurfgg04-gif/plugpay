import { requireUser, json, body, authUpdatePassword } from '../../../../../src/server/supabase.js';
export async function POST(request) {
  const auth = await requireUser(request); if (auth.error) return auth.error;
  const { pin } = await body(request);
  if (!/^\d{6}$/.test(String(pin || ''))) return json({ error: 'PIN must be exactly 6 digits' }, 400);
  const { error } = await authUpdatePassword(auth.token, String(pin));
  if (error) return json({ error: error.message }, 400);
  return json({ ok: true });
}
