/* useLandlordAdmitSeller — "landlordAdmit" group of the PlugPay store, extracted from PlugPayProvider.
   Statements are the original ones, in their original relative order. Names owned by other groups arrive through the shared
   per-render context object (ctx): groups that run earlier are destructured below, groups that run later are read lazily as ctx.name. */
import * as import_react from "react";
import { initials } from "../../../lib/utils.js";

export function useLandlordAdmitSeller(ctx) {
    const { closeModal, lbActive, openModal, setAgentClaims, showToast, updLb } = ctx;
    const [asStall, setAsStall] = (0, import_react.useState)(null);
    const [asName, setAsName] = (0, import_react.useState)("");
    const [asPhone, setAsPhone] = (0, import_react.useState)("");
    const [asCategory, setAsCategory] = (0, import_react.useState)("");
    const [asSubmitting, setAsSubmitting] = (0, import_react.useState)(false);
    const asStallLabel = asStall ? `Into ${asStall.label} \u2014 ${lbActive.name}` : "";
    const llOpenAdmitSeller = (0, import_react.useCallback)(
      (stallId, stallLabel) => {
        setAsStall({ id: stallId, label: stallLabel });
        setAsName("");
        setAsPhone("");
        setAsCategory("");
        openModal("modal-admit-seller");
      },
      [openModal]
    );
    const llSubmitAdmitSeller = () => {
      if (!asName.trim() || !asPhone.trim() || !asCategory.trim()) {
        showToast("Please fill in all fields");
        return;
      }
      if (!asStall) {
        closeModal("modal-admit-seller");
        return;
      }
      const stall = asStall, name = asName.trim(), phone = asPhone.trim(), category = asCategory.trim();
      const token = "clm" + Date.now().toString(36);
      const colors = ["#51104a", "#185FA5", "#534AB7", "#BA7517", "#8b008b"];
      const color = colors[Math.floor(Math.random() * colors.length)];
      setAgentClaims((l) => [{ id: token, token, businessName: "", ownerName: name, phone, category, floor: "", number: stall.id, loc: stall.label, buildingName: lbActive.name, status: "INVITED", verified: true, source: "landlord", sentAt: new Date().toISOString() }, ...l]);
      updLb(lbActive.id, (cur) => ({
        vacant: cur.vacant.filter((s) => s.id !== stall.id),
        onPlugPay: cur.onPlugPay + 1,
        verified: [{ id: "nv-" + token, claimToken: token, name, phone, sub: `${category} \u00b7 ${stall.label}`, initials: initials(name), color, badge: "\u2713 Verified" }, ...cur.verified]
      }));
      showToast(`${name} admitted & verified \u2713 Claim link sent to ${phone} on WhatsApp`);
      setAsStall(null);
      closeModal("modal-admit-seller");
    };
    return {
      llOpenAdmitSeller,
      asStallLabel,
      asName,
      setAsName,
      asPhone,
      setAsPhone,
      asCategory,
      setAsCategory,
      asSubmitting,
      llSubmitAdmitSeller
    };
}
