import { usePlugPay } from "../../store/context.js";

// The official profile reads its data through this hook so own and other sellers render identically.
export function useSV() {
  var pp = usePlugPay(), v = pp.viewedSeller;
  if (v) return { own: false, profile: v.profile, stats: v.stats, assignment: v.assignment, pending: !v.verified, catalogue: v.catalogue, reviews: [] };
  return { own: true, profile: pp.sellerProfile, stats: pp.sellerStats, assignment: pp.stallAssignment, pending: pp.landlordVerifyPending, catalogue: pp.catalogueItems, reviews: pp.sellerReviews };
}
