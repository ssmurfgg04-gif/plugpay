import { adminDb, json, body, cleanPhone, authVerifyOtp } from '../../../../../src/server/supabase.js';
import { devAuthEnabled, devSession, DEV_OTP } from '../../../../../src/server/devAuth.js';
export async function POST(request) {
  const { phone, token, role = 'seller' } = await body(request);
  const normalized = cleanPhone(phone);
  if (!normalized || !/^\d{4,8}$/.test(String(token || ''))) return json({ error: 'Valid phone and OTP are required' }, 400);
  let data, error;
  if (devAuthEnabled()) { // DEV ONLY: fixed OTP
    if (String(token) !== DEV_OTP) return json({ error: 'Invalid OTP (dev mode: use 123456)' }, 401);
    ({ data, error } = await devSession(normalized, role));
  } else {
    ({ data, error } = await authVerifyOtp(normalized, String(token)));
  }
  const session = data?.session || (data?.access_token ? data : null); // GoTrue returns the session flat; supabase-js wraps it
  if (error || !session || !data.user) return json({ error: error?.message || 'OTP verification failed' }, 401);
  const admin = adminDb();
  const roles = [role].filter(Boolean);
  await admin.from('profiles').upsert({ id: data.user.id, phone: normalized, email: data.user.email || null, roles }, { onConflict: 'id' });
  if (role === 'seller') {
    await admin.from('sellers').upsert({ user_id: data.user.id, business_name: data.user.user_metadata?.business_name || 'New seller', owner_name: data.user.user_metadata?.full_name || 'Seller', phone: normalized }, { onConflict: 'user_id', ignoreDuplicates: true });
  }
  return json({ ok: true, access_token: session.access_token, refresh_token: session.refresh_token, expires_at: session.expires_at, user: { id: data.user.id, phone: normalized, role } });
}
