import * as import_jsx_runtime from "../../../ppJsxRuntime.js";
import { usePlugPay } from "../../../store/context.js";
import { Modal } from "../../common/Modal.js";
import { h } from "../../common/h.js";
import { Link } from "../../common/routing.js";
import { Ic } from "../../common/ui.js";

export function RecordSaleModal() {
  const { rsName, setRsName, rsPhone, setRsPhone, rsCode, setRsCode, rsTotal, rsSubmitting, submitRecordSale, focusMerchantProfileTab, sellerProfile } = usePlugPay();
  const hasCode = rsCode.trim().length > 0;
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(
    Modal,
    {
      id: "modal-record-sale",
      innerClassName: "plc-modal",
      closeButtonStyle: { background: "rgba(255,255,255,.22)", color: "#fff", borderColor: "rgba(255,255,255,.65)" },
      onExit: focusMerchantProfileTab,
      children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "plc-head", style: { background: "#8b008b" }, children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "plc-title", children: "Record a sale" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "plc-sub", children: ["For ", sellerProfile.bizName, " \xB7 Add the M-Pesa code once it's paid to send a receipt, or leave it blank to send a payment-link invoice."] })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "plc-body", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "plc-field", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { className: "plc-label", children: "Buyer Name" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
              "input",
              {
                className: "plc-input",
                type: "text",
                placeholder: "e.g. John Kamau",
                value: rsName,
                onChange: (e) => setRsName(e.target.value)
              }
            )
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "plc-field", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { className: "plc-label", children: "Buyer Phone" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
              "input",
              {
                className: "plc-input",
                type: "tel",
                placeholder: "07XX XXX XXX",
                value: rsPhone,
                onChange: (e) => setRsPhone(e.target.value)
              }
            )
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemRowsField, { prefix: "rs" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "plc-total-row", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Total" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
              "KSh ",
              rsTotal.toLocaleString()
            ] })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "plc-field", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { className: "plc-label", children: "M-Pesa Transaction Code (optional)" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
              "input",
              {
                className: "plc-input",
                type: "text",
                style: { textTransform: "uppercase" },
                placeholder: "e.g. SJK7H92LQA \u2014 leave blank to send an invoice instead",
                value: rsCode,
                onChange: (e) => setRsCode(e.target.value)
              }
            ),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "icf-hint", style: { marginTop: 6, marginBottom: 0 }, children: hasCode ? "This will be recorded as a completed sale and a receipt will be sent." : "No code yet? This will send a payment-link invoice instead \u2014 add the code later to turn it into a receipt." })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { className: "plc-submit", onClick: () => submitRecordSale(), disabled: rsSubmitting, children: rsSubmitting ? "Sending\u2026" : hasCode ? "Record sale & send receipt \u2192" : "Send invoice via WhatsApp \u2192" })
        ] })
      ]
    }
  );
}

function ItemRowsField(props) {
  var prefix = props.prefix, pp = usePlugPay();
  var items = pp.rsItems, cat = pp.catalogueItems, isReceipt = true;
  var listId = "cat-names-" + prefix;
  function patch(row, p) { pp.updateItemRow(prefix, row.id, p); }
  function fromProduct(row, p, qty) {
    patch(row, { productId: p.id, name: p.name, unit: String(p.price), qty: qty, price: String(Number(p.price) * qty), category: p.category });
  }
  function pick(row, id) {
    if (!id) { patch(row, { productId: "", category: "" }); return; }
    var p = cat.filter(function (x) { return x.id === id; })[0];
    if (p) fromProduct(row, p, Math.max(1, Number(row.qty) || 1));
  }
  function setName(row, v) {
    var m = cat.filter(function (x) { return x.name.toLowerCase() === v.trim().toLowerCase(); })[0];
    if (m) { fromProduct(row, m, Math.max(1, Number(row.qty) || 1)); return; }
    var linked = row.productId && cat.filter(function (x) { return x.id === row.productId && x.name === v; })[0];
    patch(row, { name: v, productId: linked ? row.productId : "", category: linked ? row.category : "" });
  }
  function setQty(row, v) { var q = Math.max(1, parseInt(v, 10) || 1); var u = Number(row.unit) || 0; patch(row, { qty: q, price: u ? String(u * q) : row.price }); }
  function setUnit(row, v) { var q = Number(row.qty) || 1; patch(row, { unit: v, price: v === "" ? "" : String((Number(v) || 0) * q) }); }
  return h("div", { className: "plc-field" },
    h("label", { className: "plc-label" }, "Products / Services"),
    cat.length === 0
      ? h("div", { className: "icf-hint" }, Ic("package"), h("span", null, "Your catalogue is empty. ", h(Link, { to: "/seller/catalogue" }, "Add products"), " to autofill items here."))
      : h("div", { className: "icf-hint" }, Ic("zap"), h("span", null, "Pick a product from your catalogue to autofill the name and price. This also keeps your sales analytics and stock accurate.")),
    h("datalist", { id: listId }, cat.map(function (c) { return h("option", { key: c.id, value: c.name }); })),
    items.map(function (row) {
      var p = row.productId ? cat.filter(function (x) { return x.id === row.productId; })[0] : null;
      var over = isReceipt && p && (Number(row.qty) || 1) > p.stock;
      var line = Number(row.price) || 0;
      return h("div", { key: row.id, className: "icf-row" + (p ? " linked" : "") },
        h("select", { className: "plc-input", value: row.productId || "", onChange: function (e) { pick(row, e.target.value); }, "aria-label": "Catalogue product" },
          h("option", { value: "" }, cat.length ? "Custom item (type below)" : "No catalogue products"),
          cat.map(function (c) { return h("option", { key: c.id, value: c.id, disabled: isReceipt && c.stock <= 0 }, c.name + " \u2014 KSh " + Number(c.price).toLocaleString() + (c.stock <= 0 ? " (out of stock)" : " (" + c.stock + " in stock)")); })),
        h("div", { className: "icf-line" },
          h("input", { className: "plc-input icf-name", type: "text", list: listId, placeholder: "Item name", value: row.name, onChange: function (e) { setName(row, e.target.value); } }),
          h("input", { className: "plc-input icf-qty", type: "number", min: 1, step: 1, title: "Quantity", "aria-label": "Quantity", value: row.qty == null ? 1 : row.qty, onChange: function (e) { setQty(row, e.target.value); } }),
          h("input", { className: "plc-input icf-unit", type: "number", min: 1, placeholder: "Unit KSh", title: "Unit price", "aria-label": "Unit price", value: row.unit == null ? "" : row.unit, onChange: function (e) { setUnit(row, e.target.value); } }),
          h("div", { className: "icf-total" }, "KSh " + line.toLocaleString()),
          h("button", { type: "button", className: "plc-item-remove", onClick: function () { pp.removeItemRow(prefix, row.id); }, title: "Remove item", "aria-label": "Remove item", style: { visibility: items.length > 1 ? "visible" : "hidden" } }, "\u2715")),
        p && !over && h("div", { className: "icf-tag" }, Ic("link", 12), "Linked to catalogue \u00b7 " + p.category + " \u00b7 " + p.stock + " in stock"),
        over && h("div", { className: "field-err" }, Ic("triangle-alert", 13), "Only " + p.stock + " in stock. Reduce the quantity."));
    }),
    h("button", { type: "button", className: "plc-add-item", onClick: function () { pp.addItemRow(prefix); } }, "\uFF0B Add another item"));
}
