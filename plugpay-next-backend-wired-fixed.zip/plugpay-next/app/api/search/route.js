import { adminDb, json } from '../../../src/server/supabase.js';
export async function GET(request) {
  const q = (new URL(request.url).searchParams.get('q') || '').trim();
  const type = new URL(request.url).searchParams.get('type') || 'all';
  const db = adminDb();
  const out = [];
  if (type === 'all' || type === 'merchant') {
    let query = db.from('sellers').select('id,business_name,owner_name,category,address,verification_status').order('business_name').limit(50);
    if (q) query = query.or(`business_name.ilike.%${q}%,owner_name.ilike.%${q}%,category.ilike.%${q}%,address.ilike.%${q}%`);
    const { data } = await query; (data || []).forEach(x => out.push({ id:x.id, type:'merchant', name:x.business_name, sub:[x.category,x.address].filter(Boolean).join(' · '), sellerId:x.id, verified:x.verification_status === 'verified' }));
  }
  if (type === 'all' || type === 'building') {
    let query = db.from('buildings').select('id,name,address,category').order('name').limit(50);
    if (q) query = query.or(`name.ilike.%${q}%,address.ilike.%${q}%,category.ilike.%${q}%`);
    const { data } = await query; (data || []).forEach(x => out.push({ id:x.id, type:'building', name:x.name, sub:[x.category,x.address].filter(Boolean).join(' · '), buildingId:x.id }));
  }
  return json({ results: out });
}
