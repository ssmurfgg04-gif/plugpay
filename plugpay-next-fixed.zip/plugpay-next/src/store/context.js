import * as import_react from "react";
import * as import_react2 from "react";

export var PlugPayContext = (0, import_react.createContext)(null);

export function usePlugPay() {
    const ctx = (0, import_react2.useContext)(PlugPayContext);
    if (!ctx) throw new Error("usePlugPay must be used inside <PlugPayProvider>");
    return ctx;
  }
