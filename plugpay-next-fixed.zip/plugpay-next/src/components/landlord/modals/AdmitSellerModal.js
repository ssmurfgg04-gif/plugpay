import * as import_jsx_runtime from "../../../ppJsxRuntime.js";
import { usePlugPay } from "../../../store/context.js";
import { Modal } from "../../common/Modal.js";

/* ---- Admit seller ---- */
var labelStyle = {
  fontSize: "11px",
  fontWeight: 700,
  color: "var(--muted)",
  fontFamily: "var(--fm)",
  display: "block",
  marginBottom: "6px",
  textTransform: "uppercase",
  letterSpacing: ".06em"
};

var inputStyle = {
  width: "100%",
  padding: "12px 14px",
  border: "1.5px solid var(--border2)",
  borderRadius: "var(--r6)",
  fontSize: "14.5px",
  fontFamily: "var(--fb)",
  outline: "none",
  background: "var(--bg)",
  marginBottom: "12px"
};

function focusHandlers() {
  return {
    onFocus: (e) => e.currentTarget.style.borderColor = "var(--accent)",
    onBlur: (e) => e.currentTarget.style.borderColor = "var(--border2)"
  };
}

export function AdmitSellerModal() {
  const {
    asStallLabel,
    asName,
    setAsName,
    asPhone,
    setAsPhone,
    asCategory,
    setAsCategory,
    asSubmitting,
    llSubmitAdmitSeller
  } = usePlugPay();
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, { id: "modal-admit-seller", innerClassName: "modal", children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { padding: "48px 24px 24px", maxWidth: "380px" }, children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { textAlign: "center", marginBottom: "18px" }, children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        "div",
        {
          style: {
            width: "52px",
            height: "52px",
            borderRadius: "50%",
            background: "var(--accent-bg)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: "24px",
            margin: "0 auto 10px"
          },
          children: "\u{1F513}"
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { fontSize: "19px", fontWeight: 900, color: "var(--ink)", marginBottom: "4px" }, children: "Admit a new seller" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { fontSize: "12.5px", color: "var(--muted)", lineHeight: "1.55" }, children: asStallLabel || "Into an unoccupied stall" })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { style: labelStyle, children: "SELLER NAME" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      "input",
      {
        type: "text",
        placeholder: "e.g. Grace Wambui",
        style: inputStyle,
        value: asName,
        onChange: (e) => setAsName(e.target.value),
        ...focusHandlers()
      }
    ),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { style: labelStyle, children: "PHONE NUMBER" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      "input",
      {
        type: "tel",
        placeholder: "07XX XXX XXX",
        style: inputStyle,
        value: asPhone,
        onChange: (e) => setAsPhone(e.target.value),
        ...focusHandlers()
      }
    ),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { style: labelStyle, children: "BUSINESS CATEGORY" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      "input",
      {
        type: "text",
        placeholder: "e.g. Fashion, Electronics\u2026",
        style: { ...inputStyle, marginBottom: "16px" },
        value: asCategory,
        onChange: (e) => setAsCategory(e.target.value),
        onKeyDown: (e) => {
          if (e.key === "Enter") llSubmitAdmitSeller();
        },
        ...focusHandlers()
      }
    ),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(
      "div",
      {
        style: {
          fontSize: "11.5px",
          color: "var(--muted)",
          lineHeight: "1.6",
          background: "var(--accent-bg)",
          borderRadius: "var(--r6)",
          padding: "10px 12px",
          marginBottom: "16px",
          display: "flex",
          gap: "8px",
          alignItems: "flex-start"
        },
        children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { style: { fontSize: "14px", flexShrink: 0 }, children: "\u2139\uFE0F" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Admitting a seller here marks them Verified and sends a claim link to their WhatsApp. It opens the sign-in page so they can take over the stall." })
        ]
      }
    ),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      "button",
      {
        style: {
          width: "100%",
          padding: "14px",
          borderRadius: "100px",
          background: "var(--grad)",
          color: "#fff",
          fontFamily: "var(--fb)",
          fontSize: "15px",
          fontWeight: 800,
          border: "none",
          cursor: "pointer"
        },
        onClick: () => llSubmitAdmitSeller(),
        disabled: asSubmitting,
        children: asSubmitting ? "Admitting\u2026" : "Admit & verify seller \u2192"
      }
    )
  ] }) });
}
