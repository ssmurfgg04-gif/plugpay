/* useSellerRiders — "sellerRiders" group of the PlugPay store, extracted from PlugPayProvider.
   Statements are the original ones, in their original relative order. Names owned by other groups arrive through the shared
   per-render context object (ctx): groups that run earlier are destructured below, groups that run later are read lazily as ctx.name. */
import * as import_react from "react";
import { emptyRiderRow } from "../../../data/sales.js";

export function useSellerRiders(ctx) {
    const { showToast } = ctx;
    const [riders, setRiders] = (0, import_react.useState)([]);
    const riderIdRef = (0, import_react.useRef)(1);
    const [riderRows, setRiderRows] = (0, import_react.useState)([emptyRiderRow(0)]);
    const updateRiderRow = (0, import_react.useCallback)((id, patch) => {
      setRiderRows((rows) => rows.map((r) => r.id === id ? { ...r, ...patch } : r));
    }, []);
    const saveTrustedRiders = (0, import_react.useCallback)(() => {
      const valid = riderRows.filter((r) => r.name.trim());
      if (valid.length === 0) {
        showToast("Add at least one name first");
        return;
      }
      setRiders((r) => [...valid.map((v) => ({ name: v.name, role: v.role })), ...r]);
      setRiderRows([emptyRiderRow(riderIdRef.current++)]);
      showToast(`${valid.length > 1 ? `${valid.length} trusted people` : valid[0].name} added to your profile \u2713`);
    }, [riderRows, showToast]);
    return {
      setRiders,
      riders,
      riderRows,
      updateRiderRow,
      saveTrustedRiders
    };
}
