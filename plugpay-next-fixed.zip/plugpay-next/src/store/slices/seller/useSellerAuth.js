/* useSellerAuth — "sellerAuth" group of the PlugPay store, extracted from PlugPayProvider.
   Statements are the original ones, in their original relative order. Names owned by other groups arrive through the shared
   per-render context object (ctx): groups that run earlier are destructured below, groups that run later are read lazily as ctx.name. */
import * as import_react from "react";

export function useSellerAuth(ctx) {
    const { openModal, showToast } = ctx;
    const [merchantLoggedIn, setMerchantLoggedIn] = (0, import_react.useState)(false);
    const [authMethod, setAuthMethodState] = (0, import_react.useState)("whatsapp");
    const [authStep, setAuthStep] = (0, import_react.useState)("phone");
    const [authPhone, setAuthPhone] = (0, import_react.useState)("");
    const [authOtp, setAuthOtp] = (0, import_react.useState)("");
    const [authPinLoginValue, setAuthPinLoginValue] = (0, import_react.useState)("");
    const [authSetPinValue, setAuthSetPinValue] = (0, import_react.useState)("");
    const [authHasPin, setAuthHasPin] = (0, import_react.useState)(false);
    const finishLoginRef = (0, import_react.useRef)(null);
    const authSetMethod = (0, import_react.useCallback)((m) => {
      setAuthMethodState(m);
      setAuthPhone("");
    }, []);
    const openAuthModal = (0, import_react.useCallback)(() => {
      ctx.claimTokenRef.current = null;
      ctx.setClaimInfo(null);
      setAuthStep("phone");
      setAuthPhone("");
      setAuthOtp("");
      setAuthPinLoginValue("");
      setAuthSetPinValue("");
      authSetMethod("whatsapp");
      openModal("modal-register");
    }, [authSetMethod, openModal]);
    const requireSellerLogin = (0, import_react.useCallback)(
      (actionLabel) => {
        if (!merchantLoggedIn) {
          showToast("Sign in to your seller account to " + actionLabel);
          openAuthModal();
          return false;
        }
        return true;
      },
      [merchantLoggedIn, openAuthModal, showToast]
    );
    const authSendOTP = (0, import_react.useCallback)(() => {
      const val = authPhone.trim() || "07XX XXX XXX";
      showToast(`OTP sent to ${val} via ${authMethod === "sms" ? "SMS" : "WhatsApp"} \u2713`);
      setAuthStep("otp");
    }, [authMethod, authPhone, showToast]);
    const authVerifyOTP = (0, import_react.useCallback)(() => {
      if (!authHasPin) {
        showToast("Verified \u2713");
        setAuthStep("setpin");
      } else {
        showToast("Verified \u2713 Loading your stall profile\u2026");
        finishLoginRef.current && finishLoginRef.current();
      }
    }, [authHasPin, showToast]);
    const authSetPin = (0, import_react.useCallback)(() => {
      if (!/^\d{6}$/.test(authSetPinValue.trim())) {
        showToast("Enter a 6-digit PIN");
        return;
      }
      setAuthHasPin(true);
      showToast("PIN set \u2713 Use it next time to unlock your profile instantly.");
      finishLoginRef.current && finishLoginRef.current();
    }, [authSetPinValue, showToast]);
    const authShowPinLogin = (0, import_react.useCallback)(() => setAuthStep("pinlogin"), []);
    const authGoBackFromPin = (0, import_react.useCallback)(() => setAuthStep("phone"), []);
    const authPinLogin = (0, import_react.useCallback)(() => {
      if (!/^\d{6}$/.test(authPinLoginValue.trim())) {
        showToast("Enter your 6-digit PIN");
        return;
      }
      setAuthHasPin(true);
      showToast("Unlocked \u2713 Loading your stall profile\u2026");
      finishLoginRef.current && finishLoginRef.current();
    }, [authPinLoginValue, showToast]);
    const authGoBack = (0, import_react.useCallback)(() => setAuthStep("phone"), []);
    return {
      finishLoginRef,
      setMerchantLoggedIn,
      setAuthStep,
      setAuthOtp,
      setAuthPinLoginValue,
      setAuthSetPinValue,
      setAuthMethodState,
      setAuthPhone,
      merchantLoggedIn,
      requireSellerLogin,
      openAuthModal,
      authMethod,
      authSetMethod,
      authStep,
      authPhone,
      authOtp,
      authPinLoginValue,
      authSetPinValue,
      authSendOTP,
      authVerifyOTP,
      authSetPin,
      authShowPinLogin,
      authGoBackFromPin,
      authPinLogin,
      authGoBack
    };
}
