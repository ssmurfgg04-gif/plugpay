import * as import_react6 from "react";
import * as import_jsx_runtime from "../../../ppJsxRuntime.js";
import { usePlugPay } from "../../../store/context.js";
import { useSV } from "../useSV.js";

var FILTERS = ["All", "Phones", "Laptops", "Accessories"];

export function CatalogueTab() {
  const { showToast, openAuthModal, merchantLoggedIn } = usePlugPay();
  const catalogueItems = useSV().catalogue;
  const PRODUCTS = catalogueItems.map((i) => ({ icon: i.icon, image: i.image, name: i.name, price: "KSh " + Number(i.price).toLocaleString(), stock: i.stock > 0 ? i.stock + " in stock" : "Out of stock", cat: i.category }));
  const FILTERS = ["All", ...Array.from(new Set(PRODUCTS.map((p) => p.cat)))];
  const [filter, setFilter] = (0, import_react6.useState)("All");
  const items = filter === "All" ? PRODUCTS : PRODUCTS.filter((p) => p.cat === filter);
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "modal-tab-body on", style: { padding: "12px" }, children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "cat-filters", children: FILTERS.map((f) => {
      const count = f === "All" ? PRODUCTS.length : PRODUCTS.filter((p) => p.cat === f).length;
      return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", { className: `cat-filter${filter === f ? " on" : ""}`, onClick: () => setFilter(f), children: [
        f,
        " (",
        count,
        ")"
      ] }, f);
    }) }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "cat-grid", children: items.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "cat-item", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "cat-img", children: p.image ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", { src: p.image, alt: p.name, style: { width: "100%", height: "100%", objectFit: "cover" } }) : p.icon }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "cat-body", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "cat-name", children: p.name }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "cat-price", children: p.price }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "cat-stock", children: p.stock }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { className: "cat-buy", onClick: () => showToast(`Opening WhatsApp checkout for ${p.name} \u2713`), children: "Checkout via WhatsApp" })
      ] })
    ] }, p.name)) })
  ] });
}
