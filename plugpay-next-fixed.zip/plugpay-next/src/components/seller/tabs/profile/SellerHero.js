import { usePlugPay } from "../../../../store/context.js";
import { PR, h } from "../../../common/h.js";

export function SellerHero(props) {
  var pp = usePlugPay();
  var sp = pp.sellerProfile;
  var _e = PR.useState(false), editing = _e[0], setEditing = _e[1];
  var _f = PR.useState(sp), form = _f[0], setForm = _f[1];
  function set(k, v) { var n = {}; n[k] = v; setForm(Object.assign({}, form, n)); }
  function save() {
    if (!form.bizName.trim()) { pp.showToast("Business name is required"); return; }
    pp.updateSellerProfile({ bizName: form.bizName.trim(), ownerName: form.ownerName.trim(), role: form.role.trim(), bio: form.bio.trim(), street: form.street.trim() });
    setEditing(false);
  }
  return h(PR.Fragment, null,
    h("div", { className: "tp-hero", style: { marginTop: 0 } },
      props.editable && h("button", { className: "sp-hero-edit", onClick: function () { setForm(sp); setEditing(!editing); } }, editing ? "\u2715 Close" : "\u270F\uFE0F Edit header"),
      h("div", { className: "tp-hero-avatar-wrap" }, h("div", { className: "tp-hero-avatar" }, (sp.bizName || "W").charAt(0).toUpperCase()), h("div", { className: "tp-hero-av-check" }, "\u2713")),
      h("div", { className: "tp-hero-name" }, sp.bizName),
      h("div", { className: "tp-hero-role" }, sp.ownerName + " \u00b7 " + sp.role),
      h("div", { className: "tp-hero-badge" }, h("span", { className: "tp-v-icon" }, "\u2713"), " Verified Seller Profile"),
      h("div", { className: "tp-hero-bio" }, sp.bio),
      h("div", { className: "tp-hero-loc" }, h("span", null, "\uD83D\uDCCD " + sp.street), h("span", null, pp.stallAssignment.building + ", " + pp.stallAssignment.loc)),
      h("div", { className: "tp-landlord-tag" }, h("span", { className: "tp-landlord-tick" + (pp.landlordVerifyPending ? " pending" : "") }, pp.landlordVerifyPending ? "\u23F3" : "\u2713"), " ", h("span", null, pp.landlordVerifyPending ? "Pending" : "Verified")),
      h("div", { className: "tp-hero-stats" },
        h("div", { className: "tp-hero-stat" }, h("div", { className: "tp-hero-stat-n" }, pp.sellerStats.sales), h("div", { className: "tp-hero-stat-l" }, "Sales")),
        h("div", { className: "tp-hero-stat" }, h("div", { className: "tp-hero-stat-n" }, "235"), h("div", { className: "tp-hero-stat-l" }, "Followers")),
        h("div", { className: "tp-hero-stat" }, h("div", { className: "tp-hero-stat-n" }, pp.sellerStats.reviewCount), h("div", { className: "tp-hero-stat-l" }, "Reviews")),
        h("div", { className: "tp-hero-stat" }, h("div", { className: "tp-hero-stat-n" }, pp.sellerStats.trust), h("div", { className: "tp-hero-stat-l" }, "Trust"))
      )
    ),
    editing && h("div", { className: "tp-card", style: { padding: 13 } },
      h("div", { className: "tp-section-title" }, "Edit header"),
      [["bizName", "Business name"], ["ownerName", "Owner name"], ["role", "Business type / role"], ["street", "Street location"]].map(function (f) {
        return h("label", { key: f[0], className: "plc-field", style: { display: "block", marginBottom: 10 } }, h("span", { className: "plc-label" }, f[1]), h("input", { className: "plc-input", list: f[0] === "role" ? "sp-roles" : undefined, value: form[f[0]], onChange: function (e) { set(f[0], e.target.value); } }));
      }),
      h("datalist", { id: "sp-roles" }, ["Electronics Retailer", "Fashion & Clothing", "Food & Groceries", "Hardware & Building", "Beauty & Cosmetics", "Furniture", "Services & Repairs", "Wholesaler"].map(function (o) { return h("option", { key: o, value: o }); })),
      h("label", { className: "plc-field", style: { display: "block", marginBottom: 10 } }, h("span", { className: "plc-label" }, "Short bio"), h("textarea", { className: "plc-input", style: { minHeight: 70 }, value: form.bio, onChange: function (e) { set("bio", e.target.value); } })),
      h("div", { className: "sp-lock-note" }, "\uD83D\uDD12 Verified badge, landlord verification, stall location and stats are set by PlugPay and your landlord \u2014 they can't be edited."),
      h("div", { className: "sp-edit-actions" }, h("button", { className: "sp-edit-btn on", onClick: save }, "Save changes"), h("button", { className: "sp-edit-btn", onClick: function () { setEditing(false); } }, "Cancel"))
    )
  );
}
