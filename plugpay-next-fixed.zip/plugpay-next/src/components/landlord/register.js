import { h } from "../common/h.js";
import { PP_registry } from "../common/registry.js";
import { PP_ROUTES } from "../common/routing.js";
import { LandlordModal } from "./auth/LandlordModal.js";
import { AdmitSellerModal } from "./modals/AdmitSellerModal.js";
import { LandlordBuildingsPage } from "./tabs/buildings/LandlordBuildingsPage.js";
import { LandlordBuildingView } from "./tabs/dashboard/LandlordBuildingView.js";
import { LandlordDashboardPage } from "./tabs/dashboard/LandlordDashboardPage.js";
import { LandlordVacatedList, LandlordVerificationList, LandlordVerifiedList } from "./tabs/dashboard/LandlordSellerLists.js";
import { LandlordVacantStalls } from "./tabs/dashboard/LandlordVacantStalls.js";
import { LbSwitcher } from "./tabs/dashboard/LbSwitcher.js";
import { LandlordSellersPage } from "./tabs/sellers/LandlordSellersPage.js";
import { LandlordStallsPage } from "./tabs/stalls/LandlordStallsPage.js";

/* ---- Wiring: registers this group's modals, slots, pages and routes ---- */
PP_ROUTES.push(
  ["/landlord/dashboard", "landlord-dashboard"],
  ["/landlord/buildings", "landlord-buildings"],
  ["/landlord/sellers", "landlord-sellers"],
  ["/landlord/stalls", "landlord-stalls"],
  ["/landlord/documents", "landlord-sellers"]
);

PP_registry.register("modals", "landlord", LandlordModal, 90);

PP_registry.register("modals", "admit-seller", AdmitSellerModal, 110);

PP_registry.register("landlord.dashboard", "switcher", LbSwitcher, 10);

PP_registry.register("landlord.dashboard", "building", LandlordBuildingView, 20);

PP_registry.register("landlord.dashboard", "verification", LandlordVerificationList, 30);

PP_registry.register("landlord.dashboard", "verified", LandlordVerifiedList, 40);

PP_registry.register("landlord.dashboard", "vacated", LandlordVacatedList, 50);

PP_registry.register("landlord.dashboard", "vacant", LandlordVacantStalls, 60);

PP_registry.registerPage("landlord-dashboard", function () { return h(LandlordDashboardPage, null); });

PP_registry.registerPage("landlord-buildings", function () { return h(LandlordBuildingsPage, null); });

PP_registry.registerPage("landlord-sellers", function () { return h(LandlordSellersPage, null); });

PP_registry.registerPage("landlord-stalls", function () { return h(LandlordStallsPage, null); });
