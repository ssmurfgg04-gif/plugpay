import { navigate } from "../../lib/router.js";
import { PR, h } from "./h.js";

/* ---- Router and navigation ---- */
export var PP_ROUTES = [["/", "home"]];

export function goBack() { if (window.history.length > 1) window.history.back(); else navigate("/"); }

export function useHashRoute() {
  var _s = PR.useState(function () {
    var r = window.location.pathname;
    return r || "/";
  });
  var route = _s[0], setRoute = _s[1];
  PR.useEffect(function () {
    function onHash() {
      var r = window.location.pathname;
      setRoute(r || "/");
    }
    window.addEventListener("popstate", onHash); window.addEventListener("pp:nav", onHash);
    return function () { window.removeEventListener("popstate", onHash); window.removeEventListener("pp:nav", onHash); };
  }, []);
  return route;
}

export function Link(props) {
  var rest = {};
  for (var k in props) { if (k !== "to" && k !== "children") rest[k] = props[k]; }
  rest.href = props.to;
  return h("a", rest, props.children);
}

export var PP_CONFIG = { nav: {
  landlord: [["dashboard", "Dashboard", "/landlord/dashboard"], ["buildings", "Buildings", "/landlord/buildings"], ["sellers", "Sellers", "/landlord/sellers"], ["stalls", "Stalls", "/landlord/stalls"]],
  agent: [["buildings", "Buildings", "/agent/buildings"], ["claims", "Claims", "/agent/claims"]]
} };

export function parseRoute(route) {
  if (route === "") route = "/";
  for (var i = 0; i < PP_ROUTES.length; i++) {
    var r = PP_ROUTES[i], m = typeof r[0] === "string" ? (route === r[0] ? [] : null) : route.match(r[0]);
    if (m) { var out = { page: r[1] }; if (r[2]) out[r[2]] = decodeURIComponent(m[1]); return out; }
  }
  return { page: "home" };
}
