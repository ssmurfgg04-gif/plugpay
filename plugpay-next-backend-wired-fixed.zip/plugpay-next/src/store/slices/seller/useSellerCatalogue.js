/* useSellerCatalogue — "sellerCatalogue" group of the PlugPay store, extracted from PlugPayProvider.
   Statements are the original ones, in their original relative order. Names owned by other groups arrive through the shared
   per-render context object (ctx): groups that run earlier are destructured below, groups that run later are read lazily as ctx.name. */
import * as import_react from "react";
import { PRODUCTS } from "../../../data/products.js";
import { usePersisted } from "../../usePersisted.js";
import { apiFetch } from "../../../lib/backend.js";

export function useSellerCatalogue(ctx) {
    const { invoicesList, invoicesListRef, showToast, stockRef } = ctx;
    const catIdRef = (0, import_react.useRef)(1);
    const [catalogueItems, setCatalogueItems] = usePersisted("catalogue",
      () => PRODUCTS.map((p) => ({ id: "ci" + catIdRef.current++, icon: p.icon, image: "", name: p.name, price: p.price.replace(/[^0-9]/g, ""), category: p.cat, stock: parseInt(p.stock, 10) || 0 }))
    );
    stockRef.current = catalogueItems;
    invoicesListRef.current = invoicesList;
    (0, import_react.useEffect)(() => {
      apiFetch('/api/seller/catalogue').then((r) => {
        if (!r.items || !r.items.length) return;
        setCatalogueItems(r.items.map((p) => ({ id:p.id, icon:'\u{1F4E6}', image:p.image_url||'', name:p.name, price:String(Math.round(Number(p.price_minor||0)/100)), category:p.category||'General', stock:Number(p.stock||0) })));
      }).catch(() => {});
    }, []);
    const addCatalogueItem = (0, import_react.useCallback)((item) => {
      if (!String(item.name || "").trim() || !item.price) {
        showToast("Enter a product name and price");
        return false;
      }
      const local={ id: "ci" + Date.now().toString(36) + (catIdRef.current++), icon: "\u{1F4E6}", image: item.image || "", name: item.name.trim(), price: String(item.price), category: (item.category || "").trim() || "General", stock: Number(item.stock) || 0 }; setCatalogueItems((c) => [local, ...c]); apiFetch('/api/seller/catalogue',{method:'POST',body:JSON.stringify(item)}).then((r)=>{if(r.item)setCatalogueItems((c)=>c.map(x=>x.id===local.id?{...x,id:r.item.id}:x));}).catch((e)=>showToast(e.message));
      showToast(`${item.name} added to your catalogue \u2713`);
      return true;
    }, [showToast]);
    const updateCatalogueItem = (0, import_react.useCallback)((id, patch) => {
      setCatalogueItems((c) => c.map((x) => x.id === id ? { ...x, ...patch } : x)); apiFetch('/api/seller/catalogue/'+encodeURIComponent(id),{method:'PATCH',body:JSON.stringify(patch)}).catch((e)=>showToast(e.message));
    }, [showToast]);
    const removeCatalogueItem = (0, import_react.useCallback)((id) => {
      setCatalogueItems((c) => c.filter((x) => x.id !== id));
      apiFetch('/api/seller/catalogue/'+encodeURIComponent(id),{method:'DELETE'}).catch((e)=>showToast(e.message));
      showToast("Product removed");
    }, [showToast]);
    return {
      setCatalogueItems,
      catalogueItems,
      updateCatalogueItem,
      addCatalogueItem,
      removeCatalogueItem
    };
}
