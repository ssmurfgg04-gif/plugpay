import * as import_jsx_runtime from "../../../ppJsxRuntime.js";
import { usePlugPay } from "../../../store/context.js";
import { Modal } from "../../common/Modal.js";
import { AuthOtpStep } from "./AuthOtpStep.js";
import { AuthPhoneStep } from "./AuthPhoneStep.js";
import { AuthPinLoginStep } from "./AuthPinLoginStep.js";
import { AuthSetPinStep } from "./AuthSetPinStep.js";

export function RegisterModal() {
  const { authStep, focusMerchantProfileTab } = usePlugPay();
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, { id: "modal-register", onExit: focusMerchantProfileTab, children: [
    authStep === "phone" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthPhoneStep, {}),
    authStep === "pinlogin" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthPinLoginStep, {}),
    authStep === "otp" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthOtpStep, {}),
    authStep === "setpin" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthSetPinStep, {})
  ] });
}
