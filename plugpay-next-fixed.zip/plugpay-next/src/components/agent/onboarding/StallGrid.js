import * as import_jsx_runtime from "../../../ppJsxRuntime.js";

export function StallGrid({
  stalls,
  renderCell,
  onStallClick,
  cellMinWidth = 52,
  maxHeight = 320,
  emptyMessage = "No stalls on this floor yet."
}) {
  if (stalls.length === 0) {
    return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "stall-grid-empty", children: emptyMessage });
  }
  const scrollable = stalls.length > 24;
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
    "div",
    {
      className: `stall-grid-scroll${scrollable ? " scroll" : ""}`,
      style: scrollable ? { maxHeight } : void 0,
      children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "stall-grid", style: { ["--stall-min"]: `${cellMinWidth}px` }, children: stalls.map((s) => {
        var _a;
        const cell = renderCell(s);
        const active = (_a = cell.clickable) != null ? _a : Boolean(onStallClick);
        return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
          "div",
          {
            className: `sg-cell${cell.className ? ` ${cell.className}` : ""}${active ? "" : " sg-static"}`,
            style: cell.style,
            title: cell.title,
            onClick: active ? () => onStallClick == null ? void 0 : onStallClick(s) : void 0,
            children: cell.label
          },
          s.id
        );
      }) })
    }
  );
}
