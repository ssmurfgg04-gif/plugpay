import * as import_jsx_runtime from "../../ppJsxRuntime.js";
import { usePlugPay } from "../../store/context.js";
import { useSV } from "./useSV.js";

export function PublicSellerProfileHeader(props) {
  const { toggleFollowMerchant, following, showToast, copyText } = usePlugPay();
  const sv = useSV();
  const sellerProfile = sv.profile, sellerStats = sv.stats, landlordVerifyPending = sv.pending;
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-hero public-seller-profile-header", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-hero-avatar-wrap", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-hero-avatar", children: (sellerProfile.bizName || "W").charAt(0).toUpperCase() }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-hero-av-check", children: "\u2713" })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-hero-name", children: sellerProfile.bizName }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-hero-role", children: sellerProfile.ownerName + " \xB7 " + sellerProfile.role }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-hero-badge", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "tp-v-icon", children: "\u2713" }),
          " Verified Seller Profile"
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-hero-bio", children: sellerProfile.bio }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-hero-loc", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "\u{1F4CD} " + sellerProfile.street }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: sv.assignment.building + ", " + sv.assignment.loc })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-landlord-tag", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `tp-landlord-tick${landlordVerifyPending ? " pending" : ""}`, children: landlordVerifyPending ? "\u23F3" : "\u2713" }),
          " ",
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: landlordVerifyPending ? undefined : "tp-verified-badge", children: landlordVerifyPending ? "Pending" : "Landlord verified" })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-hero-actions", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", { className: "tp-hero-btn tp-hero-btn-solid", onClick: () => toggleFollowMerchant(), children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: following ? "\u2713" : "\uFF0B" }),
            " ",
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: following ? "Following" : "Follow" })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
            "button",
            {
              className: "tp-hero-btn tp-hero-btn-outline",
              onClick: () => showToast("Opening WhatsApp chat with " + sellerProfile.bizName + "\u2026"),
              children: "Message"
            }
          ),
          (0, import_jsx_runtime.jsx)("button", { className: "tp-hero-btn tp-hero-btn-outline tp-hero-share", "aria-label": "Share profile", onClick: () => { if (navigator.share) { navigator.share({ title: sellerProfile.bizName, url: "https://plug.pay/m/wanjiku-electronics" }).catch(() => {}); } else copyText("plug.pay/m/wanjiku-electronics", "Profile link copied \u2713"); }, children: (0, import_jsx_runtime.jsxs)("svg", { viewBox: "0 0 24 24", width: 16, height: 16, fill: "none", stroke: "currentColor", strokeWidth: 2, strokeLinecap: "round", strokeLinejoin: "round", children: [
            (0, import_jsx_runtime.jsx)("circle", { cx: 18, cy: 5, r: 3 }),
            (0, import_jsx_runtime.jsx)("circle", { cx: 6, cy: 12, r: 3 }),
            (0, import_jsx_runtime.jsx)("circle", { cx: 18, cy: 19, r: 3 }),
            (0, import_jsx_runtime.jsx)("line", { x1: 8.59, y1: 13.51, x2: 15.42, y2: 17.49 }),
            (0, import_jsx_runtime.jsx)("line", { x1: 15.41, y1: 6.51, x2: 8.59, y2: 10.49 })
          ] }) })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-hero-stats", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-hero-stat", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-hero-stat-n", children: String(sellerStats.sales) }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-hero-stat-l", children: "Sales" })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-hero-stat", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-hero-stat-n", children: String(sellerStats.followers || 235) }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-hero-stat-l", children: "Followers" })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-hero-stat", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-hero-stat-n", children: String(sellerStats.reviewCount) }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-hero-stat-l", children: "Reviews" })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "tp-hero-stat", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-hero-stat-n", children: String(sellerStats.trust) }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tp-hero-stat-l", children: "Trust" })
          ] })
        ] })
      ] });
}
